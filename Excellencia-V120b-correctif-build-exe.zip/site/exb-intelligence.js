/* EXCELLENCIA INTELLIGENCE — moteur central (lot 1). Architecture hybride, 100 % locale pour l'essentiel :
 *  1. Automatisation locale : surveille les données (lecture seule), publie des événements, relance les contrôles à chaque modification.
 *  2. Moteur de règles : détecte erreurs, incohérences et doublons entre modules (clients, projets, devis, factures, caisse, stock, personnel, participants).
 *  3. Moteurs spécialisés : registre EXBI.engines (liaison EXBLIEN branchée ; calcul facture ; les autres lots s'y enregistrent).
 *  4. Intelligence artificielle : l'assistant existant reçoit le contexte (EXBI.contextText) ; sans Internet, réponses locales du moteur.
 *  5. Synchronisation : les changements reçus de la base partagée sont vus comme n'importe quelle modification (journal + contrôles).
 * Historique des modifications (qui / quand / avant → après), confirmation avant toute opération critique, rapport de contrôle.
 * AUCUNE donnée existante n'est modifiée par ce fichier ; les seules écritures sont ses propres clés (exb_intel_*) et, après confirmation, l'appel d'une fonction existante.
 * Pour retirer : supprimer la balise <script src="exb-intelligence.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXBI) return;
  var VERSION = 'INTEL-1', K_HIST = 'exb_intel_history', K_IGN = 'exb_intel_ignored';
  var COLS = [
    { k: 'exb_clients', l: 'Clients', show: 'clients' }, { k: 'exb_projects', l: 'Projets', show: 'projets' },
    { k: 'exb_quotes', l: 'Devis', show: 'metreDevis' }, { k: 'exb_invoices', l: 'Factures', show: 'chantiers' },
    { k: 'exb_cash', l: 'Caisse', show: 'finances' }, { k: 'exb_stock', l: 'Stock', show: 'stock' },
    { k: 'exb_stock_moves', l: 'Mouvements de stock', show: 'stock' }, { k: 'exb_hr', l: 'Personnel', show: 'rh' },
    { k: 'exb_studies', l: 'Études', show: 'bureauEtudes' }, { k: 'exb_participants', l: 'Participants', show: 'participants' }
  ];
  var $ = function (i) { return d.getElementById(i); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function jget(k, df) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? df : v; } catch (e) { return df; } }
  function jset(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function norm(s) { s = String(s == null ? '' : s); try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {} return s.toLowerCase().replace(/\s+/g, ' ').trim(); }
  function digits(s) { return String(s == null ? '' : s).replace(/\D/g, ''); }
  function num(x) { x = +x; return isFinite(x) ? x : 0; }
  function hash(s) { var h = 5381, i; for (i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return h; }
  function today() { return new Date().toISOString().slice(0, 10); }
  /* V121i : une fiche null / non-objet est ignorée (elle faisait planter le moteur) ; pendant un passage de contrôle (run), chaque collection n'est lue et analysée qu'une seule fois (memo). */
  var memo = null;
  function clean(a) { for (var i = 0; i < a.length; i++) if (!a[i] || typeof a[i] !== 'object') return a.filter(function (o) { return o && typeof o === 'object'; }); return a; }
  function list0(k) {
    try { if (w.EXBLIEN && w.EXBLIEN.rd) { var a = w.EXBLIEN.rd(k); if (Array.isArray(a)) return clean(a); } } catch (e) {}
    try { var v = JSON.parse(((typeof exbStorage !== 'undefined' ? exbStorage : null) || w.exbStorage || w.localStorage).getItem(k) || '[]'); return Array.isArray(v) ? clean(v) : []; } catch (e) { return []; }
  }
  function list(k) { if (memo) { if (!Object.prototype.hasOwnProperty.call(memo, k)) memo[k] = list0(k); return memo[k]; } return list0(k); }
  function lab(o) { return String(o.full_name || o.name || o.nom || o.no || o.receipt_no || o.cert_no || o.employee || o.title || o.item || o.client || o.id || '?').slice(0, 60); }
  function who() { try { return (w.EXBDB && w.EXBDB.info && w.EXBDB.info().label) || 'Utilisateur local'; } catch (e) { return 'Utilisateur local'; } }
  function colOf(k) { return COLS.filter(function (c) { return c.k === k; })[0] || { k: k, l: k, show: '' }; }

  /* ---------- bus d'événements ---------- */
  var subs = {};
  var bus = {
    on: function (t, f) { (subs[t] = subs[t] || []).push(f); },
    emit: function (t, p) { (subs[t] || []).forEach(function (f) { try { f(p); } catch (e) {} }); }
  };

  /* ---------- moteurs spécialisés ---------- */
  var engines = {};
  function registerEngine(id, label, fn) { engines[id] = { id: id, label: label, run: fn }; }
  function invTot(i) {
    var ht = (i.lines || []).reduce(function (a, l) { return a + num(l.q) * num(l.pu); }, 0), ttc = ht * (1 + num(i.tva) / 100),
      paid = (i.payments || []).reduce(function (a, p) { return a + num(p.amount); }, 0);
    return { ht: ht, ttc: ttc, paid: paid, reste: Math.max(0, ttc - paid) };
  }
  registerEngine('calcul.facture', 'Calcul des factures (HT, TVA, TTC, reste)', function () { return []; });
  registerEngine('liaison', 'Liaison des modules (EXBLIEN)', function () {
    var out = []; if (!w.EXBLIEN || !w.EXBLIEN.anomalies) return out;
    w.EXBLIEN.anomalies().forEach(function (m) { out.push({ sev: 'alerte', mod: 'Liaison', msg: String(m) }); });
    return out;
  });

  /* ---------- moteur de règles ---------- */
  function F(sev, mod, msg, col, id, extra) { var o = { sev: sev, mod: mod, msg: msg, ref: { col: col, id: id } }; if (extra) for (var k in extra) o[k] = extra[k]; return o; }
  function dup(arr, keyFn, col, mod, what, sev) {
    var seen = {}, out = [];
    arr.forEach(function (o) { var k = keyFn(o); if (!k) return; if (seen[k]) out.push(F(sev || 'alerte', mod, 'Doublon possible (' + what + ') : « ' + lab(seen[k]) + ' » et « ' + lab(o) + ' »', col, o.id, { other: seen[k].id })); else seen[k] = o; });
    return out;
  }
  var RULES = [
    { id: 'dup.projets', check: function () { return dup(list('exb_projects'), function (p) { return p.name ? norm(p.name) + '|' + norm(p.client) : ''; }, 'exb_projects', 'Projets', 'même nom et même client'); } },
    { id: 'dup.factures', check: function () { return dup(list('exb_invoices'), function (i) { return i.no ? norm(i.no) : ''; }, 'exb_invoices', 'Factures', 'même numéro', 'erreur'); } },
    { id: 'dup.participants', check: function () { return dup(list('exb_participants'), function (p) { var ph = digits(p.phone); return ph.length >= 8 ? ph : (p.full_name || p.name) && p.birth_date ? norm(p.full_name || p.name) + '|' + p.birth_date : ''; }, 'exb_participants', 'Participants', 'même téléphone ou même nom et naissance'); } },
    { id: 'dup.stock', check: function () { return dup(list('exb_stock'), function (s) { return s.name ? norm(s.name) : ''; }, 'exb_stock', 'Stock', 'même désignation'); } },
    { id: 'dup.devis', check: function () { return dup(list('exb_quotes'), function (q) { return q.no || q.number ? norm(q.no || q.number) : ''; }, 'exb_quotes', 'Devis', 'même numéro', 'erreur'); } },
    { id: 'fact.coherence', check: function () {
      var out = []; list('exb_invoices').forEach(function (i) {
        var n = i.no || i.id;
        if (!i.lines || !i.lines.length) out.push(F('alerte', 'Factures', 'Facture ' + n + ' : aucune ligne', 'exb_invoices', i.id));
        if ((i.lines || []).some(function (l) { return num(l.q) < 0 || num(l.pu) < 0; })) out.push(F('erreur', 'Factures', 'Facture ' + n + ' : quantité ou prix négatif', 'exb_invoices', i.id));
        if (i.date && i.due && i.due < i.date) out.push(F('erreur', 'Factures', 'Facture ' + n + ' : échéance (' + i.due + ') antérieure à la date (' + i.date + ')', 'exb_invoices', i.id));
        if (num(i.tva) < 0 || num(i.tva) > 30) out.push(F('alerte', 'Factures', 'Facture ' + n + ' : TVA inhabituelle (' + i.tva + ' %)', 'exb_invoices', i.id));
        if (!i.client && !i.client_id && !i.project_id) out.push(F('alerte', 'Factures', 'Facture ' + n + ' : ni client ni chantier', 'exb_invoices', i.id));
      }); return out; } },
    { id: 'projet.coherence', check: function () {
      var out = [], inv = list('exb_invoices'), byPrj = null; list('exb_projects').forEach(function (p) {
        if (p.start && p.end && p.end < p.start) out.push(F('erreur', 'Projets', 'Projet « ' + lab(p) + ' » : fin avant le début', 'exb_projects', p.id));
        if (!p.client && !p.client_id) out.push(F('info', 'Projets', 'Projet « ' + lab(p) + ' » : aucun client rattaché', 'exb_projects', p.id));
        if (/termin|cl[oô]tur/i.test(p.status || '')) {
          if (!byPrj) { byPrj = {}; inv.forEach(function (i) { if (i.project_id != null) (byPrj[i.project_id] = byPrj[i.project_id] || []).push(i); }); }
          var due = (byPrj[p.id] || []).reduce(function (a, i) { return a + invTot(i).reste; }, 0);
          if (due > 0.005) out.push(F('alerte', 'Projets ↔ Factures', 'Projet « ' + lab(p) + ' » terminé mais ' + due.toFixed(2) + ' restent à encaisser', 'exb_projects', p.id));
        }
      }); return out; } },
    { id: 'devis.coherence', check: function () {
      var out = []; list('exb_quotes').forEach(function (q) {
        if (!q.client && !q.client_id) out.push(F('info', 'Devis', 'Devis ' + lab(q) + ' : aucun client', 'exb_quotes', q.id));
        if ('total' in q && num(q.total) <= 0) out.push(F('alerte', 'Devis', 'Devis ' + lab(q) + ' : montant nul', 'exb_quotes', q.id));
      }); return out; } },
    { id: 'caisse.coherence', check: function () {
      var out = []; list('exb_cash').forEach(function (c) {
        if ('amount' in c && num(c.amount) <= 0) out.push(F('erreur', 'Caisse', 'Écriture ' + lab(c) + ' : montant nul ou négatif', 'exb_cash', c.id));
        if (c.date && String(c.date).slice(0, 10) > today()) out.push(F('alerte', 'Caisse', 'Écriture ' + lab(c) + ' : date dans le futur', 'exb_cash', c.id));
      }); return out; } },
    { id: 'stock.coherence', check: function () {
      var out = []; list('exb_stock').forEach(function (s) {
        var q = num(s.qty != null ? s.qty : s.quantity), mn = num(s.min != null ? s.min : s.threshold);
        if (q < 0) out.push(F('erreur', 'Stock', '« ' + lab(s) + ' » : quantité négative (' + q + ')', 'exb_stock', s.id));
        else if (mn > 0 && q <= mn) out.push(F('alerte', 'Stock', '« ' + lab(s) + ' » sous le seuil (' + q + ' / ' + mn + ')', 'exb_stock', s.id));
      }); return out; } },
    { id: 'contacts', check: function () {
      var out = [], re = /^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/;
      [['exb_clients', 'Clients'], ['exb_participants', 'Participants'], ['exb_hr', 'Personnel']].forEach(function (c) {
        list(c[0]).forEach(function (o) {
          if (o.phone && digits(o.phone).length < 8) out.push(F('info', c[1], '« ' + lab(o) + ' » : numéro de téléphone incomplet', c[0], o.id));
          if (o.email && !re.test(String(o.email).trim())) out.push(F('info', c[1], '« ' + lab(o) + ' » : adresse e-mail invalide', c[0], o.id));
        });
      }); return out; } }
  ];
  var state = { findings: [], reco: [], at: 0 }, fixers = {}, filters = [], recoProviders = [], undoers = {};
  function ignored() { return jget(K_IGN, {}); }
  var stats = {};
  function timed(id, fn) {
    var t0 = Date.now(), st = stats[id] || (stats[id] = { runs: 0, errors: 0, ms: 0, max: 0, last: '' }), r = [];
    try { r = fn() || []; st.last = ''; } catch (e) { st.errors++; st.last = String(e && e.message || e).slice(0, 120); }
    var dt = Date.now() - t0; st.runs++; st.ms += dt; if (dt > st.max) st.max = dt; return r;
  }
  var running = false, gen = 0, asyncOn = false, again = false, ENGX = [];
  function jobs() {
    var j = []; RULES.forEach(function (r) { j.push({ id: 'rule:' + r.id, rule: r.id, fn: r.check }); });
    Object.keys(engines).forEach(function (id) { j.push({ id: 'engine:' + id, rule: id, fn: engines[id].run }); }); return j;
  }
  function collect(out, jb) { timed(jb.id, jb.fn).forEach(function (f) { if (f && typeof f === 'object') { f.rule = jb.rule; out.push(f); } }); }
  function finish(out) {
    var ign = ignored();
    filters.forEach(function (fl) { out = out.filter(function (f) { try { return fl(f) !== false; } catch (e) { return true; } }); });
    out.forEach(function (f) { f.key = f.rule + '|' + (f.ref ? f.ref.id : '') + '|' + f.msg; try { if (fixers[f.rule]) f.fix = fixers[f.rule](f) || null; } catch (e) {} });
    state.findings = out.filter(function (f) { return !ign[f.key]; });
    try { state.reco = recos(); } catch (e) { state.reco = []; }
  }
  /* run() : passage complet immédiat (inchangé pour les autres lots). Il annule un passage progressif en cours. */
  function run() {
    if (running) return state.findings; /* pas de passage imbriqué : une règle ou un lot qui appelle run() ne relance pas tout */
    running = true; gen++; memo = {};
    try { var out = []; jobs().forEach(function (jb) { collect(out, jb); }); finish(out); }
    finally { memo = null; running = false; asyncOn = false; }
    state.at = Date.now(); bus.emit('update', summary()); badge();
    return state.findings;
  }
  /* runAsync() : même résultat, mais rend la main à l'écran entre les contrôles (≈ 12 ms par tranche) ; les demandes en rafale sont fusionnées en un seul passage de plus. */
  var YIELD = 12;
  function runAsync() {
    if (running) return Promise.resolve(state.findings);
    if (d.hidden) return Promise.resolve(run());
    if (asyncOn) { again = true; return Promise.resolve(state.findings); }
    asyncOn = true; again = false; var my = ++gen, J = jobs(), out = [], i = 0;
    return new Promise(function (res) {
      function stop() { memo = null; asyncOn = false; res(state.findings); }
      function step() {
        if (my !== gen) { res(state.findings); return; } /* un run() synchrone a pris le relais */
        memo = memo || {}; var t0 = Date.now();
        try { while (i < J.length && Date.now() - t0 < YIELD) collect(out, J[i++]); } catch (e) { i = J.length; }
        if (i < J.length) { memo = null; setTimeout(step, 0); return; }
        try { running = true; finish(out); } catch (e) {} running = false; memo = null; asyncOn = false;
        state.at = Date.now(); bus.emit('update', summary()); badge(); res(state.findings);
        if (again) { again = false; setTimeout(runAsync, 50); }
      }
      setTimeout(step, 0);
    });
  }
  function summary() {
    var s = { erreur: 0, alerte: 0, info: 0, total: 0, reco: state.reco.length };
    state.findings.forEach(function (f) { s[f.sev] = (s[f.sev] || 0) + 1; s.total++; });
    return s;
  }

  /* ---------- recommandations ---------- */
  function go(key) { closePanel(); try { w.show(key); } catch (e) {} }
  function copy(t) { try { if (w.navigator.clipboard && w.navigator.clipboard.writeText) { w.navigator.clipboard.writeText(t); return true; } } catch (e) {} return false; }
  function prepareInvoice(q, prj) {
    var pid = q.project_id || '';
    if (!pid && q.project) { var m = prj.filter(function (p) { return norm(p.name) === norm(q.project); }); if (m.length === 1) pid = m[0].id; }
    if (!pid) { toast('Rattachez d’abord ce devis à un chantier (champ Projet).'); return; }
    closePanel(); try { w.show('chantiers'); } catch (e) {}
    setTimeout(function () { try { if (w.EXBCH && w.EXBCH.pid && w.EXBCH.fromQuote) { w.EXBCH.pid(pid); w.EXBCH.fromQuote(q.id); logEvent('brouillon', 'Facture préparée depuis le devis ' + lab(q)); } } catch (e) { toast('Préparation impossible.'); } }, 500);
  }
  function recos() {
    var r = [], inv = list('exb_invoices'), t = today();
    var late = inv.filter(function (i) { return i.due && i.due < t && invTot(i).reste > 0.005; });
    if (late.length) r.push({ ic: '🧾', t: late.length + ' facture(s) en retard à relancer', x: 'Reste à encaisser : ' + late.reduce(function (a, i) { return a + invTot(i).reste; }, 0).toFixed(2) + '.',
      acts: [{ l: 'Ouvrir les factures', f: function () { go('chantiers'); } }, { l: 'Copier un message de relance', f: function () { copy('Bonjour, sauf erreur de notre part, la facture ' + (late[0].no || '') + ' est arrivée à échéance. Merci de nous indiquer la date de règlement. Cordialement.'); toast('Message copié.'); } }] });
    var lim15 = new Date(Date.now() - 15 * 864e5).toISOString().slice(0, 10), prj = list('exb_projects');
    var invQ = {}; inv.forEach(function (i) { if (i.quote_id != null) invQ[i.quote_id] = 1; });
    var noInv = list('exb_quotes').filter(function (q) { return num(q.total) > 0 && (!q.date || String(q.date).slice(0, 10) <= lim15) && !invQ[q.id]; });
    if (noInv.length) r.push({ ic: '📝', t: noInv.length + ' devis de plus de 15 jours sans facture liée', x: 'À vérifier : un devis déjà facturé sans lien peut figurer ici. « Préparer » ouvre un brouillon à relire, rien n’est enregistré.',
      acts: noInv.slice(0, 3).map(function (q) { return { l: 'Préparer : ' + lab(q), f: function () { prepareInvoice(q, prj); } }; }) });
    var low = list('exb_stock').filter(function (s) { var q = num(s.qty != null ? s.qty : s.quantity), m = num(s.min != null ? s.min : s.threshold); return m > 0 && q <= m; });
    if (low.length) r.push({ ic: '🧱', t: low.length + ' matériau(x) à réapprovisionner', x: low.slice(0, 4).map(lab).join(', '), acts: [{ l: 'Ouvrir le stock', f: function () { go('stock'); } }] });
    var nophone = list('exb_clients').filter(function (c) { return !digits(c.phone) && !c.email; });
    if (nophone.length) r.push({ ic: '👤', t: nophone.length + ' client(s) sans moyen de contact', x: 'Complétez téléphone ou e-mail pour les relances automatiques.', acts: [{ l: 'Ouvrir les clients', f: function () { go('clients'); } }] });
    var fx = state.findings.filter(function (f) { return f.rule === 'liaison'; }).length;
    if (fx && w.EXBLIEN && w.EXBLIEN.linkAll) r.push({ ic: '🔗', t: 'Liaison automatique des modules', x: 'Des enregistrements peuvent être rattachés à leur client ou chantier (aucune suppression).', acts: [{ l: 'Relancer la liaison…', f: function () { confirmBox('Relancer la liaison automatique ?', 'Les liens client ↔ chantier ↔ devis ↔ factures manquants seront ajoutés (identifiants seulement, rien n’est supprimé ni renommé). L’opération est inscrite au journal.', 'Lancer la liaison').then(function (ok) { if (!ok) return; try { var res = w.EXBLIEN.linkAll({}); logEvent('liaison', 'Liaison automatique lancée', res); toast('Liaison terminée.'); } catch (e) { toast('Liaison impossible.'); } run(); render(); }); } }] });
    recoProviders.forEach(function (pv) { try { r = r.concat(pv() || []); } catch (e) {} });
    return r;
  }

  /* ---------- historique des modifications ---------- */
  var snap = null, hist = jget(K_HIST, []);
  function saveHist() { if (jset(K_HIST, hist)) return true; hist = hist.slice(0, 300); if (jset(K_HIST, hist)) return true; hist = hist.slice(0, 80); return jset(K_HIST, hist); }
  function logEvent(op, msg, extra) { hist.unshift({ at: new Date().toISOString(), op: op, msg: msg, by: who(), undo: extra && extra.undo ? extra.undo : undefined }); hist = hist.slice(0, 1000); jset(K_HIST, hist); try { if (typeof w.audit === 'function') w.audit('INTEL_' + op.toUpperCase(), msg); } catch (e) {} bus.emit('history', hist[0]); }
  function short(v) { var s = typeof v === 'object' ? JSON.stringify(v) : String(v == null ? '' : v); return s.length > 60 ? s.slice(0, 57) + '…' : s; }
  /* V121i : lecture brute (sans analyse) pour savoir très vite si une collection a changé ; au-delà de 60 changements en un passage (import massif), l'historique garde une seule ligne groupée au lieu d'effacer les 1000 entrées. */
  function rawOf(k) { try { var st = (typeof exbStorage !== 'undefined' ? exbStorage : null) || w.exbStorage || w.localStorage; var v = st && st.getItem(k); return typeof v === 'string' ? v : null; } catch (e) { return null; } }
  var pushBudget = 0, overflow = 0, FLOOD = 60;
  function poll() {
    if (d.hidden) return;
    var first = !snap, changed = 0; snap = snap || {}; pushBudget = FLOOD; overflow = 0;
    COLS.forEach(function (c) {
      try {
        var raw = rawOf(c.k); if (raw !== null && snap[c.k] && snap[c.k].raw === raw) return;
        var arr = list0(c.k), s = JSON.stringify(arr), sig = hash(s);
        if (snap[c.k] && snap[c.k].sig === sig) { snap[c.k].raw = raw; return; }
        var map = {}; arr.forEach(function (o, n) { map[o.id != null ? o.id : '#' + n] = JSON.stringify(o); });
        var prev = snap[c.k]; snap[c.k] = { sig: sig, map: map, raw: raw };
        if (!prev) return;
        Object.keys(map).forEach(function (id) {
          if (!(id in prev.map)) { push(c, id, 'création', map[id], null); changed++; }
          else if (prev.map[id] !== map[id]) { push(c, id, 'modification', map[id], prev.map[id]); changed++; }
        });
        Object.keys(prev.map).forEach(function (id) { if (!(id in map)) { push(c, id, 'suppression', null, prev.map[id]); changed++; } });
      } catch (e) { /* une collection illisible ne bloque pas les autres */ }
    });
    if (overflow) { hist.unshift({ at: new Date().toISOString(), op: 'modification', msg: overflow + ' modifications supplémentaires regroupées (import ou synchronisation massive)', by: who() }); hist = hist.slice(0, 1000); }
    if (!first && changed) { saveHist(); bus.emit('change', changed); sched(); }
    if (first) run();
  }
  function push(c, id, op, now, before) {
    if (pushBudget <= 0) { overflow++; return; } pushBudget--;
    var o = JSON.parse(now || before), p = before && now ? JSON.parse(before) : null, fields = [];
    if (p) Object.keys(o).concat(Object.keys(p)).filter(function (k, i, a) { return a.indexOf(k) === i && k !== 'updated_at'; }).forEach(function (k) { if (JSON.stringify(o[k]) !== JSON.stringify(p[k]) && fields.length < 6) fields.push({ f: k, a: short(p[k]), b: short(o[k]) }); });
    hist.unshift({ at: new Date().toISOString(), op: op, col: c.k, l: c.l, id: id, name: lab(o), fields: fields, by: who() });
    hist = hist.slice(0, 1000); bus.emit('history', hist[0]);
  }
  var tm = null;
  function sched() { clearTimeout(tm); tm = setTimeout(function () { runAsync().then(function () { if ($('exbIntelPanel')) render(); }); }, 900); }

  /* ---------- confirmation avant opération critique ---------- */
  function confirmBox(title, msg, okLabel) {
    return new Promise(function (res) {
      var o = d.createElement('div'); o.id = 'exbIntelConfirm'; o.setAttribute('role', 'dialog'); o.setAttribute('aria-modal', 'true');
      o.style.cssText = 'position:fixed;inset:0;z-index:100030;background:#0009;display:flex;align-items:center;justify-content:center;padding:16px;font-family:Arial,Helvetica,sans-serif';
      o.innerHTML = '<div style="background:#fff;color:#12254a;max-width:420px;width:100%;border-radius:14px;padding:18px;border-top:4px solid #c8962e"><h3 style="margin:0 0 8px;font-size:17px">' + esc(title) + '</h3><p style="margin:0 0 16px;font-size:14px;line-height:1.45">' + esc(msg) + '</p><div style="display:flex;gap:8px;justify-content:flex-end"><button data-v="0" style="min-height:44px;padding:0 16px;border-radius:10px;border:1px solid #c5cedd;background:#fff;font:700 14px Arial;cursor:pointer">Annuler</button><button data-v="1" style="min-height:44px;padding:0 16px;border-radius:10px;border:0;background:#1f6feb;color:#fff;font:700 14px Arial;cursor:pointer">' + esc(okLabel || 'Confirmer') + '</button></div></div>';
      o.onclick = function (e) { var b = e.target.closest('[data-v]'); if (!b && e.target !== o) return; o.remove(); res(!!b && b.getAttribute('data-v') === '1'); };
      d.body.appendChild(o); var b = o.querySelector('[data-v="0"]'); if (b) b.focus();
    });
  }
  function toast(m) { try { w.notify(m, 'info', 3500); } catch (e) {} }

  /* ---------- passerelle IA (assistant existant) ---------- */
  function contextText() {
    var s = summary(), t = 'Contrôle des données (Excellencia Intelligence) : ' + s.erreur + ' erreur(s), ' + s.alerte + ' alerte(s), ' + s.info + ' information(s).';
    var top = state.findings.filter(function (f) { return f.sev !== 'info'; }).slice(0, 6).map(function (f) { return '- ' + f.msg; });
    return t + (top.length ? '\n' + top.join('\n') : '') + (state.reco.length ? '\nRecommandations : ' + state.reco.slice(0, 4).map(function (r) { return r.t; }).join(' ; ') : '');
  }
  function answerText() {
    var s = summary(); if (!s.total && !state.reco.length) return 'Tout est cohérent : aucune erreur, incohérence ni doublon détecté dans les données locales.';
    var t = 'Contrôle des données : ' + s.erreur + ' erreur(s), ' + s.alerte + ' alerte(s), ' + s.info + ' information(s).\n';
    t += state.findings.slice(0, 8).map(function (f) { return '• ' + f.msg; }).join('\n');
    if (state.reco.length) t += '\n\nRecommandations :\n' + state.reco.slice(0, 5).map(function (r) { return '→ ' + r.t; }).join('\n');
    return t + '\n\nOuvrez 🧠 Intelligence (en-tête) pour le détail et les actions.';
  }
  function hookAI() {
    try { if (typeof w.aiContext === 'function' && !w.aiContext.__intel) { var o = w.aiContext; w.aiContext = function () { var r = o.apply(this, arguments); try { return typeof r === 'string' ? r + '\n' + contextText() : r; } catch (e) { return r; } }; w.aiContext.__intel = 1; } } catch (e) {}
    try { if (typeof w.localAI === 'function' && !(w.__exbAIHooks = w.__exbAIHooks || {}).intel) { (w.__exbAIHooks = w.__exbAIHooks || {}).intel = 1; var l = w.localAI; w.localAI = function (raw) { try { if (/\b(anomalie|incoherence|doublon|recommandation|sante des donnees|controle des donnees|verifie les donnees|intelligence)/.test(norm(raw))) { run(); return { answer: answerText(), actions: [] }; } } catch (e) {} return l.apply(this, arguments); }; w.localAI.__intel = 1; } } catch (e) {}
  }

  /* ---------- rapport ---------- */
  function reportHtml() {
    var s = summary(), rows = state.findings.map(function (f) { return '<tr><td>' + esc(f.sev) + '</td><td>' + esc(f.mod) + '</td><td>' + esc(f.msg) + '</td></tr>'; }).join('');
    return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Rapport de contrôle</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Rapport de contrôle des données</h1><p>' + new Date().toLocaleString('fr-FR') + ' — ' + s.erreur + ' erreur(s), ' + s.alerte + ' alerte(s), ' + s.info + ' information(s)</p><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Gravité</th><th>Module</th><th>Constat</th></tr>' + (rows || '<tr><td colspan="3">Aucune anomalie.</td></tr>') + '</table><h2>Recommandations</h2><ul>' + state.reco.map(function (r) { return '<li>' + esc(r.t) + ' — ' + esc(r.x) + '</li>'; }).join('') + '</ul></body></html>';
  }
  function downloadReport() {
    try { var b = new Blob([reportHtml()], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'rapport-controle-' + today() + '.html'; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); logEvent('rapport', 'Rapport de contrôle exporté'); } catch (e) { toast('Export impossible.'); }
  }

  /* ---------- interface ---------- */
  var tab = 'ctl';
  function css() {
    if ($('exbIntelCss')) return; var s = d.createElement('style'); s.id = 'exbIntelCss';
    s.textContent = '#exbIntelPanel{position:fixed;inset:0;z-index:100020;background:#0008;display:flex;align-items:flex-end;justify-content:center;font-family:Arial,Helvetica,sans-serif}' +
      '#exbIntelPanel .ip{background:#f3f6fc;color:#12254a;width:100%;max-width:720px;height:88vh;border-radius:16px 16px 0 0;display:flex;flex-direction:column;border-top:4px solid #c8962e}' +
      '#exbIntelPanel header{display:flex;align-items:center;gap:8px;padding:12px 14px;background:#0f2e66;color:#fff;border-radius:12px 12px 0 0}#exbIntelPanel header b{flex:1;font-size:16px}' +
      '#exbIntelPanel .it{display:flex;gap:6px;padding:10px 12px;overflow-x:auto}#exbIntelPanel .it button{flex:none;min-height:40px;padding:0 14px;border-radius:999px;border:1px solid #e3e9f4;background:#fff;color:#12254a;font:700 13px Arial;cursor:pointer}#exbIntelPanel .it button.on{background:#1f6feb;color:#fff;border-color:#1f6feb}' +
      '#exbIntelPanel .ib{flex:1;overflow:auto;padding:0 12px 14px}' +
      '#exbIntelPanel .ic{background:#fff;border:1px solid #e3e9f4;border-radius:12px;padding:10px 12px;margin-bottom:8px;font-size:13px;line-height:1.4}' +
      '#exbIntelPanel .ic small{color:#4a5a73;display:block}' +
      '#exbIntelPanel .ib button.a{min-height:36px;padding:0 12px;border-radius:9px;border:1px solid #1f6feb;background:#eaf1ff;color:#0f2e66;font:700 12px Arial;cursor:pointer;margin:6px 6px 0 0}' +
      '#exbIntelPanel .x{min-width:44px;min-height:44px;border:0;border-radius:10px;background:#ffffff1f;color:#fff;font-size:18px;cursor:pointer}' +
      '#exbIntelPanel button:focus-visible{outline:2px solid #c8962e;outline-offset:2px}';
    d.head.appendChild(s);
  }
  function icon(s) { return s === 'erreur' ? '🔴' : s === 'alerte' ? '🟠' : '🔵'; }
  function render() {
    var p = $('exbIntelPanel'); if (!p) return; var s = summary(), b = '';
    if (tab === 'ctl') {
      b += '<div class="ic"><b>' + s.erreur + '</b> erreur(s) · <b>' + s.alerte + '</b> alerte(s) · <b>' + s.info + '</b> info(s) <small>Dernier contrôle : ' + new Date(state.at || Date.now()).toLocaleTimeString('fr-FR') + ' · fonctionne hors connexion</small><button class="a" data-a="run">↻ Revérifier</button><button class="a" data-a="rep">⬇ Rapport</button><button class="a" data-a="ai">🤖 Demander à l’assistant</button></div>';
      b += state.findings.length ? state.findings.slice().sort(function (x, y) { return ['erreur', 'alerte', 'info'].indexOf(x.sev) - ['erreur', 'alerte', 'info'].indexOf(y.sev); }).slice(0, 200).map(function (f, i) {
        var c = f.ref && f.ref.col ? colOf(f.ref.col) : null;
        return '<div class="ic">' + icon(f.sev) + ' ' + esc(f.msg) + '<small>' + esc(f.mod) + '</small>' + (f.fix ? '<button class="a" data-a="fix" data-i="' + i + '">' + esc(f.fix.label) + '</button>' : '') + (c && c.show ? '<button class="a" data-a="open" data-i="' + i + '">Ouvrir</button>' : '') + '<button class="a" data-a="ign" data-i="' + i + '">Ignorer</button></div>';
      }).join('') : '<div class="ic">✅ Aucune erreur, incohérence ni doublon détecté.</div>';
      p._list = state.findings.slice().sort(function (x, y) { return ['erreur', 'alerte', 'info'].indexOf(x.sev) - ['erreur', 'alerte', 'info'].indexOf(y.sev); }).slice(0, 200);
    } else if (tab === 'rec') {
      b += state.reco.length ? state.reco.map(function (r, i) { return '<div class="ic">' + r.ic + ' <b>' + esc(r.t) + '</b><small>' + esc(r.x) + '</small>' + r.acts.map(function (a, j) { return '<button class="a" data-a="reco" data-i="' + i + '" data-j="' + j + '">' + esc(a.l) + '</button>'; }).join('') + '</div>'; }).join('') : '<div class="ic">Aucune recommandation pour le moment.</div>';
    } else if (tab === 'his') {
      b += hist.length ? hist.slice(0, 120).map(function (h, hi) { return '<div class="ic"><b>' + esc(h.op) + '</b> ' + esc(h.l ? h.l + ' — ' + h.name : h.msg) + '<small>' + new Date(h.at).toLocaleString('fr-FR') + ' · ' + esc(h.by) + '</small>' + (h.fields || []).map(function (f) { return '<small>' + esc(f.f) + ' : ' + esc(f.a) + ' → ' + esc(f.b) + '</small>'; }).join('') + (h.undo && !h.undone ? '<button class="a" data-a="undo" data-i="' + hi + '">↩ Annuler cette opération</button>' : '') + (h.undone ? '<small>↩ annulée</small>' : '') + '</div>'; }).join('') : '<div class="ic">L’historique se remplit au fil des modifications (clients, projets, devis, factures, caisse, stock, personnel…).</div>';
    } else {
      b += Object.keys(engines).map(function (id) { return '<div class="ic">⚙️ <b>' + esc(engines[id].label) + '</b><small>' + esc(id) + '</small></div>'; }).join('') + '<div class="ic">🤖 <b>Assistant IA</b><small>' + (w.navigator.onLine ? 'En ligne : assistant complet si configuré' : 'Hors connexion : réponses locales du moteur') + '</small></div><div class="ic">🔒 Opérations critiques : confirmation obligatoire + inscription au journal.</div>';
    }
    if (tab === 'eng') ENGX.forEach(function (f) { try { b += f() || ''; } catch (e) {} });
    p.querySelector('.ib').innerHTML = b;
    [].forEach.call(p.querySelectorAll('.it button'), function (x) { x.className = x.getAttribute('data-t') === tab ? 'on' : ''; });
  }
  function openPanel(t) {
    if (t) tab = t; css(); run();
    if ($('exbIntelPanel')) { render(); return; }
    var p = d.createElement('div'); p.id = 'exbIntelPanel'; p.className = 'no-print'; p.setAttribute('role', 'dialog'); p.setAttribute('aria-label', 'Excellencia Intelligence');
    p.innerHTML = '<div class="ip"><header><b>🧠 Excellencia Intelligence</b><button class="x" data-a="close" aria-label="Fermer">✕</button></header><div class="it"><button data-t="ctl">Contrôles</button><button data-t="rec">Recommandations</button><button data-t="his">Historique</button><button data-t="eng">Moteurs</button></div><div class="ib"></div></div>';
    p.addEventListener('click', function (e) {
      if (e.target === p) { closePanel(); return; }
      var tb = e.target.closest('[data-t]'); if (tb) { tab = tb.getAttribute('data-t'); render(); return; }
      var b = e.target.closest('[data-a]'); if (!b) return; var a = b.getAttribute('data-a'), i = +b.getAttribute('data-i'), j = +b.getAttribute('data-j');
      if (a === 'close') closePanel();
      else if (a === 'run') { run(); render(); }
      else if (a === 'rep') downloadReport();
      else if (a === 'ai') { closePanel(); try { w.exbAssistant(); } catch (x) {} }
      else if (a === 'fix') { var fx = p._list && p._list[i]; if (fx && fx.fix) { Promise.resolve(fx.fix.run()).then(function () { run(); render(); }); } }
      else if (a === 'undo') { var h = hist[i]; if (h && h.undo && undoers[h.undo.type]) { confirmBox('Annuler cette opération ?', h.msg + ' — les données reviendront à leur état précédent.', 'Annuler l’opération').then(function (ok) { if (!ok) return; try { undoers[h.undo.type](h.undo.data); h.undone = true; jset(K_HIST, hist); logEvent('annulation', 'Annulation : ' + h.msg); } catch (e) { toast('Annulation impossible.'); } run(); render(); }); } }
      else if (a === 'open') { var f = p._list && p._list[i], c = f && f.ref && colOf(f.ref.col); if (c && c.show) go(c.show); }
      else if (a === 'ign') { var g = p._list && p._list[i]; if (g) { var m = ignored(); m[g.key] = 1; jset(K_IGN, m); logEvent('ignoré', g.msg); run(); render(); } }
      else if (a === 'reco') { var r = state.reco[i]; if (r && r.acts[j]) r.acts[j].f(); }
    });
    d.body.appendChild(p); render();
  }
  function closePanel() { var p = $('exbIntelPanel'); if (p) p.remove(); }
  function badge() {
    var s = summary(), n = s.erreur + s.alerte, b = $('xbIntel'); if (!b) return; var i = b.querySelector('i'); if (i) i.textContent = n ? String(n > 99 ? '99+' : n) : '';
  }
  function mountButton() {
    var top = $('xbTop'); if (!top || $('xbIntel')) return !!$('xbIntel');
    var b = d.createElement('button'); b.id = 'xbIntel'; b.type = 'button'; b.className = 'xb'; b.title = 'Excellencia Intelligence : contrôles, recommandations, historique'; b.setAttribute('aria-label', 'Excellencia Intelligence');
    b.innerHTML = '🧠<i></i>'; b.onclick = function () { openPanel('ctl'); }; top.insertBefore(b, top.firstChild); badge(); return true;
  }

  /* ---------- démarrage ---------- */
  w.EXBI = { version: VERSION, bus: bus, engines: engines, registerEngine: registerEngine, addRule: function (r) { if (r && r.id && r.check) RULES.push(r); },
    addFixer: function (rule, fn) { fixers[rule] = fn; }, addFilter: function (fn) { filters.push(fn); }, addReco: function (fn) { recoProviders.push(fn); }, registerUndo: function (type, fn) { undoers[type] = fn; }, helpers: { list: list, lab: lab, norm: norm, digits: digits, num: num, esc: esc, jget: jget, jset: jset, copy: copy, go: go, toast: toast, today: today },
    run: run, runAsync: runAsync, addEngineInfo: function (fn) { if (typeof fn === 'function') ENGX.push(fn); }, stats: function () { return JSON.parse(JSON.stringify(stats)); }, isRunning: function () { return running; }, summary: summary, findings: function () { return state.findings.slice(); }, recommendations: function () { return state.reco.slice(); },
    history: function () { return hist.slice(); }, log: logEvent, confirm: confirmBox, open: openPanel, contextText: contextText, report: reportHtml, calc: { invoice: invTot }, collections: COLS };
  function boot() {
    var n = 0, t = setInterval(function () { mountButton(); hookAI(); n++; if (($('xbIntel') && n > 4) || n > 80) clearInterval(t); }, 500);
    setTimeout(poll, 2500); setInterval(poll, 5000); setInterval(function () { if (!d.hidden) { runAsync().then(function () { if ($('exbIntelPanel') && tab === 'ctl') render(); }); } }, 300000);
    w.addEventListener('online', function () { sched(); });
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})(window, document);
