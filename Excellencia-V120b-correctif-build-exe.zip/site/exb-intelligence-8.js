/* EXCELLENCIA INTELLIGENCE — lot 8 : réception intelligente des demandes (apprenants, TP/TD, formateurs, clients, personnel, logiciels, projets BTP).
 * Extension (à charger APRÈS exb-intelligence.js, de préférence après le lot 7). Utilise les fonctions EXISTANTES de l'application :
 *   import  = EXB_INBOX.importRows (même importMany que le bouton « ⬇ Importer » : mêmes contrôles, mêmes doublons) ;
 *   approbation = window.approveEntity (même matricule, même journal d'audit).
 * Chaque demande est d'abord VÉRIFIÉE : champs obligatoires, téléphone/e-mail, code suspect, doublon, matricule inconnu, envoi répété, afflux anormal.
 * Seules les demandes « conformes » peuvent être traitées automatiquement ; les autres restent pour vous, avec la raison.
 * Niveaux par type : Interdit / Demander (par défaut) / Automatique. Approbation automatique : apprenants seulement (formateurs et personnel : toujours validés par vous).
 * Plafond d'approbations automatiques par heure. Rien n'est jamais supprimé ni rejeté automatiquement. Journal : exb_ai_log (celui de l'assistant), sans noms.
 * Pour retirer : supprimer la balise <script src="exb-intelligence-8.js"> de index.html. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot8) return; I.lot8 = true;
    var H = I.helpers, list = H.list, norm = H.norm, digits = H.digits, esc = H.esc, jget = H.jget, jset = H.jset, toast = H.toast;
    var K_CFG = 'exb_perm_inbox', K_IGN = 'exb_intel_inbox_ign', K_RATE = 'exb_intel_inbox_rate';
    var TYPES = {
      insc: { l: 'Apprenants', ic: '🎓', ent: 'participant', idf: 'participant_id', col: 'exb_participants', appr: true, auto: true },
      tptd: { l: 'TP / TD', ic: '📝' },
      form: { l: 'Formateurs', ic: '👨‍🏫', ent: 'trainer', idf: 'trainer_id', col: 'exb_trainers', appr: true, auto: false },
      cli: { l: 'Clients', ic: '🏢' },
      pers: { l: 'Personnel', ic: '👷', ent: 'hr', idf: 'id', col: 'exb_hr', appr: true, auto: false },
      soft: { l: 'Logiciels', ic: '💻' },
      btp: { l: 'Projets BTP', ic: '🏗️' }
    }, ORDER = ['insc', 'tptd', 'form', 'cli', 'pers', 'soft', 'btp'];
    var NEED = { insc: ['name', 'phone', 'training'], tptd: ['matricule', 'work_type'], form: ['name'], cli: ['full_name', 'phone'], pers: ['name'], soft: [], btp: ['name', 'phone'] };
    var FL = { name: 'nom', phone: 'téléphone', training: 'formation', matricule: 'matricule', work_type: 'travail demandé', full_name: 'nom complet' };
    var SUSP = /<\s*(script|iframe|object|embed)|\bon(error|load|click|mouse[a-z]+|focus|blur|change|submit|toggle)\s*=\s*["']?[^>\s]|javascript\s*:|data\s*:\s*text\/html/i;
    var LV = ['forbid', 'ask', 'auto'], LVL = { forbid: '🔒 Interdit', ask: '✋ Demander', auto: '✅ Automatique' };
    var EXB = function () { return w.EXB_INBOX || null; };

    /* ---------- réglages ---------- */
    function cfg() {
      var c = jget(K_CFG, null); c = c && typeof c === 'object' ? c : {}; var o = { imp: {}, app: {}, paid: c.paid !== false, max: Math.min(100, Math.max(1, parseInt(c.max, 10) || 10)) };
      ORDER.forEach(function (t) { var v = c.imp && c.imp[t]; o.imp[t] = LV.indexOf(v) >= 0 ? v : 'ask'; });
      ORDER.forEach(function (t) { if (!TYPES[t].appr) return; var v = c.app && c.app[t]; v = LV.indexOf(v) >= 0 ? v : 'ask'; if (v === 'auto' && (!TYPES[t].auto || o.imp[t] !== 'auto')) v = 'ask'; o.app[t] = v; });
      return o;
    }
    function saveCfg(c) { jset(K_CFG, c); try { if (I.sec && I.sec.accept) I.sec.accept(K_CFG); } catch (e) {} }
    function master() { var p = jget('exb_ai_perm', {}); return !(p && p.on === false); }       /* assistant désactivé = rien d'automatique */
    function importBlocked() { var p = jget('exb_ai_perm', {}); return !!(p && p.lv && p.lv.import === 'forbid'); }
    function mode(kind, t) { var c = cfg(); if (!master() || importBlocked()) return 'forbid'; return kind === 'imp' ? c.imp[t] : (c.app[t] || 'forbid'); }

    /* ---------- vérification d'une demande ---------- */
    function lab(r) { var x = r.d || {}; return String(x.full_name || x.name || x.matricule || x.work_type || '?').slice(0, 60); }
    function scanObj(v, k) { if (k > 3 || v == null) return false; if (typeof v === 'string') return v.length < 30000 && SUSP.test(v); if (Array.isArray(v)) return v.slice(0, 60).some(function (x) { return scanObj(x, k + 1); }); if (typeof v === 'object') return Object.keys(v).slice(0, 80).some(function (q) { return q === '__proto__' || scanObj(v[q], k + 1); }); return false; }
    function vet(t, r, ctx) {
      var x = r.d || {}, why = [], sec = false, ph = digits(x.phone), em = String(x.email || '').trim();
      NEED[t].forEach(function (k) { if (!String(x[k] == null ? '' : x[k]).trim()) why.push('champ manquant : ' + FL[k]); });
      if (x.phone && ph.length < 8) why.push('téléphone incomplet');
      if (em && !/^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(em)) why.push('e-mail invalide');
      var susp = (I.sec && I.sec.scan) ? I.sec.scan(x) : scanObj(x, 0); if (susp) { why.push('code suspect (script, onerror=, javascript:)'); sec = true; }
      var PA = ctx.P, TR = ctx.T, CL = ctx.C, HR = ctx.H;
      if (t === 'insc') { if (PA.some(function (p) { var pp = digits(p.phone), pe = String(p.email || '').toLowerCase(); return (ph.length >= 6 && pp === ph) || (em && pe === em.toLowerCase()) || (norm(p.name) === norm(x.name) && pp === ph); })) why.push('apprenant déjà enregistré (doublon)'); }
      if (t === 'tptd') { var p = PA.filter(function (q) { return String(q.matricule || '').trim() === String(x.matricule || '').trim(); })[0]; if (x.matricule && !p) why.push('matricule introuvable'); else if (p && p.approval_status !== 'APPROUVE') why.push('apprenant pas encore approuvé'); }
      if (t === 'form' && TR.some(function (q) { return q && norm(q.name) === norm(x.name) && (!ph || !q.phone || digits(q.phone) === ph); })) why.push('formateur déjà enregistré (doublon)');
      if (t === 'cli' && CL.some(function (q) { return q && ((ph.length >= 6 && digits(q.phone) === ph) || (norm(q.full_name || q.name) === norm(x.full_name) && x.full_name)); })) why.push('client déjà enregistré (doublon)');
      if (t === 'pers' && HR.some(function (q) { return q && norm(q.name) === norm(x.name) && (!ph || !q.phone || digits(q.phone) === ph); })) why.push('personnel déjà enregistré (doublon)');
      if (ph.length >= 6 && ctx.seen[t + ph]) why.push('même téléphone envoyé plusieurs fois'); else if (ph.length >= 6) ctx.seen[t + ph] = 1;
      if (ctx.flood[t]) { why.push('afflux anormal de demandes'); sec = true; }
      return { ok: !why.length, why: why, sec: sec, paid: t === 'insc' ? !!x.insc_payee : null };
    }

    /* ---------- analyse des demandes en attente ---------- */
    var state = { at: 0, items: {}, capped: false };
    function ign() { var g = jget(K_IGN, []); return Array.isArray(g) ? g : []; }
    function scan() {
      var B = EXB(), out = {}, ig = ign(); if (!B || !B.rows) { state.items = out; return out; }
      var ctx = { P: list('exb_participants'), T: list('exb_trainers'), C: list('exb_clients'), H: list('exb_hr'), seen: {}, flood: {} };
      ORDER.forEach(function (t) { var pend = B.rows(t).filter(function (r) { return !r.imported; }), recent = pend.filter(function (r) { return Date.now() - Date.parse(r.created_at) < 600000; }); ctx.flood[t] = recent.length >= 15; });
      ORDER.forEach(function (t) {
        var rows = B.rows(t).filter(function (r) { return !r.imported && ig.indexOf(String(r.id)) < 0; });
        rows.sort(function (a, b) { return Date.parse(a.created_at) - Date.parse(b.created_at); });
        out[t] = rows.map(function (r) { return { r: r, v: vet(t, r, ctx) }; });
      });
      state.items = out; state.at = Date.now(); return out;
    }
    function count(t, onlyOk) { return (state.items[t] || []).filter(function (it) { return !onlyOk || it.v.ok; }).length; }
    function total(onlyOk) { return ORDER.reduce(function (a, t) { return a + count(t, onlyOk); }, 0); }

    /* ---------- approbation d'une fiche importée ---------- */
    function candidate(t, r) {
      var T = TYPES[t], x = r.d || {}, ph = digits(x.phone), em = String(x.email || '').toLowerCase(), nm = norm(x.name || x.full_name);
      var c = list(T.col).filter(function (o) {
        if (!o || o.approval_status === 'APPROUVE' || o.approval_status === 'REJETE') return false;
        if (t === 'insc') return (ph.length >= 6 && digits(o.phone) === ph) || (em && String(o.email || '').toLowerCase() === em);
        return norm(o.name) === nm && (!ph || !o.phone || digits(o.phone) === ph);
      });
      return c.length === 1 ? c[0] : null;
    }
    function approveOne(t, r) {
      var T = TYPES[t]; if (!T.ent || typeof w.approveEntity !== 'function') return 'indisponible';
      var o = candidate(t, r); if (!o) return 'fiche introuvable ou ambiguë';
      var ok; try { ok = w.approveEntity(T.ent, o[T.idf], { silent: true }); } catch (e) { ok = false; }
      return ok ? 'ok' : 'refusée par l’application';
    }
    function rate() { var a = jget(K_RATE, []); a = (Array.isArray(a) ? a : []).filter(function (x) { return Date.now() - x < 3600000; }); return a; }
    function ratePush(n) { var a = rate(); for (var i = 0; i < n; i++) a.push(Date.now()); jset(K_RATE, a.slice(-200)); }
    function jlog(a, l, m, ok) { try { var L = jget('exb_ai_log', []); L = Array.isArray(L) ? L : []; L.push({ t: new Date().toISOString(), a: a, l: String(l).slice(0, 160), m: m, ok: !!ok }); jset('exb_ai_log', L.slice(-200)); } catch (e) {} }

    /* ---------- traitement ---------- */
    var busy = false;
    function process(t, ids, doApprove, how) {
      var B = EXB(); if (!B || !B.importRows || !B.on()) return Promise.resolve({ imp: 0, app: 0, skip: [] });
      var items = (state.items[t] || []).filter(function (it) { return ids.indexOf(String(it.r.id)) >= 0; });
      if (!items.length) return Promise.resolve({ imp: 0, app: 0, skip: [] });
      return B.importRows(t, items.map(function (it) { return String(it.r.id); })).then(function (n) {
        var app = 0, skip = [];
        if (doApprove && n) {
          items.forEach(function (it) {
            if (how === 'auto') { if (!it.v.ok || (t === 'insc' && cfg().paid && !it.v.paid)) { skip.push(lab(it.r) + ' : ' + (it.v.ok ? 'inscription non payée' : 'non conforme')); return; } if (rate().length >= cfg().max) { state.capped = true; skip.push(lab(it.r) + ' : plafond horaire atteint'); return; } }
            var res = approveOne(t, it.r); if (res === 'ok') { app++; if (how === 'auto') ratePush(1); } else skip.push(lab(it.r) + ' : ' + res);
          });
        }
        jlog('import', 'Importer les demandes : ' + TYPES[t].l + ' (' + n + ')', how === 'auto' ? 'automatique' : 'validé', n > 0);
        if (doApprove) jlog('approve', 'Approuver : ' + TYPES[t].l + ' (' + app + ')', how === 'auto' ? 'automatique' : 'validé', app > 0);
        try { I.log('reception', TYPES[t].l + ' : ' + n + ' importée(s), ' + app + ' approuvée(s) (' + (how === 'auto' ? 'automatique' : 'validé') + ')'); } catch (e) {}
        return Promise.resolve(B.reload()).then(function () { scan(); try { I.run(); } catch (e) {} return { imp: n, app: app, skip: skip }; });
      });
    }
    function tick() {
      if (d.hidden || busy) return; var B = EXB(); if (!B || !B.on() || !master()) return;
      var any = ORDER.some(function (t) { return mode('imp', t) === 'auto'; }); if (!any) return;
      busy = true;
      Promise.resolve(B.reload()).then(function () {
        scan(); var chain = Promise.resolve(), done = 0, appr = 0;
        ORDER.forEach(function (t) {
          if (mode('imp', t) !== 'auto') return;
          var ids = (state.items[t] || []).filter(function (it) { return it.v.ok; }).map(function (it) { return String(it.r.id); }); if (!ids.length) return;
          chain = chain.then(function () { return process(t, ids, mode('app', t) === 'auto', 'auto'); }).then(function (s) { done += s.imp; appr += s.app; });
        });
        return chain.then(function () { if (done) toast('🤖 ' + done + ' demande(s) importée(s)' + (appr ? ', ' + appr + ' approuvée(s)' : '') + ' automatiquement.'); });
      }).catch(function () {}).then(function () { busy = false; });
    }

    /* ---------- règle de sécurité, recommandation, assistant ---------- */
    I.addRule({ id: 'inbox.suspect', check: function () {
      var out = [], sus = 0, over = rate().length >= cfg().max && state.capped;
      ORDER.forEach(function (t) { (state.items[t] || []).forEach(function (it) { if (it.v.sec) sus++; }); });
      if (sus) out.push({ sev: 'erreur', mod: 'Sécurité ↔ Demandes', msg: sus + ' demande(s) en attente contiennent du code suspect ou arrivent en rafale : ne les importez pas sans vérification.', ref: { col: 'inbox', id: 'sus|' + sus } });
      if (over) out.push({ sev: 'alerte', mod: 'Sécurité ↔ Demandes', msg: 'Plafond d’approbations automatiques atteint (' + cfg().max + ' par heure) : afflux inhabituel d’inscriptions ?', ref: { col: 'inbox', id: 'cap' } });
      return out; } });
    I.addReco(function () {
      var n = total(false), ok = total(true); if (!n) return [];
      return [{ ic: '📥', t: n + ' demande(s) en attente (' + ok + ' conforme(s))', x: 'Apprenants, clients, personnel, TP/TD… Les demandes conformes peuvent être importées et approuvées en un geste ; les autres restent à vérifier.', acts: [{ l: 'Ouvrir la réception intelligente', f: function () { open(); } }] }];
    });
    function answer() {
      var B = EXB(); if (!B || !B.on()) return 'Je ne vois pas les demandes en ligne : connectez-vous d’abord à Participants › Demandes en ligne.';
      scan(); var n = total(false); if (!n) return 'Aucune nouvelle demande en attente.';
      return n + ' demande(s) en attente, dont ' + total(true) + ' conforme(s) :\n' + ORDER.filter(function (t) { return count(t); }).map(function (t) { return '• ' + TYPES[t].l + ' : ' + count(t) + ' (' + count(t, true) + ' conformes)'; }).join('\n') + '\nJ’ouvre la réception pour vous laisser les importer et les approuver.';
    }
    function hook() { try { if (typeof w.localAI === 'function' && !(w.__exbAIHooks = w.__exbAIHooks || {}).inbox) { (w.__exbAIHooks = w.__exbAIHooks || {}).inbox = 1; var l = w.localAI; w.localAI = function (raw) { try { if (/\b(importe|importer|approuve|approuver|traite|traiter|valide|valider)\b.*\b(demande|inscription|apprenant|client|personnel|formateur)|\b(demande|inscription)s?\b.*\b(attente|recue|nouvelle)/.test(norm(raw))) { var a = answer(); setTimeout(open, 50); return { answer: a, actions: [] }; } } catch (e) {} return l.apply(this, arguments); }; w.localAI.__inbox = 1; } } catch (e) {} }

    /* ---------- interface ---------- */
    function css() {
      if (d.getElementById('exbInboxCss')) return; var s = d.createElement('style'); s.id = 'exbInboxCss';
      s.textContent = '#exbInboxP{position:fixed;inset:0;z-index:100025;background:#0008;display:flex;align-items:flex-end;justify-content:center;font-family:Arial,Helvetica,sans-serif}#exbInboxP .ip{background:#f3f6fc;color:#12254a;width:100%;max-width:720px;height:88vh;border-radius:16px 16px 0 0;display:flex;flex-direction:column;border-top:4px solid #c8962e}#exbInboxP header{display:flex;align-items:center;gap:8px;padding:12px 14px;background:#0f2e66;color:#fff;border-radius:12px 12px 0 0}#exbInboxP header b{flex:1;font-size:16px}#exbInboxP .ib{flex:1;overflow:auto;padding:10px 12px 16px}#exbInboxP .c{background:#fff;border:1px solid #e3e9f4;border-radius:12px;padding:10px;margin:0 0 10px}#exbInboxP .c h4{margin:0 0 6px;font-size:15px}#exbInboxP .r{border-top:1px solid #eef2f8;padding:7px 0;font-size:13px;display:flex;gap:6px;align-items:center;flex-wrap:wrap}#exbInboxP .r span{flex:1;min-width:140px}#exbInboxP small{display:block;color:#8a4b00;font-size:12px}#exbInboxP .ok small{color:#0a7a3d}#exbInboxP button{min-height:38px;padding:0 12px;border-radius:999px;border:1px solid #1f6feb;background:#fff;color:#1f6feb;font:700 13px Arial;cursor:pointer;margin:3px 4px 0 0}#exbInboxP button.p{background:#1f6feb;color:#fff}#exbInboxP button.g{border-color:#c8cfdc;color:#556}#exbInboxP select{min-height:36px;border-radius:8px;border:1px solid #c8cfdc;margin:2px 6px 2px 0}';
      d.head.appendChild(s);
    }
    var cur = null;
    function badge(it) { return it.v.ok ? '<div class="ok"><small>✅ Conforme' + (it.v.paid === false ? ' · inscription non payée' : it.v.paid ? ' · payée' : '') + '</small></div>' : '<small>' + (it.v.sec ? '🛑 ' : '⚠ ') + esc(it.v.why.join(' ; ')) + '</small>'; }
    function render() {
      if (!cur) return; var B = EXB(), c = cfg(), h = '';
      if (!B || !B.on()) h += '<div class="c"><b>Non connecté.</b> Ouvrez Participants › Demandes en ligne et connectez-vous au compte administrateur. L’application se verrouille après inactivité et coupe cette connexion : le traitement automatique ne tourne que connecté.</div>';
      else {
        var any = false;
        ORDER.forEach(function (t) {
          var its = state.items[t] || []; if (!its.length) return; any = true; var T = TYPES[t], okN = its.filter(function (i) { return i.v.ok; }).length, canApp = T.appr && mode('app', t) !== 'forbid' && mode('imp', t) !== 'forbid';
          h += '<div class="c"><h4>' + T.ic + ' ' + esc(T.l) + ' — ' + its.length + ' en attente (' + okN + ' conforme' + (okN > 1 ? 's' : '') + ')</h4>';
          its.slice(0, 25).forEach(function (it) { h += '<div class="r"><span><b>' + esc(lab(it.r)) + '</b>' + badge(it) + '</span><button class="g" data-a="one" data-t="' + t + '" data-id="' + esc(it.r.id) + '">Importer</button><button class="g" data-a="ign" data-id="' + esc(it.r.id) + '">Ignorer</button></div>'; });
          if (its.length > 25) h += '<div class="r"><span>… et ' + (its.length - 25) + ' autre(s)</span></div>';
          if (okN && mode('imp', t) !== 'forbid') h += '<button class="p" data-a="ok" data-t="' + t + '" data-ap="0">⬇ Importer les ' + okN + ' conforme(s)</button>' + (canApp ? '<button class="p" data-a="ok" data-t="' + t + '" data-ap="1">⬇✅ Importer + approuver</button>' : '');
          h += '</div>';
        });
        if (!any) h += '<div class="c">✅ Aucune nouvelle demande en attente.</div>';
        var pa = ORDER.filter(function (t) { return TYPES[t].appr; }).map(function (t) { return { t: t, l: list(TYPES[t].col).filter(function (o) { return o && o.approval_status === 'EN ATTENTE' && (t !== 'insc' || o.source === 'INSCRIPTION_EN_LIGNE'); }) }; }).filter(function (x) { return x.l.length; });
        pa.forEach(function (x) { var T = TYPES[x.t]; h += '<div class="c"><h4>⏳ ' + esc(T.l) + ' importé(s), à approuver — ' + x.l.length + '</h4>'; x.l.slice(0, 20).forEach(function (o) { var bad = I.sec && I.sec.scan ? I.sec.scan(o) : scanObj(o, 0); h += '<div class="r"><span><b>' + esc(String(o.name || '?').slice(0, 60)) + '</b>' + (bad ? '<small>🛑 code suspect</small>' : '') + '</span>' + (bad ? '' : '<button class="p" data-a="app" data-t="' + x.t + '" data-id="' + esc(o[T.idf]) + '">✅ Approuver</button>') + '</div>'; }); h += '</div>'; });
      }
      h += '<details class="c"><summary><b>⚙ Réglages (qui décide quoi)</b></summary><p style="font-size:12px;margin:8px 0">Par défaut tout est sur « Demander » : rien ne se fait sans vous. « Automatique » ne traite que les demandes conformes, uniquement pendant que l’application est ouverte et connectée.</p>';
      ORDER.forEach(function (t) { var T = TYPES[t]; h += '<div class="r"><span>' + T.ic + ' ' + esc(T.l) + '</span>Import <select data-s="imp" data-t="' + t + '">' + LV.map(function (v) { return '<option value="' + v + '"' + (c.imp[t] === v ? ' selected' : '') + '>' + LVL[v] + '</option>'; }).join('') + '</select>' + (T.appr ? 'Approbation <select data-s="app" data-t="' + t + '">' + LV.filter(function (v) { return v !== 'auto' || (T.auto && c.imp[t] === 'auto'); }).map(function (v) { return '<option value="' + v + '"' + (c.app[t] === v ? ' selected' : '') + '>' + LVL[v] + '</option>'; }).join('') + '</select>' : '') + '</div>'; });
      h += '<div class="r"><span><label><input type="checkbox" data-s="paid"' + (c.paid ? ' checked' : '') + '> Approbation automatique : exiger l’inscription payée</label></span></div><div class="r"><span>Plafond d’approbations automatiques par heure</span><select data-s="max">' + [3, 5, 10, 20, 50].map(function (v) { return '<option' + (c.max === v ? ' selected' : '') + '>' + v + '</option>'; }).join('') + '</select></div><small style="color:#556">Formateurs et personnel : approbation toujours validée par vous. Rien n’est jamais rejeté ni supprimé automatiquement.</small></details>';
      cur.querySelector('.ib').innerHTML = h;
    }
    function summaryMsg(s) { return s.imp + ' importée(s), ' + s.app + ' approuvée(s)' + (s.skip.length ? '. À faire vous-même : ' + s.skip.slice(0, 4).join(' ; ') : '') + '.'; }
    function onClick(e) {
      var b = e.target.closest && e.target.closest('[data-a]'); if (!b) return; var a = b.getAttribute('data-a'), t = b.getAttribute('data-t'), id = b.getAttribute('data-id');
      if (a === 'x') { cur.remove(); cur = null; return; }
      if (a === 'ign') { var g = ign(); g.push(String(id)); jset(K_IGN, g.slice(-300)); scan(); render(); return; }
      if (busy) { toast('Un traitement est déjà en cours.'); return; }
      if (a === 'ok') { var ap = b.getAttribute('data-ap') === '1', ids = (state.items[t] || []).filter(function (i) { return i.v.ok; }).map(function (i) { return String(i.r.id); });
        I.confirm(ap ? 'Importer et approuver' : 'Importer', ids.length + ' demande(s) conforme(s) : ' + TYPES[t].l + (ap ? '. L’approbation crée un matricule et rend la fiche active.' : '.'), ap ? 'Importer + approuver' : 'Importer').then(function (y) { if (!y) return; busy = true; process(t, ids, ap, 'manuel').then(function (s) { toast(summaryMsg(s)); }).catch(function () { toast('Traitement impossible.'); }).then(function () { busy = false; render(); }); }); return; }
      if (a === 'one') { var it = (state.items[t] || []).filter(function (i) { return String(i.r.id) === String(id); })[0]; if (!it) return;
        I.confirm('Importer cette demande', it.v.ok ? lab(it.r) : lab(it.r) + ' — attention : ' + it.v.why.join(' ; '), 'Importer').then(function (y) { if (!y) return; busy = true; process(t, [String(id)], false, 'manuel').then(function (s) { toast(summaryMsg(s)); }).catch(function () {}).then(function () { busy = false; render(); }); }); return; }
      if (a === 'app') { var T = TYPES[t], o = list(T.col).filter(function (q) { return q && String(q[T.idf]) === String(id); })[0]; if (!o) return;
        I.confirm('Approuver', String(o.name || '?').slice(0, 60) + ' (' + T.l + ') : un matricule sera créé.', 'Approuver').then(function (y) { if (!y) return; var ok = false; try { ok = w.approveEntity(T.ent, id, { silent: true }); } catch (x) {} jlog('approve', 'Approuver : ' + T.l + ' (' + (ok ? 1 : 0) + ')', 'validé', ok); toast(ok ? 'Approuvé(e).' : 'Approbation refusée par l’application.'); scan(); render(); }); }
    }
    function onChange(e) {
      var s = e.target.getAttribute && e.target.getAttribute('data-s'); if (!s) return; var c = cfg(), t = e.target.getAttribute('data-t');
      if (s === 'imp' || s === 'app') {
        if (s === 'app' && e.target.value === 'auto') { I.confirm('Approbation automatique', 'Les apprenants conformes seront approuvés sans votre validation (matricule, carte et QR « authentique »). Les inscriptions publiques viennent de n’importe qui : gardez « exiger l’inscription payée » activé.', 'Activer').then(function (y) { if (y) { c.app[t] = 'auto'; saveCfg(c); } render(); }); return; }
        if (s === 'imp' && e.target.value === 'auto') { I.confirm('Import automatique', 'Les demandes conformes de « ' + TYPES[t].l + ' » seront importées sans votre validation, tant que l’application est ouverte et connectée.', 'Activer').then(function (y) { if (y) { c.imp[t] = 'auto'; saveCfg(c); } render(); }); return; }
        c[s][t] = e.target.value; if (s === 'imp' && e.target.value !== 'auto' && c.app[t] === 'auto') c.app[t] = 'ask';
      } else if (s === 'paid') c.paid = !!e.target.checked; else if (s === 'max') c.max = parseInt(e.target.value, 10) || 10;
      saveCfg(c); render();
    }
    function open() {
      css(); if (cur) { cur.remove(); cur = null; }
      cur = d.createElement('div'); cur.id = 'exbInboxP'; cur.setAttribute('role', 'dialog'); cur.setAttribute('aria-modal', 'true');
      cur.innerHTML = '<div class="ip"><header><b>📥 Réception intelligente des demandes</b><button class="g" data-a="x" aria-label="Fermer">✕</button></header><div class="ib"></div></div>';
      cur.addEventListener('click', onClick); cur.addEventListener('change', onChange); d.body.appendChild(cur);
      var B = EXB(); Promise.resolve(B && B.on() ? B.reload() : null).then(function () { scan(); render(); });
      scan(); render();
    }
    I.intake = { open: open, scan: scan, vet: vet, process: process, config: cfg, pending: total, tick: tick };
    scan(); hook(); var n2 = 0, t2 = setInterval(function () { hook(); if (++n2 > 40) clearInterval(t2); }, 750);
    setTimeout(function () { scan(); tick(); }, 8000); setInterval(function () { if (I.tasks) I.tasks.add({ key: 'inbox.tick', group: 'inbox', label: 'Réception : analyse', prio: 'normale', timeout: 120000, fn: function () { scan(); return tick(); } }); else { scan(); tick(); } }, 60000);
    I.run();
  }
  boot(0);
})(window, document);
