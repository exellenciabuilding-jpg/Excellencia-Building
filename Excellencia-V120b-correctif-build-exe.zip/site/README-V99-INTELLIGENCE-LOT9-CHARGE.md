# EXCELLENCIA INTELLIGENCE — lot 9 : tenir la charge (beaucoup de tâches, beaucoup de données)

Nouveau : `exb-intelligence-9.js` (après le lot 1). Corrigés : `exb-intelligence.js`, `exb-intelligence-7.js`, `exb-intelligence-8.js` (voir « Correctifs »), `index.html` (1 balise), `sw.js` (cache, version `v121i`). Test : `node tools/test-intelligence-9.js` (70 contrôles).
**Aucune donnée métier modifiée.** Seule clé écrite : `exb_intel_tasks_log` (100 dernières tâches : nom, durée, réussite ; aucune donnée personnelle).

## Correctifs du moteur (exb-intelligence.js)
| Problème | Correction | Mesuré (8 500 fiches) |
|---|---|---|
| Une fiche `null` dans une collection faisait échouer **tout** le contrôle (signalé au lot 7) | Les fiches non valides sont ignorées, le reste est contrôlé | avant : erreur, 0 constat ; après : 15 constats |
| Chaque règle relisait et ré-analysait les mêmes collections | Une seule lecture par collection et par passage | factures 4 → 1 lecture, projets 3 → 1 ; passage 103 → 27 ms |
| Une règle qui plante disparaissait sans trace | Isolée, comptée, expliquée (🧠 › Moteurs) ; les autres continuent | — |
| Un contrôle lancé depuis un autre contrôle pouvait boucler | Passage unique à la fois | — |
| Calculs en double (projets × factures, devis × factures) | Index par projet / devis | — |
| Un import de 500 fiches effaçait les 1000 lignes d'historique | 60 lignes détaillées au plus par passage + 1 ligne « N modifications regroupées » | 500 créations → 61 lignes |
| Suivi des modifications : toutes les collections ré-analysées toutes les 5 s | Comparaison rapide du texte brut d'abord ; une collection illisible n'arrête pas les autres | — |
| Les contrôles automatiques gelaient l'écran avec beaucoup de données | `EXBI.runAsync()` : tranches de ≈ 12 ms, demandes en rafale fusionnées, même résultat que `run()` (vérifié) ; utilisé pour les relances automatiques | — |
| Stockage de l'appareil plein : l'historique n'était plus enregistré (sans message) | Repli : on garde les 300 puis 80 dernières lignes | — |
| **Assistant** : les lots 1, 7 et 8 s'enveloppaient mutuellement à chaque passage ; la chaîne passait de 2 à 10 niveaux | Registre partagé `w.__exbAIHooks` : chaque lot s'accroche une seule fois | profondeur 10 → 5 |

## Nouveau : file de tâches `EXBI.tasks`
- **Priorités** critique / haute / normale / basse, avec vieillissement (+1 niveau par minute d'attente : rien ne reste bloqué).
- **Fusion** : trois demandes identiques = une exécution (la plus urgente et la plus récente gagnent).
- **Une tâche à la fois** par défaut (`setConcurrency(1..3)`), l'écran respire entre deux tâches.
- **Délai maximum** par tâche (30 s par défaut), **nouvelles tentatives** espacées (×2 à chaque essai), **disjoncteur** : 3 échecs de suite → ce type de tâche est suspendu 5 min, les autres continuent.
- **Attente automatique** hors connexion (`needsNet`) et, pour les tâches basses, onglet masqué.
- **Plafond de 200 tâches** : les moins urgentes sont écartées en premier, jamais une tâche critique.
- Pause / reprise / annulation / vidage ; `status()`, `idle()`, `log()`.
- `EXBI.tasks.batch(éléments, fonction, {budget, onProgress})` : traite de très gros volumes par tranches, avec progression et `.cancel()` (20 000 éléments testés).

## Nouveau : plusieurs demandes dans un seul message (assistant)
« Ouvre les clients puis importe les demandes ; fais une sauvegarde » → trois demandes traitées dans l'ordre, trois actions proposées (8 au plus, doublons fusionnés), parties non comprises signalées sans bloquer le reste. Séparateurs : retour à la ligne, `;`, « puis », « ensuite », « et puis », « et aussi », « après cela ». Un texte à rédiger (message, mail, lettre) n'est **jamais** découpé. **Les autorisations restent celles de Paramètres › Assistant IA** : chaque action est Interdite / à valider / automatique selon vos réglages ; rien n'est contourné. Question « charge du moteur ? » → état local.

## Panneau 🧠 › Moteurs
Charge de la file (par priorité), contrôles les plus lents, contrôles en erreur, volume des données, dernières tâches ; boutons Pause / Reprendre / Vider. Recommandation 🛠 si un contrôle ou une tâche est en difficulté.

## Limites levées (version finale)
- **Tâches qui survivent à la fermeture** : `EXBI.tasks.define('nom', fn)` puis `add({name:'nom', args:{…}})`. Les tâches nommées en attente sont gardées dans `exb_intel_tasks_pending` (100 au plus) et reprises à la réouverture, avec leurs arguments (testé : fermeture simulée, reprise, retrait de la liste).
- **Lots 7 et 8 sur la même file** : le suivi de sécurité (5 s) et l'analyse de la réception (60 s) passent par `EXBI.tasks` (disjoncteur, délai maximum, une tâche à la fois). Sans le lot 9, ils fonctionnent comme avant.
- **Échec de `check.js`** : le test `licence-config` attendait un commentaire périmé (`requireToken:false`) alors que votre licence est volontairement `true`. J'ai corrigé le **test**, pas la licence : `check.js` donne maintenant 518 réussis, 0 échec.

## Réserves restantes
- Une tâche non nommée (fonction directe) reste en mémoire : perdue à la fermeture de la page.
- Un délai dépassé n'arrête pas la fonction (le navigateur ne le permet pas) : la file avance et ignore le résultat tardif.
- Le découpage des demandes est une règle de lecture : une phrase inhabituelle est traitée comme avant, sans découpage.
- Mesures en navigateur simulé (Node), pas sur téléphone ni avec votre Supabase.

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-9.js">` de index.html. Les correctifs du moteur sont inoffensifs s'ils restent.
