# V120m — Recherche robuste, mise à jour automatique, démarrage silencieux

## 1. Notification « Intégration Enterprise V97 prête »
Supprimée : plus aucun message au démarrage (`exb-v97-integration.js`). Elle ne s'affiche que si on la demande explicitement (`EXB_V97.validate(true)`).

## 2. Barre de recherche : plus de blocages
**Cause** : à chaque touche tapée, la recherche relisait, décodait et analysait d'un seul bloc ~28 collections (participants, clients, devis, TFL…). Plus les données grandissaient, plus l'écran se figeait « par moments ».
**Correctifs** (`exb-recherche-globale.js`) :
- index en mémoire, reconstruit uniquement quand les données changent (préparé en arrière-plan 6 s après l'ouverture) ;
- calcul découpé en tranches de ~10 ms : l'écran, la saisie et le défilement restent fluides ;
- anti-rebond (on cherche quand la frappe se calme) ; une nouvelle frappe annule la recherche en cours ;
- au plus 500 résultats collectés (60 affichés) ; message « Recherche en cours… » ; toute erreur est contenue (la barre ne reste jamais bloquée).
Mesure (8 000 fiches, frappe réelle) : 7 blocages de ~60 ms avant, 0 après ; mêmes résultats.

## 3. Mise à jour automatique sans fermer l'écran
Nouveau `exb-maj-auto.js` :
- vérifie toute seule (20 s après l'ouverture, toutes les 20 min, au retour sur l'appli, au retour du réseau ; jamais en mode économie de données / 2G / hors connexion) ;
- la nouvelle version se télécharge et s'installe en arrière-plan ; **rien n'est rechargé pendant que vous travaillez** ;
- elle s'applique quand l'application est en arrière-plan (30 s) ou inactive (2 min), sans champ en saisie, sans fenêtre ouverte ; sinon au prochain démarrage ;
- au plus un rechargement toutes les 10 min (aucune boucle) ;
- une ligne discrète dans la liste de la cloche (aucune fenêtre).
Testé : mise à jour détectée, 0 rechargement avec un champ actif, 1 rechargement au repos, aucune erreur.
Limite : ne concerne que la version navigateur/PWA (https) ; l'installateur Windows et l'APK se mettent à jour en installant le nouveau fichier.

Fichiers : `exb-recherche-globale.js`, `exb-v97-integration.js`, `exb-maj-auto.js` (nouveau), `index.html`, `sw.js`.
