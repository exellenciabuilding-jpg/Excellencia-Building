# V122f — Fusion des modifications « V121 accès immédiat » dans V122e

Seul le logiciel central (dossier `site`) est modifié : index.html, espace-apprenant.html, inscription.html, sw.js.

## Repris de modifs-v121
- Bouton « 📢 Publier les résultats (semestre / finale) » : réservé aux résultats de fin de semestre et finaux ; les TP / TD en sont exclus (textes de l'invite et de la confirmation mis à jour).
- Notes de TP / TD : publiées automatiquement pour TOUTES les évaluations de type TP / TD / travail (en ligne ou saisies dans le logiciel). Rubrique « Notes de TP / TD » dans Mes résultats.
- L'espace apprenant s'ouvre tout seul depuis le logiciel connecté : plus besoin du premier clic sur « Publier l'espace apprenant » (numéro WhatsApp repris du dernier reçu ; modifiable ensuite par ce bouton).
- Espace apprenant : messages vides reformulés (« apparaîtront automatiquement »), rafraîchissement automatique toutes les 90 s, matricule prérempli via `?m=`.
- inscription.html : le bouton « Accéder à mon espace apprenant » ouvre l'espace avec le matricule prérempli.
- sw.js : cache v122f (force le rechargement).

## Non repris (V122e fait déjà mieux ou l'inverse serait une régression)
- Bouton « Installer l'application » de l'espace apprenant et manifeste d'application (interdits depuis V121d / V122c).
- Script SQL `migration-v121-acces-immediat.sql` : V122e contient déjà `migration-v121-acces-direct-inscription.sql` (même effet, plus robuste). Ne pas exécuter les deux.
- Anciennes listes de scripts de index.html et de sw.js (V122e contient les modules plus récents).

## À faire
Redéployer `site` sur Netlify, recharger le logiciel. `node tools/check.js` : 535 contrôles, 0 échec. Non testé sur un vrai Supabase.
