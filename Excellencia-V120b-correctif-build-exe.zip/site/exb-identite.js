/* exb-identite.js (V99k) — UNE SEULE identité pour tous les documents remis au client.
 * Nom, slogan, téléphone, e-mail, adresse, logo, mentions légales, lieu de signature, signature + cachet.
 * Utilisé automatiquement par : devis (métré + devis rapide), fiches du personnel, dossiers/fiches participants,
 * rapports, exports PDF (EXBPdf) et impressions. Aucune donnée n'est envoyée en ligne. */
window.EXBId = (function () {
  'use strict';
  var KEY = 'EXB_IDENTITE_V1';
  var ORIGIN = 'Excellencia Building';
  /* valeurs d'origine de l'application (déjà présentes dans l'affiche : Kinshasa, RDC / téléphone / e-mail) */
  var BASE = { phone: '+243 810 644 554', email: 'Excellenciabuilding@gmail.com', address: 'Kinshasa, RDC', country: 'République Démocratique du Congo', tag: 'Ingénierie & Construction', dg: 'Ir Ibwampere Ngwala Louis' };

  function own() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function setExtra(p) { var s = own(); Object.keys(p).forEach(function (k) { s[k] = p[k]; }); try { localStorage.setItem(KEY, JSON.stringify(s)); return true; } catch (e) { return false; } }
  function s(v) { return String(v == null ? '' : v).trim(); }

  function get() {
    var B = window.EXB_BRAND || {}, g = {}, p = {}, o = own();
    try { g = (typeof getBrand === 'function' && getBrand()) || {}; } catch (e) {}
    try { p = (typeof load === 'function' && load('exb_poster_data', null)) || {}; } catch (e) {}
    var name = s(B.name) && s(B.name) !== ORIGIN ? s(B.name) : (s(g.name) || s(B.name) || ORIGIN);
    var original = name.toLowerCase() === ORIGIN.toLowerCase();
    var logo = '';
    if (s(B.logo)) logo = B.logo; else { try { logo = typeof getLogo === 'function' ? getLogo('exb') : ''; } catch (e) {} }
    if (!logo && original) logo = 'icon-192.png';  /* une entreprise cliente sans logo n'affiche jamais celui de l'éditeur d'origine */
    var phone = s(o.phone) || s(B.phone) || s(p.p_contact_phone) || (original ? BASE.phone : '');
    var email = s(o.email) || s(B.email) || s(p.p_contact_email) || (original ? BASE.email : '');
    var address = s(o.address) || s(B.address) || s(p.p_contact_address) || (original ? BASE.address : '');
    return {
      name: name,
      tagline: s(B.tagline) || (original ? BASE.tag : ''),
      phone: phone, email: email, address: address,
      country: s(B.country) || (original ? BASE.country : ''),
      logo: logo,
      legal: s(o.legal), footer: s(o.footer), website: s(o.website),
      dg: s(o.dg) || (original ? BASE.dg : ''),
      dgRole: s(o.dgRole) || 'Directeur Général',
      city: s(o.city) || (original ? 'Kinshasa' : '')
    };
  }
  function contactLine(I) { I = I || get(); return [I.phone ? 'Tél : ' + I.phone : '', I.email ? 'E-mail : ' + I.email : ''].filter(Boolean).join('   ·   '); }
  function placeLine(I) { I = I || get(); var a = I.address, c = I.country; return [a, c && (!a || a.toLowerCase().indexOf(c.toLowerCase()) < 0) ? c : ''].filter(Boolean).join(', '); }
  function legalLine(I) { I = I || get(); return I.legal ? I.legal.split(/\r?\n+/).map(function (x) { return x.trim(); }).filter(Boolean).join('  ·  ') : ''; }

  /* Nom du Directeur Général : une seule saisie, reprise partout (reçus, certificats, devis, factures, PDF). */
  function applyDg(force) {
    var I = get(), nm = I.dg; if (!nm) return;
    [].forEach.call(document.querySelectorAll('.exb-dg'), function (e) { e.textContent = nm; });
    var inp = document.getElementById('director');
    if (inp) { if (!inp.dataset.dgBound) { inp.dataset.dgBound = '1'; inp.addEventListener('input', function () { inp.dataset.touched = '1'; }); } if (force || inp.dataset.touched !== '1') inp.value = nm; }
  }
  (function () { var n = 0, t = setInterval(function () { n++; try { applyDg(false); } catch (e) {} if (n > 12) clearInterval(t); }, 700); })();

  /* signature + cachet de l'administrateur (PNG transparent), mis en cache le temps d'une action */
  function visa() { try { if (window.EXBSign && EXBSign.active()) return EXBSign.visa('png'); } catch (e) {} return Promise.resolve(''); }

  /* petit bloc de réglage dans « Logo Excellencia Building » (à côté de la signature et du cachet) */
  function buildUi() {
    var anchor = document.getElementById('exbSignAuto');
    if (!anchor || document.getElementById('exbIdBox')) return !!document.getElementById('exbIdBox');
    var host = anchor.closest('label'); if (!host) return false;
    var o = own(), I = get();
    var box = document.createElement('div'); box.id = 'exbIdBox';
    box.style.cssText = 'margin-top:14px;padding:12px;border:1px solid #cbd5e1;border-radius:10px;background:#f8fafc';
    function esc(v) { return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;'); }
    box.innerHTML = '<b>🧾 Identité imprimée sur les devis, fiches et documents clients</b>' +
      '<div class="hint" style="margin:4px 0 8px">Ces informations apparaissent automatiquement dans l\'en-tête et le pied de page de tous les documents remis au client.</div>' +
      '<label>Nom du Directeur Général (imprimé sous la signature des reçus, certificats, devis, factures…)</label><input id="exbIdDg" value="' + esc(I.dg) + '" placeholder="Ir Prénom Nom"/>' +
      '<label>Fonction</label><input id="exbIdDgRole" value="' + esc(I.dgRole) + '"/>' +
      '<label>Téléphone</label><input id="exbIdPhone" value="' + esc(I.phone) + '"/>' +
      '<label>E-mail</label><input id="exbIdEmail" value="' + esc(I.email) + '"/>' +
      '<label>Adresse</label><input id="exbIdAddress" value="' + esc(I.address) + '"/>' +
      '<label>Ville de signature (« Fait à … »)</label><input id="exbIdCity" value="' + esc(I.city) + '"/>' +
      '<label>Mentions légales (RCCM, Id. Nat., N° impôt, banque… — une ligne par information)</label><textarea id="exbIdLegal" rows="3" style="width:100%;box-sizing:border-box">' + esc(o.legal || '') + '</textarea>' +
      '<button type="button" class="gold" id="exbIdSave" style="margin-top:10px">Enregistrer l\'identité des documents</button><div class="hint" id="exbIdMsg"></div>';
    host.parentNode.insertBefore(box, host.nextSibling);
    document.getElementById('exbIdSave').onclick = function () {
      var ok = setExtra({
        phone: document.getElementById('exbIdPhone').value, email: document.getElementById('exbIdEmail').value,
        address: document.getElementById('exbIdAddress').value, city: document.getElementById('exbIdCity').value,
        legal: document.getElementById('exbIdLegal').value,
        dg: document.getElementById('exbIdDg').value.trim(), dgRole: document.getElementById('exbIdDgRole').value.trim()
      });
      applyDg(true);
      var m = document.getElementById('exbIdMsg'); if (m) m.textContent = ok ? '✓ Identité enregistrée : elle sera utilisée sur tous les prochains documents.' : 'Enregistrement impossible (espace de stockage plein).';
      try { if (window.EXBMetre && EXBMetre.refreshVisa) EXBMetre.refreshVisa(); } catch (e) {}
    };
    return true;
  }
  (function () { var n = 0, t = setInterval(function () { n++; try { if (buildUi() || n > 600) clearInterval(t); } catch (e) { if (n > 600) clearInterval(t); } }, 800); })();

  return { get: get, applyDg: applyDg, setExtra: setExtra, contactLine: contactLine, placeLine: placeLine, legalLine: legalLine, visa: visa };
})();
