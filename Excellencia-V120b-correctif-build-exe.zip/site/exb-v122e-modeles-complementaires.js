/* Excellencia Building V122e — Modèles complémentaires pour « Documents de chantier » / « Pièces écrites ».
 * Chargé APRÈS exb-v122-pieces-chantier.js et AVANT exb-v81-pieces.js.
 * Ajoute des modèles aux familles existantes (rapports, PV, comptes rendus, ordres de service, clauses, fiches,
 * lettres, contrats, attestations, notes, dossier) sans jamais remplacer un modèle déjà présent (même nom = l’ancien est conservé).
 * Mise en forme : « # Titre », « ## Sous-titre », « - puce », « 1. numéro », « | a | b | » (1re ligne = en-tête), **gras**.
 * Variables autorisées : {{projet}} {{client}} {{moa}} {{lieu}} {{permis}} {{societe}} {{phase}} {{date}} {{date_effet}}
 * {{entreprise}} {{lot}} {{objet}} {{no}} {{destinataire}} {{dg}} {{ville}} {{pays}}…
 * Les clauses et textes réglementaires sont des bases courantes : à faire valider par votre conseil juridique et à adapter à la réglementation locale. */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA;
  if (!D) return;

  var HD = function (t) {
    return '# ' + t + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}\nDate : {{date_effet}}\n';
  };
  var FT = '\n\nFait à {{ville}}, le {{date}}';
  var PVH = '# PROCÈS-VERBAL DE ';
  var PVB = '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}\nDate : {{date_effet}}\n';
  var SAL = 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.';
  var SIMPLE = function (t, body) { return HD(t) + '\n' + body + FT; };
  var ROWS = function (n, cols) {
    var r = '|', i; for (i = 0; i < cols; i++) r += ' ____________ |';
    var o = []; for (i = 0; i < n; i++) o.push(r); return o.join('\n');
  };
  var CK = function (t, pts) {
    return HD('FICHE DE CONTRÔLE — ' + t) + '\n| Point à contrôler | Référence (plan / CCTP) | Conforme | Observation |\n' +
      pts.map(function (p) { return '| ' + p + ' | ____________ | oui / non | ____________ |'; }).join('\n') +
      '\n## Décision\nContrôle satisfaisant / à reprendre avant le ____________\nContrôlé par : ____________ — fonction : ____________' + FT;
  };
  var CRH = function (t, pts) {
    return '# COMPTE RENDU — ' + t + '\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}} · Lieu : {{lieu}}\n## Participants\n| Nom | Fonction / entreprise | Présent |\n| ____________ | ____________ | oui / non |\n| ____________ | ____________ | oui / non |\n## Ordre du jour\n' +
      pts.map(function (p, i) { return (i + 1) + '. ' + p; }).join('\n') +
      '\n## Décisions et actions\n| N° | Décision / action | Responsable | Échéance |\n| 1 | ____________ | ____________ | ____ |\n| 2 | ____________ | ____________ | ____ |\nProchaine réunion : ____________' + FT;
  };
  var OSH = '# ORDRE DE SERVICE N° {{no}}\nNature : ';
  var OSB = '\nProjet : {{projet}} — Lot : {{lot}}\nÀ l’attention de : {{entreprise}}\n\n';
  var CL = function (t, items) {
    return '# ' + t + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}}\n\n' +
      items.map(function (x, i) { return '## Article ' + (i + 1) + ' — ' + x[0] + '\n' + x[1]; }).join('\n') +
      '\n\nLes présentes clauses s’appliquent au marché relatif à {{objet}}, à compter du {{date_effet}}.';
  };
  var LT = function (objet, corps) {
    return 'Objet : ' + objet + '\n\nMadame, Monsieur,\n\n' + corps + '\n\n' + SAL;
  };

  /* ===================== RAPPORTS ===================== */
  var RAP = {
'Rapport de terrassement et de fouilles': SIMPLE('RAPPORT DE TERRASSEMENT ET DE FOUILLES',
'## Données\n| Élément | Prévu | Réalisé |\n| Volume de déblais (m³) | ____ | ____ |\n| Volume de remblais (m³) | ____ | ____ |\n| Profondeur des fouilles (m) | ____ | ____ |\n| Évacuation des terres (voyages) | ____ | ____ |\n## Nature du sol rencontré\n- ____________________\n## Eaux, blindages et sécurité des fouilles\n- ____________________\n## Anomalies et décisions\n- ____________________'),
'Rapport de réception du ferraillage avant coulage': SIMPLE('RAPPORT DE RÉCEPTION DU FERRAILLAGE',
'Ouvrage : {{objet}}\n| Élément | Diamètres / nombre | Enrobage (mm) | Recouvrements | Conforme |\n' + ROWS(4, 5) + '\n## Conclusion\nAutorisation de coulage : accordée / refusée — réserves : ____________'),
'Rapport de suivi des délais et du planning': SIMPLE('RAPPORT DE SUIVI DES DÉLAIS',
'Date de démarrage : ____________ · Délai contractuel : ____ jours · Date de fin contractuelle : ____________\n## Avancement\n| Tâche | Début prévu | Fin prévue | Fin réelle / estimée | Écart (jours) |\n' + ROWS(5, 5) + '\n## Causes des écarts\n- ____________________\n## Mesures de rattrapage\n- ____________________'),
'Rapport de suivi budgétaire du chantier': SIMPLE('RAPPORT DE SUIVI BUDGÉTAIRE',
'| Poste | Budget initial | Engagé | Payé | Reste à engager | Écart |\n| Main-d’œuvre | ____ | ____ | ____ | ____ | ____ |\n| Matériaux | ____ | ____ | ____ | ____ | ____ |\n| Matériel et engins | ____ | ____ | ____ | ____ | ____ |\n| Sous-traitance | ____ | ____ | ____ | ____ | ____ |\n| Frais généraux | ____ | ____ | ____ | ____ | ____ |\n## Analyse\nMarge prévisionnelle : ____ % — dérives identifiées : ____________\n## Actions correctives\n- ____________________'),
'Rapport d’accident du travail': SIMPLE('RAPPORT D’ACCIDENT DU TRAVAIL',
'Date et heure : ____________ · Lieu précis : ____________\n## Victime\nNom : ____________ · Fonction : ____________ · Ancienneté : ____\n## Circonstances\n____________________\n## Lésions et soins prodigués\n____________________\n## Causes identifiées\n- Causes immédiates : ____________\n- Causes profondes : ____________\n## Témoins\n' + ROWS(2, 2) + '\n## Mesures prises pour éviter la répétition\n- ____________________\nDéclaration aux autorités / à l’assureur : faite le ____________'),
'Rapport de contrôle des échafaudages et équipements de levage': SIMPLE('RAPPORT DE CONTRÔLE DES ÉCHAFAUDAGES ET DU LEVAGE',
'| Équipement | Localisation | Vérifié le | État | Action |\n' + ROWS(4, 5) + '\nOuvrage interdit d’utilisation tant que les anomalies relevées ne sont pas corrigées.'),
'Rapport de consommation de matériaux et de carburant': SIMPLE('RAPPORT DE CONSOMMATION',
'Période : du ____________ au ____________\n| Désignation | Unité | Stock initial | Entrées | Sorties | Stock final |\n| Ciment | sacs | ____ | ____ | ____ | ____ |\n| Fer à béton | barres | ____ | ____ | ____ | ____ |\n| Sable / gravier | m³ | ____ | ____ | ____ | ____ |\n| Gasoil | litres | ____ | ____ | ____ | ____ |\n## Écarts et explications\n- ____________________'),
'Rapport de levée de réserves': SIMPLE('RAPPORT DE LEVÉE DE RÉSERVES',
'| N° | Réserve | Localisation | Corrigée le | Vérifiée par | Statut |\n' + ROWS(5, 6) + '\nRéserves restant à lever : ____ — nouveau délai : ____________'),
'Rapport de sous-traitant': SIMPLE('RAPPORT D’ACTIVITÉ D’UN SOUS-TRAITANT',
'Sous-traitant : ____________ · Nature des travaux : {{objet}}\n| Poste | Quantité réalisée | Avancement | Qualité (A/B/C) |\n' + ROWS(4, 4) + '\n## Respect des délais, de la sécurité et des consignes\n- ____________________\n## Appréciation générale\n____________________'),
'Rapport d’activité du mois (direction)': SIMPLE('RAPPORT D’ACTIVITÉ POUR LA DIRECTION',
'## Faits marquants\n- ____________________\n## Chiffres clés\n| Indicateur | Valeur |\n| Chantiers en cours | ____ |\n| Effectif total | ____ |\n| Chiffre d’affaires facturé | ____ |\n| Encaissements | ____ |\n| Accidents / incidents | ____ |\n## Décisions demandées à la direction\n- ____________________')
  };

  /* ===================== PROCÈS-VERBAUX ===================== */
  var PV = {
'Réception de la charpente et de la couverture': PVH + 'RÉCEPTION DE LA CHARPENTE ET DE LA COUVERTURE' + PVB + '\n| Élément | Constat | Conforme |\n| Charpente (assemblages, contreventement) | ____________ | oui / non |\n| Couverture (fixations, recouvrements) | ____________ | oui / non |\n| Évacuation des eaux pluviales | ____________ | oui / non |\nRéserves : ____________' + FT,
'Réception de l’étanchéité (essai d’eau)': PVH + 'RÉCEPTION DE L’ÉTANCHÉITÉ' + PVB + '\nEssai de mise en eau réalisé du ____________ au ____________ (durée : ____ heures).\nRésultat : aucune fuite constatée / fuites constatées à : ____________\nDécision : ouvrage accepté / à reprendre avant le ____________' + FT,
'Réception du lot menuiseries': PVH + 'RÉCEPTION DU LOT MENUISERIES' + PVB + '\n| Ouvrage | Quantité | Fonctionnement | Défauts |\n' + ROWS(4, 4) + '\nRéserves : ____________' + FT,
'Réception de la plomberie (essai de pression)': PVH + 'RÉCEPTION DE LA PLOMBERIE' + PVB + '\nEssai de pression : ____ bar pendant ____ heures — chute de pression : ____\nÉvacuations : écoulement correct / défauts : ____________\nDécision : réception prononcée / réserves : ____________' + FT,
'Réception de l’installation électrique': PVH + 'RÉCEPTION DE L’INSTALLATION ÉLECTRIQUE' + PVB + '\n| Contrôle | Résultat |\n| Continuité de la terre | ____ Ω |\n| Isolement des circuits | ____ MΩ |\n| Fonctionnement des disjoncteurs différentiels | ____________ |\n| Repérage du tableau | ____________ |\nDécision : réception prononcée / réserves : ____________' + FT,
'Réception de la dalle et de la chape': PVH + 'RÉCEPTION DE LA DALLE ET DE LA CHAPE' + PVB + '\n| Contrôle | Tolérance | Mesuré |\n| Planéité (règle de 2 m) | ____ mm | ____ mm |\n| Niveau fini | ± ____ mm | ____ mm |\n| Fissuration | aucune / légère | ____________ |\nDécision : accepté / à reprendre : ____________' + FT,
'Réception des clôtures et aménagements extérieurs': PVH + 'RÉCEPTION DES AMÉNAGEMENTS EXTÉRIEURS' + PVB + '\n| Ouvrage | Longueur / surface | Constat |\n' + ROWS(4, 3) + '\nRéserves : ____________' + FT,
'Constat de livraison non conforme': PVH + 'CONSTAT DE LIVRAISON NON CONFORME' + PVB + '\nFournisseur : ____________ · Bon de livraison n° ____________\n| Désignation | Quantité commandée | Quantité livrée | Anomalie |\n' + ROWS(3, 4) + '\nDécision : refus / acceptation sous réserve / retour au fournisseur' + FT,
'Constat d’abandon de poste ou de chantier': PVH + 'CONSTAT D’ABANDON DE POSTE' + PVB + '\nIl est constaté que ____________ (nom, fonction) n’a pas rejoint son poste depuis le ____________.\nLes témoins soussignés confirment cet état de fait.' + FT,
'Mise en service et formation à l’utilisation': PVH + 'MISE EN SERVICE ET FORMATION' + PVB + '\nÉquipement / installation : {{objet}}\nMise en service effectuée le ____________ ; essais satisfaisants : oui / non.\nPersonnel formé : ____________ (durée : ____ h). Notices remises : oui / non.' + FT,
'Prise de possession anticipée': PVH + 'PRISE DE POSSESSION ANTICIPÉE' + PVB + '\nLe maître d’ouvrage prend possession de : ____________ avant la réception définitive de l’ensemble.\nÉtat des lieux : ____________\nCette prise de possession ne vaut pas réception de l’ensemble des travaux.' + FT,
'Visite préalable à la réception (pré-réception)': PVH + 'PRÉ-RÉCEPTION' + PVB + '\n| Local / ouvrage | Défaut relevé | À corriger avant le |\n' + ROWS(6, 3) + '\nUne visite de contrôle sera organisée le ____________ avant la réception.' + FT
  };

  /* ===================== COMPTES RENDUS ===================== */
  var CR = {
'Réunion de démarrage avec les sous-traitants': CRH('RÉUNION DE DÉMARRAGE AVEC LES SOUS-TRAITANTS', ['Présentation du projet et des interfaces', 'Planning d’intervention', 'Règles de sécurité et accueil', 'Modalités de facturation']),
'Réunion de suivi budgétaire': CRH('RÉUNION DE SUIVI BUDGÉTAIRE', ['Avancement des dépenses', 'Écarts constatés', 'Travaux supplémentaires en cours', 'Prévisions de trésorerie']),
'Réunion de coordination avec les concessionnaires': CRH('RÉUNION AVEC LES CONCESSIONNAIRES (EAU, ÉLECTRICITÉ)', ['Raccordements prévus', 'Autorisations et délais', 'Travaux préalables à charge de chacun', 'Calendrier d’intervention']),
'Réunion de levée de réserves': CRH('RÉUNION DE LEVÉE DE RÉSERVES', ['Revue de la liste des réserves', 'Réserves levées', 'Réserves restantes et délais', 'Date de la visite de contrôle']),
'Réunion de quart d’heure sécurité': CRH('QUART D’HEURE SÉCURITÉ', ['Rappel des risques du jour', 'Équipements de protection individuelle', 'Retour sur les incidents récents', 'Questions du personnel']),
'Réunion de clôture financière': CRH('RÉUNION DE CLÔTURE FINANCIÈRE', ['Décompte général et définitif', 'Retenues et pénalités éventuelles', 'Libération de la retenue de garantie', 'Solde du marché'])
  };

  /* ===================== ORDRES DE SERVICE ===================== */
  var OS = {
'Modification du programme d’exécution': OSH + 'MODIFICATION DU PROGRAMME D’EXÉCUTION' + OSB + 'Le programme d’exécution est modifié comme suit : ____________\nMotif : ____________\nCette modification ne change pas le délai contractuel / modifie le délai de ____ jours.' + FT,
'Évacuation des déblais et nettoyage': OSH + 'ÉVACUATION DES DÉBLAIS ET NETTOYAGE' + OSB + 'L’entreprise évacue les déblais et débris stockés à ____________ avant le ____________ et remet le site en état de propreté.' + FT,
'Mise en place de mesures de sécurité renforcées': OSH + 'MESURES DE SÉCURITÉ RENFORCÉES' + OSB + 'Suite à ____________, l’entreprise met en œuvre immédiatement : ____________\nLes travaux concernés restent suspendus jusqu’à la vérification des mesures.' + FT,
'Remplacement de personnel ou de sous-traitant': OSH + 'REMPLACEMENT DE PERSONNEL OU DE SOUS-TRAITANT' + OSB + 'Pour le motif suivant : ____________, il est demandé à l’entreprise de remplacer ____________ avant le ____________.' + FT,
'Réalisation d’essais de laboratoire': OSH + 'ESSAIS DE LABORATOIRE' + OSB + 'L’entreprise fait réaliser les essais suivants par un laboratoire agréé : ____________\nLes résultats sont transmis avant le ____________.' + FT,
'Exécution de reprises de désordres': OSH + 'REPRISE DE DÉSORDRES' + OSB + 'Les désordres décrits en annexe (____________) sont à reprendre avant le ____________, aux frais de l’entreprise.' + FT,
'Prise en compte d’une modification de plan': OSH + 'MODIFICATION DE PLAN' + OSB + 'Les plans indice ____ remplacent les plans indice ____. Les ouvrages déjà exécutés seront vérifiés : ____________' + FT,
'Interdiction d’accès à une zone': OSH + 'INTERDICTION D’ACCÈS À UNE ZONE' + OSB + 'L’accès à la zone ____________ est interdit à compter du ____________ pour le motif suivant : ____________' + FT
  };

  /* ===================== CLAUSES ===================== */
  var CLA = {
'Clauses de garantie décennale et de parfait achèvement': CL('CLAUSES DE GARANTIES APRÈS RÉCEPTION', [
  ['Garantie de parfait achèvement', 'L’entreprise répare, pendant un an à compter de la réception, tous les désordres signalés par le maître d’ouvrage, par notification écrite.'],
  ['Garantie des éléments d’équipement', 'Les éléments d’équipement dissociables sont garantis pendant ____ an(s) à compter de la réception.'],
  ['Garantie décennale', 'L’entreprise reste responsable, pendant ____ ans à compter de la réception, des dommages compromettant la solidité de l’ouvrage ou le rendant impropre à sa destination, dans les limites prévues par la loi applicable.'],
  ['Assurance', 'L’entreprise justifie des assurances couvrant ces responsabilités avant le démarrage des travaux.']]),
'Clauses de fourniture et d’approvisionnement des matériaux': CL('CLAUSES DE FOURNITURE DES MATÉRIAUX', [
  ['Origine et qualité', 'Les matériaux sont neufs, conformes aux normes et aux spécifications du CCTP. L’entreprise fournit les fiches techniques sur demande.'],
  ['Échantillons et agrément', 'Aucun matériau n’est mis en œuvre sans agrément préalable écrit du maître d’ouvrage ou de son représentant.'],
  ['Stockage', 'L’entreprise stocke les matériaux à l’abri de l’humidité, du soleil et des vols. Les matériaux détériorés sont évacués.'],
  ['Rebut', 'Les matériaux refusés sont évacués dans un délai de ____ jours, à la charge de l’entreprise.']]),
'Clauses de qualité et d’essais du béton': CL('CLAUSES DE QUALITÉ ET D’ESSAIS DU BÉTON', [
  ['Composition', 'La composition du béton (classe, dosage, rapport E/C) est soumise à l’agrément avant le premier coulage.'],
  ['Prélèvements', 'Des éprouvettes sont prélevées à chaque coulage structurel, à raison de ____ éprouvettes par ____ m³. Les essais d’écrasement sont réalisés à 7 et 28 jours.'],
  ['Mise en œuvre', 'La vibration, la cure et le décoffrage respectent les délais du CCTP.'],
  ['Non-conformité', 'Un béton non conforme est repris, renforcé ou démoli aux frais de l’entreprise, selon la décision du maître d’œuvre.']]),
'Clauses de réception des ouvrages et de levée des réserves': CL('CLAUSES DE RÉCEPTION ET DE LEVÉE DES RÉSERVES', [
  ['Demande de réception', 'L’entreprise informe par écrit le maître d’ouvrage de l’achèvement des travaux. La visite a lieu sous ____ jours.'],
  ['Procès-verbal', 'La réception est constatée par un procès-verbal signé des parties, avec ou sans réserves.'],
  ['Levée des réserves', 'Les réserves sont levées dans le délai fixé au procès-verbal. À défaut, le maître d’ouvrage peut faire exécuter les travaux aux frais de l’entreprise après mise en demeure.']]),
'Clauses de transport, de manutention et de stockage': CL('CLAUSES DE TRANSPORT ET DE MANUTENTION', [
  ['Transport', 'Le transport des matériaux jusqu’au chantier est à la charge de ____________. Le déchargement est sous la responsabilité de l’entreprise.'],
  ['Manutention', 'Les engins de levage sont conduits par un personnel qualifié et contrôlé.'],
  ['Stockage', 'Les aires de stockage sont définies avec le maître d’œuvre et ne gênent ni la circulation ni les voisins.']]),
'Clauses de pénalités et de primes': CL('CLAUSES DE PÉNALITÉS ET DE PRIMES', [
  ['Pénalités de retard', 'En cas de retard, une pénalité de ____ ‰ du montant du marché par jour calendaire est appliquée, plafonnée à ____ % du marché.'],
  ['Pénalités de manquement', 'L’absence aux réunions, le non-respect des consignes de sécurité ou de propreté peuvent donner lieu à une pénalité forfaitaire de ____ par constat.'],
  ['Prime d’avance', 'Une prime de ____ par jour d’avance sur le délai contractuel peut être accordée si la qualité est conforme.']]),
'Clauses relatives à la propriété intellectuelle et aux plans': CL('CLAUSES SUR LES PLANS ET DOCUMENTS', [
  ['Propriété', 'Les plans, notes de calcul et documents d’étude restent la propriété de leur auteur jusqu’au paiement intégral.'],
  ['Usage', 'Le maître d’ouvrage peut utiliser les documents pour la réalisation, l’exploitation et l’entretien de l’ouvrage.'],
  ['Diffusion', 'Toute diffusion à un tiers ou réutilisation pour un autre projet nécessite l’accord écrit de l’auteur.']]),
'Clauses de résolution amiable des difficultés': CL('CLAUSES DE RÉSOLUTION AMIABLE', [
  ['Notification', 'Toute difficulté est notifiée par écrit à l’autre partie, avec exposé des faits et des demandes.'],
  ['Réunion de conciliation', 'Les parties se réunissent dans un délai de ____ jours pour rechercher une solution amiable.'],
  ['Suite', 'À défaut d’accord sous ____ jours, les parties appliquent la clause de règlement des litiges du marché.']]),
'Clauses de sécurité des tiers et de signalisation': CL('CLAUSES DE SÉCURITÉ DES TIERS', [
  ['Clôture et signalisation', 'Le chantier est clôturé, signalé et éclairé pour interdire l’accès aux tiers.'],
  ['Circulation', 'Les entrées et sorties d’engins sont organisées avec un homme trafic en cas de besoin.'],
  ['Responsabilité', 'L’entreprise est responsable des dommages causés aux tiers du fait de son chantier.']])
  };

  /* ===================== FICHES ET FORMULAIRES ===================== */
  var FCH = {
'Fiche de contrôle — terrassement': CK('TERRASSEMENT', ['Implantation et niveaux', 'Profondeur et largeur des fouilles', 'Nature et portance du sol', 'Fond de fouille propre et compacté', 'Évacuation des eaux']),
'Fiche de contrôle — fondations': CK('FONDATIONS', ['Béton de propreté', 'Dimensions des semelles', 'Ferraillage et enrobage', 'Attentes de poteaux', 'Classe de béton']),
'Fiche de contrôle — poteaux et poutres': CK('POTEAUX ET POUTRES', ['Aplomb des poteaux', 'Section et ferraillage', 'Cadres et espacements', 'Coffrage étanche et étayé', 'Épaisseur d’enrobage']),
'Fiche de contrôle — dalle et plancher': CK('DALLE ET PLANCHER', ['Niveaux et épaisseur', 'Ferraillage et chaises', 'Réservations et fourreaux', 'Étaiement', 'Cure du béton']),
'Fiche de contrôle — toiture': CK('TOITURE', ['Pentes', 'Fixations', 'Recouvrements', 'Rives et faîtages', 'Évacuation des eaux pluviales']),
'Fiche de contrôle — menuiseries': CK('MENUISERIES', ['Dimensions conformes', 'Pose d’aplomb et de niveau', 'Fonctionnement', 'Quincaillerie et serrures', 'Étanchéité périphérique']),
'Fiche de contrôle — plâtrerie et faux plafonds': CK('PLÂTRERIE ET FAUX PLAFONDS', ['Ossature et fixations', 'Planéité', 'Joints et finition', 'Trappes de visite', 'Réservations pour luminaires']),
'Fiche de contrôle — climatisation et ventilation': CK('CLIMATISATION ET VENTILATION', ['Position des unités', 'Tuyauteries et isolation', 'Évacuation des condensats', 'Raccordement électrique', 'Essais de fonctionnement']),
'Fiche de contrôle — voirie et réseaux divers': CK('VOIRIE ET RÉSEAUX DIVERS', ['Niveaux et pentes', 'Compactage des couches', 'Regards et caniveaux', 'Raccordements', 'Épreuves d’étanchéité']),
'Fiche de contrôle — échafaudage': CK('ÉCHAFAUDAGE', ['Stabilité et calage', 'Ancrages', 'Garde-corps et plinthes', 'Planchers complets', 'Accès sécurisé']),
'Fiche de contrôle — engins et véhicules': CK('ENGINS ET VÉHICULES', ['Documents et conducteur habilité', 'Freins et direction', 'Éclairage et avertisseur', 'Fuites d’huile ou de carburant', 'Signalisation de recul']),
'Fiche de contrôle — équipements de protection individuelle': CK('ÉQUIPEMENTS DE PROTECTION INDIVIDUELLE', ['Casques', 'Chaussures de sécurité', 'Gilets haute visibilité', 'Gants et lunettes', 'Harnais antichute']),
'Permis de travail en hauteur': HD('PERMIS DE TRAVAIL EN HAUTEUR') + '\nTravaux : {{objet}} · Hauteur : ____ m\n| Mesure de sécurité | Mise en place |\n| Garde-corps / filet | oui / non |\n| Harnais et point d’ancrage | oui / non |\n| Balisage de la zone au sol | oui / non |\n| Conditions météo vérifiées | oui / non |\nValidité : du ____________ au ____________\nResponsable : ____________ — Exécutant : ____________' + FT,
'Permis de feu': HD('PERMIS DE FEU') + '\nNature des travaux (soudure, meulage, découpe) : ____________\n| Mesure | Mise en place |\n| Matériaux inflammables éloignés | oui / non |\n| Extincteur à proximité | oui / non |\n| Surveillance après travaux (30 min) | oui / non |\nValidité : ____________\nResponsable : ____________' + FT,
'Autorisation de fouille': HD('AUTORISATION DE FOUILLE') + '\nEmplacement : ____________ · Profondeur : ____ m\n| Vérification | Résultat |\n| Réseaux enterrés repérés | oui / non |\n| Blindage / talutage prévu | oui / non |\n| Balisage et clôture | oui / non |\nAutorisé par : ____________' + FT,
'Fiche de levage': HD('FICHE DE LEVAGE') + '\nCharge à lever : ____ kg · Engin : ____________ · Capacité à la portée : ____ kg\n| Vérification | Oui / non |\n| Élingues et accessoires contrôlés | ____ |\n| Zone de manœuvre balisée | ____ |\n| Signaleur désigné | ____ |\n| Vent inférieur au seuil admissible | ____ |\nResponsable de l’opération : ____________' + FT,
'Fiche de consignation électrique': HD('FICHE DE CONSIGNATION ÉLECTRIQUE') + '\nInstallation concernée : ____________\n1. Séparation de la source : ____________\n2. Condamnation en position ouverte : ____________\n3. Vérification d’absence de tension : ____________\n4. Mise à la terre et en court-circuit : ____________\nConsigné par : ____________ — déconsigné par : ____________' + FT,
'Fiche de suivi des essais de béton': HD('FICHE DE SUIVI DES ESSAIS DE BÉTON') + '\n| Date de coulage | Ouvrage | Éprouvette n° | Affaissement (cm) | Écrasement 7 j | Écrasement 28 j |\n' + ROWS(5, 6) + '\nRésistance caractéristique exigée : ____ MPa' + FT,
'Fiche de suivi des livraisons': HD('FICHE DE SUIVI DES LIVRAISONS') + '\n| Date | Fournisseur | Désignation | Quantité | Bon n° | Contrôle |\n' + ROWS(6, 6) + FT,
'Fiche de pointage des ouvriers': HD('FICHE DE POINTAGE DES OUVRIERS') + '\nSemaine du ____________ au ____________\n| Nom | Fonction | Lun | Mar | Mer | Jeu | Ven | Sam | Total (h) |\n' + ROWS(8, 9) + FT,
'Fiche d’inventaire du matériel': HD('FICHE D’INVENTAIRE DU MATÉRIEL') + '\n| Désignation | Référence | État | Quantité | Emplacement |\n' + ROWS(8, 5) + FT,
'Fiche de réclamation du client': HD('FICHE DE RÉCLAMATION') + '\nClient : {{client}}\nNature de la réclamation : ____________\nLocalisation : ____________\nDate de constat : ____________\nAction proposée : ____________ — Délai : ____________\nTraitée par : ____________ — Clôturée le : ____________' + FT,
'Fiche de levée d’une non-conformité': HD('FICHE DE LEVÉE DE NON-CONFORMITÉ') + '\nRéférence de la non-conformité : n° ____\nAction corrective réalisée : ____________\nDate : ____________\nContrôle de l’efficacité : satisfaisant / non satisfaisant\nVisa du responsable qualité : ____________' + FT,
'Check-list de sécurité quotidienne': HD('CHECK-LIST DE SÉCURITÉ QUOTIDIENNE') + '\n| Point | Oui | Non | Action |\n| Zone propre et dégagée | | | ____ |\n| EPI portés par tous | | | ____ |\n| Échafaudages et échelles en bon état | | | ____ |\n| Installations électriques protégées | | | ____ |\n| Extincteurs et trousse de secours accessibles | | | ____ |\n| Clôture et signalisation en place | | | ____ |\nVérifié par : ____________' + FT
  };

  /* ===================== LETTRES ===================== */
  var LET = {
'Transmission d’un décompte ou d’une situation': LT('Transmission de la situation de travaux n° {{no}} — {{projet}}', 'Veuillez trouver ci-joint la situation de travaux n° {{no}} relative à {{objet}}, arrêtée au ____________, pour un montant de ____________.\n\nNous vous remercions de bien vouloir procéder à sa vérification et à son règlement dans les délais prévus au marché.'),
'Demande d’acompte': LT('Demande d’acompte — {{projet}}', 'Conformément au marché, nous sollicitons le versement de l’acompte de ____________ correspondant à l’avancement des travaux constaté le ____________.\n\nNous restons à votre disposition pour toute précision.'),
'Notification d’un changement de planning': LT('Modification du planning — {{projet}}', 'Nous vous informons que le planning d’exécution est modifié du fait de ____________. La nouvelle date prévisionnelle de fin des travaux est le ____________.\n\nNous mettons tout en œuvre pour limiter l’impact sur le délai contractuel.'),
'Demande d’instruction (information manquante)': LT('Demande d’instruction — {{objet}}', 'Pour poursuivre les travaux relatifs à {{objet}}, nous avons besoin de l’information suivante : ____________.\n\nNous vous prions de nous répondre avant le ____________, faute de quoi les travaux concernés risquent d’être suspendus sans que le retard nous soit imputable.'),
'Transmission des plans d’exécution pour approbation': LT('Plans d’exécution pour approbation — {{projet}}', 'Veuillez trouver ci-joint les plans d’exécution suivants : ____________ (indice ____).\n\nNous vous demandons de nous retourner ces documents visés ou annotés avant le ____________ afin de ne pas retarder les travaux.'),
'Notification d’un sinistre ou d’un dégât': LT('Déclaration d’un sinistre — {{projet}}', 'Nous vous informons que le ____________, un sinistre est survenu sur le chantier : ____________.\n\nLes premières mesures de sauvegarde ont été prises. Un rapport détaillé vous sera transmis sous ____ jours.'),
'Réclamation pour travaux non rémunérés': LT('Réclamation — travaux non prévus au marché', 'Des travaux non prévus au marché ont été exécutés sur instruction de ____________ : ____________.\n\nNous vous demandons de bien vouloir régulariser par un avenant d’un montant de ____________ ou de nous faire part de vos observations sous ____ jours.'),
'Lettre d’accompagnement des attestations d’assurance': LT('Attestations d’assurance — {{projet}}', 'Conformément au marché, veuillez trouver ci-joint nos attestations d’assurance valables du ____________ au ____________.\n\nNous vous prions de bien vouloir en accuser réception.'),
'Réponse à une mise en demeure': LT('Réponse à votre mise en demeure du ____________', 'Nous avons bien reçu votre courrier du ____________ et vous apportons les éléments suivants : ____________.\n\nNous proposons de mettre en œuvre les actions suivantes avant le ____________ : ____________.'),
'Invitation à une réunion de chantier': LT('Invitation à la réunion de chantier du {{date_effet}}', 'Nous vous invitons à participer à la réunion de chantier qui se tiendra le {{date_effet}} à ____ h, sur le site de {{lieu}}.\n\nOrdre du jour : ____________\n\nVotre présence est importante pour la bonne coordination des travaux.')
  };

  /* ===================== CONTRATS ===================== */
  var CTR = {
'Contrat de travaux (marché à prix forfaitaire)': '# CONTRAT DE TRAVAUX À PRIX FORFAITAIRE\nEntre {{moa}} (le maître d’ouvrage) et {{societe}} (l’entrepreneur).\n\n## Article 1 — Objet\nLe maître d’ouvrage confie à l’entrepreneur les travaux suivants : {{objet}}, sur le site : {{lieu}}.\n## Article 2 — Prix\nPrix forfaitaire, ferme et non révisable : ____________ , toutes taxes comprises / hors taxes.\n## Article 3 — Délai\nLes travaux sont exécutés en ____ jours à compter du {{date_effet}}.\n## Article 4 — Paiement\n- Acompte à la signature : ____ %\n- Acomptes selon avancement\n- Solde à la réception : ____ %\n## Article 5 — Garanties et assurances\nL’entrepreneur justifie de ses assurances avant le démarrage.\n## Article 6 — Litiges\nÀ défaut d’accord amiable, les tribunaux compétents de {{ville}} sont saisis.' + FT,
'Contrat de main-d’œuvre journalière': '# CONTRAT DE MAIN-D’ŒUVRE JOURNALIÈRE\nEntre {{societe}} et ____________ (nom du travailleur).\n\n## Article 1 — Fonction\nLe travailleur est engagé comme ____________ sur le chantier {{projet}} à {{lieu}}.\n## Article 2 — Rémunération\n____________ par jour de travail effectif, payé chaque ____________.\n## Article 3 — Durée\nContrat valable du {{date_effet}} jusqu’à ____________ (ou fin des travaux concernés).\n## Article 4 — Obligations\nLe travailleur respecte les consignes de sécurité et le règlement intérieur du chantier et porte les équipements fournis.' + FT,
'Contrat de transport de matériaux': '# CONTRAT DE TRANSPORT DE MATÉRIAUX\nEntre {{societe}} (donneur d’ordre) et ____________ (transporteur).\n\n## Article 1 — Objet\nTransport de : ____________ vers le chantier {{projet}} à {{lieu}}.\n## Article 2 — Prix\n____________ par voyage / par tonne / par m³.\n## Article 3 — Responsabilité\nLe transporteur est responsable de la marchandise de la prise en charge à la livraison, et de tout dommage causé aux tiers pendant le transport.\n## Article 4 — Paiement\nSur présentation des bons de livraison signés, sous ____ jours.' + FT,
'Convention de mise à disposition de terrain ou de local': '# CONVENTION DE MISE À DISPOSITION\nEntre {{moa}} et {{societe}}.\n\nObjet : mise à disposition de ____________ situé à {{lieu}} pour l’installation et le stockage liés au chantier {{projet}}.\nDurée : du {{date_effet}} au ____________. Redevance : ____________.\nL’occupant remet les lieux en état à la fin de l’occupation.' + FT
  };

  /* ===================== ATTESTATIONS ===================== */
  var ATT = {
'Attestation de bonne fin de sous-traitance': '# ATTESTATION DE BONNE FIN DE SOUS-TRAITANCE\n\nNous, {{societe}}, attestons que {{entreprise}} a exécuté pour notre compte les travaux relatifs à {{objet}} sur le chantier {{projet}}, à {{lieu}}, de manière satisfaisante et dans les délais convenus.\n\nCette attestation est délivrée pour servir et valoir ce que de droit.' + FT,
'Attestation de réalisation de travaux (référence client)': '# ATTESTATION DE RÉALISATION DE TRAVAUX\n\nJe soussigné, {{client}}, atteste que {{societe}} a réalisé pour mon compte les travaux suivants : {{objet}}, à {{lieu}}, achevés le ____________, pour un montant de ____________.\n\nJe suis satisfait des prestations fournies.' + FT,
'Attestation de conformité des ouvrages exécutés': '# ATTESTATION DE CONFORMITÉ\n\nNous, {{societe}}, attestons que les ouvrages relatifs à {{objet}} réalisés sur {{projet}} sont conformes aux plans d’exécution, au CCTP et aux règles de l’art, sous réserve des observations portées au procès-verbal de réception.' + FT,
'Attestation de formation à la sécurité': '# ATTESTATION DE FORMATION À LA SÉCURITÉ\n\nNous attestons que M./Mme ____________ a suivi une formation à la sécurité sur le chantier {{projet}} le ____________ (durée : ____ h).\nThèmes : risques du chantier, EPI, travail en hauteur, premiers secours.' + FT,
'Attestation de non-sinistre': '# ATTESTATION DE NON-SINISTRE\n\nNous, {{societe}}, attestons qu’aucun accident ni sinistre n’a été déclaré sur le chantier {{projet}} du ____________ au ____________.' + FT
  };

  /* ===================== NOTES / PLANS / MÉTHODES ===================== */
  var NOT = {
'Mode opératoire — coulage de béton': SIMPLE('MODE OPÉRATOIRE — COULAGE DE BÉTON', '## Préparation\n- Contrôle du ferraillage et du coffrage\n- Vérification des réservations\n- Commande du béton : classe ____, volume ____ m³\n## Exécution\n- Accès et rotation des camions\n- Vibration, mise à niveau\n- Prélèvement d’éprouvettes\n## Cure et décoffrage\n- Arrosage / protection pendant ____ jours\n- Décoffrage après ____ jours\n## Sécurité\n- Port des EPI, signalisation de la zone'),
'Mode opératoire — maçonnerie': SIMPLE('MODE OPÉRATOIRE — MAÇONNERIE', '## Préparation\n- Traçage et niveaux\n- Humidification des supports\n## Exécution\n- Montage au fil et au niveau, joints de ____ mm\n- Chaînages et linteaux\n## Contrôle\n- Aplomb, alignement, épaisseur'),
'Plan de gestion des déchets de chantier': SIMPLE('PLAN DE GESTION DES DÉCHETS', '| Type de déchet | Quantité estimée | Mode de tri | Évacuation |\n| Gravats | ____ | benne | ____ |\n| Bois | ____ | tas | ____ |\n| Métaux | ____ | tas | ____ |\n| Plastiques et emballages | ____ | sacs | ____ |\n| Déchets dangereux | ____ | zone isolée | ____ |'),
'Plan d’assurance qualité simplifié': SIMPLE('PLAN D’ASSURANCE QUALITÉ SIMPLIFIÉ', '## Organisation\nResponsable qualité : ____________\n## Points d’arrêt\n- Réception des fouilles\n- Réception du ferraillage\n- Autorisation de coulage\n- Réception des supports avant finitions\n## Enregistrements\n- Fiches de contrôle, essais, non-conformités'),
'Planning d’exécution simplifié': SIMPLE('PLANNING D’EXÉCUTION', '| Tâche | Début | Fin | Responsable | Dépendance |\n' + ROWS(8, 5)),
'Note de calcul des quantités': SIMPLE('NOTE DE CALCUL DES QUANTITÉS', '| Poste | Unité | Dimensions | Quantité | Remarques |\n' + ROWS(8, 5) + '\nMéthode de mesure : ____________'),
'Procédure de gestion des modifications': SIMPLE('PROCÉDURE DE GESTION DES MODIFICATIONS', '1. Demande de modification écrite avec justification\n2. Évaluation technique, coût et délai\n3. Validation par le maître d’ouvrage\n4. Émission de l’ordre de service ou de l’avenant\n5. Mise à jour des plans et du planning'),
'Organigramme et responsabilités du chantier': SIMPLE('ORGANISATION DU CHANTIER', '| Fonction | Nom | Téléphone | Responsabilité |\n| Directeur de chantier | ____ | ____ | ____ |\n| Chef de chantier | ____ | ____ | ____ |\n| Responsable sécurité | ____ | ____ | ____ |\n| Responsable qualité | ____ | ____ | ____ |\n| Magasinier | ____ | ____ | ____ |')
  };

  /* ===================== DOSSIER DE CHANTIER ===================== */
  var DOS = {
'Liste des intervenants du projet': '# LISTE DES INTERVENANTS\nProjet : {{projet}} — {{lieu}}\n| Rôle | Société | Contact | Téléphone |\n| Maître d’ouvrage | {{moa}} | ____ | ____ |\n| Entreprise | {{societe}} | {{dg}} | ____ |\n| Bureau d’études | ____ | ____ | ____ |\n| Contrôle technique | ____ | ____ | ____ |\n| Sous-traitants | ____ | ____ | ____ |',
'Registre des documents transmis': '# REGISTRE DES DOCUMENTS TRANSMIS\nProjet : {{projet}} — {{lieu}}\n| N° | Date | Document | Indice | Destinataire | Statut |\n' + ROWS(8, 6),
'Fiche de synthèse du chantier': '# FICHE DE SYNTHÈSE DU CHANTIER\nProjet : {{projet}} — {{lieu}}\nClient : {{client}} · Permis : {{permis}} · Phase : {{phase}}\n| Donnée | Valeur |\n| Montant du marché | ____ |\n| Délai contractuel | ____ |\n| Date de démarrage | ____ |\n| Date de réception | ____ |\n| Surface / quantité principale | ____ |'
  };

  var NEW_MODELS = { rapport: RAP, pv: PV, cr: CR, os: OS, clause: CLA, fiche: FCH, lettre: LET, contrat: CTR, attest: ATT, note: NOT, dossier: DOS };

  D.models = D.models || {};
  var added = 0;
  Object.keys(NEW_MODELS).forEach(function (t) {
    var dst = D.models[t] || (D.models[t] = {}), src = NEW_MODELS[t];
    Object.keys(src).forEach(function (n) {
      if (!Object.prototype.hasOwnProperty.call(dst, n)) { dst[n] = src[n]; added++; }
    });
  });

  w.EXBPIE_V122E = { added: added };
})(window);
