/* Excellencia Building V122 — Renfort du module « Pièces écrites » (espace entreprise) :
 *  - 3 nouveaux types : RAPPORTS DE CHANTIER, CLAUSES DE CHANTIER, FICHES ET FORMULAIRES DE CHANTIER ;
 *  - procès-verbaux supplémentaires, lettres, contrats et attestations de chantier.
 * Fichier chargé APRÈS exb-v81-pieces-modeles.js et AVANT exb-v81-pieces.js : il ajoute ses modèles à EXBPIE_DATA
 * sans jamais remplacer un modèle existant (même nom = l’ancien est conservé).
 * Mise en forme : « # Titre », « ## Sous-titre », « - puce », « 1. numéro », « | a | b | » (1re ligne = en-tête), **gras**.
 * Variables remplies automatiquement : {{projet}} {{client}} {{moa}} {{lieu}} {{entreprise}} {{lot}} {{objet}} {{date}} {{date_effet}}
 * {{no}} {{societe}} {{dg}} {{ville}} {{pays}}… Ces textes sont des bases courantes : faire valider les clauses par votre conseil juridique. */
(function (w) {
  'use strict';
  var D = w.EXBPIE_DATA;
  if (!D) return;

  var HD = function (t) {
    return '# ' + t + '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}\nDate : {{date_effet}}\n';
  };
  var FT = '\n\nFait à {{ville}}, le {{date}}';
  var PVH = '# PROCÈS-VERBAL DE ';
  var PVB = '\nProjet : {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}\nDate : {{date_effet}}\n';
  var SAL = 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.';

  /* ===================== RAPPORTS DE CHANTIER ===================== */
  var RAP = {
'Rapport journalier de chantier': HD('RAPPORT JOURNALIER DE CHANTIER N° ___') + `
## Conditions du jour
| Élément | Constat |
| Météo | ____________ |
| Heures de travail | ____ h → ____ h |
| Arrêt éventuel (cause) | ____________ |
## Effectif présent
| Catégorie | Nombre | Entreprise / sous-traitant |
| Chef de chantier / conducteur de travaux | ___ | ____________ |
| Maçons, coffreurs, ferrailleurs | ___ | ____________ |
| Manœuvres | ___ | ____________ |
| Autres corps de métier | ___ | ____________ |
## Travaux exécutés
- ____________________
- ____________________
## Matériaux livrés et matériel présent
| Désignation | Quantité | Observation |
| ____________ | ____ | ____________ |
## Incidents, difficultés et instructions reçues
- ____________________
## Prévisions du lendemain
- ____________________` + FT,

'Rapport hebdomadaire d’avancement': HD('RAPPORT HEBDOMADAIRE D’AVANCEMENT — SEMAINE N° ___') + `
Période : du ____________ au ____________
## Synthèse
Avancement global déclaré : ____ % (prévu : ____ %). Écart par rapport au planning : ____ jours.
## Travaux réalisés cette semaine
| Poste / ouvrage | Quantité réalisée | Cumul | Avancement |
| ____________ | ____ | ____ | ____ % |
| ____________ | ____ | ____ | ____ % |
## Effectif moyen et heures
- Effectif moyen par jour : ____ personnes — jours d’intempéries : ____
## Difficultés et points bloquants
- ____________________
## Décisions attendues du maître d’ouvrage / de la maîtrise d’œuvre
- ____________________
## Programme de la semaine prochaine
- ____________________` + FT,

'Rapport mensuel d’avancement': HD('RAPPORT MENSUEL D’AVANCEMENT — MOIS DE ____________') + `
## 1. Résumé du mois
____________________
## 2. Avancement physique par poste
| Poste | Prévu (%) | Réalisé (%) | Écart | Commentaire |
| Terrassements / fondations | ____ | ____ | ____ | ____________ |
| Gros œuvre | ____ | ____ | ____ | ____________ |
| Second œuvre | ____ | ____ | ____ | ____________ |
| Finitions | ____ | ____ | ____ | ____________ |
## 3. Situation financière
- Montant du marché : ____________ — travaux exécutés à ce jour : ____________ — facturé : ____________ — payé : ____________
- Avenants en cours : ____________________
## 4. Délais
- Date contractuelle d’achèvement : ____________ — prévision actuelle : ____________
## 5. Qualité, sécurité et environnement
- ____________________
## 6. Risques et actions correctives
| Risque / difficulté | Action | Responsable | Échéance |
| ____________ | ____________ | ____________ | ____ |
## 7. Photos et pièces jointes
- ____________________` + FT,

'Rapport de contrôle qualité': HD('RAPPORT DE CONTRÔLE QUALITÉ') + `
Ouvrage contrôlé : {{objet}}
## Points contrôlés
| Point de contrôle | Référence (plan / CCTP) | Conforme | Observation |
| Implantation et cotes | ____________ | oui / non | ____________ |
| Qualité des matériaux | ____________ | oui / non | ____________ |
| Dimensions et alignements | ____________ | oui / non | ____________ |
| Mise en œuvre | ____________ | oui / non | ____________ |
| Propreté et protection des ouvrages | ____________ | oui / non | ____________ |
## Non-conformités relevées
- ____________________
## Conclusion
- Ouvrage accepté / accepté avec réserves / refusé : ____________
- Délai de correction : ____________` + FT,

'Rapport d’essais et de contrôle du béton': HD('RAPPORT D’ESSAIS ET DE CONTRÔLE DU BÉTON') + `
Ouvrage bétonné : {{objet}}
## Béton
- Classe de résistance prescrite : ____________ — centrale / fabrication sur site : ____________
- Dosage en ciment : ____ kg/m³ — rapport eau/ciment : ____ — volume mis en œuvre : ____ m³
## Essais
| Essai | Résultat | Exigence | Conforme |
| Affaissement (cône d’Abrams) | ____ cm | ____ cm | oui / non |
| Éprouvettes prélevées (nombre) | ____ | ____ | — |
| Résistance à 7 jours | ____ MPa | ____ MPa | oui / non |
| Résistance à 28 jours | ____ MPa | ____ MPa | oui / non |
## Conditions de mise en œuvre
- Température : ____ °C — vibration : ____ — cure du béton : ____________
- Décoffrage le : ____________
## Conclusion
____________________` + FT,

'Rapport hygiène, sécurité et environnement': HD('RAPPORT HYGIÈNE, SÉCURITÉ ET ENVIRONNEMENT (HSE)') + `
## Visite du jour
| Point vérifié | Conforme | Observation / action |
| Port des équipements de protection individuelle | oui / non | ____________ |
| Échafaudages, échelles et protections de rive | oui / non | ____________ |
| Tranchées et fouilles protégées | oui / non | ____________ |
| Installations électriques provisoires | oui / non | ____________ |
| Stockage des matériaux et propreté | oui / non | ____________ |
| Trousse de secours et extincteurs | oui / non | ____________ |
| Sanitaires, eau potable | oui / non | ____________ |
## Accidents et presque-accidents
- ____________________
## Actions correctives
| Action | Responsable | Échéance |
| ____________ | ____________ | ____ |
## Causerie sécurité du jour
Thème : ____________ — personnes présentes : ____` + FT,

'Rapport d’intempéries et d’arrêt de chantier': HD('RAPPORT D’INTEMPÉRIES / ARRÊT DE CHANTIER') + `
## Événement
- Nature (pluie, inondation, vent, autre) : ____________
- Début : ____________ — fin : ____________ — durée d’arrêt : ____ jours
## Conséquences
- Ouvrages touchés ou endommagés : ____________________
- Personnel immobilisé : ____ personnes — matériel immobilisé : ____________
## Mesures conservatoires prises
- ____________________
## Incidence sur le délai
Demande de prolongation de ____ jours calendaires, à justifier par le relevé météo et le journal de chantier.` + FT,

'Rapport photographique': HD('RAPPORT PHOTOGRAPHIQUE') + `
Objet : {{objet}}
Les photos sont datées et classées par zone ; chaque photo est accompagnée d’une légende.
| N° | Zone / ouvrage | Date | Légende |
| 1 | ____________ | ____ | ____________ |
| 2 | ____________ | ____ | ____________ |
| 3 | ____________ | ____ | ____________ |
| 4 | ____________ | ____ | ____________ |
## Observations générales
____________________` + FT,

'Rapport de réception de matériaux': HD('RAPPORT DE RÉCEPTION DE MATÉRIAUX') + `
Fournisseur : ____________ — bon de livraison n° ____________
| Désignation | Quantité commandée | Quantité reçue | Qualité conforme | Observation |
| ____________ | ____ | ____ | oui / non | ____________ |
| ____________ | ____ | ____ | oui / non | ____________ |
## Contrôles effectués
- Aspect, marquage et certificats fournis : ____________________
- Stockage prévu : ____________________
## Décision
Matériaux acceptés / acceptés avec réserves / refusés : ____________` + FT,

'Rapport de désordres / diagnostic': HD('RAPPORT DE DÉSORDRES') + `
Ouvrage concerné : {{objet}}
## Description des désordres
| N° | Localisation | Nature (fissure, infiltration, flèche…) | Gravité |
| 1 | ____________ | ____________ | faible / moyenne / grave |
| 2 | ____________ | ____________ | faible / moyenne / grave |
## Causes probables
- ____________________
## Mesures d’urgence
- ____________________
## Réparations proposées
- ____________________
Ce rapport est établi sur la base des constatations visuelles ; une étude complémentaire peut être nécessaire.` + FT,

'Rapport de fin de chantier': HD('RAPPORT DE FIN DE CHANTIER') + `
## 1. Rappel du projet
Projet {{projet}} à {{lieu}} — maître d’ouvrage {{moa}}.
## 2. Déroulement
- Date de démarrage : ____________ — achèvement réel : ____________ — délai contractuel : ____________
## 3. Bilan technique
- ____________________
## 4. Bilan financier
- Montant initial : ____________ — avenants : ____________ — montant final : ____________
## 5. Réserves et garanties
- Réserves restantes : ____________________ — début du délai de garantie : ____________
## 6. Documents remis
- Dossier des ouvrages exécutés, plans de récolement, notices, garanties : ____________________
## 7. Enseignements
- ____________________` + FT
  };

  /* ===================== CLAUSES DE CHANTIER ===================== */
  var CLA = {
'Clauses de délais et de pénalités de retard': `# CLAUSES DE DÉLAIS ET DE PÉNALITÉS DE RETARD
Projet : {{projet}} — {{lieu}}
## Article 1 — Délai d’exécution
Le délai d’exécution des travaux est de ___ jours calendaires, à compter de la date fixée par l’ordre de service de démarrage.
## Article 2 — Planning
L’entreprise remet un planning détaillé dans les ___ jours suivant l’ordre de service et le met à jour chaque mois.
## Article 3 — Pénalités de retard
En cas de retard imputable à l’entreprise, une pénalité de ___ ‰ du montant du marché par jour calendaire de retard est appliquée, sans mise en demeure préalable, dans la limite de ___ % du montant du marché.
## Article 4 — Prolongation
Le délai est prolongé en cas d’intempéries exceptionnelles, de force majeure, de retard du maître d’ouvrage ou de travaux supplémentaires, sur demande écrite justifiée de l’entreprise adressée dans les ___ jours suivant l’événement.`,

'Clauses de prix, de paiement et d’acomptes': `# CLAUSES DE PRIX ET DE PAIEMENT
Projet : {{projet}} — {{lieu}}
## Article 1 — Prix
Les prix sont ____ (fermes / révisables) et comprennent toutes les sujétions de l’exécution des travaux : main-d’œuvre, matériaux, matériel, transport, frais généraux et taxes.
## Article 2 — Avance de démarrage
Une avance de ___ % du montant du marché est versée à la signature de l’ordre de service de démarrage, contre garantie, et remboursée par déduction proportionnelle sur les décomptes.
## Article 3 — Situations de travaux
L’entreprise remet une situation mensuelle des travaux exécutés. La maîtrise d’œuvre la vérifie et l’arrête dans un délai de ___ jours.
## Article 4 — Paiement
Les sommes dues sont réglées dans un délai de ___ jours à compter de l’approbation de la situation par le maître d’ouvrage. Tout retard de paiement ouvre droit à des intérêts au taux de ___ % l’an.
## Article 5 — Décompte final
Le décompte général et définitif est établi dans les ___ jours suivant la réception des travaux.`,

'Clauses de révision et d’actualisation des prix': `# CLAUSES DE RÉVISION DES PRIX
Projet : {{projet}} — {{lieu}}
## Article 1 — Principe
Les prix du marché sont ____ (fermes et non révisables / révisables selon la formule ci-dessous).
## Article 2 — Formule
P = P0 × (a + b × S/S0 + c × M/M0), où P0 est le prix initial, S l’indice de main-d’œuvre, M l’indice des matériaux, a la part fixe, b et c les parts respectives de main-d’œuvre et de matériaux (a + b + c = 1).
## Article 3 — Indices de référence
Indices publiés par : ____________ — date de référence : ____________
## Article 4 — Seuil de déclenchement
La révision n’intervient que si la variation cumulée dépasse ___ %.`,

'Clauses de retenue de garantie et cautionnement': `# CLAUSES DE RETENUE DE GARANTIE ET CAUTIONNEMENT
Projet : {{projet}} — {{lieu}}
## Article 1 — Retenue de garantie
Une retenue de ___ % est opérée sur chaque paiement. Elle est restituée à l’expiration du délai de garantie, après levée des réserves, ou remplacée par une caution bancaire.
## Article 2 — Garantie de bonne exécution
L’entreprise remet, avant le démarrage, une garantie de bonne exécution égale à ___ % du montant du marché, valable jusqu’à la réception.
## Article 3 — Garantie de restitution d’avance
Toute avance versée est couverte par une garantie d’un montant équivalent.`,

'Clauses d’assurances et de responsabilités': `# CLAUSES D’ASSURANCES ET RESPONSABILITÉS
Projet : {{projet}} — {{lieu}}
## Article 1 — Assurances de l’entreprise
Avant le démarrage, l’entreprise remet les attestations d’assurance couvrant sa responsabilité civile, les accidents du travail de son personnel, son matériel et les dommages aux ouvrages pendant l’exécution.
## Article 2 — Responsabilité
L’entreprise répond des dommages causés aux personnes, aux biens et aux ouvrages voisins du fait de ses travaux, de son personnel et de ses sous-traitants.
## Article 3 — Garde du chantier
L’entreprise assure la garde et la protection du chantier, des matériaux et des ouvrages jusqu’à la réception.
## Article 4 — Garanties après réception
Garantie de parfait achèvement : ___ mois. Garanties de bon fonctionnement et décennale : selon la réglementation de {{pays}}.`,

'Clauses de sous-traitance': `# CLAUSES DE SOUS-TRAITANCE
Projet : {{projet}} — {{lieu}}
## Article 1 — Autorisation
Toute sous-traitance est soumise à l’accord écrit préalable du maître d’ouvrage, sur présentation de l’identité, des références et des assurances du sous-traitant.
## Article 2 — Responsabilité
L’entreprise reste seule responsable envers le maître d’ouvrage de l’exécution du marché, y compris des travaux sous-traités.
## Article 3 — Obligations
Le sous-traitant respecte le CCTP, le planning, les règles de sécurité et le règlement intérieur du chantier.
## Article 4 — Paiement
Le sous-traitant est payé par l’entreprise dans un délai de ___ jours après paiement par le maître d’ouvrage.
## Article 5 — Interdiction
La sous-traitance de la totalité du marché est interdite.`,

'Clauses d’hygiène, de sécurité et de santé': `# CLAUSES D’HYGIÈNE, DE SÉCURITÉ ET DE SANTÉ (HSE)
Projet : {{projet}} — {{lieu}}
## Article 1 — Plan de sécurité
L’entreprise établit avant le démarrage un plan d’hygiène et de sécurité adapté au chantier et le tient à jour.
## Article 2 — Équipements de protection
Casque, chaussures de sécurité et gilet sont obligatoires pour toute personne présente sur le chantier ; les équipements spécifiques (harnais, lunettes, gants, protection auditive) sont fournis par l’entreprise.
## Article 3 — Travaux dangereux
Les travaux en hauteur, en fouille profonde, à proximité de réseaux et les travaux à chaud font l’objet d’une autorisation de travail écrite.
## Article 4 — Accidents
Tout accident ou presque-accident est signalé immédiatement au maître d’œuvre et fait l’objet d’un rapport écrit.
## Article 5 — Santé et vie de chantier
Eau potable, sanitaires propres, trousse de secours et zone de repos sont mis à disposition du personnel.
## Article 6 — Sanctions
Le non-respect répété des règles de sécurité peut entraîner l’arrêt du chantier aux frais de l’entreprise.`,

'Clauses de protection de l’environnement et de propreté': `# CLAUSES DE PROTECTION DE L’ENVIRONNEMENT ET DE PROPRETÉ
Projet : {{projet}} — {{lieu}}
## Article 1 — Propreté du chantier
Le chantier et ses abords sont maintenus propres ; les déchets sont triés, stockés et évacués régulièrement vers des sites autorisés.
## Article 2 — Pollutions
Il est interdit de déverser huiles, laitances de ciment ou produits chimiques dans le sol, les caniveaux ou les cours d’eau.
## Article 3 — Nuisances
Les bruits, poussières et circulations d’engins sont limités ; les horaires de travail respectent la réglementation locale et le voisinage.
## Article 4 — Remise en état
À la fin des travaux, l’entreprise démonte ses installations, évacue ses déchets et remet les lieux en état.`,

'Clauses d’intempéries et de force majeure': `# CLAUSES D’INTEMPÉRIES ET DE FORCE MAJEURE
Projet : {{projet}} — {{lieu}}
## Article 1 — Intempéries
Sont comptés comme jours d’intempéries les jours où les conditions météorologiques rendent l’exécution des travaux impossible, constatés sur le journal de chantier et contresignés par la maîtrise d’œuvre.
## Article 2 — Force majeure
Est un cas de force majeure tout événement extérieur, imprévisible et irrésistible (catastrophe naturelle, troubles, décision des autorités…).
## Article 3 — Procédure
La partie qui l’invoque le notifie par écrit dans les ___ jours de sa survenance et prend les mesures conservatoires.
## Article 4 — Effets
Le délai est prolongé de la durée de l’événement. Aucune indemnité n’est due, sauf accord écrit des parties.`,

'Clauses de travaux supplémentaires et d’avenants': `# CLAUSES DE TRAVAUX SUPPLÉMENTAIRES ET D’AVENANTS
Projet : {{projet}} — {{lieu}}
## Article 1 — Principe
Aucun travail supplémentaire ou modificatif n’est exécuté sans ordre de service écrit du maître d’ouvrage ou de la maîtrise d’œuvre.
## Article 2 — Chiffrage
L’entreprise remet un devis détaillé et l’incidence sur le délai avant exécution ; les prix du marché s’appliquent en priorité, à défaut les prix sont convenus contradictoirement.
## Article 3 — Avenant
Les travaux supplémentaires dépassant ___ % du marché font l’objet d’un avenant signé des parties.
## Article 4 — Travaux non autorisés
Les travaux exécutés sans ordre écrit ne sont pas payés et peuvent être démolis aux frais de l’entreprise.`,

'Clauses de réception et de garanties': `# CLAUSES DE RÉCEPTION ET DE GARANTIES
Projet : {{projet}} — {{lieu}}
## Article 1 — Demande de réception
L’entreprise informe par écrit le maître d’œuvre de l’achèvement des travaux ; les opérations préalables à la réception ont lieu dans les ___ jours.
## Article 2 — Réception
La réception est prononcée par procès-verbal, avec ou sans réserves. Elle est refusée si les ouvrages ne sont pas en état d’être utilisés.
## Article 3 — Garantie de parfait achèvement
Pendant ___ mois après la réception, l’entreprise répare à ses frais tous les désordres signalés.
## Article 4 — Dossier des ouvrages exécutés
Plans de récolement, notices, certificats et garanties sont remis avant la réception.
## Article 5 — Réception définitive
Elle est prononcée à l’expiration du délai de garantie ; la retenue de garantie est alors restituée.`,

'Clauses de résiliation': `# CLAUSES DE RÉSILIATION
Projet : {{projet}} — {{lieu}}
## Article 1 — Résiliation aux torts de l’entreprise
Le maître d’ouvrage peut résilier le marché après mise en demeure restée sans effet pendant ___ jours, notamment en cas de retard grave, d’abandon de chantier, de malfaçons non reprises ou de sous-traitance non autorisée.
## Article 2 — Résiliation pour convenance
Le maître d’ouvrage peut résilier à tout moment ; l’entreprise est alors indemnisée des travaux exécutés et des frais justifiés engagés.
## Article 3 — Résiliation par l’entreprise
L’entreprise peut résilier en cas de défaut de paiement persistant après mise en demeure de ___ jours.
## Article 4 — Effets
Un constat contradictoire des travaux exécutés est dressé et le décompte de résiliation est établi dans les ___ jours.`,

'Clauses de règlement des litiges': `# CLAUSES DE RÈGLEMENT DES LITIGES
Projet : {{projet}} — {{lieu}}
## Article 1 — Règlement amiable
Les parties cherchent d’abord une solution amiable, par réunion de conciliation tenue dans les ___ jours suivant la notification du désaccord.
## Article 2 — Médiation ou arbitrage
À défaut d’accord, le litige est soumis à ____ (médiation / arbitrage / expert désigné d’un commun accord).
## Article 3 — Juridiction
À défaut, les tribunaux compétents de {{ville}} ({{pays}}) sont seuls compétents.
## Article 4 — Droit applicable
Le présent marché est régi par le droit en vigueur en {{pays}}.
## Article 5 — Poursuite des travaux
Sauf décision contraire, l’entreprise poursuit les travaux pendant le règlement du litige.`,

'Clauses de confidentialité et de propriété des études': `# CLAUSES DE CONFIDENTIALITÉ ET DE PROPRIÉTÉ
Projet : {{projet}} — {{lieu}}
## Article 1 — Confidentialité
Chaque partie garde confidentiels les plans, études, prix et informations échangés et ne les utilise que pour l’exécution du projet.
## Article 2 — Propriété des études
Les plans, notes de calcul et documents établis par {{societe}} restent sa propriété intellectuelle jusqu’au paiement intégral ; ils ne peuvent être réutilisés pour un autre projet sans son accord écrit.
## Article 3 — Durée
Ces obligations durent ___ ans après la fin du projet.`,

'Clauses de contrôle qualité et de matériaux': `# CLAUSES DE CONTRÔLE QUALITÉ ET DE MATÉRIAUX
Projet : {{projet}} — {{lieu}}
## Article 1 — Qualité des matériaux
Les matériaux sont neufs, conformes aux normes et au CCTP, et approuvés avant commande sur présentation d’échantillons ou de fiches techniques.
## Article 2 — Essais
Les essais prévus (béton, compactage, résistance des aciers…) sont réalisés par un laboratoire agréé ; leur coût est à la charge de ____________.
## Article 3 — Points d’arrêt
Fond de fouille, ferraillage, coffrage et étanchéité sont contrôlés et acceptés par écrit avant l’étape suivante.
## Article 4 — Matériaux refusés
Les matériaux non conformes sont évacués du chantier dans les ___ jours.`,

'Clauses de personnel et de main-d’œuvre': `# CLAUSES DE PERSONNEL ET DE MAIN-D’ŒUVRE
Projet : {{projet}} — {{lieu}}
## Article 1 — Personnel
L’entreprise emploie du personnel qualifié, déclaré et rémunéré conformément à la législation du travail de {{pays}}.
## Article 2 — Responsable de chantier
Un conducteur de travaux ou chef de chantier est présent en permanence et représente l’entreprise auprès de la maîtrise d’œuvre.
## Article 3 — Interdictions
Le travail des enfants, le travail forcé et toute forme de discrimination ou de harcèlement sont interdits sur le chantier.
## Article 4 — Registre du personnel
Un registre des présences est tenu à jour et mis à la disposition du maître d’œuvre.`,

'Règlement intérieur de chantier': `# RÈGLEMENT INTÉRIEUR DE CHANTIER
Projet : {{projet}} — {{lieu}}
Applicable à toute personne entrant sur le chantier.
1. Horaires de travail : de ____ h à ____ h, du ____ au ____.
2. L’accès est réservé aux personnes autorisées et munies de leurs équipements de protection.
3. Il est interdit de consommer de l’alcool ou des drogues, de fumer hors des zones prévues et de dormir sur le chantier sans autorisation.
4. Les engins sont conduits uniquement par des personnes qualifiées et autorisées.
5. Les matériaux et outils sont rangés ; le chantier est nettoyé chaque soir.
6. Tout accident, vol ou dégât est signalé immédiatement au chef de chantier.
7. Les visiteurs sont accompagnés et signent le registre d’accès.
8. Le non-respect du règlement peut entraîner l’exclusion du chantier.
## Pris connaissance
| Nom | Fonction | Date | Signature |
| ____________ | ____________ | ____ | ____________ |
| ____________ | ____________ | ____ | ____________ |`,

'Recueil de clauses générales de chantier': `# CLAUSES GÉNÉRALES DE CHANTIER
Projet : {{projet}} — {{lieu}}
Maître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}
Les clauses suivantes complètent le marché ; en cas de contradiction, les clauses particulières du marché l’emportent.
## 1. Délais
Le délai d’exécution est de ___ jours calendaires ; pénalité de retard : ___ ‰ par jour, plafonnée à ___ %.
## 2. Prix et paiement
Prix ____ (fermes / révisables) ; paiement par situations mensuelles dans un délai de ___ jours ; avance de ___ %.
## 3. Garanties
Retenue de garantie de ___ % ; garantie de parfait achèvement de ___ mois.
## 4. Assurances
Attestations de responsabilité civile et d’accidents du travail remises avant le démarrage.
## 5. Sous-traitance
Soumise à l’accord écrit préalable du maître d’ouvrage ; l’entreprise reste responsable.
## 6. Hygiène et sécurité
Plan de sécurité, équipements de protection obligatoires, déclaration des accidents.
## 7. Travaux supplémentaires
Uniquement sur ordre de service écrit ; avenant au-delà de ___ % du marché.
## 8. Intempéries et force majeure
Prolongation du délai sur demande écrite justifiée.
## 9. Réception
Procès-verbal de réception, dossier des ouvrages exécutés remis avant la réception.
## 10. Résiliation et litiges
Mise en demeure de ___ jours avant résiliation ; règlement amiable, puis ____ ; droit de {{pays}}.`
  };

  /* ===================== FICHES ET FORMULAIRES DE CHANTIER ===================== */
  var FCH = {
'Fiche de non-conformité': `# FICHE DE NON-CONFORMITÉ N° {{no}}
Projet : {{projet}} — {{lieu}}
Entreprise : {{entreprise}} · Lot : {{lot}}
Date de constat : {{date_effet}}
## Description
Ouvrage concerné : {{objet}}
Écart constaté : ____________________
Référence non respectée (plan, CCTP, norme) : ____________________
## Gravité
faible / moyenne / grave
## Action corrective demandée
- ____________________
Délai de correction : ____________
## Suivi
| Date | Action réalisée | Vérifié par | Clôturée |
| ____ | ____________ | ____________ | oui / non |` + FT,

'Demande d’approbation de plans ou d’échantillons': `# DEMANDE D’APPROBATION N° {{no}}
Projet : {{projet}} — {{lieu}}
Entreprise : {{entreprise}} · Lot : {{lot}}
Date : {{date}}
## Documents ou échantillons soumis
| Désignation | Référence / indice | Nombre |
| ____________ | ____ | ____ |
| ____________ | ____ | ____ |
## Avis de la maîtrise d’œuvre
Approuvé / approuvé avec observations / refusé : ____________
Observations : ____________________
Date de retour : ____________` + FT,

'Fiche de réception de matériaux': `# FICHE DE RÉCEPTION DE MATÉRIAUX
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}} · Fournisseur : ____________ · Bon de livraison n° ____________
| Matériau | Quantité | Conforme | Observation |
| Ciment | ____ | oui / non | ____________ |
| Sable / gravier | ____ | oui / non | ____________ |
| Acier | ____ | oui / non | ____________ |
| Blocs / briques | ____ | oui / non | ____________ |
| Autre : ____________ | ____ | oui / non | ____________ |
Réceptionné par : ____________ — fonction : ____________` + FT,

'Journal de chantier': `# JOURNAL DE CHANTIER
Projet : {{projet}} — {{lieu}}
Entreprise : {{entreprise}}
| Date | Météo | Effectif | Travaux exécutés | Visiteurs / instructions | Visa |
| ____ | ____ | ____ | ____________ | ____________ | ____ |
| ____ | ____ | ____ | ____________ | ____________ | ____ |
| ____ | ____ | ____ | ____________ | ____________ | ____ |
| ____ | ____ | ____ | ____________ | ____________ | ____ |
| ____ | ____ | ____ | ____________ | ____________ | ____ |
Le journal de chantier est tenu chaque jour et sert de preuve pour les intempéries, les retards et les instructions reçues.`,

'Bordereau de transmission': `# BORDEREAU DE TRANSMISSION N° {{no}}
Projet : {{projet}} — {{lieu}}
De : {{societe}} — À : ____________ — Date : {{date}}
| N° | Désignation du document | Indice | Nombre | Pour (information / approbation / exécution) |
| 1 | ____________ | ____ | ____ | ____________ |
| 2 | ____________ | ____ | ____ | ____________ |
| 3 | ____________ | ____ | ____ | ____________ |
Observations : ____________________
Accusé de réception (nom, date, signature) : ____________________`,

'Demande de situation de travaux (décompte)': `# SITUATION DE TRAVAUX N° {{no}}
Projet : {{projet}} — {{lieu}}
Entreprise : {{entreprise}} · Lot : {{lot}} · Période arrêtée au : {{date_effet}}
| Poste | Montant du marché | Avancement (%) | Montant exécuté |
| ____________ | ____ | ____ | ____ |
| ____________ | ____ | ____ | ____ |
| ____________ | ____ | ____ | ____ |
## Récapitulatif
- Total des travaux exécutés : ____________
- À déduire : situations précédentes ____________ · avance à rembourser ____________ · retenue de garantie ____________
- **Net à payer : ____________**
## Visa de la maîtrise d’œuvre
Situation vérifiée et arrêtée à la somme de : ____________` + FT,

'Fiche d’accueil sécurité': `# FICHE D’ACCUEIL SÉCURITÉ
Projet : {{projet}} — {{lieu}}
Nom : ____________ · Fonction : ____________ · Entreprise : {{entreprise}} · Date : {{date_effet}}
## Consignes présentées
- Port obligatoire du casque, des chaussures de sécurité et du gilet.
- Zones dangereuses, circulation des engins et issues de secours.
- Emplacement de la trousse de secours, des extincteurs et du point de rassemblement.
- Interdiction d’intervenir sur les installations électriques et sur les échafaudages sans autorisation.
- Signalement immédiat de tout accident ou situation dangereuse.
Je déclare avoir reçu et compris ces consignes.
| Nom | Signature | Présenté par |
| ____________ | ____________ | ____________ |`,

'Fiche de présence du personnel': `# FICHE DE PRÉSENCE DU PERSONNEL
Projet : {{projet}} — {{lieu}}
Entreprise : {{entreprise}} · Semaine du ____________ au ____________
| Nom | Fonction | Lun | Mar | Mer | Jeu | Ven | Sam | Total |
| ____________ | ____________ | ____ | ____ | ____ | ____ | ____ | ____ | ____ |
| ____________ | ____________ | ____ | ____ | ____ | ____ | ____ | ____ | ____ |
| ____________ | ____________ | ____ | ____ | ____ | ____ | ____ | ____ | ____ |
Visa du chef de chantier : ____________`,

'Autorisation d’accès au chantier': `# AUTORISATION D’ACCÈS AU CHANTIER
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}}
{{societe}} autorise la personne suivante à accéder au chantier, accompagnée et munie des équipements de protection :
- Nom : ____________ · Organisme : ____________
- Motif de la visite : {{objet}}
- Durée : ____________
Le visiteur s’engage à respecter le règlement intérieur et les consignes de sécurité.` + FT,

'Décharge de remise de documents ou de matériel': `# DÉCHARGE
Projet : {{projet}} — {{lieu}}
Je soussigné(e) ____________, agissant pour ____________, reconnais avoir reçu de {{societe}}, le {{date_effet}} :
| Désignation | Quantité | État |
| ____________ | ____ | ____________ |
| ____________ | ____ | ____________ |
Je m’engage à les utiliser pour le projet {{projet}} et à les restituer sur demande.` + FT
  };

  /* ===================== PROCÈS-VERBAUX SUPPLÉMENTAIRES ===================== */
  var PV = {
'Réception de matériaux / livraison': PVH + 'RÉCEPTION DE MATÉRIAUX' + PVB + `
Les matériaux listés ci-dessous ont été livrés et contrôlés en présence des parties.
| Désignation | Quantité | Conforme | Observation |
| ____________ | ____ | oui / non | ____________ |
| ____________ | ____ | oui / non | ____________ |
## Décision
Matériaux acceptés / acceptés avec réserves / refusés et à évacuer avant le ____________.` + FT,

'Réception de support (point d’arrêt)': PVH + 'RÉCEPTION D’UN SUPPORT / POINT D’ARRÊT' + PVB + `
Ouvrage contrôlé : {{objet}} (fond de fouille, ferraillage, coffrage, support d’étanchéité…)
## Contrôles
| Point vérifié | Conforme | Observation |
| Cotes et niveaux | oui / non | ____________ |
| Conformité aux plans | oui / non | ____________ |
| Propreté et état | oui / non | ____________ |
## Décision
L’entreprise est autorisée / non autorisée à poursuivre l’étape suivante.` + FT,

'Réception partielle': PVH + 'RÉCEPTION PARTIELLE' + PVB + `
Partie d’ouvrage réceptionnée : {{objet}}
Après visite, il est constaté que cette partie est achevée et conforme, sous réserve des points suivants :
| N° | Réserve | Délai de levée |
| 1 | ____________ | ____ |
## Décision
La réception partielle est prononcée au ____________. Le transfert de garde et le point de départ des garanties concernent uniquement cette partie.` + FT,

'Refus de réception': PVH + 'REFUS DE RÉCEPTION' + PVB + `
Après visite des ouvrages, la réception est refusée pour les motifs suivants :
| N° | Motif | Référence (plan / CCTP) |
| 1 | ____________ | ____________ |
| 2 | ____________ | ____________ |
## Décision
L’entreprise reprend les ouvrages et présente à nouveau les travaux avant le ____________.` + FT,

'Essais et contrôles': PVH + 'ESSAIS ET CONTRÔLES' + PVB + `
Nature des essais : {{objet}}
| Essai | Valeur obtenue | Exigence | Résultat |
| ____________ | ____ | ____ | conforme / non conforme |
| ____________ | ____ | ____ | conforme / non conforme |
## Conclusion
____________________` + FT,

'Arrêt ou reprise de chantier (intempéries, force majeure)': PVH + 'CONSTAT D’ARRÊT / DE REPRISE DE CHANTIER' + PVB + `
Cause : {{objet}}
- Arrêt constaté le : ____________ — reprise le : ____________ — durée : ____ jours
- Ouvrages protégés et mesures prises : ____________________
Le présent constat sert de base à la demande de prolongation de délai.` + FT,

'Remise des clés et des ouvrages': PVH + 'REMISE DES CLÉS ET DES OUVRAGES' + PVB + `
L’entreprise remet au maître d’ouvrage {{moa}} les ouvrages du projet {{projet}} et les clés suivantes :
| Désignation | Nombre |
| ____________ | ____ |
## Documents remis
- Plans de récolement, notices, certificats et garanties : ____________________
Le maître d’ouvrage prend possession des lieux à compter de ce jour.` + FT,

'Agrément de matériaux / échantillons': PVH + 'AGRÉMENT DE MATÉRIAUX' + PVB + `
| Matériau / échantillon | Référence | Décision (agréé / refusé) | Observation |
| ____________ | ____________ | ____________ | ____________ |
| ____________ | ____________ | ____________ | ____________ |
Les matériaux agréés ne peuvent être remplacés sans accord écrit de la maîtrise d’œuvre.` + FT,

'Inventaire du matériel et des stocks': PVH + 'INVENTAIRE DU MATÉRIEL ET DES STOCKS' + PVB + `
| Désignation | Quantité | État | Localisation |
| ____________ | ____ | ____________ | ____________ |
| ____________ | ____ | ____________ | ____________ |
Inventaire arrêté contradictoirement à la date indiquée ci-dessus.` + FT,

'Réception des travaux d’un sous-traitant': PVH + 'RÉCEPTION DES TRAVAUX D’UN SOUS-TRAITANT' + PVB + `
Sous-traitant : ____________ — nature des travaux : {{objet}}
Les travaux ont été visités. Réserves éventuelles :
| N° | Réserve | Délai |
| 1 | ____________ | ____ |
## Décision
Travaux acceptés / acceptés avec réserves / refusés.` + FT,

'Constat d’avancement pour paiement': PVH + 'CONSTAT D’AVANCEMENT DES TRAVAUX' + PVB + `
| Poste | Quantité prévue | Quantité exécutée | Avancement |
| ____________ | ____ | ____ | ____ % |
| ____________ | ____ | ____ | ____ % |
Ce constat contradictoire sert de base à la situation de travaux n° ____.` + FT,

'Constat de sinistre / de dégâts': PVH + 'CONSTAT DE SINISTRE' + PVB + `
Nature du sinistre : {{objet}}
## Faits et dégâts constatés
- ____________________
## Mesures conservatoires
- ____________________
## Déclaration aux assurances
Date : ____________ — référence : ____________
Le constat est établi sans préjudice des responsabilités de chacun.` + FT,

'Désaccord / réserves d’une partie': PVH + 'DÉSACCORD ET RÉSERVES' + PVB + `
Partie émettant des réserves : ____________
Objet du désaccord : {{objet}}
## Position des parties
| Partie | Position |
| ____________ | ____________ |
| ____________ | ____________ |
Les parties conviennent de se revoir le ____________ pour rechercher une solution amiable.` + FT
  };

  /* ===================== LETTRES, CONTRATS, ATTESTATIONS ===================== */
  var LET = {
'Notification de démarrage de chantier': 'Objet : Démarrage des travaux — {{projet}}\n\nMadame, Monsieur,\n\nNous vous informons que les travaux du projet {{projet}}, à {{lieu}}, démarreront le {{date_effet}}. Nous vous remercions de nous communiquer les accès, les points de branchement et la liste des personnes à contacter sur place.\n\n' + SAL + '\n\n{{societe}}',
'Demande de prolongation de délai': 'Objet : Demande de prolongation de délai — {{objet}}\n\nMadame, Monsieur,\n\nPour le projet {{projet}}, nous sollicitons une prolongation de ___ jours calendaires du délai d’exécution, pour le motif suivant : {{objet}}. Les justificatifs (journal de chantier, relevés météo, ordres de service) sont joints.\n\nNous restons à votre disposition pour en discuter.\n\n' + SAL + '\n\n{{societe}}',
'Demande de réception des travaux': 'Objet : Demande de réception — {{projet}}\n\nMadame, Monsieur,\n\nLes travaux du lot « {{lot}} » du projet {{projet}} étant achevés, nous vous prions de bien vouloir fixer les opérations préalables à la réception. Le dossier des ouvrages exécutés sera remis avant la visite.\n\n' + SAL + '\n\n{{societe}}',
'Demande d’agrément de sous-traitant': 'Objet : Demande d’agrément de sous-traitant — {{lot}}\n\nMadame, Monsieur,\n\nNous demandons l’agrément de l’entreprise ____________ pour la sous-traitance des travaux du lot « {{lot}} ». Ses références et ses attestations d’assurance sont joints.\n\n' + SAL + '\n\n{{societe}}',
'Réserves sur un décompte': 'Objet : Réserves sur le décompte — {{objet}}\n\nMadame, Monsieur,\n\nNous avons examiné le décompte n° ____ du projet {{projet}} et formulons les réserves suivantes : ____________________. Nous vous prions de bien vouloir procéder aux rectifications nécessaires.\n\n' + SAL + '\n\n{{societe}}'
  };

  var CTR = {
'Contrat de fourniture de matériaux': `# CONTRAT DE FOURNITURE DE MATÉRIAUX
Entre {{societe_rep}}, ci-après « l’acheteur », et ____________, ci-après « le fournisseur ».
## Article 1 — Objet
Fourniture de ____________ pour le projet {{projet}}, à {{lieu}}.
## Article 2 — Quantités, qualité et prix
Quantités : ____________ — qualité conforme aux normes et au CCTP — prix unitaire : ____________.
## Article 3 — Livraison
Lieu : {{lieu}} — délai : ___ jours — la livraison est accompagnée d’un bon de livraison.
## Article 4 — Paiement
Dans un délai de ___ jours après livraison et facture.
## Article 5 — Garantie
Les matériaux non conformes sont remplacés aux frais du fournisseur.
## Article 6 — Litiges
Les litiges relèvent des tribunaux de {{ville}}.` + FT + `
| Pour l’acheteur | Pour le fournisseur |
| Lu et approuvé | Lu et approuvé |`,

'Contrat de location de matériel de chantier': `# CONTRAT DE LOCATION DE MATÉRIEL DE CHANTIER
Entre {{societe_rep}}, « le locataire », et ____________, « le loueur ».
## Article 1 — Matériel loué
Désignation : ____________ — état à la remise : ____________.
## Article 2 — Durée et prix
Du ____________ au ____________ — loyer : ____________ par jour / mois.
## Article 3 — Obligations du locataire
Usage conforme à sa destination, par du personnel qualifié ; entretien courant et carburant à la charge du locataire.
## Article 4 — Pannes et dommages
Les pannes non imputables au locataire sont réparées par le loueur ; les dommages dus à un mauvais usage sont à la charge du locataire.
## Article 5 — Restitution
Le matériel est restitué en bon état, avec un état des lieux contradictoire.` + FT + `
| Le locataire | Le loueur |
| Lu et approuvé | Lu et approuvé |`,

'Avenant au marché': `# AVENANT N° {{no}} AU MARCHÉ
Projet : {{projet}} — {{lieu}}
Entre {{moa}} et {{entreprise}}.
## Article 1 — Objet
Le présent avenant a pour objet : {{objet}}.
## Article 2 — Incidence financière
Montant initial du marché : ____________ — montant de l’avenant : ____________ — nouveau montant : ____________.
## Article 3 — Incidence sur le délai
Prolongation / réduction de ___ jours ; nouvelle date d’achèvement : ____________.
## Article 4 — Autres clauses
Les autres dispositions du marché restent inchangées.` + FT + `
| Le maître d’ouvrage | L’entreprise |
| Lu et approuvé | Lu et approuvé |`
  };

  var ATT = {
'Attestation de fin de travaux': `# ATTESTATION DE FIN DE TRAVAUX
Je soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que les travaux du lot « {{lot}} » du projet {{projet}}, à {{lieu}}, ont été achevés le {{date_effet}}.
La présente attestation est délivrée pour servir et valoir ce que de droit.` + FT,
'Attestation de levée de réserves': `# ATTESTATION DE LEVÉE DE RÉSERVES
Nous attestons que les réserves formulées lors de la réception du projet {{projet}} ont été levées le {{date_effet}} par l’entreprise {{entreprise}}.
La présente attestation est délivrée pour servir et valoir ce que de droit.` + FT,
'Attestation de bonne exécution des travaux et quitus': `# ATTESTATION DE QUITUS
{{moa}} atteste que l’entreprise {{entreprise}} a exécuté les travaux du lot « {{lot}} » du projet {{projet}} conformément au marché et lui donne quitus pour ces travaux.` + FT
  };

  /* ===================== V122b — SÉRIE COMPLÉMENTAIRE ===================== */
  var CK = function (t, pts) {
    return HD('FICHE DE CONTRÔLE — ' + t) + '\n| Point à contrôler | Référence (plan / CCTP) | Conforme | Observation |\n' +
      pts.map(function (p) { return '| ' + p + ' | ____________ | oui / non | ____________ |'; }).join('\n') +
      '\n## Décision\nContrôle satisfaisant / à reprendre avant le ____________\nContrôlé par : ____________ — fonction : ____________' + FT;
  };
  var CRH = function (t, pts) {
    return '# COMPTE RENDU — ' + t + '\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}} · Lieu : {{lieu}}\n## Participants\n| Nom | Fonction / entreprise | Présent |\n| ____________ | ____________ | oui / non |\n| ____________ | ____________ | oui / non |\n## Ordre du jour\n' +
      pts.map(function (p, i) { return (i + 1) + '. ' + p; }).join('\n') +
      '\n## Décisions et actions\n| N° | Décision / action | Responsable | Échéance |\n| 1 | ____________ | ____________ | ____ |\n| 2 | ____________ | ____________ | ____ |\nProchaine réunion : ____________' + FT;
  };
  var OSH = '# ORDRE DE SERVICE N° {{no}}\nNature : ';
  var OSB = '\nProjet : {{projet}} — Lot : {{lot}}\nÀ l’attention de : {{entreprise}}\n\n';
  var SIMPLE = function (t, body) { return HD(t) + '\n' + body + FT; };

  /* --- rapports --- */
  var RAP2 = {
'Rapport d’implantation et de topographie': SIMPLE('RAPPORT D’IMPLANTATION ET DE TOPOGRAPHIE', 'Ouvrage : {{objet}}\n## Repères et références\n| Repère | Description | Cote / coordonnée |\n| ____ | ____________ | ____________ |\n## Contrôles\n- Axes et alignements vérifiés : ____________\n- Niveaux (cote 0.00 de référence) : ____________\n- Écarts constatés : ____________\n## Conclusion\nImplantation validée / à reprendre : ____________'),
'Rapport de coulage de béton': SIMPLE('RAPPORT DE COULAGE DE BÉTON', 'Ouvrage : {{objet}}\n- Début : ____ h — fin : ____ h — volume coulé : ____ m³ — classe de béton : ____________\n- Provenance (centrale / site) : ____________ — bons de livraison : ____________\n## Contrôles avant coulage\n- Ferraillage, enrobage, coffrage et propreté contrôlés : oui / non\n## Pendant le coulage\n- Vibration : ____________ — température : ____ °C — incidents : ____________\n## Après coulage\n- Cure : ____________ — éprouvettes prélevées : ____ — décoffrage prévu le : ____________'),
'Rapport de ferraillage': SIMPLE('RAPPORT DE FERRAILLAGE', 'Ouvrage : {{objet}}\n| Élément | Diamètre / nombre | Espacement | Enrobage | Conforme |\n| ____________ | ____ | ____ | ____ | oui / non |\n| ____________ | ____ | ____ | ____ | oui / non |\n## Observations\n- Recouvrements, ancrages, cales, ligatures : ____________\n## Décision\nAutorisation de couler : oui / non'),
'Rapport d’avancement par lot': SIMPLE('RAPPORT D’AVANCEMENT PAR LOT', '| Lot | Entreprise | Prévu (%) | Réalisé (%) | Retard (jours) |\n| ____________ | ____________ | ____ | ____ | ____ |\n| ____________ | ____________ | ____ | ____ | ____ |\n| ____________ | ____________ | ____ | ____ | ____ |\n## Points de blocage\n- ____________________\n## Actions\n- ____________________'),
'Rapport de main-d’œuvre et de pointage': SIMPLE('RAPPORT DE MAIN-D’ŒUVRE ET DE POINTAGE', 'Période : du ____________ au ____________\n| Catégorie | Effectif moyen | Heures | Heures supplémentaires | Absences |\n| Maçons | ____ | ____ | ____ | ____ |\n| Ferrailleurs / coffreurs | ____ | ____ | ____ | ____ |\n| Manœuvres | ____ | ____ | ____ | ____ |\n| Autres | ____ | ____ | ____ | ____ |\nTotal heures de la période : ____________'),
'Rapport de visite du maître d’ouvrage': SIMPLE('RAPPORT DE VISITE DU MAÎTRE D’OUVRAGE', 'Visiteur(s) : {{moa}} — accompagné(s) par : ____________\n## Parties visitées\n- ____________________\n## Remarques et demandes du maître d’ouvrage\n| N° | Remarque | Suite donnée | Délai |\n| 1 | ____________ | ____________ | ____ |\n## Décisions prises\n- ____________________'),
'Rapport de gestion des déchets': SIMPLE('RAPPORT DE GESTION DES DÉCHETS DE CHANTIER', '| Type de déchet | Quantité | Mode de traitement | Évacuation (date) |\n| Gravats | ____ | ____________ | ____ |\n| Bois / emballages | ____ | ____________ | ____ |\n| Ferrailles | ____ | ____________ | ____ |\n| Déchets dangereux | ____ | ____________ | ____ |\nSite d’évacuation autorisé : ____________'),
'Rapport d’audit de chantier': SIMPLE('RAPPORT D’AUDIT DE CHANTIER', '| Domaine | Note (sur 10) | Constat |\n| Organisation et planning | ____ | ____________ |\n| Qualité d’exécution | ____ | ____________ |\n| Sécurité | ____ | ____________ |\n| Propreté et environnement | ____ | ____________ |\n| Documents et suivi | ____ | ____________ |\n## Recommandations\n- ____________________'),
'Rapport de maintenance du matériel': SIMPLE('RAPPORT DE MAINTENANCE DU MATÉRIEL', '| Matériel / engin | Date | Intervention | Heures de fonctionnement | État |\n| ____________ | ____ | ____________ | ____ | ____________ |\n| ____________ | ____ | ____________ | ____ | ____________ |\nPannes ayant arrêté le chantier : ____________'),
'Rapport de pré-réception': SIMPLE('RAPPORT DE PRÉ-RÉCEPTION', 'Visite interne avant la réception officielle.\n| Local / ouvrage | Défaut constaté | À reprendre par | Délai |\n| ____________ | ____________ | ____________ | ____ |\n| ____________ | ____________ | ____________ | ____ |\nDate prévue de la réception : ____________'),
'Rapport des risques et opportunités': SIMPLE('RAPPORT DES RISQUES ET OPPORTUNITÉS', '| Risque / opportunité | Probabilité | Impact | Mesure | Responsable |\n| ____________ | faible / moyenne / forte | délai / coût / qualité | ____________ | ____________ |\n| ____________ | faible / moyenne / forte | délai / coût / qualité | ____________ | ____________ |'),
'Rapport de livraison hebdomadaire des matériaux': SIMPLE('RAPPORT DE LIVRAISONS DE LA SEMAINE', 'Semaine du ____________ au ____________\n| Date | Fournisseur | Matériau | Quantité | Bon n° | Conforme |\n| ____ | ____________ | ____________ | ____ | ____ | oui / non |\n| ____ | ____________ | ____________ | ____ | ____ | oui / non |')
  };

  /* --- procès-verbaux --- */
  var PV2 = {
'Réception des fondations': PVH + 'RÉCEPTION DES FONDATIONS' + PVB + '\nLes fondations (fouilles, béton de propreté, ferraillage, coulage) ont été contrôlées.\n| Point | Conforme | Observation |\n| Profondeur et niveau d’assise | oui / non | ____________ |\n| Dimensions | oui / non | ____________ |\n| Qualité du sol rencontré | oui / non | ____________ |\n## Décision\nLa suite des travaux est autorisée / suspendue jusqu’à reprise des points relevés.' + FT,
'Réception du gros œuvre': PVH + 'RÉCEPTION DU GROS ŒUVRE' + PVB + '\n| Ouvrage | Conforme | Réserve |\n| Structure (poteaux, poutres, dalles) | oui / non | ____________ |\n| Maçonnerie | oui / non | ____________ |\n| Toiture / charpente | oui / non | ____________ |\n## Décision\nLe gros œuvre est réceptionné / réceptionné avec réserves.' + FT,
'Réception des réseaux (eau, électricité)': PVH + 'RÉCEPTION DES RÉSEAUX' + PVB + '\n| Réseau | Essai réalisé | Résultat |\n| Eau potable | pression / étanchéité | ____________ |\n| Évacuation | écoulement | ____________ |\n| Électricité | isolement / terre | ____________ |\n## Décision\nRéseaux acceptés / à reprendre : ____________' + FT,
'Réception des finitions et de la peinture': PVH + 'RÉCEPTION DES FINITIONS' + PVB + '\n| Local | Peinture | Sols | Menuiseries | Observation |\n| ____________ | ____________ | ____________ | ____________ | ____________ |\nRéserves à lever avant le ____________.' + FT,
'Ouverture de chantier': PVH + 'OUVERTURE DE CHANTIER' + PVB + '\nOuverture officielle du chantier en présence des parties.\n## Vérifications\n- Panneau de chantier, clôture, branchements : ____________\n- Assurances et autorisations remises : ____________\n- Plan d’hygiène et de sécurité remis : ____________\nDélai contractuel : ___ jours à compter de ce jour.' + FT,
'Mise à disposition du terrain': PVH + 'MISE À DISPOSITION DU TERRAIN' + PVB + '\nLe maître d’ouvrage met à disposition le terrain situé à {{lieu}}, libre de toute occupation.\n- Superficie : ____________ — accès : ____________ — limites matérialisées : oui / non\n- Servitudes ou réseaux existants : ____________' + FT,
'État des lieux des avoisinants avant travaux': PVH + 'CONSTAT DES AVOISINANTS AVANT TRAVAUX' + PVB + '\n| Propriété / ouvrage voisin | État constaté (fissures, clôtures…) | Photos |\n| ____________ | ____________ | oui / non |\nCe constat sert de référence en cas de réclamation du voisinage.' + FT,
'Prélèvement d’échantillons de béton': PVH + 'PRÉLÈVEMENT D’ÉCHANTILLONS DE BÉTON' + PVB + '\nOuvrage : {{objet}}\n| Éprouvette n° | Date de prélèvement | Affaissement | Laboratoire | Écrasement prévu le |\n| ____ | ____ | ____ | ____________ | ____ |\n| ____ | ____ | ____ | ____________ | ____ |' + FT,
'Livraison de logements / locaux': PVH + 'LIVRAISON DE LOCAUX' + PVB + '\nLocal livré : ____________ — acquéreur / occupant : ____________\n- Clés remises : ____ — compteurs relevés : ____________\n- Défauts constatés : ____________\nLe bénéficiaire reconnaît avoir pris possession des lieux.' + FT,
'Remise du dossier des ouvrages exécutés': PVH + 'REMISE DU DOSSIER DES OUVRAGES EXÉCUTÉS' + PVB + '\n| Pièce remise | Nombre | Observation |\n| Plans de récolement | ____ | ____________ |\n| Notices et garanties | ____ | ____________ |\n| Certificats et essais | ____ | ____________ |' + FT
  };

  /* --- comptes rendus --- */
  var CR2 = {
'Réunion hebdomadaire de chantier': CRH('RÉUNION HEBDOMADAIRE DE CHANTIER', ['Avancement des travaux', 'Planning et retards', 'Qualité et sécurité', 'Questions diverses']),
'Réunion avec le maître d’ouvrage': CRH('RÉUNION AVEC LE MAÎTRE D’OUVRAGE', ['Point d’avancement', 'Décisions attendues du maître d’ouvrage', 'Budget et avenants', 'Planning et réception']),
'Réunion de sécurité': CRH('RÉUNION DE SÉCURITÉ', ['Accidents et presque-accidents', 'Respect des équipements de protection', 'Risques de la semaine à venir', 'Actions correctives']),
'Réunion avec les sous-traitants': CRH('RÉUNION AVEC LES SOUS-TRAITANTS', ['Planning d’intervention', 'Interfaces entre corps d’état', 'Qualité et reprises', 'Documents à fournir']),
'Réunion de préparation de la réception': CRH('RÉUNION DE PRÉPARATION DE LA RÉCEPTION', ['Liste des réserves', 'Essais et documents à remettre', 'Date de la réception', 'Nettoyage et remise des clés']),
'Réunion de fin de chantier': CRH('RÉUNION DE FIN DE CHANTIER', ['Bilan technique et financier', 'Levée des réserves', 'Garanties et maintenance', 'Remise du dossier des ouvrages exécutés'])
  };

  /* --- ordres de service --- */
  var OS2 = {
'Modification du planning': OSH + 'MODIFICATION DU PLANNING' + OSB + 'Le planning d’exécution est modifié comme suit : {{objet}}.\nNouvelle date d’achèvement : {{date_effet}}.\n\nFait à {{ville}}, le {{date}}',
'Changement de matériaux': OSH + 'CHANGEMENT DE MATÉRIAUX' + OSB + 'Il est ordonné de remplacer les matériaux prévus par : {{objet}}.\nL’incidence financière et sur le délai sera chiffrée avant exécution.\n\nFait à {{ville}}, le {{date}}',
'Accélération des travaux': OSH + 'ACCÉLÉRATION DES TRAVAUX' + OSB + 'L’entreprise renforce ses moyens (personnel, matériel, horaires) afin de tenir la date du {{date_effet}}.\nLes sujétions correspondantes seront précisées par avenant.\n\nFait à {{ville}}, le {{date}}',
'Suspension partielle des travaux': OSH + 'SUSPENSION PARTIELLE DES TRAVAUX' + OSB + 'Les travaux suivants sont suspendus à compter du {{date_effet}} : {{objet}}.\nLes autres travaux se poursuivent normalement.\n\nFait à {{ville}}, le {{date}}',
'Essais complémentaires': OSH + 'ESSAIS COMPLÉMENTAIRES' + OSB + 'L’entreprise fait réaliser les essais suivants : {{objet}}, avant le {{date_effet}}, et en remet les résultats à la maîtrise d’œuvre.\n\nFait à {{ville}}, le {{date}}',
'Purge et démolition d’ouvrages non conformes': OSH + 'DÉMOLITION D’OUVRAGES NON CONFORMES' + OSB + 'Il est ordonné de démolir et reconstruire, aux frais de l’entreprise : {{objet}}, avant le {{date_effet}}.\n\nFait à {{ville}}, le {{date}}',
'Clôture du chantier': OSH + 'CLÔTURE DU CHANTIER' + OSB + 'L’entreprise démonte ses installations, nettoie le site et évacue ses déchets avant le {{date_effet}}.\n\nFait à {{ville}}, le {{date}}'
  };

  /* --- notes et fiches techniques --- */
  var NOT2 = {
'Plan d’installation de chantier': SIMPLE('PLAN D’INSTALLATION DE CHANTIER', '## Implantation\n- Accès et circulation des engins : ____________\n- Zone de stockage des matériaux : ____________\n- Base de vie (bureau, vestiaires, sanitaires) : ____________\n- Branchements provisoires (eau, électricité) : ____________\n- Clôture, panneau, gardiennage : ____________\n## Observations\n____________________'),
'Plan d’hygiène et de sécurité (simplifié)': SIMPLE('PLAN D’HYGIÈNE ET DE SÉCURITÉ', '## Responsable sécurité\nNom : ____________ — téléphone : ____________\n## Risques principaux\n| Risque | Mesure de prévention | Responsable |\n| Chutes de hauteur | ____________ | ____________ |\n| Fouilles et tranchées | ____________ | ____________ |\n| Engins et circulation | ____________ | ____________ |\n| Électricité | ____________ | ____________ |\n## Secours\n- Hôpital / centre de santé le plus proche : ____________\n- Numéros d’urgence : ____________'),
'Méthodologie d’exécution (mode opératoire)': SIMPLE('MÉTHODOLOGIE D’EXÉCUTION', 'Ouvrage : {{objet}}\n## 1. Moyens\n- Personnel : ____________ — matériel : ____________ — matériaux : ____________\n## 2. Étapes\n1. ____________________\n2. ____________________\n3. ____________________\n## 3. Contrôles qualité\n- ____________________\n## 4. Sécurité\n- ____________________'),
'Note de synthèse mensuelle': SIMPLE('NOTE DE SYNTHÈSE MENSUELLE', '- Avancement : ____ % — délai restant : ____ jours\n- Situation financière : ____________\n- Principaux événements : ____________\n- Décisions à prendre : ____________'),
'Fiche technique d’ouvrage': SIMPLE('FICHE TECHNIQUE D’OUVRAGE', 'Ouvrage : {{objet}}\n| Caractéristique | Valeur |\n| Dimensions | ____________ |\n| Matériaux | ____________ |\n| Résistance / classe | ____________ |\n| Date d’exécution | ____________ |\n| Entreprise | {{entreprise}} |'),
'Procédure de réception des matériaux': SIMPLE('PROCÉDURE DE RÉCEPTION DES MATÉRIAUX', '1. Vérifier le bon de livraison et la quantité.\n2. Contrôler l’aspect et la conformité aux fiches approuvées.\n3. Prélever les échantillons à essayer.\n4. Stocker à l’abri et à l’écart du sol.\n5. Signaler et isoler tout matériau non conforme.')
  };

  /* --- fiches de contrôle et formulaires --- */
  var FCH2 = {
'Fiche de contrôle — ferraillage': CK('FERRAILLAGE', ['Diamètres et nombre de barres', 'Espacement des armatures', 'Enrobage et cales', 'Recouvrements et ancrages', 'Propreté des aciers']),
'Fiche de contrôle — coffrage': CK('COFFRAGE', ['Dimensions et niveaux', 'Rigidité et étaiement', 'Étanchéité des joints', 'Propreté et huile de décoffrage', 'Réservations et fourreaux']),
'Fiche de contrôle — coulage du béton': CK('COULAGE DU BÉTON', ['Classe de béton conforme au bon de livraison', 'Affaissement', 'Vibration', 'Éprouvettes prélevées', 'Cure du béton']),
'Fiche de contrôle — maçonnerie': CK('MAÇONNERIE', ['Alignement et aplomb', 'Épaisseur des joints', 'Chaînages et linteaux', 'Qualité des blocs', 'Mortier']),
'Fiche de contrôle — enduits': CK('ENDUITS', ['Planéité', 'Adhérence', 'Épaisseur', 'Fissures', 'Angles et arêtes']),
'Fiche de contrôle — étanchéité': CK('ÉTANCHÉITÉ', ['Support propre et sec', 'Pentes vers les évacuations', 'Relevés et recouvrements', 'Essai de mise en eau', 'Protection finale']),
'Fiche de contrôle — carrelage et sols': CK('CARRELAGE ET SOLS', ['Planéité du support', 'Calepinage', 'Joints', 'Adhérence (sondage)', 'Propreté']),
'Fiche de contrôle — peinture': CK('PEINTURE', ['Préparation du support', 'Nombre de couches', 'Uniformité de la teinte', 'Raccords et finitions', 'Protection des autres ouvrages']),
'Fiche de contrôle — plomberie': CK('PLOMBERIE', ['Diamètres et matériaux', 'Essai de pression', 'Pentes d’évacuation', 'Siphons et ventilation', 'Robinetterie']),
'Fiche de contrôle — électricité': CK('ÉLECTRICITÉ', ['Section des câbles', 'Protections (disjoncteurs)', 'Mise à la terre', 'Mesure d’isolement', 'Repérage du tableau']),
'Demande d’achat / commande de matériaux': '# DEMANDE D’ACHAT N° {{no}}\nProjet : {{projet}} — {{lieu}}\nDemandeur : ____________ — date : {{date}} — livraison souhaitée le : ____________\n| Désignation | Quantité | Unité | Prix estimé | Fournisseur proposé |\n| ____________ | ____ | ____ | ____ | ____________ |\n| ____________ | ____ | ____ | ____ | ____________ |\nApprobation : ____________',
'Bon de sortie de matériel': '# BON DE SORTIE DE MATÉRIEL\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}} — bénéficiaire : ____________\n| Matériel / outil | Quantité | État à la sortie | Retour prévu |\n| ____________ | ____ | ____________ | ____ |\n| ____________ | ____ | ____________ | ____ |\nVisa du magasinier : ____________',
'Liste de réserves (punch list)': '# LISTE DE RÉSERVES\nProjet : {{projet}} — {{lieu}}\nEntreprise : {{entreprise}} · Lot : {{lot}}\n| N° | Localisation | Réserve | Délai | Levée (date) |\n| 1 | ____________ | ____________ | ____ | ____ |\n| 2 | ____________ | ____________ | ____ | ____ |\n| 3 | ____________ | ____________ | ____ | ____ |\n| 4 | ____________ | ____________ | ____ | ____ |',
'Fiche d’avancement par lot': '# FICHE D’AVANCEMENT PAR LOT\nProjet : {{projet}} — {{lieu}}\n| Lot | Entreprise | Montant du lot | Avancement (%) | Visa |\n| ____________ | ____________ | ____ | ____ | ____ |\n| ____________ | ____________ | ____ | ____ | ____ |\n| ____________ | ____________ | ____ | ____ | ____ |',
'Fiche de visite de chantier': '# FICHE DE VISITE DE CHANTIER\nProjet : {{projet}} — {{lieu}}\nDate : {{date_effet}} — visiteur : ____________\n| Zone visitée | Constat | Photo n° | Action |\n| ____________ | ____________ | ____ | ____________ |\n| ____________ | ____________ | ____ | ____________ |',
'Fiche d’incident / presque-accident': '# FICHE D’INCIDENT / PRESQUE-ACCIDENT\nProjet : {{projet}} — {{lieu}}\nDate et heure : ____________ — lieu précis : ____________\n## Description\n____________________\n## Personnes concernées\n- ____________________\n## Causes et mesures immédiates\n- ____________________\n## Mesures préventives\n- ____________________',
'Registre d’accès des visiteurs': '# REGISTRE D’ACCÈS DES VISITEURS\nProjet : {{projet}} — {{lieu}}\n| Date | Nom | Organisme | Motif | Heure d’arrivée | Heure de départ | Signature |\n| ____ | ____________ | ____________ | ____________ | ____ | ____ | ____ |\n| ____ | ____________ | ____________ | ____________ | ____ | ____ | ____ |\n| ____ | ____________ | ____________ | ____________ | ____ | ____ | ____ |',
'Demande d’information (RFI)': '# DEMANDE D’INFORMATION N° {{no}}\nProjet : {{projet}} — {{lieu}}\nDe : {{entreprise}} — à : ____________ — date : {{date}}\n## Question\n{{objet}}\n## Documents de référence\n- ____________________\n## Réponse de la maîtrise d’œuvre\n____________________\nDate de réponse souhaitée : ____________',
'Demande de modification (changement)': '# DEMANDE DE MODIFICATION N° {{no}}\nProjet : {{projet}} — {{lieu}}\nDemandeur : ____________ — date : {{date}}\n## Modification demandée\n{{objet}}\n## Incidences\n- Coût : ____________ — délai : ____________ — autres ouvrages : ____________\n## Décision\nAccordée / refusée / à étudier : ____________',
'Check-list de démarrage de chantier': '# CHECK-LIST DE DÉMARRAGE DE CHANTIER\nProjet : {{projet}} — {{lieu}}\n| Point | Fait | Date | Observation |\n| Ordre de service de démarrage reçu | oui / non | ____ | ____________ |\n| Assurances et garanties remises | oui / non | ____ | ____________ |\n| Plan d’hygiène et de sécurité | oui / non | ____ | ____________ |\n| Panneau et clôture de chantier | oui / non | ____ | ____________ |\n| Branchements eau et électricité | oui / non | ____ | ____________ |\n| Planning d’exécution remis | oui / non | ____ | ____________ |',
'Check-list de fin de chantier': '# CHECK-LIST DE FIN DE CHANTIER\nProjet : {{projet}} — {{lieu}}\n| Point | Fait | Date | Observation |\n| Travaux achevés et nettoyés | oui / non | ____ | ____________ |\n| Essais réalisés et résultats remis | oui / non | ____ | ____________ |\n| Réserves levées | oui / non | ____ | ____________ |\n| Dossier des ouvrages exécutés remis | oui / non | ____ | ____________ |\n| Installations de chantier démontées | oui / non | ____ | ____________ |\n| Clés et garanties remises | oui / non | ____ | ____________ |'
  };

  /* --- clauses complémentaires --- */
  var CLA2 = {
'Clauses de documents et d’études d’exécution': '# CLAUSES DE DOCUMENTS ET D’ÉTUDES D’EXÉCUTION\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Plans d’exécution\nL’entreprise établit les plans d’exécution et de détails et les soumet à l’approbation de la maîtrise d’œuvre ___ jours avant les travaux concernés.\n## Article 2 — Notes de calcul\nLes notes de calcul sont remises avec les plans de structure et signées par un ingénieur.\n## Article 3 — Documents après travaux\nPlans de récolement, notices et garanties sont remis avant la réception.',
'Clauses de planning et de suivi': '# CLAUSES DE PLANNING ET DE SUIVI\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Réunions\nUne réunion de chantier a lieu chaque ___ ; la présence du conducteur de travaux est obligatoire.\n## Article 2 — Comptes rendus\nLe compte rendu est diffusé sous ___ jours ; sans observation dans ce délai, il est réputé accepté.\n## Article 3 — Rapports\nL’entreprise remet un rapport d’avancement chaque ___ avec photos datées.',
'Clauses d’installation et de vie de chantier': '# CLAUSES D’INSTALLATION ET DE VIE DE CHANTIER\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Installations\nL’entreprise installe à ses frais clôture, panneau, bureau, sanitaires et stockage.\n## Article 2 — Branchements\nEau et électricité provisoires : à la charge de ____________.\n## Article 3 — Gardiennage\nLe gardiennage du chantier est assuré par ____________ pendant les heures de fermeture.',
'Clauses de coordination entre corps d’état': '# CLAUSES DE COORDINATION ENTRE CORPS D’ÉTAT\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Principe\nChaque entreprise coordonne ses interventions avec celles des autres lots sous la direction de la maîtrise d’œuvre.\n## Article 2 — Dégradations\nLes dégradations causées aux ouvrages d’un autre lot sont réparées par l’entreprise responsable.\n## Article 3 — Réservations\nLes réservations et fourreaux sont indiqués avant coulage.',
'Clauses de matériel et d’engins': '# CLAUSES DE MATÉRIEL ET D’ENGINS\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Moyens\nL’entreprise met en place le matériel nécessaire, en bon état, entretenu et assuré.\n## Article 2 — Conducteurs\nLes engins sont conduits par des opérateurs qualifiés et autorisés.\n## Article 3 — Pannes\nLes pannes n’ouvrent droit à aucune prolongation de délai.',
'Clauses de gestion des déchets': '# CLAUSES DE GESTION DES DÉCHETS\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Tri\nLes déchets sont triés par nature et stockés dans des zones dédiées.\n## Article 2 — Évacuation\nL’évacuation est assurée vers des sites autorisés ; les bordereaux sont conservés.\n## Article 3 — Brûlage\nLe brûlage de déchets sur le chantier est interdit.',
'Clauses de voisinage et d’accès': '# CLAUSES DE VOISINAGE ET D’ACCÈS\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Accès\nLes accès sont maintenus libres et la circulation des riverains n’est pas entravée.\n## Article 2 — Nuisances\nPoussières, bruit et boue sur la voie publique sont limités et nettoyés.\n## Article 3 — Réclamations\nToute plainte du voisinage est traitée par l’entreprise sous ___ jours.',
'Clauses de réclamations et de contestations': '# CLAUSES DE RÉCLAMATIONS\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Forme\nToute réclamation est écrite, motivée et chiffrée.\n## Article 2 — Délai\nElle est adressée dans les ___ jours suivant l’événement, faute de quoi elle est irrecevable.\n## Article 3 — Réponse\nLe maître d’ouvrage répond dans un délai de ___ jours.',
'Clauses de propriété des ouvrages et de transfert des risques': '# CLAUSES DE PROPRIÉTÉ ET DE TRANSFERT DES RISQUES\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Propriété\nLes ouvrages et matériaux incorporés deviennent la propriété du maître d’ouvrage au fur et à mesure de leur paiement.\n## Article 2 — Risques\nLa garde et les risques sont supportés par l’entreprise jusqu’à la réception.',
'Clauses de garantie de bonne fin': '# CLAUSES DE GARANTIE DE BONNE FIN\nProjet : {{projet}} — {{lieu}}\n## Article 1 — Garantie\nL’entreprise fournit une garantie de bonne fin de ___ % du montant du marché, délivrée par un établissement agréé.\n## Article 2 — Mise en jeu\nElle peut être mise en jeu après mise en demeure restée sans effet.\n## Article 3 — Libération\nElle est libérée à la réception sans réserve.'
  };

  /* --- lettres complémentaires --- */
  var LET2 = {
'Transmission du rapport de chantier': 'Objet : Transmission du rapport de chantier — {{projet}}\n\nMadame, Monsieur,\n\nVeuillez trouver ci-joint le rapport de chantier n° {{no}} du projet {{projet}} pour la période du ____________ au ____________.\n\n' + SAL + '\n\n{{societe}}',
'Convocation à la réception des travaux': 'Objet : Convocation à la réception — {{projet}}\n\nMadame, Monsieur,\n\nNous vous convoquons aux opérations de réception des travaux du projet {{projet}} le {{date_effet}}, à {{lieu}}. Votre présence ou celle de votre représentant est indispensable.\n\n' + SAL + '\n\n{{societe}}',
'Notification de suspension de travaux': 'Objet : Suspension des travaux — {{objet}}\n\nMadame, Monsieur,\n\nNous vous notifions la suspension des travaux du projet {{projet}} à compter du {{date_effet}}, pour le motif suivant : {{objet}}. Les mesures de protection du chantier restent à votre charge.\n\n' + SAL + '\n\n{{societe}}',
'Invitation du client à visiter le chantier': 'Objet : Invitation à visiter le chantier — {{projet}}\n\nMadame, Monsieur,\n\nNous avons le plaisir de vous inviter à visiter le chantier {{projet}} le {{date_effet}} à {{lieu}}. Les équipements de protection seront mis à votre disposition.\n\n' + SAL + '\n\n{{societe}}',
'Avertissement pour non-respect de la sécurité': 'Objet : Avertissement — non-respect des règles de sécurité\n\nMadame, Monsieur,\n\nLors de notre visite du {{date_effet}} sur le chantier {{projet}}, nous avons constaté : {{objet}}. Nous vous demandons de corriger immédiatement ces manquements. À défaut, l’arrêt des travaux concernés pourra être ordonné.\n\n' + SAL + '\n\n{{societe}}',
'Réponse à une demande de prolongation de délai': 'Objet : Réponse à votre demande de prolongation — {{objet}}\n\nMadame, Monsieur,\n\nAprès examen de votre demande relative au projet {{projet}}, nous vous informons que : accord pour ___ jours / refus motivé : ____________.\n\n' + SAL + '\n\n{{societe}}'
  };

  /* --- dossier de chantier --- */
  var DOS = {
'Page de garde du dossier de chantier': '# DOSSIER DE CHANTIER\n## {{projet}} — {{lieu}}\nMaître d’ouvrage : {{moa}}\nEntreprise : {{societe}}\nPermis / autorisation : {{permis}}\nPhase : {{phase}}\nDate d’édition : {{date}}\n\nChaque page porte le QR code de vérification : le scan ouvre la page publique d’authenticité du document.',
'Sommaire du dossier de chantier': '# SOMMAIRE DU DOSSIER DE CHANTIER\nProjet : {{projet}} — {{lieu}}\n## 1. Pièces administratives\n- Marché, ordres de service, avenants\n## 2. Rapports de chantier\n- Rapports journaliers, hebdomadaires, mensuels\n## 3. Procès-verbaux et comptes rendus\n- Réceptions, constats, réunions\n## 4. Qualité et sécurité\n- Fiches de contrôle, essais, rapports HSE\n## 5. Correspondance\n- Lettres, mises en demeure, notifications\n## 6. Dossier des ouvrages exécutés\n- Plans de récolement, notices, garanties',
'Liste des pièces du dossier des ouvrages exécutés': '# LISTE DES PIÈCES DU DOSSIER DES OUVRAGES EXÉCUTÉS\nProjet : {{projet}} — {{lieu}}\n| N° | Pièce | Indice | Remise le | Visa |\n| 1 | Plans de récolement | ____ | ____ | ____ |\n| 2 | Notices d’entretien | ____ | ____ | ____ |\n| 3 | Certificats et essais | ____ | ____ | ____ |\n| 4 | Garanties et assurances | ____ | ____ | ____ |\n| 5 | Photos de fin de chantier | ____ | ____ | ____ |',
'Fiche d’intervention ultérieure sur l’ouvrage': '# FICHE D’INTERVENTION ULTÉRIEURE\nProjet : {{projet}} — {{lieu}}\n| Ouvrage | Entretien conseillé | Fréquence | Précautions |\n| Toiture | ____________ | ____ | ____________ |\n| Façades | ____________ | ____ | ____________ |\n| Installations électriques | ____________ | ____ | ____________ |\n| Plomberie | ____________ | ____ | ____________ |'
  };

  /* fusion dans les séries principales (sans écraser) */
  function addAll(dst, src) { Object.keys(src).forEach(function (k) { if (!Object.prototype.hasOwnProperty.call(dst, k)) dst[k] = src[k]; }); }
  addAll(RAP, RAP2); addAll(PV, PV2); addAll(FCH, FCH2); addAll(CLA, CLA2); addAll(LET, LET2);

  /* ===================== FUSION SANS ÉCRASEMENT ===================== */
  var NEW_TYPES = {
    rapport: ['RAP', 'Rapport de chantier', '📊'],
    clause:  ['CLA', 'Clauses de chantier', '⚖️'],
    fiche:   ['FCH', 'Fiche et formulaire de chantier', '🧾'],
    dossier: ['DOS', 'Dossier de chantier', '📂']
  };
  var NEW_MODELS = { rapport: RAP, clause: CLA, fiche: FCH, dossier: DOS, pv: PV, cr: CR2, os: OS2, note: NOT2, lettre: LET, contrat: CTR, attest: ATT };

  /* les nouveaux types se placent avant « Texte libre » (qui reste en dernier) */
  var T = D.types || (D.types = {}), libre = T.libre;
  if (libre) delete T.libre;
  Object.keys(NEW_TYPES).forEach(function (k) { if (!T[k]) T[k] = NEW_TYPES[k]; });
  if (libre) T.libre = libre;

  D.models = D.models || {};
  Object.keys(NEW_MODELS).forEach(function (t) {
    var dst = D.models[t] || (D.models[t] = {}), src = NEW_MODELS[t];
    Object.keys(src).forEach(function (n) { if (!Object.prototype.hasOwnProperty.call(dst, n)) dst[n] = src[n]; });
  });

  /* signature : rapports et attestations = Directeur Général ; clauses = aucune (annexes de contrat) ; fiches = aucune */
  D.sign = D.sign || {};
  if (!D.sign.rapport) D.sign.rapport = 'dg';
  if (!D.sign.clause) D.sign.clause = 'none';
  if (!D.sign.fiche) D.sign.fiche = 'none';
  if (!D.sign.dossier) D.sign.dossier = 'dg';

  w.EXBPIE_V122 = { types: Object.keys(NEW_TYPES), count: Object.keys(NEW_MODELS).reduce(function (n, t) { return n + Object.keys(NEW_MODELS[t]).length; }, 0) };
})(window);
