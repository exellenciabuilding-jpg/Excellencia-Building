# V119g — Accueil : widgets Horloge + Météo

Deux cartes en haut du tableau de bord (sous le bandeau de bienvenue), comme sur l'écran d'accueil du téléphone.

- **Horloge** : analogique, les aiguilles tournent en temps réel (heure de l'appareil), pastille de date, température actuelle. S'arrête quand l'application est en arrière-plan.
- **Météo** : ville, température, conditions, min/max du jour. Appui sur la carte : « Ma position (GPS) » ou recherche d'une ville (mémorisée).
- **Position** : GPS de l'appareil → sinon position approximative par IP → sinon Kinshasa. Actualisation toutes les 15 min, au retour sur l'accueil et au retour de la connexion.
- **Hors connexion** : la dernière météo reste affichée, avec l'heure de mise à jour.
- Données : Open-Meteo (sans clé), BigDataCloud (nom du lieu), GeoJS (IP). Aucune clé API à configurer.

Fichiers : `exb-home-widgets.js` (nouveau), `index.html` (balise script), `sw.js` (cache hors ligne), `scripts/patch-android.js` (permissions de localisation).
Retrait : supprimer la balise `<script src="exb-home-widgets.js">`.

Android : relancer `npm run android:sync` pour appliquer les permissions. Windows (Electron) : le GPS y est souvent indisponible ; la position par IP prend le relais.
Testé : navigateur réel (GPS simulé, aiguilles en mouvement, choix de ville, cache) ; `check.js` 510/510. Non testé : APK et installateur Windows.
