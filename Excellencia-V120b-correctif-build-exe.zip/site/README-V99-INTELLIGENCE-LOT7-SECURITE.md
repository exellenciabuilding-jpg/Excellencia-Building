# EXCELLENCIA INTELLIGENCE — lot 7 : modifications et menaces (sécurité)

Nouveau : `exb-intelligence-7.js` (après `exb-intelligence.js`). Modifiés : `index.html` (1 balise), `sw.js`. Test : `node tools/test-intelligence-7.js`.
**Lecture seule sur vos données métier.** Écrit seulement `exb_intel_sec_base` (empreintes de référence) et `exb_intel_sec_log` (journal de sécurité). Aucune valeur sensible n'est copiée : une empreinte courte, le nom du réglage, la date.

## Détecté (panneau 🧠, module « Sécurité »)
- Réglages protégés (licence, identifiants, droits, 2FA, autorisations de l'assistant, réglages de la réception) modifiés, apparus ou supprimés **entre deux ouvertures** ; bouton « Valider ce changement ». En cours de session ou depuis un autre onglet : journal de sécurité.
- Horloge reculée ; entrées d'audit datées du futur.
- Suppression massive de fiches (≥ moitié d'une collection d'au moins 8) ; journal d'audit vidé ou désordonné.
- Connexions : ≥ 5 échecs en 15 min (alerte), ≥ 10 (erreur), réussite juste après des échecs, compte verrouillé.
- Injection : fiches avec `<script>`, `onerror=`, `javascript:`, identifiants piégés ; script/iframe d'origine inconnue ajouté à la page.
- Fraude / erreur : montant > 20 × la médiane ; facture déjà payée puis modifiée ; ≥ 25 modifications ou ≥ 5 suppressions en 2 min.

## L'IA en plus
Réponses locales (menace, sécurité, intégrité, horloge, fraude…), indice de sécurité /100, recommandation de sauvegarde (> 7 jours), **Rapport de sécurité** HTML hors ligne. API pour les autres lots : `EXBI.sec.scan(objet)`, `EXBI.sec.accept(clé)`.

## Réserves honnêtes
Confiance à la première utilisation (référence créée à la première analyse). Empreintes 2 × 32 bits : altérations simples, pas une attaque ciblée ; quelqu'un qui contrôle l'appareil peut aussi modifier la référence. Ce n'est ni un antivirus ni la sécurité du serveur (RLS, 2FA). Seuils à ajuster (« Ignorer » disponible). Testé : 33 contrôles en navigateur simulé.

## À signaler (moteur d'origine, non modifié)
`exb-intelligence.js` plante si une collection contient une fiche `null`.

## Retour en arrière
Supprimer la balise `<script src="exb-intelligence-7.js">` de index.html.
