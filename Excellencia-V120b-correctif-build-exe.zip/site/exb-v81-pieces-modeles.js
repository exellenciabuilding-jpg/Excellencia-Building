/* Excellencia Building V119 — Bibliothèque de modèles de « Pièces écrites ».
 * Chaque modèle est un texte à variables {{projet}}, {{client}}, {{lieu}}… remplies automatiquement, puis librement modifiables.
 * Mise en forme : « # Titre », « ## Sous-titre », « - puce », « 1. numéro », « | a | b | » (tableau), **gras**.
 * Ces modèles sont des bases courantes à adapter : les clauses contractuelles doivent être validées par votre conseil juridique. */
(function (w) {
  'use strict';
  var T = {
    cctp:   ['CCTP',  'Cahier des clauses techniques particulières', '📐'],
    ccap:   ['CCAP',  'Cahier des clauses administratives particulières', '📑'],
    lettre: ['LTR',   'Lettre', '✉️'],
    cr:     ['CR',    'Compte rendu de réunion', '🗒️'],
    os:     ['OS',    'Ordre de service', '📣'],
    pv:     ['PV',    'Procès-verbal', '📝'],
    attest: ['ATT',   'Attestation', '🏅'],
    contrat:['CTR',   'Contrat / convention', '🤝'],
    note:   ['NOT',   'Note, rapport ou fiche technique', '📋'],
    libre:  ['LIB',   'Texte libre', '✍️']
  };

  /* ---------- CCTP : un lot = des articles ---------- */
  var LOTS = {
'Généralités': `## Objet
Le présent CCTP définit la nature, la qualité et les conditions d’exécution des ouvrages du projet {{projet}}, situé à {{lieu}}, pour le compte de {{moa}}.
## Documents de référence
- Plans et pièces écrites du dossier de consultation, indice le plus récent.
- Normes et règles de l’art en vigueur ; en l’absence de règle locale, les normes françaises (NF/DTU) et les Eurocodes servent de référence.
## Obligations de l’entreprise
- Vérifier les plans et cotes sur place avant exécution et signaler toute anomalie par écrit.
- Soumettre à l’approbation de l’architecte les échantillons, fiches techniques et plans d’exécution avant commande.
- Assurer la protection des ouvrages exécutés et la propreté du chantier.`,
'Installation de chantier et terrassements': `## Installation
- Clôture, panneau de chantier, branchements provisoires eau et électricité, sanitaires et local de stockage.
- Implantation des ouvrages par un géomètre ou l’entreprise, contrôlée par l’architecte avant toute fouille.
## Terrassements
- Décapage de la terre végétale et mise en dépôt ; fouilles en rigole et en puits aux cotes des plans.
- Fond de fouille purgé, compacté et réceptionné par l’architecte avant ferraillage.
- Remblais par couches de 20 cm maximum, compactées ; évacuation des déblais excédentaires.`,
'Fondations': `- Fondations conformes au plan de fondation et à l’étude de sol : semelles filantes, semelles isolées, longrines ou radier selon les plans.
- Béton de propreté de 5 cm minimum sous toutes les fondations ; fond de fouille réceptionné avant ferraillage.
- Attentes de poteaux et de chaînages positionnées avec précision avant bétonnage.
- Protection des fondations contre les eaux de ruissellement et les remontées d’humidité (hérisson, polyane, enduit hydrofuge selon plans).`,
'Béton armé': `## Matériaux
- Ciment de classe agréée par l’architecte ; granulats propres, exempts d’argile et de matières organiques ; eau potable.
- Aciers à haute adhérence de nuance indiquée aux plans (ex. FeE500), stockés hors du sol et sans rouille non adhérente.
- Béton de propreté de 5 cm minimum sous toutes les fondations.
## Mise en œuvre
- Coffrages étanches, rigides et propres ; décoffrage selon les délais convenus avec l’architecte.
- Enrobages minimaux conformes aux plans, assurés par des cales en béton ou plastique.
- Vibration systématique du béton ; cure d’au moins 7 jours (arrosage ou produit de cure).
- Résistance caractéristique minimale indiquée aux plans ; éprouvettes de contrôle prélevées sur demande de l’architecte.`,
'Maçonnerie': `- Blocs pleins ou creux de dimensions indiquées aux plans, de résistance suffisante, stockés à l’abri.
- Mortier dosé à 300 kg de ciment par m³ de sable minimum pour les joints et hourdages.
- Joints horizontaux et verticaux de 1 cm, harpages et chaînages horizontaux et verticaux conformes aux plans.
- Linteaux au-dessus de toutes les baies ; réservations pour les gaines et canalisations avant exécution des enduits.`,
'Enduits et revêtements': `## Enduits
- Enduit au mortier en deux couches (dressage et finition), sur supports propres et humidifiés.
- Planéité vérifiée à la règle de 2 m : flèche maximale de 5 mm.
## Revêtements de sol et muraux
- Carreaux de première qualité, échantillon agréé ; calepinage soumis à l’architecte.
- Pose collée ou scellée selon support, joints réguliers, plinthes assorties.`,
'Étanchéité': `- Support propre, sec, dépoussiéré et formé de pentes conformes aux plans (1,5 % minimum vers les évacuations).
- Revêtement d’étanchéité (bitumineux, membrane ou résine) de qualité agréée, relevés d’au moins 15 cm en périphérie et autour des émergences.
- Évacuations d’eaux pluviales avec crapaudines, trop-pleins et joints de dilatation traités.
- Essai de mise en eau pendant 48 h avant réception du lot ; garantie d’étanchéité remise par l’entreprise.`,
'Charpente et couverture': `- Charpente (bois traité ou métallique protégée) conforme au plan de structure et aux notes de calcul.
- Couverture en tôles ou tuiles de qualité agréée, fixations anticorrosion, recouvrements et faîtages étanches.
- Gouttières, descentes d’eaux pluviales et raccordement au réseau d’évacuation.
- Essai d’étanchéité avant réception du lot.`,
'Cloisons et faux plafonds': `- Cloisons en blocs, en plaques de plâtre sur ossature ou en panneaux selon plans ; épaisseurs et hauteurs conformes aux plans.
- Faux plafonds en plaques ou en dalles suspendues sur ossature métallique, trappes de visite aux emplacements des organes techniques.
- Joints traités et bandes collées ; planéité contrôlée à la règle de 2 m.
- Réservations et renforts prévus pour les appareils suspendus et les luminaires.`,
'Menuiseries': `- Portes, fenêtres et châssis conformes aux plans de menuiserie (dimensions, sens d’ouverture, vitrage).
- Bois séchés et traités, ou profilés métalliques protégés ; quincaillerie de qualité, serrures avec trois clés.
- Pose d’aplomb et de niveau, calfeutrement périphérique, réglage avant réception.`,
'Métallerie et ferronnerie': `- Ouvrages en acier (garde-corps, portails, grilles, escaliers métalliques) conformes aux plans et détails d’exécution.
- Soudures continues meulées, protection antirouille (primaire) et peinture de finition en deux couches.
- Scellements et fixations dimensionnés pour les charges d’usage ; hauteur des garde-corps conforme à la réglementation.`,
'Plomberie sanitaire': `- Alimentation en eau froide (et chaude si prévue) par canalisations de matériau et diamètre indiqués ; robinets d’arrêt par local.
- Évacuation des eaux usées et vannes par tuyaux PVC, pentes minimales de 1 cm par mètre, siphons et ventilations.
- Appareils sanitaires de première qualité, échantillons agréés.
- Essais de pression et d’étanchéité avant fermeture des tranchées et gaines.`,
'Électricité': `- Installation conforme aux plans électriques : tableau, circuits d’éclairage, prises, circuits spécialisés, mise à la terre.
- Câbles sous gaine, sections adaptées aux puissances, disjoncteurs différentiels de sensibilité adaptée.
- Appareillage de marque agréée ; repérage des circuits sur le tableau.
- Mesure de la résistance de terre et essais de fonctionnement avant réception.`,
'Climatisation et ventilation': `- Équipements dimensionnés selon bilan thermique remis par l’entreprise et validé par l’architecte.
- Liaisons frigorifiques isolées, évacuation des condensats raccordée, supports antivibratiles.
- Ventilation mécanique des locaux humides (sanitaires, cuisines) avec rejet à l’extérieur.
- Mise en service, réglages, notice d’entretien et formation du personnel d’exploitation.`,
'Sécurité incendie': `- Extincteurs adaptés aux risques, installés aux emplacements indiqués aux plans, avec signalisation.
- Issues de secours dégagées, éclairage de sécurité et plans d’évacuation affichés.
- Détection incendie et alarme lorsque le programme les prévoit ; vérification par un organisme agréé avant mise en service.`,
'Peinture': `- Préparation des supports (rebouchage, ponçage, impression).
- Deux couches de finition minimum, peintures de première qualité, teintes choisies par le maître d’ouvrage.
- Protection des menuiseries, sols et appareillages pendant les travaux ; retouches avant réception.`,
'VRD et aménagements extérieurs': `- Voiries, allées, parkings et réseaux enterrés conformément aux plans.
- Clôture et portail selon plans ; évacuation des eaux pluviales vers l’exutoire prévu.
- Regards, caniveaux et fosses (septique, puisard) dimensionnés et réceptionnés avant remblaiement.
- Nettoyage final et remise en état des abords.`,
'Hygiène, sécurité et environnement': `- Plan d’hygiène et de sécurité établi par l’entreprise avant démarrage ; équipements de protection individuelle obligatoires pour tout le personnel.
- Signalisation, garde-corps provisoires, protection des fouilles et des trémies, trousse de premiers secours sur site.
- Gestion des déchets : tri, stockage et évacuation vers les sites autorisés ; limitation des nuisances (bruit, poussière).
- Tout accident ou incident est déclaré à la maîtrise d’œuvre dans les 24 heures.`,
'Réception et dossier des ouvrages exécutés': `- Opérations préalables à la réception : essais, vérifications et nettoyage complet des ouvrages.
- Remise du dossier des ouvrages exécutés (DOE) : plans de récolement, fiches techniques, notices d’utilisation et d’entretien, certificats et garanties.
- Formation du maître d’ouvrage ou de l’exploitant à l’usage des équipements installés.`
  };

  /* ---------- CCAP ---------- */
  var CCAP = `# CAHIER DES CLAUSES ADMINISTRATIVES PARTICULIÈRES (CCAP)
Marché : {{projet}} — {{lieu}}
Maître d’ouvrage : {{moa}} · Maître d’œuvre : {{societe_rep}} · Entreprise : {{entreprise}}
## Article 1 — Objet du marché
Le présent marché a pour objet l’exécution des travaux du lot « {{lot}} » du projet {{projet}}.
## Article 2 — Pièces contractuelles
Par ordre de priorité décroissant : l’acte d’engagement, le présent CCAP, le CCTP, les plans d’exécution, le devis quantitatif et estimatif.
## Article 3 — Prix et paiement
- Les prix sont fermes et non révisables, exprimés hors taxes ; la TVA est appliquée au taux en vigueur.
- Paiement sur situations mensuelles visées par la maîtrise d’œuvre, dans un délai de 30 jours après réception de la facture.
- Une avance de démarrage de ___ % peut être accordée contre garantie.
## Article 4 — Délai d’exécution
Le délai est de ___ jours calendaires à compter de l’ordre de service de démarrage. Les intempéries exceptionnelles justifiées par écrit peuvent donner lieu à prolongation.
## Article 5 — Pénalités de retard
Pénalité de ___ pour mille du montant du marché par jour calendaire de retard, plafonnée à ___ % du marché.
## Article 6 — Retenue de garantie
Une retenue de ___ % est opérée sur chaque situation et restituée un an après la réception, sous réserve de la levée des réserves.
## Article 7 — Assurances
L’entreprise justifie, avant démarrage, d’une assurance responsabilité civile et, pour les ouvrages concernés, d’une garantie décennale.
## Article 8 — Sous-traitance
Toute sous-traitance est soumise à l’accord écrit préalable du maître d’ouvrage.
## Article 9 — Réunions de chantier
Une réunion hebdomadaire est tenue sur site ; l’entreprise y est représentée par un responsable habilité.
## Article 10 — Réception
La réception est prononcée après les opérations préalables et la constatation de l’achèvement des travaux ; les réserves sont consignées dans un procès-verbal avec délai de levée.
## Article 11 — Garantie de parfait achèvement
L’entreprise répare les désordres signalés pendant un an à compter de la réception.
## Article 12 — Résiliation et litiges
Les parties recherchent d’abord une solution amiable ; à défaut, le litige est porté devant la juridiction compétente du lieu des travaux.

Fait à {{ville}}, le {{date}}
| Le maître d’ouvrage | L’entreprise | Le maître d’œuvre |
| Lu et approuvé | Lu et approuvé | |`;

  var CCAP_SIMPLE = `# CONDITIONS ADMINISTRATIVES SIMPLIFIÉES
Projet : {{projet}} — {{lieu}}
Entre {{moa}} (le maître d’ouvrage) et {{entreprise}} (l’entreprise), pour le lot « {{lot}} ».
## 1. Objet
Exécution des travaux décrits dans le devis et les plans joints.
## 2. Prix et acomptes
- Montant : ____________ HT.
- Acompte de démarrage : ___ % ; solde sur situations visées par la maîtrise d’œuvre.
## 3. Délai
___ jours calendaires à compter de l’ordre de service de démarrage.
## 4. Réception et garantie
Réception avec procès-verbal ; garantie de parfait achèvement d’un an.
## 5. Litiges
Recherche d’une solution amiable avant toute action devant la juridiction compétente.

Fait à {{ville}}, le {{date}}
| Le maître d’ouvrage | L’entreprise |
| Lu et approuvé | Lu et approuvé |`;

  /* ---------- Lettres ---------- */
  var SAL = 'Veuillez agréer, Madame, Monsieur, l’expression de nos salutations distinguées.';
  var LET = {
'Transmission de documents': `Objet : {{objet}}
Réf. projet : {{projet}}

Madame, Monsieur,

Nous vous prions de trouver ci-joint les documents relatifs au projet {{projet}} (phase : {{phase}}), pour votre examen.

Nous vous remercions de nous retourner votre visa ou vos observations dans un délai de ___ jours.

${SAL}`,
'Mise en demeure à une entreprise': `Objet : Mise en demeure — {{objet}}
Réf. projet : {{projet}} — Lot : {{lot}}

Madame, Monsieur,

Malgré nos précédentes demandes, nous constatons que {{objet}}.

Nous vous mettons en demeure d’y remédier dans un délai de ___ jours à compter de la réception de la présente. À défaut, nous nous réserverons le droit d’appliquer les pénalités prévues au marché et de faire exécuter les prestations aux frais de l’entreprise.

Veuillez agréer, Madame, Monsieur, nos salutations distinguées.`,
'Demande de pièces complémentaires': `Objet : {{objet}}
Réf. projet : {{projet}}

Madame, Monsieur,

Pour poursuivre l’instruction du dossier relatif à {{projet}}, nous vous prions de nous faire parvenir les pièces suivantes :
- ____________________
- ____________________

Nous restons à votre disposition pour tout renseignement.

Veuillez agréer, Madame, Monsieur, nos salutations distinguées.`,
'Convocation à une réunion': `Objet : Convocation — réunion de chantier du {{date_effet}}
Réf. projet : {{projet}}

Madame, Monsieur,

Vous êtes convié(e) à la réunion relative au projet {{projet}}, le {{date_effet}} à ___ h, à {{lieu}}.

Ordre du jour :
- Avancement des travaux
- Points techniques en suspens
- Planning et prochaines échéances

Votre présence est indispensable.

Veuillez agréer, Madame, Monsieur, nos salutations distinguées.`,
'Offre de services': `Objet : Offre de services — {{objet}}
Réf. projet : {{projet}}

Madame, Monsieur,

Suite à votre demande, {{societe}} a l’honneur de vous soumettre son offre pour {{objet}}, relative au projet {{projet}} à {{lieu}}.

Notre offre comprend :
- La prestation décrite dans le descriptif joint ;
- Un délai d’exécution de ___ jours à compter de la signature ;
- Un montant de ____________ hors taxes, valable ___ jours.

Forts de notre expérience en ingénierie et construction, nous sommes à votre disposition pour toute précision et pour vous présenter notre offre lors d’un rendez-vous.

${SAL}`,
'Demande de devis / consultation': `Objet : Consultation — {{objet}}
Réf. projet : {{projet}} — Lot : {{lot}}

Madame, Monsieur,

Dans le cadre du projet {{projet}} à {{lieu}}, nous vous consultons pour {{objet}}.

Nous vous prions de nous remettre votre offre détaillée (quantités, prix unitaires, délai, conditions de paiement) au plus tard le {{date_effet}}. Le dossier technique est joint à la présente.

Une visite de site peut être organisée sur demande.

${SAL}`,
'Relance de paiement': `Objet : Relance — facture / situation en attente de règlement
Réf. projet : {{projet}}

Madame, Monsieur,

Sauf erreur ou omission de notre part, le règlement de ____________ (montant : ____________) relatif au projet {{projet}} n’a pas été reçu à ce jour, malgré l’échéance du ___/___/____.

Nous vous prions de bien vouloir procéder au règlement dans un délai de ___ jours. Si votre paiement a été effectué entre-temps, nous vous remercions de ne pas tenir compte de ce courrier.

${SAL}`,
'Notification de retard sur le planning': `Objet : Retard constaté — {{objet}}
Réf. projet : {{projet}} — Lot : {{lot}}

Madame, Monsieur,

Lors de notre dernier contrôle, nous avons constaté un retard de ___ jours sur le planning contractuel : {{objet}}.

Nous vous demandons de nous remettre, sous ___ jours, un planning de rattrapage précisant les moyens humains et matériels supplémentaires affectés au chantier. Nous rappelons que les pénalités de retard prévues au marché pourront être appliquées.

${SAL}`,
'Notification de non-conformité': `Objet : Non-conformité constatée — {{objet}}
Réf. projet : {{projet}} — Lot : {{lot}}

Madame, Monsieur,

Lors de notre visite du {{date_effet}}, nous avons relevé les non-conformités suivantes par rapport aux plans et au CCTP :
- ____________________
- ____________________

Nous vous demandons de procéder aux reprises nécessaires dans un délai de ___ jours et de nous en informer par écrit afin d’organiser un nouveau contrôle. Les travaux concernés ne seront pas réceptionnés tant que ces reprises ne seront pas exécutées.

${SAL}`,
'Réponse à une réclamation': `Objet : Réponse à votre réclamation — {{objet}}
Réf. projet : {{projet}}

Madame, Monsieur,

Nous avons bien reçu votre courrier relatif à {{objet}} et nous vous en remercions.

Après examen du dossier, nous vous informons que : ____________________.

Nous restons disponibles pour une rencontre sur site afin de trouver ensemble une solution satisfaisante.

${SAL}`,
'Transmission du dossier des ouvrages exécutés': `Objet : Remise du dossier des ouvrages exécutés (DOE)
Réf. projet : {{projet}}

Madame, Monsieur,

À l’issue des travaux du projet {{projet}}, nous avons le plaisir de vous remettre le dossier des ouvrages exécutés comprenant :
- Les plans de récolement ;
- Les fiches techniques et notices d’entretien des équipements ;
- Les certificats d’essais et les garanties.

Nous vous remercions d’accuser réception de ce dossier en nous retournant un exemplaire daté et signé.

${SAL}`,
'Remerciements de fin de chantier': `Objet : Remerciements — achèvement du projet {{projet}}
Réf. projet : {{projet}}

Madame, Monsieur,

À l’achèvement du projet {{projet}}, toute l’équipe de {{societe}} tient à vous remercier de la confiance que vous nous avez accordée.

Nous espérons que l’ouvrage répond à vos attentes et restons à votre écoute durant la période de garantie ainsi que pour vos projets futurs.

${SAL}`,
'Lettre libre': `Objet : {{objet}}
Réf. projet : {{projet}}

Madame, Monsieur,



${SAL}`
  };

  /* ---------- Comptes rendus ---------- */
  var CR = {
'Réunion de chantier': `# COMPTE RENDU DE RÉUNION DE CHANTIER N° ___
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}} · Phase : {{phase}}
## Présents
| Nom | Fonction / Société | Présent |
| ____________ | ____________ | Oui |
| ____________ | ____________ | Oui |
## Avancement des travaux
- ____________________
## Décisions et points à traiter
| N° | Point | Responsable | Échéance |
| 1 | ____________ | ____________ | ____ |
| 2 | ____________ | ____________ | ____ |
## Prochaine réunion
Le ____________ à ___ h, à {{lieu}}.

Ce compte rendu est réputé accepté sans observation dans un délai de 7 jours après sa diffusion.`,
'Réunion de lancement': `# COMPTE RENDU DE LA RÉUNION DE LANCEMENT
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}} · Maître d’ouvrage : {{moa}}
## Présents
| Nom | Fonction / Société | Présent |
| ____________ | ____________ | Oui |
## Rappel du projet
- Nature des travaux : ____________________
- Délai contractuel : ___ jours à compter de l’ordre de service de démarrage.
## Organisation du chantier
- Responsable de chantier : ____________________
- Jours et heures des réunions hebdomadaires : ____________________
- Installations de chantier, accès, stockage : ____________________
## Points d’attention
- Documents à remettre avant démarrage (assurances, plan d’hygiène et sécurité, planning d’exécution).
- Échantillons et fiches techniques à soumettre à l’approbation.
## Décisions
| N° | Point | Responsable | Échéance |
| 1 | ____________ | ____________ | ____ |`,
'Réunion de coordination technique': `# COMPTE RENDU DE COORDINATION TECHNIQUE
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}}
## Participants
| Nom | Lot / Société | Présent |
| ____________ | ____________ | Oui |
## Points de coordination
| N° | Interface entre lots | Problème | Solution retenue | Responsable |
| 1 | ____________ | ____________ | ____________ | ____________ |
## Plans et documents à modifier
- ____________________
## Prochaine réunion
Le ____________ à ___ h.`,
'Visite de chantier': `# COMPTE RENDU DE VISITE DE CHANTIER
Projet : {{projet}} — {{lieu}}
Date de visite : {{date_effet}} · Phase : {{phase}}
## Constatations
- Avancement général : ____________________
- Qualité d’exécution : ____________________
- Hygiène et sécurité : ____________________
## Observations et réserves
| N° | Observation | Lot concerné | Délai de reprise |
| 1 | ____________ | ____________ | ____ |
## Suite à donner
- ____________________`
  };

  /* ---------- Ordres de service ---------- */
  var OSH = `# ORDRE DE SERVICE N° {{no}}\nNature : `;
  var OSB = `\nProjet : {{projet}} — Lot : {{lot}}\nÀ l’attention de : {{entreprise}}\n\n`;
  var OS = {
'Démarrage des travaux': OSH + `DÉMARRAGE DES TRAVAUX` + OSB + `Il est ordonné à l’entreprise de commencer les travaux le {{date_effet}}.\nLe délai contractuel de ___ jours court à compter de cette date.\n\nFait à {{ville}}, le {{date}}`,
'Arrêt des travaux': OSH + `ARRÊT DES TRAVAUX` + OSB + `Il est ordonné à l’entreprise d’arrêter les travaux à compter du {{date_effet}}, pour le motif suivant : {{objet}}.\nLes mesures conservatoires nécessaires à la protection des ouvrages et du chantier restent à la charge de l’entreprise.\n\nFait à {{ville}}, le {{date}}`,
'Reprise des travaux': OSH + `REPRISE DES TRAVAUX` + OSB + `Il est ordonné à l’entreprise de reprendre les travaux le {{date_effet}}. Le délai restant à courir est de ___ jours.\n\nFait à {{ville}}, le {{date}}`,
'Travaux supplémentaires': OSH + `TRAVAUX SUPPLÉMENTAIRES / MODIFICATIFS` + OSB + `Il est ordonné à l’entreprise d’exécuter les travaux suivants : {{objet}}.\n| Désignation | Unité | Quantité | Prix unitaire |\n| ____________ | ____ | ____ | ____ |\nMontant estimé : ____________ HT. Incidence sur le délai : ___ jours.\nCes travaux feront l’objet d’un avenant au marché.\n\nFait à {{ville}}, le {{date}}`,
'Prolongation de délai': OSH + `PROLONGATION DE DÉLAI` + OSB + `Considérant {{objet}}, le délai d’exécution du marché est prolongé de ___ jours calendaires.\nLa nouvelle date contractuelle d’achèvement est fixée au {{date_effet}}.\nLes autres dispositions du marché restent inchangées.\n\nFait à {{ville}}, le {{date}}`,
'Reprise de malfaçons': OSH + `REPRISE DE MALFAÇONS` + OSB + `Il est ordonné à l’entreprise de reprendre, à ses frais, les ouvrages non conformes suivants : {{objet}}.\nLes reprises seront terminées au plus tard le {{date_effet}} et notifiées par écrit à la maîtrise d’œuvre pour contrôle.\n\nFait à {{ville}}, le {{date}}`,
'Préparation de la réception': OSH + `PRÉPARATION DE LA RÉCEPTION` + OSB + `L’entreprise est invitée à présenter les ouvrages aux opérations préalables à la réception le {{date_effet}}, après nettoyage complet et exécution des essais prévus au CCTP.\nLe dossier des ouvrages exécutés doit être remis avant cette date.\n\nFait à {{ville}}, le {{date}}`
  };

  /* ---------- Procès-verbaux ---------- */
  var PVH = `# PROCÈS-VERBAL DE `;
  var PV = {
'Réception provisoire': PVH + `RÉCEPTION PROVISOIRE
Projet : {{projet}} — {{lieu}}
Maître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}
Date des opérations : {{date_effet}}

Après visite des ouvrages, en présence des parties soussignées, il a été constaté que les travaux sont achevés et conformes, sous réserve des points listés ci-après.
## Réserves
| N° | Désignation de la réserve | Délai de levée |
| 1 | ____________ | ____ |
| 2 | ____________ | ____ |
## Décision
La réception provisoire est prononcée à la date du {{date_effet}}. Le délai de garantie de parfait achèvement court à compter de cette date. La levée des réserves donnera lieu à un constat écrit.

Fait à {{ville}}, le {{date}}`,
'Réception définitive': PVH + `RÉCEPTION DÉFINITIVE
Projet : {{projet}} — {{lieu}}
Maître d’ouvrage : {{moa}} · Entreprise : {{entreprise}} · Lot : {{lot}}
Date des opérations : {{date_effet}}

À l’expiration du délai de garantie, les parties ont procédé à la visite des ouvrages. Il est constaté que les réserves de la réception provisoire sont levées et que les désordres signalés pendant la garantie ont été réparés.
## Décision
La réception définitive est prononcée à la date du {{date_effet}}. La retenue de garantie est restituée à l’entreprise.

Fait à {{ville}}, le {{date}}`,
'Levée de réserves': PVH + `LEVÉE DE RÉSERVES
Projet : {{projet}} — {{lieu}}
Entreprise : {{entreprise}} · Lot : {{lot}}
Date de contrôle : {{date_effet}}
## Réserves contrôlées
| N° | Réserve | Levée (oui / non) | Observation |
| 1 | ____________ | ____ | ____________ |
| 2 | ____________ | ____ | ____________ |
## Conclusion
Les réserves marquées « oui » sont levées. Les autres devront être reprises au plus tard le ____________.

Fait à {{ville}}, le {{date}}`,
'Constat contradictoire': PVH + `CONSTAT CONTRADICTOIRE
Projet : {{projet}} — {{lieu}}
Date et lieu du constat : {{date_effet}}, {{lieu}}
Parties présentes : {{moa}} · {{entreprise}} · {{societe}}

Objet du constat : {{objet}}
## Faits constatés
- ____________________
- ____________________
## Observations des parties
| Partie | Observation |
| ____________ | ____________ |
Le présent constat est établi contradictoirement ; chaque partie en conserve un exemplaire.

Fait à {{ville}}, le {{date}}`,
'Remise / passation de chantier': PVH + `REMISE DE CHANTIER
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}}

Le maître d’ouvrage {{moa}} remet à l’entreprise {{entreprise}} le site du projet {{projet}} libre de toute occupation, pour exécution des travaux du lot « {{lot}} ».
## État des lieux
- Accès et clôture : ____________________
- Branchements existants (eau, électricité) : ____________________
- Observations : ____________________

Fait à {{ville}}, le {{date}}`,
'Implantation des ouvrages': PVH + `IMPLANTATION DES OUVRAGES
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}}

Les ouvrages ont été implantés conformément au plan de masse et au plan de fondation, en présence des parties soussignées.
## Points de repère
| Repère | Description | Cote / coordonnée |
| ____ | ____________ | ____________ |
## Observation
Toute modification du tracé fera l’objet d’un accord écrit préalable de la maîtrise d’œuvre.

Fait à {{ville}}, le {{date}}`
  };

  /* ---------- Attestations ---------- */
  var ATT = {
'Attestation de bonne exécution': `# ATTESTATION DE BONNE EXÉCUTION

Je soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que l’entreprise {{entreprise}} a exécuté dans de bonnes conditions les travaux du lot « {{lot}} » du projet {{projet}}, situé à {{lieu}}, pour le compte de {{moa}}.

Les travaux ont été réalisés conformément aux plans, aux règles de l’art et dans les délais convenus, sans réserve majeure.

La présente attestation est délivrée pour servir et valoir ce que de droit.

Fait à {{ville}}, le {{date}}`,
'Attestation de visite de site': `# ATTESTATION DE VISITE DE SITE

Je soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que {{entreprise}} a effectué le {{date_effet}} la visite du site du projet {{projet}} situé à {{lieu}}, dans le cadre de la consultation relative au lot « {{lot}} ».

Cette visite lui a permis de prendre connaissance des lieux, des accès et des contraintes du chantier.

La présente attestation est délivrée pour servir et valoir ce que de droit.

Fait à {{ville}}, le {{date}}`,
'Attestation de travail': `# ATTESTATION DE TRAVAIL

Je soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que M./Mme ____________________, né(e) le ___/___/____ à ____________, est employé(e) au sein de notre société depuis le ___/___/____ en qualité de ____________________.

L’intéressé(e) est toujours en activité à ce jour.

La présente attestation est délivrée à sa demande pour servir et valoir ce que de droit.

Fait à {{ville}}, le {{date}}`,
'Attestation de stage': `# ATTESTATION DE STAGE

Je soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que M./Mme ____________________ a effectué un stage au sein de notre société du ___/___/____ au ___/___/____, dans le domaine : ____________________.

Pendant cette période, l’intéressé(e) a participé aux activités suivantes : ____________________.

La présente attestation est délivrée pour servir et valoir ce que de droit.

Fait à {{ville}}, le {{date}}`,
'Attestation de présence sur chantier': `# ATTESTATION DE PRÉSENCE SUR CHANTIER

Je soussigné(e), {{dg}}, {{dg_role}} de {{societe}}, atteste que M./Mme ____________________ était présent(e) sur le chantier {{projet}} à {{lieu}} le {{date_effet}}, pour : {{objet}}.

La présente attestation est délivrée pour servir et valoir ce que de droit.

Fait à {{ville}}, le {{date}}`
  };

  /* ---------- Contrats / conventions ---------- */
  var CTR = {
'Contrat de sous-traitance': `# CONTRAT DE SOUS-TRAITANCE
Entre les soussignés :
**{{societe}}**, représentée par {{dg}}, {{dg_role}}, ci-après « l’entrepreneur principal »,
et **{{entreprise}}**, ci-après « le sous-traitant ».
## Article 1 — Objet
L’entrepreneur principal confie au sous-traitant l’exécution des travaux du lot « {{lot}} » du projet {{projet}} à {{lieu}}, pour le compte de {{moa}}.
## Article 2 — Prix
Le prix forfaitaire est de ____________ hors taxes, ferme et non révisable, sauf avenant écrit.
## Article 3 — Paiement
Paiement sur situations mensuelles visées par l’entrepreneur principal, dans un délai de ___ jours après réception de la facture.
## Article 4 — Délai
Les travaux débutent le {{date_effet}} et sont achevés en ___ jours calendaires. Pénalité de retard : ___ pour mille par jour.
## Article 5 — Obligations du sous-traitant
- Exécuter les travaux selon les plans, le CCTP et les règles de l’art.
- Disposer des assurances requises et respecter les règles d’hygiène et de sécurité.
- Ne pas sous-traiter à son tour sans accord écrit.
## Article 6 — Garantie
Retenue de garantie de ___ % restituée à l’expiration du délai de garantie de parfait achèvement d’un an.
## Article 7 — Résiliation et litiges
En cas de manquement grave non corrigé après mise en demeure de ___ jours, le contrat peut être résilié. Les litiges sont réglés à l’amiable, à défaut devant la juridiction compétente.

Fait à {{ville}}, le {{date}}, en deux exemplaires.
| L’entrepreneur principal | Le sous-traitant |
| Lu et approuvé | Lu et approuvé |`,
'Contrat de prestation d’études': `# CONTRAT DE PRESTATION D’ÉTUDES
Entre les soussignés :
**{{client}}**, ci-après « le client »,
et **{{societe}}**, représentée par {{dg}}, {{dg_role}}, ci-après « le prestataire ».
## Article 1 — Objet
Le prestataire réalise pour le projet {{projet}} à {{lieu}} les études suivantes : {{objet}}.
## Article 2 — Livrables
- Plans et notes de calcul ;
- Pièces écrites et estimation ;
- Dossier remis en ___ exemplaires et au format numérique.
## Article 3 — Honoraires
Honoraires de ____________ hors taxes, payables : ___ % à la signature, ___ % à la remise des études, solde à la validation finale.
## Article 4 — Délai
Les études sont remises dans un délai de ___ jours à compter de la réception de l’acompte et des données nécessaires.
## Article 5 — Propriété et confidentialité
Les documents restent la propriété du prestataire jusqu’au paiement intégral. Chaque partie garde confidentielles les informations échangées.
## Article 6 — Résiliation et litiges
Résiliation possible en cas de manquement non corrigé sous ___ jours. Recherche d’une solution amiable avant toute action judiciaire.

Fait à {{ville}}, le {{date}}, en deux exemplaires.
| Le client | Le prestataire |
| Lu et approuvé | Lu et approuvé |`,
'Contrat de suivi de chantier': `# CONTRAT DE MISSION DE SUIVI DE CHANTIER
Entre **{{client}}** (le client) et **{{societe}}** (le prestataire).
## Article 1 — Mission
Suivi et contrôle de l’exécution des travaux du projet {{projet}} à {{lieu}} : visites régulières, comptes rendus, contrôle des situations, assistance à la réception.
## Article 2 — Fréquence
Visites : ___ par semaine ; compte rendu remis après chaque visite.
## Article 3 — Honoraires
____________ hors taxes par mois / forfait global de ____________, payable ____________.
## Article 4 — Durée
La mission débute le {{date_effet}} et prend fin à la réception définitive des travaux.
## Article 5 — Responsabilité
Le prestataire est tenu d’une obligation de moyens ; il n’est pas substitué aux entreprises dans leurs obligations d’exécution.

Fait à {{ville}}, le {{date}}.
| Le client | Le prestataire |
| Lu et approuvé | Lu et approuvé |`,
'Convention de partenariat': `# CONVENTION DE PARTENARIAT
Entre **{{societe}}**, représentée par {{dg}}, {{dg_role}},
et ____________________, représenté(e) par ____________________.
## Article 1 — Objet
Les parties conviennent de collaborer sur : {{objet}}.
## Article 2 — Engagements de {{societe}}
- ____________________
## Article 3 — Engagements du partenaire
- ____________________
## Article 4 — Durée
La convention est conclue pour ___ mois à compter du {{date_effet}}, renouvelable par accord écrit.
## Article 5 — Confidentialité et litiges
Les informations échangées restent confidentielles. Tout différend fait l’objet d’une recherche amiable préalable.

Fait à {{ville}}, le {{date}}.
| {{societe}} | Le partenaire |
| Lu et approuvé | Lu et approuvé |`
  };

  /* ---------- Notes, rapports, fiches ---------- */
  var NOT = {
'Note de service interne': `# NOTE DE SERVICE
**De :** {{dg}}, {{dg_role}}
**À :** Tout le personnel
**Objet :** {{objet}}
**Date :** {{date}}

Il est porté à la connaissance de l’ensemble du personnel que : ____________________.

Cette mesure prend effet le {{date_effet}}. Chacun est tenu de s’y conformer.`,
'Rapport de visite de chantier': `# RAPPORT DE VISITE DE CHANTIER
Projet : {{projet}} — {{lieu}}
Date : {{date_effet}} · Phase : {{phase}} · Rédigé par : ____________________
## 1. Avancement
- Travaux réalisés : ____________________
- Pourcentage d’avancement estimé : ___ %
## 2. Effectifs et matériel présents
| Entreprise / lot | Effectif | Matériel |
| ____________ | ____ | ____________ |
## 3. Constatations
- Qualité : ____________________
- Sécurité : ____________________
## 4. Points de blocage
- ____________________
## 5. Actions à mener
| N° | Action | Responsable | Échéance |
| 1 | ____________ | ____________ | ____ |`,
'Rapport d’incident / accident': `# RAPPORT D’INCIDENT / ACCIDENT
Projet : {{projet}} — {{lieu}}
Date et heure : {{date_effet}} à ___ h
## 1. Personnes concernées
| Nom | Fonction / entreprise | Blessure ou dommage |
| ____________ | ____________ | ____________ |
## 2. Description des faits
- ____________________
## 3. Causes identifiées
- ____________________
## 4. Mesures immédiates
- Premiers secours / évacuation : ____________________
- Sécurisation de la zone : ____________________
## 5. Mesures correctives
| Mesure | Responsable | Échéance |
| ____________ | ____________ | ____ |`,
'Note technique': `# NOTE TECHNIQUE
Projet : {{projet}} — {{lieu}}
Objet : {{objet}}
Date : {{date}}
## 1. Contexte
____________________
## 2. Analyse
- ____________________
## 3. Solution proposée
- ____________________
## 4. Incidences
| Domaine | Incidence |
| Délai | ____________ |
| Coût | ____________ |
| Qualité | ____________ |
## 5. Décision demandée
____________________`,
'Fiche de présentation de l’entreprise': `# PRÉSENTATION DE {{societe}}
**{{societe}}** — {{tagline}}
## Qui sommes-nous ?
{{societe}} est une société d’ingénierie et de construction basée à {{ville}}. Nous accompagnons nos clients de l’étude à la réalisation et au suivi de leurs ouvrages.
## Nos domaines d’intervention
- Études architecturales et de structure ;
- Construction de bâtiments et travaux de génie civil ;
- Métré, devis et suivi de chantier ;
- Formation aux logiciels du BTP.
## Nos engagements
- Qualité d’exécution et respect des délais ;
- Sécurité sur le chantier ;
- Transparence et suivi régulier de l’avancement.
## Contact
{{tel}} · {{email}} · {{adresse}}`,
'Bon de commande': `# BON DE COMMANDE N° {{no}}
Projet : {{projet}} — {{lieu}}
Fournisseur : {{entreprise}}
Date de commande : {{date}} · Livraison souhaitée : {{date_effet}}
| Désignation | Unité | Quantité | Prix unitaire | Total |
| ____________ | ____ | ____ | ____ | ____ |
| ____________ | ____ | ____ | ____ | ____ |
**Total hors taxes :** ____________
Conditions de paiement : ____________________
Lieu de livraison : {{lieu}}`
  };

  /* ---------- Texte libre ---------- */
  var LIB = {
'Page blanche': '',
'Document structuré': `# TITRE DU DOCUMENT
Projet : {{projet}} — {{lieu}}
Date : {{date}}
## 1. Introduction
____________________
## 2. Développement
- ____________________
- ____________________
## 3. Conclusion
____________________`,
'Tableau à remplir': `# TITRE
Projet : {{projet}} — {{lieu}}
| N° | Désignation | Responsable | Échéance |
| 1 | ____________ | ____________ | ____ |
| 2 | ____________ | ____________ | ____ |
| 3 | ____________ | ____________ | ____ |`
  };

  w.EXBPIE_DATA = {
    types: T, lots: LOTS, ccap: { 'CCAP — Marché de travaux': CCAP, 'Conditions administratives simplifiées': CCAP_SIMPLE },
    models: { lettre: LET, cr: CR, os: OS, pv: PV, attest: ATT, contrat: CTR, note: NOT, libre: LIB },
    /* types dont le pied de page porte la signature du Directeur Général / les deux parties / aucune */
    sign: { lettre: 'dg', os: 'dg', attest: 'dg', note: 'dg', libre: 'dg', pv: 'two', contrat: 'none', ccap: 'none', cctp: 'none', cr: 'none' }
  };
})(window);
