# V119i — Validation du calcul sur cas de référence (point 7)

Ajout sans effet sur l'application : dossier `site/calcul-structure/validation/`.

- `node site/calcul-structure/validation/valider.js` (ou `npm run test:calcul`) : 39 contrôles BAEL/EC2 sur le moteur réel de `index.html` (poutre, poutre à armatures comprimées, Té, poteau, dalle, semelle, flèche).
- `node site/calcul-structure/validation/rapport.js` : régénère `RAPPORT-VALIDATION.md` (tableau présentable).
- `COMPARAISON-ROBOT.md` : gabarit de 6 cas à saisir dans Robot ; à remplir avec vos résultats.

## Limites à connaître
- Les références sont recalculées avec les équations normatives, pas extraites d'un manuel ni de Robot : cela prouve l'exactitude de l'implémentation, pas encore la concordance avec Robot.
- Non couvert : poteau EC2 (5.8.8), poinçonnement EC2 complet, fissuration EC2, flèche fissurée, bâtiment, escaliers.
