# V119j — Semelle filante, radier général, mur de soutènement (point 8)

Nouveau moteur `exb-ouvrages.js` (fonctions pures, `window.EXBO`) et trois modules dans « Calcul de structure » (barre des modules, rubrique Fondations/Ouvrages) : **Semelle filante**, **Radier général**, **Mur de soutènement**. BAEL et EC2 selon la norme active ; note de calcul disponible pour chacun.

## Ce que fait chaque module
- **Semelle filante** (par mètre) : sol ELS (trapèze / surface comprimée réduite), rigidité d ≥ (B−a)/4, As par bielles (e ≤ B/24) ou par moment au nu, As,min, répartition ≥ As·B/4, effort tranchant à d du nu, choix de nappe.
- **Radier général** : méthode du plancher inversé sur une trame lx × ly (BAEL E.3, appuis continus 0,75/0,5 M0), sol, poinçonnement sous poteau (BAEL A.5.2,42 ou EC2 6.4), tranchant, vérification de rigidité de Winkler si kv est renseigné.
- **Mur de soutènement en T renversé** : poussée de Rankine, renversement et glissement (FS ≥ 1,5), contraintes au sol, voile (ELU + ELS fissuration préjudiciable), patin et talon à partir de la répartition réelle des pressions ELU.

## Parasismique
Le module « Séisme (EN 1998-1) » existait déjà (forces latérales). Non ajouté ici : dispositions constructives de ductilité (DCM/DCH), poussée sismique des terres (Mononobe-Okabe), vérification des fondations sous séisme.

## Limites
- Mur : remblai horizontal, mur vertical, sans eau ni butée ni séisme, sol homogène, charge permanente seule comme stabilisante ; pas de bêche calculée.
- Radier : réaction du sol uniforme, pas de modèle sur sol élastique ni de tassements ; débords non traités.
- Semelle filante : charge centrée ou excentricité simple, pas de semelle sur plusieurs murs.
- Validé par 27 contrôles recalculés à la main (cas H1 à H3 de `validation/valider.js`) et un test de fumée Chromium ; **pas** comparé à Robot (voir COMPARAISON-ROBOT.md).

> Mise à jour V119k : les limites « remblai horizontal, sans eau, sans butée, sans séisme » (mur) et « réaction uniforme, sans tassements » (radier) sont levées : voir `README-V119k-LIMITES-LEVEES-MUR-RADIER.md`.
