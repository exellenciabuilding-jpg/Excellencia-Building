# V122 — Analyse de structure « type Robot » (moteur `exb-robot-analyse.js`)

Nouveau moteur sans DOM (`window.EXBR`, testable sous Node) qui renforce les modules de calcul avec les fonctions de Robot Structural Analysis.

## Fonctionnalités
1. **Combinaisons automatiques** (EN 1990 6.10, 6.10a/b, ELS caractéristique / fréquente / quasi-permanente, accidentelle, sismique ±Ex ± 0,3·Ey ; BAEL 91 : 1,35G + 1,5Q + 1,3ψ0·Qi), coefficients ψ par catégorie, groupes exclusifs (vent +X / −X).
2. **Analyse statique EF de portiques plans** : barres inclinées, articulations, appuis rigides / élastiques / tassements, charges nodales, réparties (trapèze, local/global, projetées), ponctuelles, température ; réactions, détection de mécanisme.
3. **Diagrammes N, V, M, flèches** par barre et **enveloppes** de toutes les combinaisons avec combinaison dominante.
4. **Analyse modale** (condensation statique, Jacobi), masses modales effectives, **spectre EN 1998-1 3.2.2.5**, combinaison SRSS/CQC, effort tranchant à la base, dérive d'étage (dr·ν), sensibilité θ, comparaison avec la méthode des forces latérales.

## Écrans ajoutés (menu Calculs et « Ingénierie & Structure »)
- **Portique 2D — analyse EF** : n étages × m travées, enveloppes ELU/ELS, vent, séisme modal, diagrammes SVG, envoi des géométries et efforts G/Q vers les modules **Poutre** et **Poteau**.
- **Combinaisons d'actions** : liste des combinaisons et valeur dominante pour un effet donné.

## Validation
`node site/calcul-structure/validation/valider-robot.js` : 83 contrôles contre solutions analytiques (RDM, pentes-déflexions, valeurs propres exactes, EN 1990/1998-1) et contre le moteur de poutre continue existant. `npm run test:calcul` les exécute avec les anciens (111 contrôles inchangés).

## Branchement sur les modules existants
- **Portique 2D** : dimensionnement automatique **par niveau** à partir des enveloppes ELU, ELS caractéristique et séisme (G + ψ2·Q ± E) : armatures de travée, d'appui, cadres des poutres (moteur du module Poutre) et armatures des poteaux. Quand le module Poteau ne sait pas traiter la flexion composée (traction partielle), le poteau est dimensionné par un **diagramme d'interaction N–M** (aciers symétriques, bloc 0,8x, excentricité minimale).
- **Module Poutre** : carte « Contrôle par éléments finis » sous les résultats : mêmes chargements alternés et charges spéciales, concordance affichée (écart ≤ 1 % constaté), plus **tassements d'appui** et **appuis élastiques** (ce que le calcul par rotations ne permet pas).

## Limites
Linéaire élastique (pas de P-Δ ni fissuration : rigidité brute), Euler-Bernoulli, diaphragme rigide, masses concentrées, pas de torsion ni d'excentricité accidentelle, poteaux N–M sans second ordre (alerte si λ > 25) et en flexion uniaxiale, tassements pris à γ = 1,0. Non comparé à Robot : à compléter dans `COMPARAISON-ROBOT.md`.
