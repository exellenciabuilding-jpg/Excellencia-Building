/* Tests de cohérence interne du moteur V119h (node test-verif-els.js).
   Ce ne sont PAS des validations normatives : ils vérifient les formules contre des solutions fermées. */
const V = require("./exb-verif-els.js"), assert = require("assert");
let n = 0; const ok = (c, m) => { assert(c, m); n++; };
const close = (a, b, tol, m) => ok(Math.abs(a - b) <= tol * Math.abs(b), `${m} : ${a} ≠ ${b}`);
const NS = 20, L = 5, q = 0.03; // MN/m
const par = Array.from({ length: NS + 1 }, (_, i) => { const x = L * i / NS; return q * x * (L - x) / 2; });

// 1. double intégration : 5qL⁴/(384EI)
const EI = 30000 * 0.25 * Math.pow(0.5, 3) / 12;
close(V.deflection(L, par, m => m / EI).f, 5 * q * Math.pow(L, 4) / (384 * EI), 5e-3, "flèche élastique (écart de discrétisation de M sur 20 points)");

// 2. section rectangulaire : état II vs formule fermée de x (b x²/2 = n As (d−x))
const p = { b: .25, h: .5, d: .45, dp: .03, As: 12e-4, Asc: 0 }, s = V.sec(p, 15);
const x0 = 15 * p.As / p.b * (-1 + Math.sqrt(1 + 2 * p.b * p.d / (15 * p.As)));
close(s.x, x0, 1e-9, "axe neutre rectangulaire");
close(s.I2, p.b * x0 ** 3 / 3 + 15 * p.As * (p.d - x0) ** 2, 1e-9, "inertie fissurée");
// section en Té dont l'axe neutre reste dans la table = rectangle bf
const t = V.sec({ ...p, b: .2, bf: .8, h0: .2 }, 15), r = V.sec({ ...p, b: .8 }, 15);
close(t.x, r.x, 1e-9, "Té : axe neutre dans la table"); ok(t.x < .2, "axe dans la table");
// Té avec axe neutre dans l'âme : équilibre statique
const t2 = V.sec({ b: .2, h: .6, bf: .6, h0: .08, d: .55, dp: .04, As: 25e-4, Asc: 0 }, 15);
ok(t2.x > .08, "axe dans l'âme");
const Sc = .2 * t2.x ** 2 / 2 + (.6 - .2) * .08 * (t2.x - .04), St = 15 * 25e-4 * (.55 - t2.x);
close(Sc, St, 1e-9, "équilibre statique du Té fissuré");

// 3. EC2 : poutre peu chargée (non fissurée) → flèche = 5qL⁴/(384 Ec,eff I0) + retrait
const fc = 30, Ec = V.Ecm(fc), mk = k => par.map(v => v * k);
const sP = { b: .3, h: .6, d: .55, dp: .05, As: 20e-4, Asc: 5e-4 };
const e0 = V.flecheEC2({ L, Mg: mk(.05), Mq: mk(0), jr: .7, psi2: .3, sP, sN: sP, fc, phi: 2, ecs: 0 });
const I0 = V.sec(sP, V.ES / (Ec / 3)).I0;
close(e0.ftot, 5 * q * .05 * Math.pow(L, 4) / (384 * (Ec / 3) * I0), 5e-3, "EC2 non fissuré, fluage φ = 2");
// fissuré : la flèche croît plus vite que la charge
const e1 = V.flecheEC2({ L, Mg: mk(1), Mq: mk(.5), jr: .7, psi2: .3, sP, sN: sP, fc, phi: 2 });
ok(e1.ftot > e0.ftot * 20, "la fissuration augmente la flèche au-delà de la proportionnalité");
// le retrait augmente la flèche d'une poutre armée en bas
const e2 = V.flecheEC2({ L, Mg: mk(.05), Mq: mk(0), jr: .7, psi2: .3, sP, sN: sP, fc, phi: 2, ecs: 4e-4 });
ok(e2.ftot > e0.ftot, "le retrait ajoute de la flèche");

// 4. BAEL : poutre très peu chargée → Ifv ≈ I0, fgv = 5qL⁴/(384 Ev I0)
const b0 = V.flecheBAEL({ L, Mg: mk(.02), Mq: mk(0), jr: .7, sP, fc });
close(b0.fgv, 5 * q * .02 * Math.pow(L, 4) / (384 * 3700 * Math.cbrt(fc) * b0.I0), 5e-3, "BAEL fgv non fissuré");
const b1 = V.flecheBAEL({ L, Mg: mk(1), Mq: mk(.6), jr: .7, sP, fc });
ok(b1.delta > 0 && b1.fpi > b1.fgi && b1.fgv > b1.fgi, "BAEL : ordres de grandeur cohérents");
ok(b1.adm === L / 500, "BAEL : limite L/500 pour L ≤ 5 m");
ok(V.flecheBAEL({ L: 6, Mg: par.map(v => v * 1.44), Mq: par.map(v => v * .6), jr: .7, sP, fc }).adm === .005 + 6 / 1000, "BAEL : 0,5 cm + L/1000 pour L > 5 m");

// 5. fissuration EC2 : cas calculé à la main
const sF = { b: .3, h: .5, d: .45, dp: .05, As: 12.57e-4, Asc: 0 }; // 4 HA20
const f1 = V.fissEC2({ M: .12, s: sF, phi: .02, c: .03, e: .06, fc: 25, wlim: .3 });
// main : n = 200000/31476 ; contrainte ; sr,max = 3,4c + 0,425·0,8·0,5·φ/ρp,eff
const nn = 200000 / V.Ecm(25), SS = V.sec(sF, nn), sg = nn * .12 * (.45 - SS.x) / SS.I2;
close(f1.sigS, sg, 1e-9, "σs fissuré");
const hce = Math.min(2.5 * .05, (.5 - SS.x) / 3, .25), rho = 12.57e-4 / (.3 * hce), fct = V.fctm(25);
const srm = 3.4 * .03 + .8 * .5 * .425 * .02 / rho, dd = Math.max((sg - .4 * fct / rho * (1 + nn * rho)) / 2e5, .6 * sg / 2e5);
close(f1.wk, srm * dd * 1000, 1e-9, "wk = sr,max (εsm − εcm)");
ok(f1.wk > 0.05 && f1.wk < 0.6, "wk plausible : " + f1.wk.toFixed(3) + " mm");
ok(V.fissEC2({ M: .01, s: sF, phi: .02, c: .03, e: .06, fc: 25, wlim: .3 }).nonFissure, "section non fissurée : wk = 0");
ok(V.fissEC2({ M: .12, s: sF, phi: .02, c: .03, e: .25, fc: 25, wlim: .3 }).dense === false, "espacement large : sr,max = 1,3(h−x)");

// 6. poinçonnement EC2 : semelle 2×2×0,5, poteau 0,3, charge 1,2 MN
const P = { a: .3, b: .3, d: .45, h: .5, Ned: 1.2, A: 2, B: 2, fc: 25, gb: 1.5, rl: .004, eA: 0, eB: 0 };
const p1 = V.punchEC2(P);
ok(p1.vc > .3 && p1.vc < .6, "vRd,c plausible : " + p1.vc.toFixed(3));
ok(p1.ratio > 0 && p1.ok === (p1.ratio <= 1 + 1e-9), "cohérence ok/ratio");
// la charge réduit le rapport quand la semelle grandit (plus de réaction sous le contour)
ok(V.punchEC2({ ...P, A: 0, B: 0 }).ratio > p1.ratio, "sans réaction du sol sous le contour (dalle), le rapport est plus élevé");
ok(V.punchEC2({ ...P, A: 3, B: 3 }).ratio > p1.ratio, "pour un même poteau, une semelle plus grande décharge moins le contour");
ok(V.punchEC2({ ...P, d: .6, h: .65 }).ratio < p1.ratio, "plus épais → rapport plus faible");
ok(V.punchEC2({ ...P, eA: .2 }).beta > 1.15, "excentricité → β majoré");
// dalle : pas de réduction par le sol
const sl = V.punchEC2({ a: .3, b: .3, d: .2, h: .25, Ned: .3, fc: 25, gb: 1.5, rl: .005 });
ok(sl.ratio > 0, "dalle : rapport positif");
const hm = V.punchHmin(V.punchEC2, { a: .3, b: .3, d: .2, h: .25, Ned: .6, fc: 25, gb: 1.5, rl: .005 }, .05);
ok(hm > .25, "h minimale > h de départ quand non vérifié : " + hm);
// BAEL
const bp = V.punchBAEL({ a: .3, b: .3, h: .5, Ned: 1.2, A: 2, B: 2, fc: 25, gb: 1.5 });
close(bp.lim, .045 * 2 * (.3 + .3 + 1) * .5 * 25 / 1.5, 1e-9, "BAEL : 0,045·uc·h·fc/γb");

// 7. effort tranchant semelle : charge centrée, section à d du nu
const sh = V.shearFooting({ ec: false, L: 2, W: 2, c: .3, d: .3, Nuc: 1.2, e: 0, fc: 25, gb: 1.5 });
close(sh.Vu, (1.2 / 4) * 2 * ((2 - .3) / 2 - .3), 1e-9, "Vu à d du nu");
ok(V.shearFooting({ ec: false, L: 2, W: 2, c: .3, d: .9, Nuc: 1.2, e: 0, fc: 25, gb: 1.5 }).applicable === false, "d > débord : non applicable");
console.log(`${n} vérifications de cohérence réussies`);
