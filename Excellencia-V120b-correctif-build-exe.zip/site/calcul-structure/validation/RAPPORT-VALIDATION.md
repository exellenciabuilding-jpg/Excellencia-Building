# Rapport de validation — moteur de calcul de structure (V119i)

Date : 2026-11-01 · 111 contrôles · **tous dans la tolérance**

Méthode : chaque valeur de référence est recalculée à la main (formules BAEL 91 mod. 99 / EN 1992-1-1) dans `valider.js`, indépendamment du moteur, puis comparée à la sortie réelle de `index.html`.

| Cas | Grandeur | Référence | Moteur | Écart % | Tol. % | Art. | |
|---|---|---|---|---|---|---|---|
| A1 | BAEL μbu | 0.2092 | 0.2092 | 0.000 | 0.01 | A.4.3,41 | ✅ |
| A1 | BAEL As ELU (cm²) | 8.6988 | 8.6988 | 0.000 | 0.05 | A.4.3,41 | ✅ |
| A1 | BAEL σbc ELS (MPa) | 11.8301 | 11.8301 | 0.000 | 0.1 | A.4.5,2 | ✅ |
| A1 | BAEL σs ELS (MPa) | 245.8056 | 245.8056 | -0.000 | 0.1 | A.4.5,33 | ✅ |
| A1 | BAEL σs limite fissuration préjudiciable (MPa) | 250.0000 | 250.0000 | 0.000 | 0.01 | A.4.5,33 | ✅ |
| A1 | BAEL As,min = 0,23 b d ft28/fe (cm²) | 1.0868 | 1.0868 | 0.000 | 0.01 | A.4.2 | ✅ |
| A1 | BAEL τu = Vu/(b d) (MPa) | 0.8000 | 0.8000 | 0.000 | 0.01 | A.5.1,1 | ✅ |
| A1 | BAEL τ̄u (fiss. préjudiciable) (MPa) | 2.5000 | 2.5000 | 0.000 | 0.01 | A.5.1,211 | ✅ |
| A2 | EC2 μ | 0.1778 | 0.1778 | 0.000 | 0.01 | 3.1.7 | ✅ |
| A2 | EC2 As ELU (cm²) | 8.5054 | 8.5054 | 0.000 | 0.05 | 6.1 | ✅ |
| A2 | EC2 As,min = 0,26 fctm/fyk b d (cm²) | 1.5005 | 1.5005 | 0.000 | 0.01 | 9.2.1.1(1) | ✅ |
| A2 | EC2 vEd = VEd/(b·0,9d) (MPa) | 0.8889 | 0.8889 | 0.000 | 0.01 | 6.2.3 | ✅ |
| A2 | EC2 vRd,max = ν1 fcd/(cotθ+tanθ) (MPa) | 3.1034 | 3.1034 | 0.000 | 0.01 | 6.2.3(3) | ✅ |
| A2 | EC2 limite σs ELS = 0,8 fyk (MPa) | 400.0000 | 400.0000 | 0.000 | 0.01 | 7.2(5) | ✅ |
| B1 | μl (fe500)  | 0.3717 | 0.3717 | 0.000 | 0.01 | A.4.3,41 | ✅ |
| B1 | A' (cm²), σsc = min(fed ; Es εsc) | 0.7708 | 0.7708 | 0.000 | 0.1 | A.4.3,42 | ✅ |
| B1 | As (cm²) | 18.8602 | 18.8602 | 0.000 | 0.1 | A.4.3,42 | ✅ |
| C1 | Mtu (MN.m) ≥ Mu → rectangle bf×h | 1.0000 | 1.0000 | 0.000 | 0 | A.4.3,4 | ✅ |
| C1 | As Té (cm²) = Mu/(z fed), b = bf | 7.9351 | 7.9351 | 0.000 | 0.05 | A.4.3,4 | ✅ |
| D1 | BAEL Nu (kN) | 1.260e+3 | 1.260e+3 | 0.000 | 0.01 | B.8.4 | ✅ |
| D1 | BAEL λ = l0√12/a | 24.2487 | 24.2487 | 0.000 | 0.01 | B.8.3,31 | ✅ |
| D1 | BAEL α(λ ≤ 50) | 0.7755 | 0.7755 | 0.000 | 0.01 | B.8.4,1 | ✅ |
| D1 | BAEL Br (cm²) | 784.0000 | 784.0000 | 0.000 | 0.01 | B.8.4,1 | ✅ |
| D1 | BAEL As requis (cm²) = [Nu/α − Br fc28/(0,9γb)] γs/fe | 3.9746 | 3.9746 | -0.000 | 0.2 | B.8.4,1 | ✅ |
| D1 | BAEL capacité avec As retenu ≥ Nu (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | B.8.4,1 | ✅ |
| E1 | pu (kN/m²) | 11.1750 | 11.1750 | 0.000 | 0.01 | A.3.3 | ✅ |
| E1 | μx = 1/[8(1+2,4α³)] | 0.0561 | 0.0561 | -0.000 | 0.1 | Annexe E.3 | ✅ |
| E1 | μy = α²[1−0,95(1−α)²] | 0.6157 | 0.6157 | 0.000 | 0.1 | Annexe E.3 | ✅ |
| E1 | Mx0 (kN.m/m) | 10.0278 | 10.0278 | 0.000 | 0.1 | Annexe E.3 | ✅ |
| E1 | My0 (kN.m/m) | 6.1739 | 6.1739 | -0.000 | 0.1 | Annexe E.3 | ✅ |
| F1 | Nu semelle (kN) | 1.328e+3 | 1.328e+3 | 0.000 | 0.01 | A.3.3 | ✅ |
| F1 | σsol ELS = Ns/(A·B) (MPa) | 0.2375 | 0.2375 | 0.000 | 0.01 | DTU 13.12 | ✅ |
| F1 | As sens A = Nu(A−a)/(8 d fed) (cm²) | 14.7458 | 14.7458 | 0.000 | 0.1 | A.8.2,41 | ✅ |
| F1 | As sens B = Nu(B−b)/(8 (d−φ) fed) (cm²), 2e nappe | 15.1592 | 15.1592 | 0.000 | 0.1 | A.8.2,41 | ✅ |
| F1 | Poinçonnement BAEL : limite 0,045 uc h fc28/γb (MN) | 1.2000 | 1.2000 | 0.000 | 0.01 | A.5.2,42 | ✅ |
| F1 | Poinçonnement BAEL : Qu (MN) | 1.0584 | 1.0584 | 0.000 | 0.5 | A.5.2,42 | ✅ |
| G1 | EC2 flèche long terme non fissurée (m), φ = 2 | 3.832e-4 | 3.824e-4 | -0.202 | 0.6 | 7.4.3 | ✅ |
| G1 | BAEL fgv non fissurée (m) | 7.727e-5 | 7.711e-5 | -0.202 | 0.6 | B.6.5,2 | ✅ |
| G1 | BAEL limite de flèche (L > 5 m) = 0,5 cm + L/1000 (m) | 0.0110 | 0.0110 | 0.000 | 0.01 | B.6.5,3 | ✅ |
| H1 | Semelle filante Nu (kN/m) | 308.7000 | 308.7000 | 0.000 | 0.01 | A.3.3 | ✅ |
| H1 | Semelle filante σsol (MPa) | 0.1850 | 0.1850 | 0.000 | 0.01 | DTU 13.12 | ✅ |
| H1 | Semelle filante As bielles (cm²/m) | 2.6103 | 2.6103 | 0.000 | 0.1 | A.8.2,41 | ✅ |
| H1 | Semelle filante τu à d du nu (MPa) | 0.1211 | 0.1211 | 0.000 | 0.1 | A.5.2,2 | ✅ |
| H1 | Semelle filante rigidité d ≥ (B−a)/4 (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | A.8.2,1 | ✅ |
| H1 | Semelle filante : sol dépassé détecté (1 = erreur) | 1.0000 | 1.0000 | 0.000 | 0 | DTU 13.12 | ✅ |
| H1 | Semelle filante : semelle non rigide détectée (1 = erreur) | 1.0000 | 1.0000 | 0.000 | 0 | A.8.2,1 | ✅ |
| H2 | Mur : Ka = tan²(45°−φ/2) = 1/3 | 0.3333 | 0.3333 | 0.000 | 0.001 | Rankine | ✅ |
| H2 | Mur : Pa,terres (kN/m) | 34.6800 | 34.6800 | -0.000 | 0.01 | Rankine | ✅ |
| H2 | Mur : FS renversement | 2.5990 | 2.5990 | 0.000 | 0.01 | méthode classique | ✅ |
| H2 | Mur : FS glissement = μ ΣV/ΣH | 1.3051 | 1.3051 | 0.000 | 0.01 | méthode classique | ✅ |
| H2 | Mur : glissement < 1,5 détecté (1 = erreur) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| H2 | Mur : ∫σu dx = ΣVu (kN/m) | 183.1350 | 183.1350 | 0.000 | 0.2 | équilibre | ✅ |
| H2 | Mur : ∫σu·x dx = Mst − Mren (kN.m/m) | 155.0433 | 155.0436 | 0.000 | 0.5 | équilibre | ✅ |
| H2 | Mur : Mu à la base du voile (kN.m/m) | 58.9500 | 58.9500 | 0.000 | 0.01 | A.4.3 | ✅ |
| H2 | Mur : As flexion du voile (cm²/m) | 5.8697 | 5.8697 | 0.000 | 0.1 | A.4.3,41 | ✅ |
| H2 | Mur : Vu du voile (kN/m) | 51.4500 | 51.4500 | 0.000 | 0.01 | A.5.1 | ✅ |
| H2 | Mur B=2,6 m : stable (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| H2 | Mur sans surcharge : Pq = 0 | 0.0000 | 0.0000 | 0.000 | 0 | Rankine | ✅ |
| H3 | Radier pu net (kN/m²) | 79.0000 | 79.0000 | 0.000 | 0.01 | A.3.3 | ✅ |
| H3 | Radier M0x (kN.m/m) | 103.3430 | 103.3430 | -0.000 | 0.1 | Annexe E.3 | ✅ |
| H3 | Radier M0y (kN.m/m) | 69.8722 | 69.8722 | -0.000 | 0.1 | Annexe E.3 | ✅ |
| H3 | Radier σsol = (G+Q)/(lx ly) + ρ h (MPa) | 0.0742 | 0.0742 | 0.000 | 0.01 | DTU 13.12 | ✅ |
| H3 | Radier poinçonnement BAEL : limite (MN) | 2.3100 | 2.3100 | 0.000 | 0.01 | A.5.2,42 | ✅ |
| H3 | Radier poinçonnement BAEL : Qu (MN) | 2.2744 | 2.2744 | 0.000 | 0.01 | A.5.2,42 | ✅ |
| H3 | Radier longueur élastique le (m) | 3.6625 | 3.6625 | 0.000 | 0.01 | Winkler | ✅ |
| H3 | Radier h=0,30 : poinçonnement non vérifié (1 = erreur) | 1.0000 | 1.0000 | 0.000 | 0 | A.5.2,42 | ✅ |
| I1 | Mur incliné : Ka Rankine incliné | 0.3729 | 0.3729 | -0.000 | 0.001 | Rankine β | ✅ |
| I1 | Mur incliné : Pa,terres (kN/m) | 54.8678 | 54.8678 | -0.000 | 0.01 | Rankine β | ✅ |
| I1 | Mur incliné : FS renversement | 4.1271 | 4.1271 | 0.000 | 0.01 | plan virtuel | ✅ |
| I1 | Mur incliné : FS glissement | 1.5992 | 1.5992 | 0.000 | 0.01 | plan virtuel | ✅ |
| I1 | Mur : β ≥ φ refusé (1 = erreur) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| I2 | Mur + nappe : poussée des terres Pe (kN/m) | 31.6800 | 31.6800 | 0.000 | 0.01 | terres déjaugées | ✅ |
| I2 | Mur + nappe : Pw (kN/m) | 11.2500 | 11.2500 | 0.000 | 0.01 | hydrostatique | ✅ |
| I2 | Mur + nappe : sous-pression U (kN/m) | 24.0000 | 24.0000 | 0.000 | 0.01 | γw·hw·B/2 | ✅ |
| I2 | Mur + nappe : FS renversement | 2.9464 | 2.9464 | 0.000 | 0.01 | M stab. / (M ren. + U·2B/3) | ✅ |
| I2 | Mur + nappe : FS glissement | 1.5239 | 1.5239 | -0.000 | 0.01 | μ(ΣV−U)/ΣH | ✅ |
| I3 | Butée Pp = fb·Kp·γ·(hb+hs)²/2 (kN/m) | 8.6400 | 8.6400 | -0.000 | 0.01 | Rankine passif | ✅ |
| I3 | Glissement avec butée | 1.4928 | 1.4928 | 0.000 | 0.01 | (μV + Pp)/ΣH | ✅ |
| I3 | Kae φ30° kh0,1 kv0 (Mononobe-Okabe) | 0.3966 | 0.3966 | -0.011 | 0.3 | EN 1998-5 E | ✅ |
| I3 | Séisme : kh = ag·S/(g·r) | 0.2446 | 0.2446 | 0.000 | 0.01 | EN 1998-5 7.3.2.2 | ✅ |
| I3 | Séisme (1−kv) : Kae | 0.5468 | 0.5468 | 0.000 | 0.01 | EN 1998-5 E | ✅ |
| I3 | Séisme (1−kv) : ΔPae (kN/m) | 15.2544 | 15.2544 | -0.000 | 0.01 | EN 1998-5 E | ✅ |
| I3 | Séisme (1−kv) : FS glissement | 0.8213 | 0.8213 | 0.000 | 0.5 | μΣV/ΣH | ✅ |
| I3 | Séisme (1−kv) : FS renversement | 1.9909 | 1.9909 | 0.000 | 0.5 | M stab./M ren. | ✅ |
| I3 | Sans séisme : pas de bloc sismique (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| I4 | Boussinesq : I coin carré, z = B (table de Newmark) | 0.1752 | 0.1752 | 0.012 | 0.05 | Boussinesq | ✅ |
| I4 | Tassement œdométrique au centre (m) | 0.0180 | 0.0180 | 0.036 | 0.2 | Boussinesq / œdomètre | ✅ |
| I4 | Plaque de Winkler : flèche sous charge P (Hetényi) | 0.2449 | 0.2478 | 1.182 | 2 | Hetényi | ✅ |
| I4 | Plaque de Winkler : ΣR = ΣP | 1.000e+3 | 1000.0000 | -0.000 | 0.01 | équilibre | ✅ |
| I4 | Plaque sur Winkler, charge uniforme : w = q/kv | 0.5000 | 0.5000 | -0.000 | 0.01 | Winkler | ✅ |
| I4 | Plaque sur Winkler, charge uniforme : moments nuls | 0.0000 | 5.698e-10 | 0.000 | 0.0001 |  | ✅ |
| I4 | Charge excentrée : décollement détecté (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | contact unilatéral | ✅ |
| I4 | Charge excentrée : ΣR = ΣP | 3.000e+3 | 3.000e+3 | 0.000 | 0.01 | équilibre | ✅ |
| I5 | Radier EF : ΣR = ΣP (ELU) | 1.035e+5 | 1.035e+5 | 0.000 | 0.01 | équilibre | ✅ |
| I5 | Radier EF : M(mi-portée) − M(nu) = pn·l²/8 − V·a/2 (kN.m/m, travée intérieure) | 207.3750 | 190.1964 | -8.284 | 10 | équilibre statique d'une travée (maillage grossier : 10 %) | ✅ |
| I5 | Radier : tassement œdométrique calculé (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | centre > coin | ✅ |
| I6 | sfilante : plan/3D générés (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | V119l | ✅ |
| I6 | sfilante : volume de béton du plan (m³/ml ou m³) | 0.4800 | 0.4800 | 0.000 | 0.01 | géométrie | ✅ |
| I6 | sfilante : poids d'acier = Σ n·l·0,006165·φ² (kg) | 5.7014 | 5.7014 | 0.000 | 0.01 | nomenclature | ✅ |
| I6 | sfilante : aucune valeur NaN dans le plan ni la 3D (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| I6 | sfilante : DXF 2D, DXF 3D et IFC non vides (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | export | ✅ |
| I6 | radier : plan/3D générés (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | V119l | ✅ |
| I6 | radier : volume de béton du plan (m³/ml ou m³) | 243.2000 | 243.2000 | 0.000 | 0.01 | géométrie | ✅ |
| I6 | radier : poids d'acier = Σ n·l·0,006165·φ² (kg) | 7.488e+3 | 7.488e+3 | 0.000 | 0.01 | nomenclature | ✅ |
| I6 | radier : aucune valeur NaN dans le plan ni la 3D (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| I6 | radier : DXF 2D, DXF 3D et IFC non vides (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | export | ✅ |
| I6 | mur : plan/3D générés (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | V119l | ✅ |
| I6 | mur : volume de béton du plan (m³/ml ou m³) | 1.9400 | 1.9400 | 0.000 | 0.01 | géométrie | ✅ |
| I6 | mur : poids d'acier = Σ n·l·0,006165·φ² (kg) | 64.7966 | 64.7966 | 0.000 | 0.01 | nomenclature | ✅ |
| I6 | mur : aucune valeur NaN dans le plan ni la 3D (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 |  | ✅ |
| I6 | mur : DXF 2D, DXF 3D et IFC non vides (1 = oui) | 1.0000 | 1.0000 | 0.000 | 0 | export | ✅ |

## Ce que ce rapport prouve — et ne prouve pas
- Prouve : le moteur applique correctement les formules de base (flexion ELU, ELS, tranchant, poteau forfaitaire, dalle BAEL E.3, semelle par bielles, flèche non fissurée).
- Ne prouve pas : la concordance avec **Robot** ni avec un exemple publié d'un manuel ; les références ont été calculées par les mêmes équations normatives. Pour un client, compléter avec `COMPARAISON-ROBOT.md`.
- Non couvert : poteau EC2 (5.8.8), poinçonnement EC2 complet, fissuration EC2 sur cas réels, flèche fissurée, bâtiment multi-niveaux, escaliers.
