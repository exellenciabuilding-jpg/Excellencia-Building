/* V122 — Validation du moteur d'analyse « type Robot » (exb-robot-analyse.js) : node validation/valider-robot.js
   Chaque référence est une solution analytique écrite ici, indépendamment du moteur (RDM, pentes-déflexions, valeurs propres
   exactes, formules EN 1990 / EN 1998-1). Le moteur de poutre continue existant de index.html sert aussi de contre-exemple. */
const R = require("../exb-robot-analyse.js");
const rows = []; let fail = 0;
function chk(id, grandeur, ref, val, tol, ou) {
  const ecart = Math.abs(ref) < 1e-12 ? Math.abs(val) : (val - ref) / ref * 100, ok = Math.abs(ecart) <= tol && isFinite(val);
  if (!ok) fail++; rows.push({ id, grandeur, ref, val, ecart, tol, ok, ou });
}
const E = 30e6, A = .125, I = .125 * .5 ** 3 / 12, EI = E * I;
const mk = (nodes, members, supports) => R.frame({ nodes, members: members.map(m => ({ E, A, I, ...m })), supports });
const spec = (c) => [{ c, f: 1 }];
const ext = (d, k) => ({ M: d.M, V: d.V, v: d.v, N: d.N });

/* ===== R1. Poutre sur deux appuis, charge répartie ===== */
(() => {
  const L = 6, w = 20, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] }), d = R.effortsBarre(fr, 0, spec(c), 20);
  const im = d.M.indexOf(Math.max(...d.M)), iv = d.v.indexOf(Math.min(...d.v));
  chk("R1", "poutre isostatique : M max = wL²/8 (kN.m)", w * L * L / 8, Math.max(...d.M), .01, "RDM");
  chk("R1", "poutre isostatique : V appui = wL/2 (kN)", w * L / 2, d.V[0], .01, "RDM");
  chk("R1", "poutre isostatique : flèche = 5wL⁴/384EI (m)", -5 * w * L ** 4 / (384 * EI), Math.min(...d.v), .05, "RDM");
  chk("R1", "poutre isostatique : réaction A (kN)", w * L / 2, c.R[1], .01, "RDM"); chk("R1", "poutre isostatique : réaction B (kN)", w * L / 2, c.R[4], .01, "RDM");
})();

/* ===== R2. Poutre bi-encastrée et poutre console ===== */
(() => {
  const L = 5, w = 12, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] }), d = R.effortsBarre(fr, 0, spec(c), 20);
  chk("R2", "bi-encastrée : M appui = −wL²/12 (kN.m)", -w * L * L / 12, d.M[0], .01, "RDM");
  chk("R2", "bi-encastrée : M travée = wL²/24 (kN.m)", w * L * L / 24, Math.max(...d.M), .01, "RDM");
  const P = 40, fc = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }]), cc = fc.solveCase({ nodes: [{ n: 1, fy: -P }] }), dc = R.effortsBarre(fc, 0, spec(cc), 20);
  chk("R2", "console : flèche en tête = PL³/3EI (m)", -P * L ** 3 / (3 * EI), cc.u[4], .01, "RDM");
  chk("R2", "console : M d'encastrement = −PL (kN.m)", -P * L, dc.M[0], .01, "RDM");
  chk("R2", "console : flèche de la barre (double intégration) en tête (m)", -P * L ** 3 / (3 * EI), dc.v[dc.v.length - 1], .1, "RDM");
  /* charge ponctuelle à mi-portée d'une poutre bi-appuyée : M = PL/4, flèche PL³/48EI, tranchants ±P/2 de part et d'autre */
  const fp = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }]), cp = fp.solveCase({ members: [{ m: 0, type: "point", dir: "Y", P: -P, a: L / 2 }] }), dp = R.effortsBarre(fp, 0, spec(cp), 20);
  chk("R2", "charge centrée : M max = PL/4 (kN.m)", P * L / 4, Math.max(...dp.M), .01, "RDM");
  chk("R2", "charge centrée : flèche = PL³/48EI (m)", -P * L ** 3 / (48 * EI), Math.min(...dp.v), .1, "RDM");
  const i0 = dp.x.findIndex(x => Math.abs(x - L / 2) < 1e-9);
  chk("R2", "charge centrée : saut de V au point d'application = P (kN)", P, dp.V[i0] - dp.V[i0 + 1], .01, "RDM");
})();

/* ===== R3. Poutre continue à 3 appuis : comparaison avec le moteur existant de index.html (méthode des rotations) ===== */
(() => {
  const L = 5, w = 25, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }, { x: 2 * L, y: 0 }], [{ i: 0, j: 1 }, { i: 1, j: 2 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }, { n: 2, uy: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }, { m: 1, type: "dist", dir: "Y", q1: -w }] });
  const d0 = R.effortsBarre(fr, 0, spec(c), 16), d1 = R.effortsBarre(fr, 1, spec(c), 16);
  chk("R3", "continue 2 travées : M sur appui central = −wL²/8 (kN.m)", -w * L * L / 8, d0.M[d0.M.length - 1], .01, "RDM");
  chk("R3", "continue 2 travées : continuité du moment sur l'appui (kN.m)", d0.M[d0.M.length - 1], d1.M[0], .01, "RDM");
  chk("R3", "continue 2 travées : réaction centrale = 5wL/4 (kN)", 5 * w * L / 4, c.R[4], .01, "RDM");
  chk("R3", "continue 2 travées : M max en travée = 9wL²/128 (kN.m)", 9 * w * L * L / 128, Math.max(...d0.M), .05, "RDM");
  try {
    const H = require("./harness.js"), sol = H.get("solve"), res = sol([L, L], [[{ t: "u", w }], [{ t: "u", w }]]);
    chk("R3", "moteur existant (index.html) : M appui central identique (kN.m)", Math.min(...res.M[0]), d0.M[d0.M.length - 1], .05, "contre-exemple");
    chk("R3", "moteur existant (index.html) : réaction centrale identique (kN)", res.R[1], c.R[4], .05, "contre-exemple");
  } catch (e) { fail++; rows.push({ id: "R3", grandeur: "chargement du moteur existant : " + e.message, ref: 1, val: 0, ecart: 100, tol: 0, ok: false, ou: "" }); }
})();

/* ===== R4. Articulation (relâchement) : poutre encastrée-appuyée ===== */
(() => {
  const L = 6, w = 18;
  const fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1, relJ: true }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true }]);
  const c = fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] }), d = R.effortsBarre(fr, 0, spec(c), 20);
  chk("R4", "relâchement en j : M d'encastrement = −wL²/8 (kN.m)", -w * L * L / 8, d.M[0], .01, "RDM");
  chk("R4", "relâchement en j : réaction d'appui = 3wL/8 (kN)", 3 * w * L / 8, c.R[4], .01, "RDM");
  chk("R4", "relâchement en j : M en j nul (kN.m)", 0, d.M[d.M.length - 1], .01, "RDM");
  /* même résultat avec un appui sans rotation bloquée et une articulation de barre à l'extrémité libre */
  const fr2 = mk([{ x: 0, y: 0 }, { x: L, y: 0 }, { x: 2 * L, y: 0 }], [{ i: 0, j: 1 }, { i: 1, j: 2, relI: true }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, uy: true }, { n: 2, uy: true }]);
  const c2 = fr2.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }, { m: 1, type: "dist", dir: "Y", q1: -w }] }), e1 = R.effortsBarre(fr2, 1, spec(c2), 20);
  chk("R4", "articulation à l'appui central : M en i de la 2e barre nul (kN.m)", 0, e1.M[0], .01, "RDM");
})();

/* ===== R5. Tassement d'appui et appui élastique ===== */
(() => {
  const L = 4, dl = .01;
  const fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true, dy: -dl }]);
  const c = fr.solveCase({}), d = R.effortsBarre(fr, 0, spec(c), 20);
  chk("R5", "bi-encastrée, tassement δ : |M| d'extrémité = 6EIδ/L² (kN.m)", 6 * EI * dl / L ** 2, Math.abs(d.M[0]), .01, "RDM");
  chk("R5", "bi-encastrée, tassement δ : |V| = 12EIδ/L³ (kN)", 12 * EI * dl / L ** 3, Math.abs(d.V[0]), .01, "RDM");
  const w = 15, k = 50000, fs = mk([{ x: 0, y: 0 }, { x: L, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: k }]);
  const cs = fs.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -w }] });
  /* poutre sur appui rotulé (gauche) et ressort k (droite) : mécanisme corps rigide + flexion — ici l'appui gauche bloque ux et uy, le ressort reprend le reste ? (stable car rotation libre + ressort) */
  const Rr = cs.R[4], ur = cs.u[4];
  chk("R5", "ressort k : équilibre des moments → réaction = wL/2 (kN)", w * L / 2, Rr, .01, "RDM");
  chk("R5", "ressort k : déplacement = R/k (m)", -(w * L / 2) / k, ur, .01, "RDM");
})();

/* ===== R6. Portique à nœuds déplaçables : pentes-déflexions (poteaux encastrés, traverse à axe rigide) ===== */
(() => {
  const h = 4, L = 6, H = 50, Ic = I, Ib = 2 * I, Ar = 1e3;
  const fr = R.frame({ nodes: [{ x: 0, y: 0 }, { x: 0, y: h }, { x: L, y: h }, { x: L, y: 0 }], members: [{ i: 0, j: 1, E, A: Ar, I: Ic }, { i: 1, j: 2, E, A: Ar, I: Ib }, { i: 3, j: 2, E, A: Ar, I: Ic }],
    supports: [{ n: 0, ux: true, uy: true, rz: true }, { n: 3, ux: true, uy: true, rz: true }] });
  const c = fr.solveCase({ nodes: [{ n: 1, fx: H }] });
  /* pentes-déflexions : rotation θ identique aux 2 nœuds supérieurs, translation Δ de la traverse (axe rigide) ;
     nœud : (4EIc/h + 6EIb/L)·θ − (6EIc/h²)·Δ = 0 ; équilibre horizontal : 2·(6EIc/h²·θ − 12EIc/h³·Δ)·(−1) = −H  → V_col = (6EIc/h²)θ − (12EIc/h³)Δ  */
  const kn = 4 * E * Ic / h + 6 * E * Ib / L, th = (6 * E * Ic / h ** 2) / kn;          /* θ = (6EIc/h²)/kn · Δ */
  const kV = 12 * E * Ic / h ** 3 - (6 * E * Ic / h ** 2) * th;                          /* rigidité de sway d'un poteau */
  const Dsway = H / (2 * kV);
  chk("R6", "portique : déplacement horizontal de la traverse (pentes-déflexions) (m)", Dsway, c.u[3], .5, "pentes-déflexions");
  chk("R6", "portique : équilibre horizontal ΣRx = −H (kN)", -H, c.R[0] + c.R[9], .01, "équilibre");
  chk("R6", "portique : équilibre des moments autour de l'origine (résidu, kN.m)", 0, c.R[2] + c.R[11] + L * c.R[10] - H * h, .01, "équilibre");
  /* symétrie : les deux poteaux reprennent H/2 */
  chk("R6", "portique : poteau gauche reprend H/2 (kN)", -H / 2, c.R[0], 1, "symétrie");
})();

/* ===== R7. Équilibre global d'un portique quelconque (barre inclinée, charges mixtes, articulation, température) ===== */
(() => {
  const nodes = [{ x: 0, y: 0 }, { x: 0, y: 3 }, { x: 4, y: 5 }, { x: 8, y: 3 }, { x: 8, y: 0 }];
  const fr = R.frame({ nodes, members: [{ i: 0, j: 1, E, A, I }, { i: 1, j: 2, E, A, I }, { i: 2, j: 3, E, A, I, relJ: true }, { i: 3, j: 4, E, A, I }],
    supports: [{ n: 0, ux: true, uy: true, rz: true }, { n: 4, ux: true, uy: true }] });
  const loads = { nodes: [{ n: 2, fx: 10, fy: -15, m: 5 }], members: [{ m: 1, type: "dist", dir: "Y", q1: -12, proj: true }, { m: 2, type: "dist", dir: "L", q1: -8, q2: -3, a: .5, b: 3.5 }, { m: 0, type: "point", dir: "X", P: 20, a: 1.2 }, { m: 3, type: "temp", dT: 20 }] };
  const c = fr.solveCase(loads);
  /* équilibre de chaque nœud : Σ (efforts d'extrémité des barres, repère global) = charge nodale appliquée */
  const nr = Array.from({ length: 5 }, () => [0, 0, 0]);
  fr.geo.forEach((g, k) => {
    const e = c.fe[k], mm = fr.model.members[k], cs = g.c, sn = g.s;
    const gl = [cs * e[0] - sn * e[1], sn * e[0] + cs * e[1], e[2], cs * e[3] - sn * e[4], sn * e[3] + cs * e[4], e[5]];
    for (let q = 0; q < 3; q++) { nr[mm.i][q] += gl[q]; nr[mm.j][q] += gl[3 + q]; }
  });
  const P = [[0, 0, 0], [0, 0, 0], [10, -15, 5], [0, 0, 0], [0, 0, 0]];
  let res = 0; for (const n of [1, 2, 3]) for (let q = 0; q < 3; q++) res = Math.max(res, Math.abs(nr[n][q] - P[n][q]));
  res = Math.max(res, Math.abs(nr[4][2]));
  chk("R7", "portique quelconque : résidu d'équilibre aux nœuds libres (kN, kN.m)", 0, res, 1e-5, "équilibre");
  /* équilibre global : résultante des charges (calculée à la main) + réactions = 0 */
  const g2 = fr.geo[2], f2y = -(8 + 3) / 2 * 3;                         /* charge locale y sur la barre inclinée : −16,5 kN (composante locale) */
  const Fx = 10 + 20 + f2y * (-g2.s), Fy = -15 - 12 * 4 + f2y * g2.c;
  const Rx = c.R.reduce((s, v, i) => (i % 3 === 0 ? s + v : s), 0), Ry = c.R.reduce((s, v, i) => (i % 3 === 1 ? s + v : s), 0);
  chk("R7", "portique quelconque : ΣRx = −ΣFx (kN)", -Fx, Rx, .001, "équilibre");
  chk("R7", "portique quelconque : ΣRy = −ΣFy (kN)", -Fy, Ry, .001, "équilibre");
  /* barre encastrée aux deux bouts, échauffement uniforme : N = −E·A·α·ΔT (compression) */
  const ft = mk([{ x: 0, y: 0 }, { x: 5, y: 0 }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true }]);
  const ct = ft.solveCase({ members: [{ m: 0, type: "temp", dT: 30 }] }), dt = R.effortsBarre(ft, 0, spec(ct), 10);
  chk("R7", "température uniforme, barre bloquée : N = −EAαΔT (kN)", -E * A * 1e-5 * 30, dt.N[0], .01, "RDM");
})();

/* ===== R8. Combinaisons EN 1990 / BAEL ===== */
(() => {
  const act = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }];
  const cb = R.combinaisons(act, {}), ex = id => cb.find(c => c.id === id);
  chk("R8", "G + Q (cat. B) : nombre de combinaisons ELU (1,35G+1,5Q ; 1,0G+1,5Q)", 2, cb.filter(c => c.famille === "ELU").length, 0, "EN 1990");
  chk("R8", "ELU : 1,35 G + 1,5 Q → facteur de Q", 1.5, ex("ELU 1").f.Q, 0, "EN 1990 6.10");
  chk("R8", "ELS caractéristique : G + Q → facteur de Q", 1, cb.find(c => c.famille === "ELS-CAR").f.Q, 0, "EN 1990 6.14");
  chk("R8", "ELS fréquente : ψ1 = 0,5 (cat. B)", .5, cb.find(c => c.famille === "ELS-FREQ").f.Q, 0, "EN 1990 6.15");
  chk("R8", "ELS quasi-permanente : ψ2 = 0,3 (cat. B)", .3, cb.find(c => c.famille === "ELS-QP").f.Q, 0, "EN 1990 6.16");
  const act2 = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }, { n: "W+", type: "W", group: "W" }, { n: "W-", type: "W", group: "W" }, { n: "S", type: "S" }];
  const c2 = R.combinaisons(act2, {});
  chk("R8", "W+ et W− (même groupe) jamais combinés ensemble (1 = oui)", 1, c2.some(c => c.f["W+"] && c.f["W-"]) ? 0 : 1, 0, "groupe exclusif");
  const q1 = c2.find(c => c.famille === "ELU" && c.f.Q === 1.5 && c.f["W+"] > 0);
  chk("R8", "Q dominante : ψ0,W = 0,6 → 1,5 × 0,6 = 0,9", .9, q1.f["W+"], 1e-9, "EN 1990 6.10");
  const w1 = c2.find(c => c.famille === "ELU" && c.f["W+"] === 1.5 && c.f.G === 1.35);
  chk("R8", "W dominant : ψ0,Q = 0,7 → 1,5 × 0,7 = 1,05 (Q d'accompagnement)", 1.05, w1.f.Q, 1e-9, "EN 1990 6.10");
  const b1 = R.combinaisons([{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }, { n: "W", type: "W" }], { norme: "BAEL" }).find(c => c.famille === "ELU" && c.f.Q === 1.5 && c.f.W);
  chk("R8", "BAEL : 1,35G + 1,5Q + 1,3·ψ0·W (ψ0 = 0,6) → 0,78", .78, b1.f.W, 1e-9, "BAEL A.3.3,21");
  const ab = R.combinaisons(act, { sixab: true }).filter(c => c.tag);
  chk("R8", "6.10a et 6.10b générées (1 = oui)", 1, ab.some(c => c.tag === "6.10a") && ab.some(c => c.tag === "6.10b") ? 1 : 0, 0, "EN 1990 6.10a/b");
  const ac = R.combinaisons([{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }, { n: "A", type: "A" }], {}).find(c => c.famille === "ACC");
  chk("R8", "accidentelle : G + A + ψ1,1·Q (0,5)", .5, ac.f.Q, 0, "EN 1990 6.11b");
  const sm = R.combinaisons([{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "A" }, { n: "Ex", type: "E", dir: "x" }, { n: "Ey", type: "E", dir: "y" }], {}).filter(c => c.famille === "SISM");
  chk("R8", "séisme : 8 combinaisons ±Ex ± 0,3 Ey et ±0,3 Ex ± Ey (+ directions pures)", 1, sm.some(c => Math.abs(c.f.Ex) === 1 && Math.abs(Math.abs(c.f.Ey) - .3) < 1e-9) && sm.some(c => Math.abs(c.f.Ey) === 1 && Math.abs(Math.abs(c.f.Ex) - .3) < 1e-9) ? 1 : 0, 0, "EN 1998-1 4.3.3.5.1");
  chk("R8", "séisme : ψ2 appliqué à Q (0,3 en cat. A)", .3, sm[0].f.Q, 1e-9, "EN 1998-1 3.2.4");
})();

/* ===== R9. Enveloppes de combinaisons ===== */
(() => {
  const L = 5, fr = mk([{ x: 0, y: 0 }, { x: L, y: 0 }, { x: 2 * L, y: 0 }], [{ i: 0, j: 1 }, { i: 1, j: 2 }], [{ n: 0, ux: true, uy: true }, { n: 1, uy: true }, { n: 2, uy: true }]);
  const g = 15, q = 10, cases = {
    G: fr.solveCase({ members: [0, 1].map(m => ({ m, type: "dist", dir: "Y", q1: -g })) }),
    Q1: fr.solveCase({ members: [{ m: 0, type: "dist", dir: "Y", q1: -q }] }), Q2: fr.solveCase({ members: [{ m: 1, type: "dist", dir: "Y", q1: -q }] })
  };
  const cbs = [{ id: "a", f: { G: 1.35, Q1: 1.5 } }, { id: "b", f: { G: 1.35, Q2: 1.5 } }, { id: "c", f: { G: 1.35, Q1: 1.5, Q2: 1.5 } }, { id: "d", f: { G: 1 } }];
  const env = R.enveloppe(fr, cases, cbs, 20), e0 = env.barres[0];
  /* appui central : chargement des deux travées → M = −(1,35·15 + 1,5·10)·L²/8 */
  chk("R9", "enveloppe : M appui central min = −(1,35g+1,5q)·L²/8 (kN.m)", -(1.35 * g + 1.5 * q) * L * L / 8, Math.min(...e0.Mmin), .01, "RDM");
  chk("R9", "enveloppe : combinaison dominante sur appui = c (1 = oui)", 1, e0.cMmin[e0.cMmin.length - 1] === "c" ? 1 : 0, 0, "enveloppe");
  chk("R9", "enveloppe : Mmax ≥ Mmin en toute abscisse (1 = oui)", 1, e0.Mmax.every((v, i) => v >= e0.Mmin[i] - 1e-9) ? 1 : 0, 0, "enveloppe");
  chk("R9", "enveloppe : réaction d'appui d'extrémité max (kN)", 1.35 * g * L * 3 / 8 + 1.5 * q * L * 7 / 16, env.R[1].max, .5, "RDM");
})();

/* ===== R10. Analyse modale ===== */
(() => {
  /* console avec masse en tête : ω = √(3EI/(m L³)) */
  const L = 3.2, m = 25;
  const fr = mk([{ x: 0, y: 0 }, { x: 0, y: L }], [{ i: 0, j: 1 }], [{ n: 0, ux: true, uy: true, rz: true }]);
  const md = R.modale(fr, [{ n: 1, mx: m, my: 0 }], 3);
  chk("R10", "console + masse : ω = √(3EI/mL³) (rad/s)", Math.sqrt(3 * EI / (m * L ** 3)), md.modes[0].omega, .01, "dynamique");
  chk("R10", "console + masse : masse modale effective = 100 % (kN·s²/m)", m, md.modes[0].mex, .01, "dynamique");
  /* portique 2 étages à traverses rigides (cisaillement) : k = 12EI/h³ par poteau ; valeurs propres exactes du système 2 ddl */
  const h = 3, nc = 2, kst = nc * 12 * EI / h ** 3, m1 = 40, m2 = 30, Ar = 1e6, Ib = 1e3 * I;
  const nodes = [{ x: 0, y: 0 }, { x: 5, y: 0 }, { x: 0, y: h }, { x: 5, y: h }, { x: 0, y: 2 * h }, { x: 5, y: 2 * h }];
  const members = [{ i: 0, j: 2, E, A: 1e6, I }, { i: 1, j: 3, E, A: 1e6, I }, { i: 2, j: 4, E, A: 1e6, I }, { i: 3, j: 5, E, A: 1e6, I }, { i: 2, j: 3, E, A: Ar, I: Ib }, { i: 4, j: 5, E, A: Ar, I: Ib }];
  const f2 = R.frame({ nodes, members, supports: [{ n: 0, ux: true, uy: true, rz: true }, { n: 1, ux: true, uy: true, rz: true }] });
  const mm = R.modale(f2, [{ n: 2, mx: m1 / 2, my: 0 }, { n: 3, mx: m1 / 2, my: 0 }, { n: 4, mx: m2 / 2, my: 0 }, { n: 5, mx: m2 / 2, my: 0 }], 4);
  /* K = k [[2,−1],[−1,1]], M = diag(m1,m2) : det(K − λM) = 0 */
  const a = m1 * m2, b = -(kst * (2 * m2 + m1)), c0 = kst * kst, disc = Math.sqrt(b * b - 4 * a * c0), l1 = (-b - disc) / (2 * a), l2 = (-b + disc) / (2 * a);
  chk("R10", "cisaillement 2 niveaux (poteaux axialement rigides) : ω1 (rad/s)", Math.sqrt(l1), mm.modes[0].omega, .3, "valeurs propres");
  chk("R10", "cisaillement 2 niveaux (poteaux axialement rigides) : ω2 (rad/s)", Math.sqrt(l2), mm.modes[1].omega, .3, "valeurs propres");
  chk("R10", "masses modales effectives cumulées = masse totale (%)", 100, mm.modes[mm.modes.length - 1].rx * 100, .5, "participation");
  chk("R10", "périodes croissantes (1 = oui)", 1, mm.modes.every((x, i, t) => !i || x.T <= t[i - 1].T + 1e-12) ? 1 : 0, 0, "tri");
})();

/* ===== R11. Spectre de réponse EN 1998-1 ===== */
(() => {
  const s = R.spectre({ ag: 2, type: 1, sol: "B", q: 3.9 }), S = 1.2, TB = .15, TC = .5, TD = 2;
  chk("R11", "Sd(T=0) = ag·S·2/3 (m/s²)", 2 * S * 2 / 3, s.Sd(0), .001, "EN 1998-1 (3.13)");
  chk("R11", "Sd plateau = ag·S·2,5/q (m/s²)", 2 * S * 2.5 / 3.9, s.Sd(.3), .001, "EN 1998-1 (3.14)");
  chk("R11", "Sd(T = 1 s) = ag·S·2,5/q·TC/T (m/s²)", 2 * S * 2.5 / 3.9 * TC / 1, s.Sd(1), .001, "EN 1998-1 (3.15)");
  chk("R11", "Sd plancher β·ag pour T grand (m/s²)", .2 * 2, s.Sd(4), .001, "EN 1998-1 (3.16)");
  chk("R11", "Se plateau = ag·S·η·2,5 (m/s²)", 2 * S * 2.5, s.Se(.3), .001, "EN 1998-1 (3.2)");
  chk("R11", "Se continu en TC (m/s²)", s.Se(TC - 1e-9), s.Se(TC + 1e-9), .001, "continuité");
})();

/* ===== R12. Portique complet : statique, modale, spectrale ===== */
(() => {
  const pq = R.portique({ ns: 4, nb: 3, L: 5, h: 3.2, bc: 40, hc: 40, bp: 25, hp: 50, fc: 25, G: 15, Q: 8, pp: 1 });
  const fr = pq.fr, tot = pq.cases.G.R.reduce((s, v, i) => (i % 3 === 1 ? s + v : s), 0);
  const Gtot = (15 + 25 * pq.Ap) * 5 * 3 * 4 + 25 * pq.Ac * 3.2 * 4 * 4;
  chk("R12", "portique 4×3 : ΣRy sous G = poids total (kN)", Gtot, tot, .01, "équilibre");
  const act = [{ n: "G", type: "G" }, { n: "Q", type: "Q", cat: "B" }], cbs = R.combinaisons(act, {});
  const env = R.enveloppe(fr, pq.cases, cbs.filter(c => c.famille === "ELU"), 10);
  chk("R12", "enveloppe ELU : toutes les valeurs finies (1 = oui)", 1, env.barres.every(b => b.Mmax.every(isFinite) && b.Mmin.every(isFinite) && b.Vmax.every(isFinite)) ? 1 : 0, 0, "contrôle");
  /* masses : (G + 0,3 Q) par étage réparti sur les nœuds */
  const W = (15 + 25 * pq.Ap + .3 * 8) * 5 * 3 + 25 * pq.Ac * 3.2 * 4;
  const masses = []; for (let j = 1; j <= 4; j++) for (let i = 0; i <= 3; i++) masses.push({ n: pq.idx(i, j), mx: W / 9.81 * (i === 0 || i === 3 ? .5 : 1) / 3, my: 0 });
  const md = R.modale(fr, masses, 8), s = R.spectre({ ag: 1.5, type: 1, sol: "B", q: 3 }), sp = R.spectrale(fr, md, s, "x");
  chk("R12", "modale : période fondamentale cohérente avec Ct·H^0,75 (ordre de grandeur, ratio ≤ 2)", 1, md.modes[0].T / (.075 * Math.pow(12.8, .75)) < 2 && md.modes[0].T / (.075 * Math.pow(12.8, .75)) > .5 ? 1 : 0, 0, "ordre de grandeur");
  chk("R12", "spectrale : masse modale cumulée ≥ 90 % (1 = oui)", 1, sp.cumul >= .9 ? 1 : 0, 0, "EN 1998-1 4.3.3.1(3)");
  const Vb = R.combinaisonModale(sp.per.map(p => p.Vb), sp.T, 5).v, Fb = s.Sd(md.modes[0].T) * md.Mx;
  chk("R12", "effort tranchant à la base (CQC) ≤ Sd(T1)·M (borne supérieure) (1 = oui)", 1, Vb <= Fb * 1.0001 ? 1 : 0, 0, "EN 1998-1 4.3.3.2");
  chk("R12", "effort tranchant à la base = Σ réactions horizontales du mode 1 (kN)", sp.per[0].Vb, -sp.per[0].res.R.reduce((s2, v, i) => (i % 3 === 0 ? s2 + v : s2), 0), .01, "équilibre modal");
})();

/* ===== R14. Poteau en flexion composée (diagramme d'interaction) ===== */
(() => {
  const o = { b: .3, h: .3, enr: .04, fc: 25, fe: 500, acc: .85, gb: 1.5, gs: 1.15 }, fbu = .85 * 25 / 1.5 * 1000, fed = 500 / 1.15 * 1000;
  const pts = R.courbeNM(o, 12), top = pts[pts.length - 1];
  /* flexion simple (N = 0), As/2 de chaque côté : comparaison à l'équilibre de la section à la main (bloc 0,8x, acier tendu plastifié) */
  const M0 = R.momentResistant(pts, 0), A = 6e-4;
  /* référence indépendante par bisection sur x : ΣN = 0 */
  let lo = .001, hi = .3, f = xx => { const e1 = 3.5e-3 * (xx - .04) / xx, e2 = 3.5e-3 * (xx - .26) / xx, s1 = Math.max(-fed, Math.min(fed, 2e8 * e1)), s2 = Math.max(-fed, Math.min(fed, 2e8 * e2)); return fbu * .3 * .8 * xx + A * s1 + A * s2; };
  for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if (f(m) > 0) hi = m; else lo = m; }
  const xx = lo, e1 = 3.5e-3 * (xx - .04) / xx, e2 = 3.5e-3 * (xx - .26) / xx, s1 = Math.max(-fed, Math.min(fed, 2e8 * e1)), s2 = Math.max(-fed, Math.min(fed, 2e8 * e2));
  const Mref = fbu * .3 * .8 * xx * (.15 - .4 * xx) + A * s1 * (.15 - .04) + A * s2 * (.15 - .26);
  chk("R14", "flexion simple (N = 0) : M résistant du diagramme (kN.m)", Mref, M0, 1.5, "équilibre de section");
  chk("R14", "N maximal du diagramme ≈ fbu·b·h + As·σs (kN)", fbu * .09 + 12e-4 * Math.min(fed, 2e8 * 2e-3), top.N, 8, "compression pure");
  const r = R.colonneNM({ ...o, N: 600, M: 70, l0: 3 });
  chk("R14", "dimensionnement : As trouvée assure M résistant ≥ Med (1 = oui)", 1, r.ok && R.momentResistant(R.courbeNM(o, r.As), 600) >= r.Med * .999 ? 1 : 0, 0, "contrôle");
  chk("R14", "dimensionnement : As croît avec le moment (1 = oui)", 1, R.colonneNM({ ...o, N: 600, M: 100, l0: 3 }).As > r.As ? 1 : 0, 0, "contrôle");
  chk("R14", "excentricité minimale : M = 0 donne Med = N·max(h/30 ; 2 cm) (kN.m)", 600 * .02, R.colonneNM({ ...o, N: 600, M: 0, l0: 3 }).Med, .01, "EN 1992-1-1 6.1(4)");
})();

/* ===== R15. Poutre continue EF (chargements alternés, tassements) vs moteur existant et RDM ===== */
(() => {
  const H = require("./harness.js"), g = H.get;
  H.setNorme("bael");
  const st = { cont: 1, n: 4, L: "4.5; 5; 4", b: .25, h: .5, enr: 3, G: 18, Q: 10, fc: 25, fe: 500, fis: 0, pp: 1, sec: "r", sp: [{ n: "Q", s: 1, t: "p", a: 2, v: 30 }, { n: "G", s: 0, t: "u", a: 1, c: 2, v: 5 }], psi2: .3, jr: .7, phiF: 2, ecs: .4, bf: .6, h0: .12 };
  const r = g("verifier")(Object.assign({ __nv: 1 }, st)), Ls = g("spans")(st), w = 18 + 25 * .25 * .5;
  const G = Ls.map(() => w), Q = Ls.map(() => 10);
  const fe = R.poutreContinueFE({ Ls, b: .25, h: .5, fc: 25, G, Q, sp: st.sp });
  const mu = r.res.map(x => x.Mu), nT = Ls.length;
  Ls.forEach((_, i) => chk("R15", `poutre continue, travée ${i + 1} : Mu EF = moteur existant (kN.m)`, mu[i], fe.Mt[i], 1, "contre-exemple"));
  for (let j = 0; j < nT - 1; j++) chk("R15", `poutre continue, appui ${j + 2} : Mu EF = moteur existant (kN.m)`, mu[nT + j], fe.Ma[j], 1, "contre-exemple");
  /* tassement de l'appui central d'une poutre à 2 travées égales, sans charge : M = 3EIδ/L² (RDM) */
  const L = 5, d = .01, b = .3, h = .6, E = R.Ecm(25) * 1000, I = b * h ** 3 / 12;
  const t = R.poutreContinueFE({ Ls: [L, L], b, h, fc: 25, G: [0, 0], Q: [0, 0], tass: [0, 10, 0] });
  const D = t.cases.D, dd = R.effortsBarre(t.fr, 0, [{ c: D, f: 1 }], 10);
  chk("R15", "2 travées, tassement δ de l'appui central : |M| = 3EIδ/L² (kN.m)", 3 * E * I * d / (L * L), Math.abs(dd.M[dd.M.length - 1]), .5, "RDM");
  /* appui élastique : une travée sur 2 appuis dont l'un sur ressort ; réaction = wL/2 (symétrie des moments) */
  const k = R.poutreContinueFE({ Ls: [L, L], b, h, fc: 25, G: [10, 10], Q: [0, 0], ksup: [0, 1e9, 0] });
  const r0 = R.poutreContinueFE({ Ls: [L, L], b, h, fc: 25, G: [10, 10], Q: [0, 0] });
  chk("R15", "ressort très raide ≈ appui rigide : réaction centrale (kN)", r0.R[1], k.R[1], .5, "limite k → ∞");
})();

/* ===== R13. Mécanisme détecté ===== */
(() => {
  let ok = 0;
  try { R.frame({ nodes: [{ x: 0, y: 0 }, { x: 4, y: 0 }], members: [{ i: 0, j: 1, E, A, I }], supports: [{ n: 0, ux: true, uy: true }] }); } catch (e) { ok = e.code === "MECANISME" ? 1 : 0; }
  chk("R13", "poutre à un seul appui rotulé : mécanisme détecté (1 = oui)", 1, ok, 0, "stabilité");
})();

module.exports = { rows, fail };
if (require.main === module) {
  let n = 0;
  for (const r of rows) { n++; console.log((r.ok ? "OK  " : "ÉCHEC ") + r.id + " " + r.grandeur + " : réf. " + (+r.ref).toPrecision(5) + " | moteur " + (+r.val).toPrecision(5) + " | écart " + r.ecart.toFixed(3) + " % (tol. " + r.tol + " %)"); }
  console.log("\n" + n + " contrôles, " + fail + " écart(s) hors tolérance");
  process.exit(fail ? 1 : 0);
}
