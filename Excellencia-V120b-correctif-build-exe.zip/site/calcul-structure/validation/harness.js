/* Chargeur sans navigateur : exécute le <script> de ../index.html dans un contexte Node (vm)
   avec un DOM factice, puis expose les fonctions de calcul réelles du module. */
const fs = require("fs"), vm = require("vm"), path = require("path");
const dir = path.join(__dirname, "..");
const html = fs.readFileSync(path.join(dir, "index.html"), "utf8");
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const mem = {};
const stub = () => new Proxy(function () {}, {
  get: (t, k) => k === Symbol.toPrimitive ? () => "" : k === "length" ? 0 : k === "style" || k === "dataset" || k === "classList" ? stub() : stub(),
  set: () => true, apply: () => stub(), construct: () => stub(), has: () => true,
});
const ctx = {
  console, Math, JSON, Date, Array, Object, Number, String, Set, Map, Promise, RegExp, Error, parseFloat, parseInt, isNaN, isFinite,
  setTimeout: () => 0, clearTimeout() {}, setInterval: () => 0, requestAnimationFrame: () => 0,
  localStorage: { getItem: k => (k in mem ? mem[k] : null), setItem: (k, v) => { mem[k] = String(v); }, removeItem: k => { delete mem[k]; } },
  document: stub(), navigator: { userAgent: "node", language: "fr" }, location: { hash: "", href: "", search: "" },
  addEventListener() {}, matchMedia: () => ({ matches: false, addEventListener() {} }), alert() {}, print() {},
};
ctx.window = ctx; ctx.self = ctx; ctx.globalThis = ctx;
vm.createContext(ctx);
// moteur ELS (fonctions pures) chargé comme dans la page
ctx.EXBV = require("../exb-verif-els.js"); ctx.EXBO = require("../exb-ouvrages.js"); ctx.EXBR = require("../exb-robot-analyse.js");
let erreurs = [];
for (const s of scripts) { try { vm.runInContext(s, ctx, { timeout: 8000 }); } catch (e) { erreurs.push(e.message); } }
const get = code => vm.runInContext(code, ctx);
module.exports = { ctx, get, erreurs, setNorme(id) { get(`P.n={id:${JSON.stringify(id)}}`); } };
