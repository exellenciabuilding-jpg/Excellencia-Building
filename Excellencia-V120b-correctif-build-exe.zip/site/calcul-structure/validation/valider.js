/* V119i — Validation du moteur de calcul sur cas de référence (node validation/valider.js)
   Chaque cas est recalculé À LA MAIN dans ce fichier (formules BAEL 91 mod. 99 / EN 1992-1-1 réécrites
   indépendamment du moteur), puis comparé à la sortie RÉELLE de index.html (chargée par harness.js).
   Ce n'est pas une comparaison à Robot : voir COMPARAISON-ROBOT.md. */
const H = require("./harness.js"), g = H.get;
const calc = g("calculRaw"), poteau = g("poteauCalc"), semelle = g("semelleCalc"), dalle = g("dalleCalc");
const rows = []; let fail = 0;
function chk(id, grandeur, ref, val, tol, ou) {
  const ecart = ref === 0 ? Math.abs(val) : (val - ref) / ref * 100, ok = Math.abs(ecart) <= tol;
  if (!ok) fail++;
  rows.push({ id, grandeur, ref, val, ecart, tol, ok, ou });
}
const MPa = 1, rect = (mu) => { const a = 1.25 * (1 - Math.sqrt(1 - 2 * mu)); return a; };

/* ===== A. Poutre rectangulaire, flexion simple ELU/ELS ===== */
const P = { b: 25, h: 50, enr: 5, G: 0, Q: 0, L: 5, fc: 25, fe: 500, fis: 1, Mu: 150, Mser: 108, Vu: 90 };
// BAEL : fbu = 0,85 fc28/γb ; μ = Mu/(b d² fbu) ; α = 1,25(1−√(1−2μ)) ; z = d(1−0,4α) ; As = Mu/(z fed)
(() => {
  H.setNorme("bael");
  const b = .25, d = .45, fbu = .85 * 25 / 1.5, fed = 500 / 1.15, mu = .150 / (b * d * d * fbu), al = rect(mu), z = d * (1 - .4 * al);
  const As = .150 / (z * fed) * 1e4, r = calc(P);
  chk("A1", "BAEL μbu", mu, r.mub, .01, "A.4.3,41"); chk("A1", "BAEL As ELU (cm²)", As, r.asElu, .05, "A.4.3,41");
  // ELS : section fissurée, n = 15, x : b x²/2 = n As (d − x) ; σbc = Mser x / I ; σs = n Mser (d − x)/I
  const Aser = r.asRet / 1e4, n = 15, x = n * Aser / b * (-1 + Math.sqrt(1 + 2 * b * d / (n * Aser))), I = b * x ** 3 / 3 + n * Aser * (d - x) ** 2;
  chk("A1", "BAEL σbc ELS (MPa)", .108 * x / I, r.sBc, .1, "A.4.5,2"); chk("A1", "BAEL σs ELS (MPa)", n * .108 * (d - x) / I, r.sS, .1, "A.4.5,33");
  const ft = .6 + .06 * 25, lim = Math.min(2 / 3 * 500, Math.max(.5 * 500, 110 * Math.sqrt(1.6 * ft)));
  chk("A1", "BAEL σs limite fissuration préjudiciable (MPa)", lim, r.limS, .01, "A.4.5,33");
  chk("A1", "BAEL As,min = 0,23 b d ft28/fe (cm²)", .23 * b * d * ft / 500 * 1e4, r.asMin, .01, "A.4.2");
  chk("A1", "BAEL τu = Vu/(b d) (MPa)", .090 / (b * d), r.tau, .01, "A.5.1,1");
  chk("A1", "BAEL τ̄u (fiss. préjudiciable) (MPa)", Math.min(.15 * 25 / 1.5, 4), r.tauL, .01, "A.5.1,211");
})();
// EC2 : fcd = fck/γc ; mêmes équations (bloc rectangulaire λ = 0,8, η = 1) ; VRd,max : z = 0,9d, cotθ = 2,5
(() => {
  H.setNorme("ec2fr");
  const b = .25, d = .45, fcd = 25 / 1.5, fyd = 500 / 1.15, mu = .150 / (b * d * d * fcd), al = rect(mu), z = d * (1 - .4 * al);
  const r = calc(P), As = .150 / (z * fyd) * 1e4, fctm = .3 * Math.pow(25, 2 / 3);
  chk("A2", "EC2 μ", mu, r.mub, .01, "3.1.7"); chk("A2", "EC2 As ELU (cm²)", As, r.asElu, .05, "6.1");
  chk("A2", "EC2 As,min = 0,26 fctm/fyk b d (cm²)", .26 * fctm / 500 * b * d * 1e4, r.asMin, .01, "9.2.1.1(1)");
  chk("A2", "EC2 vEd = VEd/(b·0,9d) (MPa)", .090 / (b * .9 * d), r.tau, .01, "6.2.3");
  chk("A2", "EC2 vRd,max = ν1 fcd/(cotθ+tanθ) (MPa)", .6 * (1 - 25 / 250) * fcd / 2.9, r.tauL, .01, "6.2.3(3)");
  chk("A2", "EC2 limite σs ELS = 0,8 fyk (MPa)", 400, r.limS, .01, "7.2(5)");
})();

/* ===== B. Poutre avec armatures comprimées (μ > μl) ===== */
(() => {
  H.setNorme("bael");
  const Q = { ...P, Mu: 280, Mser: 200, Vu: 120 }, r = calc(Q), b = .25, d = .45, dp = .05, fbu = .85 * 25 / 1.5, fed = 500 / 1.15;
  const eL = fed / 200000, aL = 3.5 / (3.5 + 1000 * eL), muL = .8 * aL * (1 - .4 * aL), mu = .280 / (b * d * d * fbu);
  chk("B1", "μl (fe500) ", muL, r.muL, .01, "A.4.3,41"); const mr = muL * b * d * d * fbu, zl = d * (1 - .4 * aL), dm = .280 - mr;
  const asc = dm / ((d - dp) * fed) * 1e4, as = (mr / (zl * fed) + dm / ((d - dp) * fed)) * 1e4;   // σsc = fed (εsc ≥ εel)
  const e = .0035 * (aL * d - dp) / (aL * d), sig = e >= eL ? fed : e * 200000;
  const asc2 = dm / ((d - dp) * sig) * 1e4;
  if (mu > muL) { chk("B1", "A' (cm²), σsc = min(fed ; Es εsc)", asc2, r.asc, .1, "A.4.3,42"); chk("B1", "As (cm²)", mr / (zl * fed) * 1e4 + dm / ((d - dp) * fed) * 1e4, r.asElu, .1, "A.4.3,42"); }
})();

/* ===== C. Poutre en Té, axe neutre dans la table ===== */
(() => {
  H.setNorme("bael");
  const Q = { ...P, tee: { bf: 80, h0: 12 }, Mu: 150 }, r = calc(Q), bf = .8, d = .45, fbu = .85 * 25 / 1.5, fed = 500 / 1.15;
  const Mtu = bf * .12 * fbu * (d - .06), mu = .150 / (bf * d * d * fbu), al = rect(mu), z = d * (1 - .4 * al);
  chk("C1", "Mtu (MN.m) ≥ Mu → rectangle bf×h", .150 < Mtu ? 1 : 0, 1, 0, "A.4.3,4");
  chk("C1", "As Té (cm²) = Mu/(z fed), b = bf", .150 / (z * fed) * 1e4, r.asElu, .05, "A.4.3,4");
})();

/* ===== D. Poteau : méthode forfaitaire BAEL B.8.4.1 ===== */
(() => {
  H.setNorme("bael");
  const st = { sec: "r", b: .3, h: .3, H: 3, k: .7, pp: 0, fc: 25, fe: 500, enr: 3, L: [{ t: "G", l: "G", N: 600, Mx: 0, My: 0 }, { t: "Q", l: "Q", N: 300, Mx: 0, My: 0 }] };
  const r = poteau(st), Nu = 1.35 * .6 + 1.5 * .3, l0 = .7 * 3, i = .3 / Math.sqrt(12), lam = l0 / i, al = .85 / (1 + .2 * (lam / 35) ** 2);
  const Br = (.3 - .02) ** 2, as = (Nu / al - Br * 25 / (.9 * 1.5)) * 1.15 / 500 * 1e4;
  chk("D1", "BAEL Nu (kN)", Nu * 1000, r.Nu, .01, "B.8.4"); chk("D1", "BAEL λ = l0√12/a", lam, r.lam, .01, "B.8.3,31");
  chk("D1", "BAEL α(λ ≤ 50)", al, r.al, .01, "B.8.4,1"); chk("D1", "BAEL Br (cm²)", Br * 1e4, r.Br, .01, "B.8.4,1");
  chk("D1", "BAEL As requis (cm²) = [Nu/α − Br fc28/(0,9γb)] γs/fe", as, r.ac, .2, "B.8.4,1");
  // retour : la capacité avec As retenu doit couvrir Nu
  const Nrd = al * (Br * 25 / (.9 * 1.5) + r.as / 1e4 * 500 / 1.15);
  chk("D1", "BAEL capacité avec As retenu ≥ Nu (1 = oui)", Nrd >= Nu ? 1 : 0, 1, 0, "B.8.4,1");
})();

/* ===== E. Dalle pleine portant dans deux sens : BAEL Annexe E.3 (ν = 0) ===== */
(() => {
  H.setNorme("bael");
  const st = Object.assign(g("dalleDef()"), { lx: 4, ly: 5, h: .16, G: 1.5, Q: 2.5, pp: 1, enr: .03, dir: "b" }), r = dalle(st);
  const al = .8, mx = 1 / (8 * (1 + 2.4 * al ** 3)), my = al * al * (1 - .95 * (1 - al) ** 2), pu = 1.35 * (1.5 + 25 * .16) + 1.5 * 2.5;
  chk("E1", "pu (kN/m²)", pu, r.pu, .01, "A.3.3"); chk("E1", "μx = 1/[8(1+2,4α³)]", mx, r.mx0 / (pu * 16), .1, "Annexe E.3");
  chk("E1", "μy = α²[1−0,95(1−α)²]", my, r.my0 / r.mx0, .1, "Annexe E.3");
  chk("E1", "Mx0 (kN.m/m)", mx * pu * 16, r.mx0, .1, "Annexe E.3"); chk("E1", "My0 (kN.m/m)", my * mx * pu * 16, r.my0, .1, "Annexe E.3");
})();

/* ===== F. Semelle isolée, méthode des bielles (BAEL A.8.2) et sol ===== */
(() => {
  H.setNorme("bael");
  const st = Object.assign(g("semDef()"), { A: 2, B: 2, H: .5, a: .3, b: .3, enr: .05, fe: 500, fc: 25, G: .6, Q: .3, MG: 0, MQ: 0, ex: 0, ey: 0, hter: 0, sig: .25 }), r = semelle(st);
  const pp = 25 * 2 * 2 * .5, Nu = 1.35 * (600 + pp) + 1.5 * 300, Ns = 600 + pp + 300, d = .5 - .05 - .01, fed = 500 / 1.15;
  chk("F1", "Nu semelle (kN)", Nu, r.Nu, .01, "A.3.3"); chk("F1", "σsol ELS = Ns/(A·B) (MPa)", Ns / 4 / 1000, r.sol.smax, .01, "DTU 13.12");
  chk("F1", "As sens A = Nu(A−a)/(8 d fed) (cm²)", Nu / 1000 * (2 - .3) / (8 * d * fed) * 1e4, r.A.As, .1, "A.8.2,41");
  chk("F1", "As sens B = Nu(B−b)/(8 (d−φ) fed) (cm²), 2e nappe", Nu / 1000 * (2 - .3) / (8 * (d - .012) * fed) * 1e4, r.B.As, .1, "A.8.2,41");
  const Nuc = 1.35 * .6 + 1.5 * .3, h = .5, uc = 2 * (.3 + .3 + 2 * h), lim = .045 * uc * h * 25 / 1.5, Qu = Nuc * (1 - (.3 + h) * (.3 + h) / 4);
  chk("F1", "Poinçonnement BAEL : limite 0,045 uc h fc28/γb (MN)", lim, r.pun.lim, .01, "A.5.2,42"); chk("F1", "Poinçonnement BAEL : Qu (MN)", Qu, r.pun.v, .5, "A.5.2,42");
})();

/* ===== G. Flèche : poutre isostatique, EC2 7.4 / BAEL B.6.5 (formules fermées, charges de service) ===== */
(() => {
  const V = H.ctx.EXBV, L = 6, q = .02, NS = 20, par = Array.from({ length: NS + 1 }, (_, i) => q * (L * i / NS) * (L - L * i / NS) / 2);
  const sP = { b: .3, h: .6, d: .55, dp: .05, As: 20e-4, Asc: 5e-4 }, fc = 30;
  // non fissurée : f = 5 q L⁴ /(384 E I0)
  const E = V.Ecm(fc) / 3, I0 = V.sec(sP, 200000 / E).I0, ref = 5 * q * .1 * L ** 4 / (384 * E * I0);
  const e = V.flecheEC2({ L, Mg: par.map(m => m * .1), Mq: par.map(() => 0), jr: .7, psi2: .3, sP, sN: sP, fc, phi: 2, ecs: 0 });
  chk("G1", "EC2 flèche long terme non fissurée (m), φ = 2", ref, e.ftot, .6, "7.4.3");
  const Ev = 3700 * Math.cbrt(fc), b = V.flecheBAEL({ L, Mg: par.map(m => m * .02), Mq: par.map(() => 0), jr: .7, sP, fc });
  chk("G1", "BAEL fgv non fissurée (m)", 5 * q * .02 * L ** 4 / (384 * Ev * b.I0), b.fgv, .6, "B.6.5,2");
  chk("G1", "BAEL limite de flèche (L > 5 m) = 0,5 cm + L/1000 (m)", .005 + L / 1000, b.adm, .01, "B.6.5,3");
})();


/* ===== H. V119j : semelle filante, radier, mur de soutènement (ouvrages complémentaires, point 8) ===== */
const O = H.ctx.EXBO, OB = { ec: false, fc: 25, fe: 500, acc: .85 };
(() => { // H1 semelle filante BAEL : bielles As = Nu(B−a)/(8 d fed)
  const r = O.semelleFilante({ ...OB, B: 1.2, H: .4, a: .2, enr: .05, G: 150, Q: 60, e0: 0, sig: .2 }), d = .4 - .05 - .01, pp = 25 * 1.2 * .4;
  const Nu = 1.35 * (150 + pp) + 1.5 * 60, Ns = 150 + pp + 60, fed = 500 / 1.15;
  chk("H1", "Semelle filante Nu (kN/m)", Nu, r.Nu, .01, "A.3.3"); chk("H1", "Semelle filante σsol (MPa)", Ns / 1.2 / 1000, r.sol.smax, .01, "DTU 13.12");
  chk("H1", "Semelle filante As bielles (cm²/m)", Nu / 1000 * (1.2 - .2) / (8 * d * fed) * 1e4, r.As, .1, "A.8.2,41");
  chk("H1", "Semelle filante τu à d du nu (MPa)", (Nu / 1.2) * ((1.2 - .2) / 2 - d) / 1000 / d, r.cis.tau, .1, "A.5.2,2");
  chk("H1", "Semelle filante rigidité d ≥ (B−a)/4 (1 = oui)", d >= (1.2 - .2) / 4 ? 1 : 0, r.rig.ok ? 1 : 0, 0, "A.8.2,1");
  const r2 = O.semelleFilante({ ...OB, B: 1.0, H: .3, a: .2, enr: .05, G: 300, Q: 100, e0: 0, sig: .2 });
  chk("H1", "Semelle filante : sol dépassé détecté (1 = erreur)", 1, r2.D.some(x => x.g == "erreur" && /sol/i.test(x.m)) ? 1 : 0, 0, "DTU 13.12");
  const r3 = O.semelleFilante({ ...OB, B: 1.2, H: .25, a: .2, enr: .05, G: 100, Q: 40, e0: 0, sig: .2 }); // d = 0,19 m < (B−a)/4 = 0,25 m
  chk("H1", "Semelle filante : semelle non rigide détectée (1 = erreur)", 1, r3.rig.ok ? 0 : 1, 0, "A.8.2,1");
})();
(() => { // H2 mur de soutènement : Rankine, FS, équilibre ELU de la répartition des pressions
  const v = { ...OB, H: 3, t: .3, hs: .4, B: 2.2, b1: .5, gam: 18, phi: 30, q: 10, mu: .5, sig: .25, enr: .05 }, r = O.murSoutenement(v);
  const Ka = Math.pow(Math.tan(Math.PI / 4 - Math.PI / 12), 2), Ht = 3.4, Pg = .5 * Ka * 18 * Ht * Ht, Pq = Ka * 10 * Ht, Mo = Pg * Ht / 3 + Pq * Ht / 2;
  const W1 = .3 * 3 * 25, W2 = 2.2 * .4 * 25, W3 = 1.4 * 3 * 18, Ms = W1 * .65 + W2 * 1.1 + W3 * 1.5;
  chk("H2", "Mur : Ka = tan²(45°−φ/2) = 1/3", 1 / 3, r.Ka, .001, "Rankine"); chk("H2", "Mur : Pa,terres (kN/m)", Pg, r.Pg, .01, "Rankine");
  chk("H2", "Mur : FS renversement", Ms / Mo, r.FSr, .01, "méthode classique"); chk("H2", "Mur : FS glissement = μ ΣV/ΣH", .5 * (W1 + W2 + W3) / (Pg + Pq), r.FSg, .01, "méthode classique");
  chk("H2", "Mur : glissement < 1,5 détecté (1 = erreur)", 1, r.D.some(x => x.g == "erreur" && /Glissement/.test(x.m)) ? 1 : 0, 0, "");
  // équilibre : ∫σu dx = ΣVu et ∫σu x dx = M stabilisant − M renversant (ELU)
  const Vu = 1.35 * (W1 + W2 + W3) + 1.5 * 10 * 1.4, Mst = 1.35 * (W1 * .65 + W2 * 1.1 + W3 * 1.5) + 1.5 * 14 * 1.5, Mre = 1.35 * Pg * Ht / 3 + 1.5 * Pq * Ht / 2;
  chk("H2", "Mur : ∫σu dx = ΣVu (kN/m)", Vu, r.eqV, .2, "équilibre"); chk("H2", "Mur : ∫σu·x dx = Mst − Mren (kN.m/m)", Mst - Mre, r.eqM, .5, "équilibre");
  const Mu = 1.35 * Ka * 18 * 27 / 6 + 1.5 * Ka * 10 * 9 / 2, d = .3 - .05 - .01, fbu = .85 * 25 / 1.5, mu = Mu / 1000 / (d * d * fbu), al = 1.25 * (1 - Math.sqrt(1 - 2 * mu));
  chk("H2", "Mur : Mu à la base du voile (kN.m/m)", Mu, r.stem.Mu, .01, "A.4.3"); chk("H2", "Mur : As flexion du voile (cm²/m)", Mu / 1000 / (d * (1 - .4 * al) * 500 / 1.15) * 1e4, r.stem.asFlex, .1, "A.4.3,41");
  chk("H2", "Mur : Vu du voile (kN/m)", 1.35 * Ka * 18 * 9 / 2 + 1.5 * Ka * 10 * 3, r.stem.Vu, .01, "A.5.1");
  const rS = O.murSoutenement({ ...v, B: 2.6 });
  chk("H2", "Mur B=2,6 m : stable (1 = oui)", 1, rS.D.some(x => x.g == "erreur") ? 0 : 1, 0, "");
  // sans surcharge : valeurs de poussée simples
  const r0 = O.murSoutenement({ ...v, q: 0 }); chk("H2", "Mur sans surcharge : Pq = 0", 0, r0.Pq, 0, "Rankine");
})();
(() => { // H3 radier : plancher inversé, BAEL E.3 + poinçonnement
  const r = O.radier({ ...OB, lx: 5, ly: 6, h: .7, a: .4, b: .4, G: 1200, Q: 500, sig: .15, enr: .05, kv: 20 }), pu = (1.35 * 1200 + 1.5 * 500) / 30, al = 5 / 6;
  const mx = 1 / (8 * (1 + 2.4 * al ** 3)), my = al * al * (1 - .95 * (1 - al) ** 2);
  chk("H3", "Radier pu net (kN/m²)", pu, r.pu, .01, "A.3.3"); chk("H3", "Radier M0x (kN.m/m)", mx * pu * 25, r.M0x, .1, "Annexe E.3"); chk("H3", "Radier M0y (kN.m/m)", my * mx * pu * 25, r.M0y, .1, "Annexe E.3");
  chk("H3", "Radier σsol = (G+Q)/(lx ly) + ρ h (MPa)", (1700 / 30 + 25 * .7) / 1000, r.psol, .01, "DTU 13.12");
  const uc = 2 * (.4 + .4 + 1.4), lim = .045 * uc * .7 * 25 / 1.5, Qu = (1.35 * 1200 + 1.5 * 500 - pu * 1.1 * 1.1) / 1000;
  chk("H3", "Radier poinçonnement BAEL : limite (MN)", lim, r.pun.lim, .01, "A.5.2,42"); chk("H3", "Radier poinçonnement BAEL : Qu (MN)", Qu, r.pun.v, .01, "A.5.2,42");
  const E = 22000 * Math.pow(3.3, .3), le = Math.pow(4 * E * (.7 ** 3 / 12) / 20, .25); chk("H3", "Radier longueur élastique le (m)", le, r.le, .01, "Winkler");
  const rm = O.radier({ ...OB, lx: 5, ly: 6, h: .3, a: .4, b: .4, G: 1200, Q: 500, sig: .15, enr: .05, kv: 20 });
  chk("H3", "Radier h=0,30 : poinçonnement non vérifié (1 = erreur)", 1, rm.pun.ok ? 0 : 1, 0, "A.5.2,42");
})();

/* ===== I. V119k : mur (remblai incliné, nappe, butée, séisme M-O) ; radier (Winkler EF, tassements) — références recalculées à part ===== */
(() => { // I1 mur : remblai incliné (Rankine incliné, plan virtuel au talon)
  const v = { ...OB, H: 3, t: .3, hs: .4, B: 3.2, b1: .5, gam: 18, phi: 30, q: 10, mu: .5, sig: .25, enr: .05, beta: 15 }, r = O.murSoutenement(v);
  const b = 15 * Math.PI / 180, f = Math.PI / 6, cb = Math.cos(b), s = Math.sqrt(cb * cb - Math.cos(f) ** 2), Ka = cb * (cb - s) / (cb + s);
  const bh = 3.2 - .5 - .3, Hv = 3.4 + bh * Math.tan(b), Pg = .5 * Ka * 18 * Hv * Hv, Pq = Ka * 10 * Hv, Ph = (Pg + Pq) * cb, Pv = (Pg + Pq) * Math.sin(b);
  const Mo = (Pg * Hv / 3 + Pq * Hv / 2) * cb, W1 = .3 * 3 * 25, W2 = 3.2 * .4 * 25, Wr = bh * 3 * 18, Wt = .5 * 18 * bh * bh * Math.tan(b), W3 = Wr + Wt;
  const x3 = (Wr * (3.2 - bh / 2) + Wt * (3.2 - bh / 3)) / W3, Ms = W1 * .65 + W2 * 1.6 + W3 * x3 + Pv * 3.2;
  chk("I1", "Mur incliné : Ka Rankine incliné", Ka, r.Ka, .001, "Rankine β"); chk("I1", "Mur incliné : Pa,terres (kN/m)", Pg, r.Pg, .01, "Rankine β");
  chk("I1", "Mur incliné : FS renversement", Ms / Mo, r.FSr, .01, "plan virtuel"); chk("I1", "Mur incliné : FS glissement", .5 * (W1 + W2 + W3 + Pv) / Ph, r.FSg, .01, "plan virtuel");
  const rb = O.murSoutenement({ ...v, beta: 35 }); chk("I1", "Mur : β ≥ φ refusé (1 = erreur)", 1, rb.ok === false ? 1 : 0, 0, "");
})();
(() => { // I2 mur : nappe à hw = 1,5 m au-dessus de la base (poussée hydrostatique + sous-pression + terres déjaugées)
  const v = { ...OB, H: 3, t: .3, hs: .4, B: 3.2, b1: .5, gam: 18, phi: 30, q: 10, mu: .5, sig: .25, enr: .05, hw: 1.5, gsat: 20 }, r = O.murSoutenement(v);
  const Ka = 1 / 3, Ht = 3.4, hw = 1.5, zw = Ht - hw, gp = 10, bh = 2.4;
  const Pa1 = .5 * Ka * 18 * zw * zw, a1 = Ht - 2 * zw / 3, Pa2 = Ka * 18 * zw * hw, a2 = hw / 2, Pa3 = .5 * Ka * gp * hw * hw, a3 = hw / 3, Pw = .5 * 10 * hw * hw, Pq = Ka * 10 * Ht;
  const Pe = Pa1 + Pa2 + Pa3, Mo = Pa1 * a1 + Pa2 * a2 + Pa3 * a3 + Pw * hw / 3 + Pq * Ht / 2, U = .5 * 10 * hw * 3.2, hwh = hw - .4;
  const W1 = 22.5, W2 = 3.2 * .4 * 25, W3 = bh * (18 * (3 - hwh) + 20 * hwh), Ms = W1 * .65 + W2 * 1.6 + W3 * (3.2 - bh / 2) , Hs = Pe + Pw + Pq;
  chk("I2", "Mur + nappe : poussée des terres Pe (kN/m)", Pe, r.Pg, .01, "terres déjaugées"); chk("I2", "Mur + nappe : Pw (kN/m)", Pw, r.Pw, .01, "hydrostatique");
  chk("I2", "Mur + nappe : sous-pression U (kN/m)", U, r.U, .01, "γw·hw·B/2");
  chk("I2", "Mur + nappe : FS renversement", Ms / (Mo + U * 2 * 3.2 / 3), r.FSr, .01, "M stab. / (M ren. + U·2B/3)"); chk("I2", "Mur + nappe : FS glissement", .5 * (W1 + W2 + W3 - U) / Hs, r.FSg, .01, "μ(ΣV−U)/ΣH");
})();
(() => { // I3 mur : butée mobilisée à 50 % ; séisme de Mononobe-Okabe
  const v = { ...OB, H: 3, t: .3, hs: .4, B: 2.2, b1: .5, gam: 18, phi: 30, q: 10, mu: .5, sig: .25, enr: .05, fb: .5, hb: .4 }, r = O.murSoutenement(v);
  const Pp = .5 * .5 * 3 * 18 * .8 * .8, Ka = 1 / 3, Ht = 3.4, Ph = .5 * Ka * 18 * Ht * Ht + Ka * 10 * Ht, V = 22.5 + 2.2 * .4 * 25 + 1.4 * 3 * 18;
  chk("I3", "Butée Pp = fb·Kp·γ·(hb+hs)²/2 (kN/m)", Pp, r.Pp, .01, "Rankine passif"); chk("I3", "Glissement avec butée", (.5 * V + Pp) / Ph, r.FSg, .01, "(μV + Pp)/ΣH");
  // Kae : valeur de la littérature φ = 30°, δ = 0, kh = 0,1, kv = 0 → 0,397 (Okabe)
  chk("I3", "Kae φ30° kh0,1 kv0 (Mononobe-Okabe)", .3966, O.Kae(Math.PI / 6, 0, 0, Math.atan(.1)), .3, "EN 1998-5 E");
  const vs = { ...OB, H: 3, t: .3, hs: .4, B: 3.2, b1: .5, gam: 18, phi: 30, q: 10, mu: .5, sig: .25, enr: .05, ag: 2, S: 1.2, r: 1 }, rs = O.murSoutenement(vs);
  // recalcul indépendant du cas défavorable (1 − kv) : θ, Kae, ΔPae, forces d'inertie à 0,5·Hv, ψ2 = 0,3 sur la surcharge
  const kh = 2 * 1.2 / 9.81, kv = .5 * kh, ph = Math.PI / 6, th = Math.atan(kh / (1 - kv));
  const K = Math.pow(Math.cos(ph - th), 2) / (Math.cos(th) ** 2 * Math.pow(1 + Math.sqrt(Math.sin(ph) * Math.sin(ph - th) / Math.cos(th)), 2));
  const dP = .5 * 18 * 3.4 * 3.4 * ((1 - kv) * K - 1 / 3), W1 = 22.5, W2 = 3.2 * .4 * 25, W3 = 2.4 * 3 * 18, f = 1 - kv, Pq = .3 * 10 * 3.4 / 3, Pg = .5 * 18 * 3.4 * 3.4 / 3;
  const Hs = Pg + Pq + dP + kh * (W1 + W2 + W3), Vv = f * (W1 + W2 + W3);
  const Mst = f * (W1 * .65 + W2 * 1.6 + W3 * 2), Mov = Pg * 3.4 / 3 + Pq * 3.4 / 2 + dP * .5 * 3.4 + kh * (W1 * 1.9 + W2 * .2 + W3 * 1.9);
  chk("I3", "Séisme : kh = ag·S/(g·r)", kh, rs.sis.kh, .01, "EN 1998-5 7.3.2.2"); chk("I3", "Séisme (1−kv) : Kae", K, rs.sis.cases[1].Ks, .01, "EN 1998-5 E"); chk("I3", "Séisme (1−kv) : ΔPae (kN/m)", dP, rs.sis.cases[1].dP, .01, "EN 1998-5 E");
  chk("I3", "Séisme (1−kv) : FS glissement", .5 * Vv / Hs, rs.sis.cases[1].FSg, .5, "μΣV/ΣH"); chk("I3", "Séisme (1−kv) : FS renversement", Mst / Mov, rs.sis.cases[1].FSr, .5, "M stab./M ren.");
  const r0 = O.murSoutenement({ ...vs, ag: 0 }); chk("I3", "Sans séisme : pas de bloc sismique (1 = oui)", 1, r0.sis ? 0 : 1, 0, "");
})();
(() => { // I4 radier : Boussinesq, tassement, plaque de Winkler (solutions analytiques)
  chk("I4", "Boussinesq : I coin carré, z = B (table de Newmark)", .1752, O.Icoin(1, 1, 1), .05, "Boussinesq");
  // tassement central d'un carré 4 × 4 m, q = 100 kPa, couche 2 m, E = 10 MPa : formule de Newmark (m = n = 2/z), intégration fine
  const Inew = (l, b, z) => { const m = l / z, n = b / z, a = m * m + n * n, rt = Math.sqrt(a + 1), A = 2 * m * n * rt / (a + m * m * n * n + 1) * (a + 2) / (a + 1), B = Math.atan2(2 * m * n * rt, a - m * m * n * n + 1); return (A + B) / (4 * Math.PI); };
  let s = 0; const N = 4000; for (let i = 0; i < N; i++) { const z = (i + .5) * 2 / N; s += 100 * 4 * Inew(2, 2, z) * (2 / N) / 10000; }
  chk("I4", "Tassement œdométrique au centre (m)", s, O.tassement(4, 4, 100, [{ h: 2, E: 10 }]).sc, .2, "Boussinesq / œdomètre");
  // plaque mince sur Winkler : flèche sous charge ponctuelle w = P/(8 k l²), l = (D/k)^(1/4) (Hetényi), domaine 20 l
  const E = 30e6, nu = .2, P = 1000, h = .1, k = 100, Dd = E * h ** 3 / (12 * (1 - nu * nu)), l = Math.pow(Dd / k, .25), n = 66, L = 20 * l, xs = []; for (let i = 0; i <= n; i++) xs.push(-L / 2 + L * i / n);
  const pw = O.plateWinkler({ xs, ys: xs, h, E, nu, kv: k, loads: [{ i: n / 2, j: n / 2, N: P }], q: 0, bilat: true });
  chk("I4", "Plaque de Winkler : flèche sous charge P (Hetényi)", P / (8 * k * l * l), pw.w[pw.nid(n / 2, n / 2)], 2, "Hetényi"); chk("I4", "Plaque de Winkler : ΣR = ΣP", P, pw.Rtot, .01, "équilibre");
  const xu = [0, 1, 2, 3, 4, 5, 6], pu_ = O.plateWinkler({ xs: xu, ys: [0, 1, 2, 3, 4, 5, 6, 7, 8], h: .5, E, nu, kv: k, loads: [], q: 50 });
  chk("I4", "Plaque sur Winkler, charge uniforme : w = q/kv", 50 / k, pu_.w[0], .01, "Winkler"); chk("I4", "Plaque sur Winkler, charge uniforme : moments nuls", 0, Math.max(...pu_.mx.map(a => Math.max(...Array.from(a).map(Math.abs)))), 0.0001, "");
  const pe = O.plateWinkler({ xs: Array.from({ length: 13 }, (_, i) => i / 2), ys: Array.from({ length: 13 }, (_, i) => i / 2), h: 2, E, nu, kv: k, loads: [{ i: 11, j: 6, N: 3000 }], q: 0 });
  chk("I4", "Charge excentrée : décollement détecté (1 = oui)", 1, pe.uplift > 0 ? 1 : 0, 0, "contact unilatéral"); chk("I4", "Charge excentrée : ΣR = ΣP", 3000, pe.Rtot, .01, "équilibre");
})();
(() => { // I5 radier général complet : modèle EF (6 × 6 travées), équilibre des moments d'une travée intérieure
  const lx = 5, ly = 6, a = .4, G = 1200, Q = 500, r = O.radier({ ...OB, lx, ly, h: .5, a, b: a, G, Q, sig: .5, enr: .05, kv: 10, modele: 1, nbx: 6, nby: 6, ob: 0, fr: .5 });
  const ef = r.ef, ru = ef.ru, ax = ef.ax, ay = ef.ay, m = ef.m, p = (1.35 * G + 1.5 * Q) / (lx * ly), i3 = ax.col[3], half = a / 2;
  chk("I5", "Radier EF : ΣR = ΣP (ELU)", ru.Ftot, ru.Rtot, .01, "équilibre");
  let sc = 0, sm = 0, W = 0;
  for (let j = ay.col[2]; j < ay.col[3]; j++) {
    const dy = ay.xs[j + 1] - ay.xs[j], sd = d => { const e1 = d < 0 ? i3 - 1 : i3, e2 = d < 0 ? i3 - 2 : i3 + 1, c1 = (ax.xs[e1] + ax.xs[e1 + 1]) / 2, c2 = (ax.xs[e2] + ax.xs[e2 + 1]) / 2, t = (Math.abs(c1 - ax.xs[i3]) - half) / Math.abs(c2 - c1); return ru.mx[e1][j] + (ru.mx[e1][j] - ru.mx[e2][j]) * t; };
    sc += (sd(-1) + sd(1)) / 2 * dy; sm += ru.mx[i3 - (m + 1) / 2][j] * dy; W += dy;
  }
  chk("I5", "Radier EF : M(mi-portée) − M(nu) = pn·l²/8 − V·a/2 (kN.m/m, travée intérieure)", p * lx * lx / 8 - p * lx / 2 * half, -(sm - sc) / W, 10, "équilibre statique d'une travée (maillage grossier : 10 %)");
  const rt = O.radier({ ...OB, lx, ly, h: .8, a, b: a, G, Q, sig: .15, enr: .05, kv: 20, nbx: 3, nby: 3, ob: .5, h1: 8, E1: 20, Df: 1.5 });
  chk("I5", "Radier : tassement œdométrique calculé (1 = oui)", 1, rt.tassSol && rt.tassSol.sc > 0 && rt.tassSol.sc > rt.tassSol.se ? 1 : 0, 0, "centre > coin");
})();

(() => { // I6 plans d'armatures, 3D, DXF/IFC des fondations (V119l) : générateurs exécutés sur le vrai index.html
  const Mm = g("M"), def = k => Object.fromEntries(Mm[k].f.map(x => [x[0], Array.isArray(x[3]) ? x[4] : x[3]]));
  H.setNorme("bael");
  for (const [k, ov, vol] of [["sfilante", {}, 1.2 * .4], ["radier", {}, (3 * 5 + 1) * (3 * 6 + 1) * .8], ["mur", {}, .3 * 3 + 2.6 * .4]]) {
    const v = { ...def(k), ...ov }, res = Mm[k].run(v); H.ctx.__t = { k, v, R: res.R };
    const o = g(`(()=>{const {k,v,R}=__t,D=OUV_DEF[k],vv={...v,ec:false};if(!D.ok(R))return {ok:0};const d=D.d(vv,R),gm=D.p(vv,R,d),sc=D.s(vv,R),T=JSON.stringify([gm,sc]);let mx=[-1e9,-1e9,-1e9],mn=[1e9,1e9,1e9];sc.F.forEach(F=>F.p.forEach(p=>p.forEach((c,i)=>{mx[i]=Math.max(mx[i],c);mn[i]=Math.min(mn[i],c)})));
      return {ok:1,vol:d.vol,poids:d.poids,sum:d.bars.reduce((a,q)=>a+q.nb*q.len*.006165*q.phi*q.phi,0),nan:/NaN|Infinity/.test(T)?1:0,dxf:dxf2d(gm).length,dxf3:dxf3d(sc).length,ifc:ifcOf(sc,D.nom,D.ifc).length,nL:sc.L.length,nbars:d.bars.length,dx:mx[0]-mn[0]}})()`);
    chk("I6", `${k} : plan/3D générés (1 = oui)`, 1, o.ok, 0, "V119l"); chk("I6", `${k} : volume de béton du plan (m³/ml ou m³)`, vol, o.vol, .01, "géométrie");
    chk("I6", `${k} : poids d'acier = Σ n·l·0,006165·φ² (kg)`, o.sum, o.poids, .01, "nomenclature"); chk("I6", `${k} : aucune valeur NaN dans le plan ni la 3D (1 = oui)`, 1, o.nan ? 0 : 1, 0, "");
    chk("I6", `${k} : DXF 2D, DXF 3D et IFC non vides (1 = oui)`, 1, o.dxf > 1000 && o.dxf3 > 1000 && o.ifc > 1000 && o.nL > 0 ? 1 : 0, 0, "export");
  }
})();

module.exports = { rows, fail };
if (require.main === module) {
  let n = 0;
  for (const r of rows) { n++; console.log((r.ok ? "OK  " : "ÉCHEC ") + r.id + " " + r.grandeur + " : réf. " + r.ref.toPrecision(5) + " | moteur " + r.val.toPrecision(5) + " | écart " + r.ecart.toFixed(3) + " % (tol. " + r.tol + " %)"); }
  console.log("\n" + n + " contrôles, " + fail + " écart(s) hors tolérance");
  process.exit(fail ? 1 : 0);
}
