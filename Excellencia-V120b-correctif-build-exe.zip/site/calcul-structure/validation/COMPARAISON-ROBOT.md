# Comparaison avec Robot Structural Analysis (à remplir)

Procédure : pour chaque cas, saisir les mêmes données dans Robot (module « Calcul des armatures de poutre/poteau/semelle », norme choisie) et dans Excellencia, puis reporter les valeurs. Tolérance d'acceptation proposée : ±5 % sur les armatures, ±2 % sur les contraintes ; au-delà, chercher la cause (hypothèse de chargement, enrobage, diamètre imposé, section de calcul).

| N° | Ouvrage | Données (norme, section, matériaux, charges) | Grandeur | Robot | Excellencia | Écart % | Verdict |
|---|---|---|---|---|---|---|---|
| R1 | Poutre rect. | BAEL ou EC2 ; 25×50 ; enr. 5 cm ; fc 25 ; fe 500 ; Mu 150 kN.m ; Mser 108 ; Vu 90 | As ELU (cm²) | | 8,70 (BAEL) / 8,51 (EC2) | | |
| R2 | Poutre rect. | idem, Mu 280 kN.m | As et A' (cm²) | | 18,86 / 0,77 (BAEL) | | |
| R3 | Poutre Té | bf 80 ; h0 12 ; Mu 150 | As (cm²) | | 7,94 (BAEL) | | |
| R4 | Poteau 30×30 | H 3 m ; k 0,7 ; NG 600 ; NQ 300 kN | As (cm²) | | 3,97 calculé / 4,80 mini (BAEL) | | |
| R5 | Semelle 2×2×0,5 | poteau 30×30 ; G 600 ; Q 300 kN | As sens A (cm²) | | 14,75 (BAEL) | | |
| R6 | Dalle 4×5 | h 16 ; G 1,5 ; Q 2,5 kN/m² | Mx0 ; My0 (kN.m/m) | | 10,03 ; 6,17 (BAEL) | | |

Remarque : Robot peut retenir des armatures minimales, un enrobage ou des diamètres différents ; comparer d'abord les **armatures requises** avant celles retenues.

## Cas V119j (ouvrages complémentaires)
| N° | Ouvrage | Données | Grandeur | Robot | Excellencia (BAEL) | Écart % | Verdict |
|---|---|---|---|---|---|---|---|
| R7 | Semelle filante | B 1,2 ; H 0,4 ; mur 0,2 ; G 150 ; Q 60 kN/m ; sol 0,2 MPa | As (cm²/m) | | 3,28 | | |
| R8 | Mur de soutènement | H 3 ; t 0,3 ; hs 0,4 ; B 2,6 ; patin 0,5 ; γ 18 ; φ 30° ; q 10 kPa ; μ 0,5 | FS ren. / FS gliss. / As voile | | 3,65 / 1,58 / 7,89 cm²/m | | |
| R9 | Radier | 5×6 m ; h 0,8 ; poteau 0,4 ; G 1200 ; Q 500 kN | As travée x (cm²/m) | | 6,93 | | |

## Cas V119k (limites levées : remblai incliné, nappe, butée, séisme, radier sur sol élastique, tassements)
Valeurs Excellencia en BAEL. Les cas R10 à R13 reprennent le mur de R8 avec B = 3,2 m (sauf R13 : B = 2,2 m). Les cas séisme et radier EF dépendent d'hypothèses qu'il faut aligner dans Robot (voir README-V119k).
| N° | Ouvrage | Données | Grandeur | Robot | Excellencia (BAEL) | Écart % | Verdict |
|---|---|---|---|---|---|---|---|
| R10 | Mur, remblai incliné | R8 avec B 3,2 ; β 15° (δ = β, plan virtuel au talon) | FS ren. / FS gliss. / As voile | | 4,13 / 1,60 / 8,55 cm²/m | | |
| R11 | Mur, nappe | R8 avec B 3,2 ; hw 1,5 m au-dessus de la base ; γsat 20 ; aval sec | Pw / U / FS ren. / FS gliss. | | 11,25 / 24,00 kN/m / 2,95 / 1,52 | | |
| R12 | Mur, séisme | R8 avec B 3,2 ; ag 2 m/s² ; S 1,2 ; r 1 ; kv = ±0,5 kh ; ψ2 = 0,3 | FS ren. / FS gliss. sismiques (cas défavorable) | | 1,99 / 0,82 (glissement non conforme) | | |
| R13 | Mur, butée | R8 avec B 2,2 ; butée 50 % ; hb 0,4 m | Pp / FS gliss. | | 8,64 kN/m / 1,49 | | |
| R14 | Radier EF (Winkler) | 3×3 travées 5×6 ; débord 0,5 ; h 0,8 ; poteau 0,4 ; G 1200 ; Q 500 ; rive ×0,5 ; kv 20 MN/m³ | As x trav. / x appui / y trav. / y appui (cm²/m) ; σ sol max | | 11,01 / 6,93 / 9,48 / 7,67 ; 0,135 MPa | | |
| R15 | Radier, tassement | R14 + couche de 6 m, Eoed 20 MPa, assise 1,5 m | s centre / coin (mm) ; s Winkler max | | 12,4 / 3,2 ; 6,7 | | |

Remarques : dans Robot, comparer d'abord les moments de bande (modèle plaque sur ressorts) avant les armatures. Le moment sous poteau est relevé à la borne d'équilibre d'une travée intérieure (voir README-V119k).
