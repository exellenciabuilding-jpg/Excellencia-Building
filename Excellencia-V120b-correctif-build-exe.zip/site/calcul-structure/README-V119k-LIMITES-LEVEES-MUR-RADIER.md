# V119k — Limites levées : mur de soutènement et radier

Moteur `exb-ouvrages.js`. Les valeurs par défaut (remblai horizontal, sans eau, sans butée, sans séisme, réaction uniforme) redonnent exactement les résultats de V119j (R8 et R9 inchangés).

## Mur de soutènement (nouveaux champs du module)
- **Remblai incliné β** : poussée de Coulomb avec δ = β (équivalente à Rankine incliné), plan virtuel vertical au bout du talon ; poids du prisme de terre sur le talon et composante verticale de la poussée prises en compte.
- **Nappe (hw, γsat)** : terres déjaugées sous la nappe, poussée hydrostatique sur le voile et le plan virtuel, sous-pression linéaire sous la semelle (aval supposé sec, sans rideau). Appliquée avec γG à l'ELU.
- **Butée (fb, hb)** : Pp = fb·Kp·γ·(hb + hs)²/2, retenue au **glissement uniquement** (jamais dans les moments ni les pressions, par prudence).
- **Séisme (ag, S, r)** : pseudo-statique de Mononobe-Okabe (EN 1998-5, annexe E) : kh = ag·S/(g·r), kv = ±0,5·kh, deux sens de kv, incrément dynamique à 0,5·Hv, inertie du voile, de la semelle et du talus, ψ2 = 0,3 sur la surcharge. Contrôles : FS ≥ 1,1 (renversement, glissement), σ ≤ 1,33·σadm, e ≤ B/3, armatures du voile, du patin et du talon retenues au maximum statique/sismique.

## Radier (nouveaux champs du module)
- **Réaction non uniforme** (« Winkler, éléments finis ») : plaque de Mindlin sur ressorts de Winkler sur tout le radier (nbx × nby travées, débord, poteaux de rive à fr·N), décollement par itérations, poids propre inclus, moments par bandes (bande sur poteaux = min(lx, ly)/2), effort tranchant hors zone de poinçonnement, pression de sol, tassements w = p/kv.
- **Tassement du sol** : méthode œdométrique avec contraintes de Boussinesq (jusqu'à 3 couches), tassement au centre et au coin, rotation relative (alerte au-delà de 1/500), kv équivalent.
- Le modèle « plancher inversé » reste disponible ; il affiche maintenant une alerte : valable pour un radier nervuré, pas pour un radier plat.

## Limites restantes (à ne pas oublier dans une note de calcul)
- Mur : poussée hydrodynamique (séisme + nappe), charge en tête, sol non homogène, bêche calculée, stabilité d'ensemble, liquéfaction. FS sismiques et σ majorée = valeurs usuelles à adapter à l'annexe nationale. Hauteur d'application de l'incrément dynamique (0,5·Hv) à confirmer dans le texte de la norme.
- Radier EF : maillage de 5 à 6 mailles par travée ; la charge ponctuelle du poteau n'est pas résolue, donc le moment sous poteau est relevé à la borne d'équilibre d'une travée intérieure. Poinçonnement vérifié sous un poteau intérieur (rive et angle : majoration β non traitée). Sol de Winkler : les pics de pression en rive sont plus marqués que dans la réalité. Pas de nervures, pas de bêche, pas de séisme sur le radier.
- Dispositions parasismiques constructives (DCM/DCH) : non traitées.

## Validation
`node site/calcul-structure/validation/valider.js` : 96 contrôles (66 de V119i/j + 30 nouveaux, recalculés à part : Rankine incliné, nappe, butée, Kae de la littérature, séisme, Boussinesq/Newmark, flèche de Hetényi, équilibre du radier EF). Pas encore comparé à Robot : voir cas R10 à R15 de `COMPARAISON-ROBOT.md`.

## V119l — Plan d'armatures, vue 3D et exports (semelle filante, radier, mur)
Chaque module a maintenant, sous les résultats, trois boutons comme la semelle isolée :
- **Plan d'armatures** : feuille cotée avec cartouche, tableau d'aciers (repère, diamètre, forme, espacement, nombre, longueur), poids d'acier et densité (kg/m³). Semelle filante : plan de 2 m et coupe A-A. Radier : plan (barres d'extrémité et de rive de chaque nappe) et coupes sens x et sens y. Mur : coupe A-A avec barres coudées du voile, barres horizontales, patin et talon, plus l'élévation sur 2 m.
- **Vue 3D** : béton translucide, barres de toutes les nappes, légende, comme les autres modules.
- **Format DXF / BIM** : DXF 2D du plan, DXF 3D, IFC4 (béton et barres).
Quantités du mur et de la semelle filante : par mètre linéaire. Le radier est dessiné sur nbx × nby travées avec le débord saisi. Les armatures de répartition du mur et de la semelle sont dimensionnées au quart de l'armature principale (minimum de répartition) ; attentes de poteaux et chaises ne sont pas dans les poids.
Contrôles : 15 vérifications ajoutées (96 → 111) : volume, poids = Σ n·l·0,006165·φ², absence de NaN, exports non vides.
