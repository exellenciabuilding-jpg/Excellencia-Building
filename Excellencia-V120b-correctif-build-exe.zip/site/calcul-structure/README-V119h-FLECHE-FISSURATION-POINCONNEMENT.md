# V119h — Flèche, fissuration, poinçonnement, effort tranchant

Nouveau fichier : `exb-verif-els.js` (fonctions pures, `window.EXBV` ; testable sous Node : `node test-verif-els.js`).

## Poutre (point 5)
- **Flèche** calculée pour chaque travée, continuité prise en compte (double intégration des courbures sur le diagramme de moments de service).
  - EC2 7.4.3 : interpolation états I/II (ζ, β = 0,5), module effectif Ec/(1+φ), retrait, combinaison G + Ψ2·Q. Limites : L/250 (totale), L/500 (part nuisible = long terme − instantané sous charges avant cloisons).
  - BAEL B.6.5,2 : Ifi/Ifv à mi-travée, Δf = fgv − fji + fpi − fgi. Limites : L/500 (L ≤ 5 m), 0,5 cm + L/1000 (L > 5 m).
  - Calculée avec les aciers **fournis** (pas requis). Si la dispense forfaitaire est satisfaite mais que le calcul dépasse : alerte ; sinon : erreur avec solution chiffrée (h).
- **Fissuration** : wk (EC2 7.3.4) en travée et sur appui, wmax = 0,4 / 0,3 / 0,2 mm selon « Fissuration ». Sous BAEL : valeur indicative, la vérification réglementaire reste la limite de σs.
- Carte « Hypothèses de service » : Ψ2 (0,3), part de G avant cloisons (0,7), fluage φ (2), retrait εcs (0,4 ‰).
- Résultats : carte « Flèche et fissuration », section 9 de la note de calcul.

## Semelle (point 6)
- Poinçonnement : EC2 6.4 complet (contour au nu du poteau vs vRd,max ; contours de 0,25d à 2d avec réduction par la réaction du sol et majoration 2d/a ; β ≥ 1,15 ou excentré) ; BAEL A.5.2,42. Charge du poteau seule (sans poids propre ni terres, équilibrés par le sol). Solution chiffrée (H).
- Effort tranchant à d du nu dans les deux sens (EC2 6.2.2 / BAEL A.5.2,2).

## Dalle (point 6)
- Poinçonnement sous charge concentrée (champs P, u, v) ; armatures de poinçonnement EC2 estimées ; solution chiffrée (h).
- Effort tranchant : message avec épaisseur minimale chiffrée.

## Limites connues
- Charges de service sur toutes les travées (pas d'alternance) ; aciers de compression sur appui = 1/3 des aciers de travée ; section en Té seulement en travée.
- Poinçonnement de dalle : charge centrée, périmètre non tronqué ; dalle multi-travées, plancher corps creux, escalier non concernés.
- Les tests sont des contrôles de cohérence (solutions fermées), **pas** une validation sur exemples corrigés ou Robot (point 7).
- Dans le Bâtiment, le contrôle de flèche peut augmenter la hauteur de certaines poutres.
