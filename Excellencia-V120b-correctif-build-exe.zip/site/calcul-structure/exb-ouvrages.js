/* V119j — Semelle filante, radier général, mur de soutènement en béton armé (fonctions pures, window.EXBO).
   Unités : m, kN, kPa, MPa ; sections d'acier en cm². Calcul d'aide à l'étude : à faire vérifier par un ingénieur.
   Options communes o : ec (true = EC2, false = BAEL), fc, fe, gb, gs, gG, gQ, rho (kN/m³), acc (0,85 BAEL / 1 EC2). */
(function (root) {
  "use strict";
  const ES = 200000, PI = Math.PI;
  const base = o => ({ ec: !!o.ec, fc: o.fc, fe: o.fe, gb: o.gb || 1.5, gs: o.gs || 1.15, gG: o.gG || 1.35, gQ: o.gQ || 1.5, rho: o.rho || 25, acc: o.acc != null ? o.acc : (o.ec ? 1 : .85) });
  const fctm = fc => (fc <= 50 ? .3 * Math.pow(fc, 2 / 3) : 2.12 * Math.log(1 + (fc + 8) / 10));
  const ftj = (ec, fc) => (ec ? fctm(fc) : .6 + .06 * fc);
  const Ecm = fc => 22000 * Math.pow((fc + 8) / 10, .3);

  /* Flexion simple, bande de 1 m : retourne As (cm²/m), A' (cm²/m) ou erreur.  M en kN.m/m, d en m. */
  function flex(M, d, c) {
    const fbu = c.acc * c.fc / c.gb, fed = c.fe / c.gs, Mu = Math.abs(M) / 1000;
    if (!(Mu > 0)) return { As: 0, Asc: 0, mu: 0 };
    const mu = Mu / (1 * d * d * fbu), eL = fed / ES, aL = 3.5 / (3.5 + 1000 * eL), muL = .8 * aL * (1 - .4 * aL);
    if (mu > .5) return { As: Infinity, Asc: 0, mu, muL, err: "Section insuffisante (μ > 0,5)." };
    if (mu <= muL) { const al = 1.25 * (1 - Math.sqrt(1 - 2 * mu)), z = d * (1 - .4 * al); return { As: Mu / (z * fed) * 1e4, Asc: 0, mu, muL, z }; }
    return { As: Infinity, Asc: 0, mu, muL, err: "Armatures comprimées nécessaires (μ > μl) : augmentez l'épaisseur." };
  }
  const asMin = (c, d) => (c.ec ? Math.max(.26 * ftj(true, c.fc) / c.fe, .0013) : .23 * ftj(false, c.fc) / c.fe) * 1 * d * 1e4;

  /* ELS d'une bande de 1 m (section fissurée, n = 15) : contraintes (MPa). */
  function els(d, As, M) {
    const n = 15, A = As / 1e4, x = n * A * (-1 + Math.sqrt(1 + 2 * d / (n * A))), I = x ** 3 / 3 + n * A * (d - x) ** 2;
    return { x, sBc: M / 1000 * x / I, sS: n * M / 1000 * (d - x) / I };
  }
  function limS(c, fis) {
    if (c.ec) return .8 * c.fe;
    const ft = ftj(false, c.fc), b = Math.min(2 / 3 * c.fe, Math.max(.5 * c.fe, 110 * Math.sqrt(1.6 * ft)));
    return fis == 0 ? null : fis == 2 ? .8 * b : b;
  }
  /* As retenue au ELS : on augmente As de 3 % jusqu'à satisfaction (comme calculRaw). */
  function asEls(d, As, Mser, c, fis) {
    let a = As, k = 0; const lc = .6 * c.fc, ls = limS(c, fis);
    if (!(Mser > 0)) return { As: a, sBc: 0, sS: 0, lc, ls };
    let r = els(d, a, Mser);
    while (k++ < 120 && (r.sBc > lc || (ls != null && r.sS > ls))) { a *= 1.03; r = els(d, a, Mser); }
    return { As: a, sBc: r.sBc, sS: r.sS, lc, ls, ko: r.sBc > lc || (ls != null && r.sS > ls) };
  }
  /* Choix de nappe : φ, espacement e (cm) → section par mètre (cm²/m) ; φ de la liste donnée. */
  function nappe(req, h, c, phis) {
    const E = c.ec ? Math.min(3 * h * 100, 40) : Math.min(3 * h * 100, 33), es = [10, 12.5, 15, 20, 25].filter(e => e <= E);
    let best = null;
    for (const p of (phis || [8, 10, 12, 14, 16, 20, 25])) for (const e of es) {
      const s = 100 / e * PI * p * p / 400;
      if (s >= req - 1e-9 && (!best || s < best.s - 1e-9)) best = { phi: p, e, s };
    }
    return best;
  }
  /* Effort tranchant sans armatures, bande de 1 m. V en kN/m. */
  function cisaillement(V, d, As, c) {
    const tau = V / 1000 / d;
    if (!c.ec) { const lim = .07 * c.fc / c.gb; return { tau, lim, ok: tau <= lim + 1e-9, ref: "BAEL A.5.2,2" }; }
    const dm = d * 1000, k = Math.min(2, 1 + Math.sqrt(200 / dm)), rl = Math.min(.02, Math.max(As, 0) / 1e4 / d), vmin = .035 * Math.pow(k, 1.5) * Math.sqrt(c.fc);
    const lim = Math.max(.18 / c.gb * k * Math.pow(100 * rl * c.fc, 1 / 3), vmin);
    return { tau, lim, ok: tau <= lim + 1e-9, ref: "EN 1992-1-1 6.2.2" };
  }
  const push = (D, g, m, r) => D.push({ g, m, r });
  const f2 = (x, n) => (+x).toFixed(n == null ? 2 : n);

  /* =====================================================================================
     1. SEMELLE FILANTE sous mur (par mètre linéaire) — méthode des bielles (BAEL A.8.2 / EC2 6.5)
     o : { B, H, a, enr, G, Q (kN/m, hors poids propre), e0 (m, excentricité de la charge), sig (MPa), fc, fe, ... }
     ===================================================================================== */
  function semelleFilante(o) {
    const c = base(o), D = [], F = [], B = o.B, H = o.H, a = o.a, d = H - o.enr - .01, e0 = Math.abs(o.e0 || 0);
    const pp = c.rho * B * H, Gc = o.G, Qc = o.Q, Ns = Gc + pp + Qc, Nu = c.gG * (Gc + pp) + c.gQ * Qc, Nuc = c.gG * Gc + c.gQ * Qc;
    const R = { Ns, Nu, pp, d, D, F };
    if (!(B > 0 && H > 0 && a > 0 && d > .05)) { push(D, "erreur", "Dimensions invalides (hauteur utile insuffisante)."); R.ok = false; return R; }
    if (a >= B) { push(D, "erreur", "Le mur doit être plus étroit que la semelle."); R.ok = false; return R; }
    if (!(Nu > 0)) { push(D, "erreur", "La charge doit être positive."); R.ok = false; return R; }
    // sol (ELS) : trapèze si e ≤ B/6, sinon surface comprimée réduite (Meyerhof)
    const es = e0 * (Gc + Qc) / Ns, eu = e0 * Nuc / Nu, part = es > B / 6;
    const smax = (part ? Ns / (B - 2 * es) : Ns / B * (1 + 6 * es / B)) / 1000, smin = part ? 0 : Ns / B * (1 - 6 * es / B) / 1000;
    R.sol = { smax, smin, part, es, ok: smax <= o.sig + 1e-12 };
    F.push(`Poids propre = ${c.rho}·B·H = ${f2(pp)} kN/m ; Ns = ${f2(Ns)} kN/m ; Nu = ${f2(Nu)} kN/m`);
    F.push(`σsol,max = ${f2(smax, 3)} MPa (admissible ${f2(o.sig, 3)} MPa)`);
    if (!R.sol.ok) push(D, "erreur", `Contrainte au sol ${f2(smax, 3)} MPa > admissible ${f2(o.sig, 3)} MPa : largeur minimale B ≈ ${f2(Ns / (o.sig * 1000), 2)} m (à e = 0).`, c.ec ? "EN 1997-1" : "DTU 13.12");
    if (part) push(D, "alerte", "Excentricité hors du noyau central : décollement partiel, surface comprimée réduite.");
    // rigidité
    const c1 = (B - a) / 2, need = (B - a) / 4;
    R.rig = { ok: d >= need - 1e-9, need };
    if (!R.rig.ok) push(D, "erreur", `Semelle non rigide : d = ${f2(d * 100, 1)} cm < (B−a)/4 = ${f2(need * 100, 1)} cm. Augmentez H à ${f2((need + o.enr + .01) * 100, 0)} cm au moins, ou réduisez B.`, "BAEL A.8.2,1");
    else push(D, "info", `Condition de rigidité vérifiée : d = ${f2(d * 100, 1)} cm ≥ (B−a)/4 = ${f2(need * 100, 1)} cm.`, "BAEL A.8.2,1");
    // pression ELU sur le sol
    const bielles = eu <= B / 24, pu = Nu / B, sgmax = eu > B / 6 ? Nu / (B - 2 * eu) : pu * (1 + 6 * eu / B), sgmin = eu > B / 6 ? 0 : pu * (1 - 6 * eu / B);
    let Mu;
    const fed = c.fe / c.gs;
    if (bielles) { R.meth = "Bielles (e ≤ B/24)"; R.Asb = Nu / 1000 * (B - a) / (8 * d * fed) * 1e4; R.As = R.Asb; F.push(`As = Nu(B−a)/(8·d·fed) = ${f2(R.As)} cm²/m`); }
    else {
      R.meth = "Moment au nu du mur (e > B/24)"; const sf = sgmax - (sgmax - sgmin) * c1 / B; // pression au nu côté max
      Mu = c1 * c1 * (2 * sgmax + sf) / 6; // kN.m/m
      const fl = flex(Mu, d, c); if (fl.err) { push(D, "erreur", fl.err); R.ok = false; return R; }
      R.As = fl.As; R.M = Mu; F.push(`Mu = c²(2σ1+σ2)/6 = ${f2(Mu)} kN.m/m → As = ${f2(R.As)} cm²/m`);
    }
    const amin = asMin(c, d); R.amin = amin; R.req = Math.max(R.As, amin);
    if (amin > R.As) push(D, "info", "Section minimale de non-fragilité retenue.", c.ec ? "EN 1992-1-1 9.2.1.1" : "BAEL A.4.2");
    R.sel = nappe(R.req, H, c, o.phis); if (!R.sel) push(D, "erreur", "Aucune nappe standard ne convient : augmentez H.");
    R.Ar = R.req * B / 4; R.selR = nappe(R.Ar / B, H, c, o.phis); // répartition ≥ As·B/4 sur la largeur (valeur par m donnée pour l'espacement)
    R.ArTot = R.Ar; F.push(`Armatures de répartition ≥ As·B/4 = ${f2(R.Ar)} cm² sur la largeur`);
    // effort tranchant à d du nu
    const x = c1 - d; // distance de la section au bord
    if (x > 0) { const sx = sgmax - (sgmax - sgmin) * x / B; R.Vu = (sgmax + sx) / 2 * x; R.cis = cisaillement(R.Vu, d, R.sel ? R.sel.s : R.req, c); R.cis.ratio = R.cis.tau / R.cis.lim; if (!R.cis.ok) push(D, "erreur", `Effort tranchant à d du nu : τ = ${f2(R.cis.tau, 3)} MPa > ${f2(R.cis.lim, 3)} MPa : augmentez H à ${f2(Math.ceil(R.Vu / 1000 / R.cis.lim / .05) * .05 + o.enr + .01, 2)} m.`, R.cis.ref); else push(D, "info", `Effort tranchant vérifié : τ = ${f2(R.cis.tau, 3)} ≤ ${f2(R.cis.lim, 3)} MPa.`, R.cis.ref); }
    else { R.cis = { applicable: false, ok: true }; push(D, "info", "Section à d du nu hors de la semelle : effort tranchant non déterminant."); }
    R.ok = !D.some(x => x.g == "erreur"); return R;
  }

  /* =====================================================================================
     2. RADIER GÉNÉRAL — V119k
     (a) modèle « plancher inversé » (réaction du sol uniforme) sur une trame lx × ly (BAEL E.3) ;
     (b) modèle « plaque sur sol élastique de Winkler » (éléments finis de Mindlin) sur tout le radier : réaction non uniforme,
         décollement éventuel, moments par bandes, tassements différentiels ;
     (c) tassement du sol (méthode œdométrique, contraintes de Boussinesq) si des couches sont renseignées.
     o : { lx, ly, h, a, b (poteau, m), G, Q (kN par poteau), sig (MPa), enr, kv (MN/m³, 0 = ignoré), fc, fe, ...
           modele (0 = plancher inversé, 1 = Winkler EF), nbx, nby (travées), ob (débord, m), fr (coefficient des poteaux de rive),
           Df (m, profondeur d'assise), gsol (kN/m³), h1, E1, h2, E2, h3, E3 (couches compressibles : épaisseur m, module œdométrique MPa) }
     ===================================================================================== */

  /* Facteur d'influence de Boussinesq sous le coin d'un rectangle l × b uniformément chargé, à la profondeur z. */
  function Icoin(l, b, z) {
    if (!(z > 1e-9)) return .25;
    const R1 = l * l + z * z, R2 = b * b + z * z, R3 = Math.sqrt(l * l + b * b + z * z);
    return (Math.atan(l * b / (z * R3)) + l * b * z / R3 * (1 / R1 + 1 / R2)) / (2 * PI);
  }
  /* Tassement œdométrique d'un rectangle Lx × Ly chargé uniformément de q (kPa) : s = Σ Δσz·dz / Eoed.
     couches : [{h (m), E (MPa)}] depuis la base du radier. Retourne les tassements au centre et au coin (rectangle souple), en m. */
  function tassement(Lx, Ly, q, couches) {
    let z = 0, sc = 0, se = 0;
    for (const cc of couches) {
      if (!(cc.h > 0 && cc.E > 0)) continue;
      const ns = 8, dz = cc.h / ns;
      for (let k = 0; k < ns; k++) { const zm = z + (k + .5) * dz; sc += q * 4 * Icoin(Lx / 2, Ly / 2, zm) * dz / (cc.E * 1000); se += q * Icoin(Lx, Ly, zm) * dz / (cc.E * 1000); }
      z += cc.h;
    }
    return { sc, se, z };
  }

  /* Plaque de Mindlin (quadrilatère bilinéaire, cisaillement en intégration réduite) sur appuis de Winkler ponctuels (ressorts nodaux).
     P : { xs[], ys[] (coordonnées des lignes de nœuds, m), h (m), E (kPa), nu, kv (kN/m³), loads[] ({i, j, N} charges nodales descendantes, kN),
           q (kPa, charge uniforme descendante), bilat (true : ressorts bilatéraux, sans décollement) }.  Renvoie flèches w (m, vers le bas), pressions de sol (kPa), moments mx, my, mxy (kN.m/m, positifs = fibre inférieure tendue),
           efforts tranchants qx, qy (kN/m) au centre des éléments. Les ressorts qui se décollent sont retirés (itérations). */
  function plateWinkler(P) {
    const xs = P.xs, ys = P.ys, nx = xs.length, ny = ys.length, nn = nx * ny, nd = 3 * nn, nex = nx - 1, ney = ny - 1;
    const fastY = ny <= nx, nid = (i, j) => (fastY ? i * ny + j : j * nx + i), fast = fastY ? ny : nx, bw = 3 * (fast + 1) + 2;
    const D0 = P.E * Math.pow(P.h, 3) / (12 * (1 - P.nu * P.nu)), Db = [[D0, D0 * P.nu, 0], [D0 * P.nu, D0, 0], [0, 0, D0 * (1 - P.nu) / 2]], Gs = P.E / (2 * (1 + P.nu)) * (5 / 6) * P.h;
    const gp = [-1 / Math.sqrt(3), 1 / Math.sqrt(3)], sx = [-1, 1, 1, -1], sy = [-1, -1, 1, 1];
    const shape = (xi, eta) => { const N = [], dX = [], dY = []; for (let k = 0; k < 4; k++) { N.push((1 + sx[k] * xi) * (1 + sy[k] * eta) / 4); dX.push(sx[k] * (1 + sy[k] * eta) / 4); dY.push(sy[k] * (1 + sx[k] * xi) / 4); } return { N, dX, dY }; };
    const Bbend = (dx, dy, xi, eta) => { const s = shape(xi, eta), B = [new Float64Array(12), new Float64Array(12), new Float64Array(12)], jx = 2 / dx, jy = 2 / dy; for (let k = 0; k < 4; k++) { const bx = s.dX[k] * jx, by = s.dY[k] * jy; B[0][3 * k + 1] = bx; B[1][3 * k + 2] = by; B[2][3 * k + 1] = by; B[2][3 * k + 2] = bx; } return B; };
    const Bshear = (dx, dy) => { const s = shape(0, 0), B = [new Float64Array(12), new Float64Array(12)], jx = 2 / dx, jy = 2 / dy; for (let k = 0; k < 4; k++) { B[0][3 * k] = s.dX[k] * jx; B[0][3 * k + 1] = s.N[k]; B[1][3 * k] = s.dY[k] * jy; B[1][3 * k + 2] = s.N[k]; } return B; };
    const ke = (dx, dy) => {
      const K = Array.from({ length: 12 }, () => new Float64Array(12)), dA = dx * dy / 4;
      for (const xi of gp) for (const eta of gp) {
        const B = Bbend(dx, dy, xi, eta);
        for (let a = 0; a < 12; a++) for (let b = 0; b < 12; b++) { let v = 0; for (let p = 0; p < 3; p++) for (let r = 0; r < 3; r++) v += B[p][a] * Db[p][r] * B[r][b]; K[a][b] += v * dA; }
      }
      const B = Bshear(dx, dy); for (let a = 0; a < 12; a++) for (let b = 0; b < 12; b++) K[a][b] += Gs * (B[0][a] * B[0][b] + B[1][a] * B[1][b]) * 4 * dA;
      return K;
    };
    const Kp = Array.from({ length: nd }, () => new Float64Array(bw + 1)), area = new Float64Array(nn), els = [];
    for (let i = 0; i < nex; i++) for (let j = 0; j < ney; j++) {
      const dx = xs[i + 1] - xs[i], dy = ys[j + 1] - ys[j], nodes = [nid(i, j), nid(i + 1, j), nid(i + 1, j + 1), nid(i, j + 1)], k = ke(dx, dy), dof = [];
      for (const n of nodes) { dof.push(3 * n, 3 * n + 1, 3 * n + 2); area[n] += dx * dy / 4; }
      for (let a = 0; a < 12; a++) for (let b = 0; b < 12; b++) { const ga = dof[a], gb = dof[b]; if (ga <= gb) Kp[ga][gb - ga] += k[a][b]; }
      els.push({ i, j, dx, dy, dof, nodes });
    }
    const f0 = new Float64Array(nd); let Ftot = 0;
    for (let n = 0; n < nn; n++) { const v = (P.q || 0) * area[n]; f0[3 * n] = v; Ftot += v; }
    for (const L of (P.loads || [])) { f0[3 * nid(L.i, L.j)] += L.N; Ftot += L.N; }
    const active = new Uint8Array(nn).fill(1); let w = null, conv = false, it = 0;
    for (it = 0; it < 30; it++) {
      const K = Kp.map(r => Float64Array.from(r)), f = Float64Array.from(f0);
      for (let n = 0; n < nn; n++) if (active[n]) K[3 * n][0] += P.kv * area[n];
      for (let k = 0; k < nd; k++) {                                  // élimination de Gauss sur matrice bande symétrique définie positive
        const piv = K[k][0], hi = Math.min(k + bw, nd - 1);
        for (let i = k + 1; i <= hi; i++) {
          const m = K[k][i - k]; if (m === 0) continue; const fac = m / piv;
          for (let j = i; j <= hi; j++) K[i][j - i] -= fac * K[k][j - k];
          f[i] -= fac * f[k];
        }
      }
      const x = new Float64Array(nd);
      for (let i = nd - 1; i >= 0; i--) { let s = f[i]; const hi = Math.min(i + bw, nd - 1); for (let j = i + 1; j <= hi; j++) s -= K[i][j - i] * x[j]; x[i] = s / K[i][0]; }
      w = x; let chg = 0;
      for (let n = 0; n < nn && !P.bilat; n++) { const wn = w[3 * n], on = wn > 0; if (on !== !!active[n] && (active[n] ? wn < -1e-12 : wn > 1e-12)) { active[n] = on ? 1 : 0; chg++; } }
      if (!chg || P.bilat) { conv = true; break; }
    }
    const wz = new Float64Array(nn), press = new Float64Array(nn); let Rtot = 0;
    for (let n = 0; n < nn; n++) { wz[n] = w[3 * n]; press[n] = active[n] || P.bilat ? P.kv * wz[n] : 0; Rtot += press[n] * area[n]; }
    const mx = [], my = [], mxy = [], qx = [], qy = [];
    for (let i = 0; i < nex; i++) { mx.push(new Float64Array(ney)); my.push(new Float64Array(ney)); mxy.push(new Float64Array(ney)); qx.push(new Float64Array(ney)); qy.push(new Float64Array(ney)); }
    for (const e of els) {
      const u = e.dof.map(g => w[g]), B = Bbend(e.dx, e.dy, 0, 0), kap = [0, 0, 0], S = Bshear(e.dx, e.dy), gam = [0, 0];
      for (let a = 0; a < 12; a++) { kap[0] += B[0][a] * u[a]; kap[1] += B[1][a] * u[a]; kap[2] += B[2][a] * u[a]; gam[0] += S[0][a] * u[a]; gam[1] += S[1][a] * u[a]; }
      mx[e.i][e.j] = Db[0][0] * kap[0] + Db[0][1] * kap[1]; my[e.i][e.j] = Db[1][0] * kap[0] + Db[1][1] * kap[1]; mxy[e.i][e.j] = Db[2][2] * kap[2];
      qx[e.i][e.j] = Gs * gam[0]; qy[e.i][e.j] = Gs * gam[1];
    }
    const uplift = Array.from(active).filter(v => !v).length / nn;
    return { w: wz, press, mx, my, mxy, qx, qy, active, area, nx, ny, nid, conv, it, Ftot, Rtot, uplift, D0 };
  }

  /* Moments de calcul par bandes (bande sur poteaux = largeur ws centrée sur les files de poteaux, bande centrale = reste).
     comp = "mx" (moment de flexion autour de y, bandes parallèles à x) ou "my" ; half = demi-largeur du poteau dans le sens de la section.
     Sur les files de poteaux, le moment est extrapolé au nu du poteau (les moments varient vite près d'une charge ponctuelle et la valeur
     au centre des mailles voisines sous-estimerait le moment d'appui). Renvoie les enveloppes des moyennes par bande (kN.m/m). */
  function bandes(res, xs, ys, xc, yc, ws, comp, half) {
    const sec = comp == "mx", A = sec ? xs : ys, Bq = sec ? ys : xs, Ac = sec ? xc : yc, Bc = sec ? yc : xc, M = sec ? res.mx : res.my;
    const nA = A.length, nB = Bq.length - 1, nE = nA - 1, out = { colMax: -Infinity, colMin: Infinity, midMax: -Infinity, midMin: Infinity };
    const colLine = new Set(); Ac.forEach(v => { const k = A.findIndex(a => Math.abs(a - v) < 1e-9); if (k >= 0) colLine.add(k); });
    const cls = [];                                                                                    // classe de chaque élément le long de B
    for (let j = 0; j < nB; j++) {
      const yc_ = (Bq[j] + Bq[j + 1]) / 2; let kk = 0, dmin = Infinity; Bc.forEach((v, k) => { const d = Math.abs(yc_ - v); if (d < dmin) { dmin = d; kk = k; } });
      cls.push(dmin <= ws / 2 + 1e-9 ? "c" + kk : "m" + Math.floor((yc_ - Bc[0]) / (Bc.length > 1 ? Bc[1] - Bc[0] : 1e9)));
    }
    for (let s = 0; s < nA; s++) {                                                                     // section sur la ligne de nœuds s
      const acc = {};
      for (let j = 0; j < nB; j++) {
        const get = k => (sec ? M[k][j] : M[j][k]);
        let v;
        if (colLine.has(s) && half > 0) {
          const side = dir => {
            const e1 = dir < 0 ? s - 1 : s, e2 = dir < 0 ? s - 2 : s + 1; if (e1 < 0 || e1 > nE - 1) return null;
            const c1 = (A[e1] + A[e1 + 1]) / 2, v1 = get(e1); if (e2 < 0 || e2 > nE - 1) return v1;
            const c2 = (A[e2] + A[e2 + 1]) / 2, t = (Math.abs(c1 - A[s]) - half) / Math.abs(c2 - c1); return v1 + (v1 - get(e2)) * t;
          }, a = side(-1), b = side(1); v = a == null ? b : b == null ? a : (a + b) / 2;
        } else v = s == 0 ? get(0) : s == nE ? get(nE - 1) : (get(s - 1) + get(s)) / 2;
        const dB = Bq[j + 1] - Bq[j], a = acc[cls[j]] = acc[cls[j]] || { sm: 0, sw: 0 }; a.sm += v * dB; a.sw += dB;
      }
      for (const k in acc) { const mv = acc[k].sm / acc[k].sw; if (k[0] == "c") { out.colMax = Math.max(out.colMax, mv); out.colMin = Math.min(out.colMin, mv); } else { out.midMax = Math.max(out.midMax, mv); out.midMin = Math.min(out.midMin, mv); } }
    }
    return out;
  }

  /* Maillage 1D : débord ob, n travées de longueur l subdivisées en m mailles ; col = indices des files de poteaux. */
  function axe(n, l, ob, m) {
    const xs = [], col = [], nov = ob > 1e-9 ? Math.max(1, Math.round(ob / (l / m))) : 0;
    for (let k = 0; k < nov; k++) xs.push(-ob + ob * k / nov);
    for (let i = 0; i < n; i++) { col.push(xs.length); for (let s = 0; s < m; s++) xs.push(i * l + l * s / m); }
    col.push(xs.length); xs.push(n * l);
    for (let k = 1; k <= nov; k++) xs.push(n * l + ob * k / nov);
    return { xs, col };
  }

  function radier(o) {
    const c = base(o), D = [], F = [], lx = Math.min(o.lx, o.ly), ly = Math.max(o.lx, o.ly), al = lx / ly, h = o.h, d = h - o.enr - .005;
    const aire = lx * ly, pp = c.rho * h, Nu = c.gG * o.G + c.gQ * o.Q, Ns = o.G + o.Q;
    const pu = Nu / aire, ps = Ns / aire, psol = (ps + pp) / 1000;  // kPa net ; MPa total sur le sol
    const R = { lx, ly, al, h, d, pu, ps, psol, pp, Nu, Ns, D, F };
    if (!(lx > 0 && h > 0 && d > .05)) { push(D, "erreur", "Dimensions invalides."); R.ok = false; return R; }
    const winkler = o.modele == 1, nbx = Math.max(1, Math.round(o.nbx || 3)), nby = Math.max(1, Math.round(o.nby || 3)), ob = o.ob != null ? o.ob : .5, fr = o.fr > 0 ? o.fr : 1;
    const Lx = nbx * lx + 2 * ob, Ly = nby * ly + 2 * ob, At = Lx * Ly;
    // charges des poteaux (poteaux de rive : fr par côté libre, d'angle : fr²)
    const cols = []; for (let i = 0; i <= nbx; i++) for (let j = 0; j <= nby; j++) cols.push({ i, j, f: Math.pow(fr, (i == 0 || i == nbx ? 1 : 0) + (j == 0 || j == nby ? 1 : 0)) });
    const sumF = cols.reduce((s, k) => s + k.f, 0);
    if (winkler && !(o.kv > 0)) { push(D, "erreur", "Le modèle de Winkler exige un module de réaction kv > 0."); R.ok = false; return R; }
    // sol
    let pmaxEF = null;
    if (!winkler) {
      R.sol = { ok: psol <= o.sig + 1e-12 }; F.push(`σsol = (G+Q)/(lx·ly) + poids propre = ${f2(psol, 3)} MPa (admissible ${f2(o.sig, 3)} MPa)`);
      if (!R.sol.ok) push(D, "erreur", `Contrainte au sol ${f2(psol, 3)} MPa > admissible ${f2(o.sig, 3)} MPa : élargissez l'emprise du radier (débords) ou réduisez les charges.`, c.ec ? "EN 1997-1" : "DTU 13.12");
    }
    const zonesDef = {};
    if (!winkler) {
      // moments (BAEL Annexe E.3, ν = 0), panneau intermédiaire continu : Mt = 0,75 M0 ; Ma = 0,5 M0
      const mx = 1 / (8 * (1 + 2.4 * al ** 3)), my = al * al * (1 - .95 * (1 - al) ** 2), M0x = mx * pu * lx * lx, M0y = Math.max(my * M0x, M0x / 4);
      R.M0x = M0x; R.M0y = M0y; F.push(`pu net = ${f2(pu)} kN/m² ; M0x = μx·pu·lx² = ${f2(M0x)} kN.m/m ; M0y = ${f2(M0y)} kN.m/m (α = ${f2(al)})`);
      push(D, "alerte", "Plancher inversé (BAEL E.3) : valable pour un radier nervuré ou à poutres entre poteaux ; pour un radier plat sans nervures, utilisez le modèle de plaque sur sol élastique (Winkler), qui donne des moments plus élevés.", "BAEL E.3");
      Object.assign(zonesDef, { xt: [.75 * M0x, .75 * M0x / (Nu / Ns)], xa: [.5 * M0x, .5 * M0x / (Nu / Ns)], yt: [.75 * M0y, .75 * M0y / (Nu / Ns)], ya: [.5 * M0y, .5 * M0y / (Nu / Ns)] });
    } else {
      // ---------- modèle EF : plaque de Mindlin sur ressorts de Winkler, ELU puis ELS ----------
      let m = 6, ax, ay; for (; m >= 2; m--) { ax = axe(nbx, lx, ob, m); ay = axe(nby, ly, ob, m); if (ax.xs.length * ay.xs.length <= 1100) break; }
      ax = axe(nbx, lx, ob, m); ay = axe(nby, ly, ob, m); const E = Ecm(c.fc) * 1000, kvk = o.kv * 1000;
      const run = (fG, fQ) => plateWinkler({ xs: ax.xs, ys: ay.xs, h, E, nu: .2, kv: kvk, loads: cols.map(k => ({ i: ax.col[k.i], j: ay.col[k.j], N: (fG * o.G + fQ * o.Q) * k.f })), q: fG * pp });
      const ru = run(c.gG, c.gQ), rs = run(1, 1); R.ef = { ru, rs, ax, ay, m, nel: (ax.xs.length - 1) * (ay.xs.length - 1) };
      const ws = Math.min(lx, ly) / 2, bxu = bandes(ru, ax.xs, ay.xs, ax.col.map(i => ax.xs[i]), ay.col.map(j => ay.xs[j]), ws, "mx", o.a / 2), byu = bandes(ru, ax.xs, ay.xs, ax.col.map(i => ax.xs[i]), ay.col.map(j => ay.xs[j]), ws, "my", o.b / 2);
      const bxs = bandes(rs, ax.xs, ay.xs, ax.col.map(i => ax.xs[i]), ay.col.map(j => ay.xs[j]), ws, "mx", o.a / 2), bys = bandes(rs, ax.xs, ay.xs, ax.col.map(i => ax.xs[i]), ay.col.map(j => ay.xs[j]), ws, "my", o.b / 2);
      const env = (b, sgn) => (sgn > 0 ? Math.max(b.colMax, b.midMax, 0) : Math.max(-b.colMin, -b.midMin, 0));
      R.bandes = { x: bxu, y: byu };
      Object.assign(zonesDef, { xt: [env(bxu, 1), env(bxs, 1)], xa: [env(bxu, -1), env(bxs, -1)], yt: [env(byu, 1), env(bys, 1)], ya: [env(byu, -1), env(bys, -1)] });
      // Correction d'équilibre du moment sous poteau (fibre inférieure tendue) : la charge ponctuelle n'est pas résolue par le maillage
      // (singularité), donc on retient aussi la borne statique d'une travée intérieure : M_appui = M_mi-portée(moyenne sur la travée) + pn·l²/8 − pn·(l/2)(a/2).
      const pnU = (c.gG * o.G + c.gQ * o.Q) / (lx * ly), mid = (xsA, colA, nb, ysB, colB, nbB, arr, dirX) => {
        const ib = Math.floor((nb - 1) / 2), jb = Math.floor((nbB - 1) / 2), xm = (xsA[colA[ib]] + xsA[colA[ib + 1]]) / 2; let ie = 0; for (let i = 0; i < xsA.length - 1; i++) if (xm >= xsA[i] - 1e-9 && xm <= xsA[i + 1] + 1e-9) { ie = i; break; }
        let s = 0, W = 0; for (let j = ysB.indexOf(ysB[colB[jb]]); j < colB[jb + 1]; j++) { const dy = ysB[j + 1] - ysB[j]; s += arr[ie][j] * dy; W += dy; } return s / W; };
      const corr = (k, Mm, l, dimcol) => { const Mst = Mm + pnU * l * l / 8 - pnU * (l / 2) * (dimcol / 2); if (Mst > zonesDef[k][0]) { const f = Mst / (zonesDef[k][0] || Mst / (Nu / Ns)); zonesDef[k][1] *= f; zonesDef[k][0] = Mst; R.corrAppui = (R.corrAppui || []).concat(k); } };
      if (nbx >= 2) corr("xt", mid(ax.xs, ax.col, nbx, ay.xs, ay.col, nby, ru.mx, true), lx, o.a);
      if (nby >= 2) corr("yt", (() => { const ib = Math.floor((nby - 1) / 2), jb = Math.floor((nbx - 1) / 2), ym = (ay.xs[ay.col[ib]] + ay.xs[ay.col[ib + 1]]) / 2; let je = 0; for (let j = 0; j < ay.xs.length - 1; j++) if (ym >= ay.xs[j] - 1e-9 && ym <= ay.xs[j + 1] + 1e-9) { je = j; break; } let s = 0, W = 0; for (let i = ax.col[jb]; i < ax.col[jb + 1]; i++) { const dx = ax.xs[i + 1] - ax.xs[i]; s += ru.my[i][je] * dx; W += dx; } return s / W; })(), ly, o.b);
      if (R.corrAppui) F.push(`Moment sous poteau relevé à la borne d'équilibre d'une travée intérieure (zones ${R.corrAppui.join(", ")}) : le maillage ne résout pas la charge ponctuelle du poteau.`);
      F.push(`Plaque de Mindlin sur sol de Winkler (kv = ${f2(o.kv)} MN/m³) : ${R.ef.nel} éléments de ${f2(lx / m, 2)} × ${f2(ly / m, 2)} m, E = ${f2(E / 1000, 0)} MPa, ν = 0,2 ; ${ru.it} itération(s) de contact (ELU), ${rs.it} (ELS)`);
      F.push(`Moments de bande (ELU, kN.m/m) — sens x : travée ${f2(zonesDef.xt[0])}, appui ${f2(zonesDef.xa[0])} ; sens y : travée ${f2(zonesDef.yt[0])}, appui ${f2(zonesDef.ya[0])} (bande sur poteaux = ${f2(ws)} m)`);
      if (!ru.conv || !rs.conv) push(D, "alerte", "Itérations de décollement non stabilisées : résultats à vérifier (essayez un autre maillage ou kv).");
      // sol (ELS)
      let pmax = 0, pmin = Infinity; for (let n = 0; n < rs.press.length; n++) { pmax = Math.max(pmax, rs.press[n]); if (rs.active[n]) pmin = Math.min(pmin, rs.press[n]); }
      pmaxEF = pmax / 1000; R.sol = { ok: pmaxEF <= o.sig + 1e-12, smax: pmaxEF, smin: pmin / 1000, uplift: rs.uplift, ok2: true }; R.psol = pmaxEF;
      R.pu = cols.reduce((s, k) => s + (c.gG * o.G + c.gQ * o.Q) * k.f, 0) / At; R.ps = cols.reduce((s, k) => s + (o.G + o.Q) * k.f, 0) / At;
      F.push(`Réaction du sol (ELS, nœuds) : max ${f2(pmaxEF, 3)} MPa, min ${f2(pmin / 1000, 3)} MPa ; décollement : ${f2(rs.uplift * 100, 1)} % des nœuds ; résultante ${f2(rs.Rtot)} kN pour ${f2(rs.Ftot)} kN appliqués`);
      if (!R.sol.ok) push(D, "erreur", `Pression maximale du sol ${f2(pmaxEF, 3)} MPa > admissible ${f2(o.sig, 3)} MPa (modèle de Winkler : pics en rive, à relativiser en cas de bords souples ou de débord). Élargissez le radier.`, c.ec ? "EN 1997-1" : "DTU 13.12");
      else push(D, "info", `Pression de sol maximale ${f2(pmaxEF, 3)} MPa ≤ ${f2(o.sig, 3)} MPa (ELS, réaction non uniforme).`);
      if (rs.uplift > .02) push(D, "alerte", `Décollement du sol sur ${f2(rs.uplift * 100, 1)} % des nœuds (charges excentrées ou radier souple).`);
      R.tass = { wmax: Math.max(...rs.w), wmin: Math.min(...rs.w) }; R.tass.diff = R.tass.wmax - R.tass.wmin;
      R.tass.rot = R.tass.diff / (Math.min(Lx, Ly) / 2);
      F.push(`Tassement (modèle de Winkler : w = p/kv) : max ${f2(R.tass.wmax * 1000, 1)} mm, min ${f2(R.tass.wmin * 1000, 1)} mm → différentiel ${f2(R.tass.diff * 1000, 1)} mm (rotation ${f2(R.tass.rot * 1000, 2)} ‰)`);
      if (R.tass.rot > 1 / 500) push(D, "alerte", `Rotation relative estimée ${f2(R.tass.rot * 500, 2)}/500 ≥ 1/500 : tassement différentiel à examiner (limite usuelle 1/500, EN 1997-1 annexe H).`, "EN 1997-1 H");
      R.pun_col = { Ncol: (c.gG * o.G + c.gQ * o.Q), pcol: ru.press[ru.nid(ax.col[Math.min(1, nbx)], ay.col[Math.min(1, nby)])] };
    }
    const zones = {}, ft = ftj(c.ec, c.fc), r0 = .0008;
    const aminX = c.ec ? Math.max(.26 * ft / c.fe, .0013) * d * 1e4 : r0 * (3 - al) / 2 * h * 1e4, aminY = c.ec ? aminX : r0 * h * 1e4;
    R.amin = { x: aminX, y: aminY }; R.as = {}; R.sel = {}; R.M = {};
    for (const k of Object.keys(zonesDef)) {
      const [Mu_, Ms_] = zonesDef[k], fl = flex(Mu_, d, c); if (fl.err) { push(D, "erreur", `Zone ${k} : ${fl.err} Augmentez h.`); R.ok = false; return R; }
      const es = asEls(d, Math.max(fl.As, 1e-6), Ms_, c, 1); R.M[k] = Mu_;
      R.as[k] = Math.max(fl.As, es.As, k[0] == "x" ? aminX : aminY); R.sel[k] = nappe(R.as[k], h, c, o.phis);
      if (!R.sel[k]) push(D, "erreur", `Zone ${k} : aucune nappe standard ne convient, augmentez h.`);
    }
    // tranchant
    if (!winkler) {
      R.Vu = pu * lx / (2 + al); // BAEL Annexe E.3 : effort tranchant d'appui du petit côté, Vu = pu·lx/(2+α)
    } else {
      const ru = R.ef.ru, ax = R.ef.ax, ay = R.ef.ay, a = o.a, b = o.b; let V = 0;
      for (let i = 0; i < ru.qx.length; i++) for (let j = 0; j < ru.qx[i].length; j++) {
        const xc_ = (ax.xs[i] + ax.xs[i + 1]) / 2, yc_ = (ay.xs[j] + ay.xs[j + 1]) / 2; let near = false;
        for (const k of cols) if (Math.abs(xc_ - ax.xs[ax.col[k.i]]) <= a / 2 + d + 1e-9 && Math.abs(yc_ - ay.xs[ay.col[k.j]]) <= b / 2 + d + 1e-9) { near = true; break; }
        if (!near) V = Math.max(V, Math.abs(ru.qx[i][j]), Math.abs(ru.qy[i][j]));
      }
      R.Vu = V; F.push(`Effort tranchant max hors zone de poinçonnement (d autour du poteau) : Vu = ${f2(V)} kN/m`);
    }
    R.cis = cisaillement(R.Vu, d, R.sel.xt ? R.sel.xt.s : R.as.xt, c); R.cis.ratio = R.cis.tau / R.cis.lim;
    if (!R.cis.ok) push(D, "erreur", `Effort tranchant : τ = ${f2(R.cis.tau, 3)} MPa > ${f2(R.cis.lim, 3)} MPa : augmentez h à ${f2(Math.ceil((R.Vu / 1000 / R.cis.lim) / .05) * .05 + o.enr + .005, 2)} m au moins.`, R.cis.ref);
    // poinçonnement sous poteau (poteau intérieur ; rive et angle : majoration β non traitée)
    const a = o.a, b = o.b, Nuc = Nu, relief = winkler ? Math.max(R.pun_col.pcol - c.gG * pp, 0) : pu;
    if (c.ec) {
      const V = root.EXBV || (typeof require !== "undefined" ? require("./exb-verif-els.js") : null), rl = Math.min(.02, Math.sqrt(Math.max(R.as.xt, 1e-6) * Math.max(R.as.yt, 1e-6)) / 1e4 / d);
      if (V) { const p = V.punchEC2({ a, b, d, h, Ned: Nuc / 1000, A: lx, B: ly, fc: c.fc, gb: c.gb, rl, eA: 0, eB: 0 }); R.pun = { code: "EC2", ok: p.ok, ratio: p.ratio, ref: "EN 1992-1-1 6.4" }; }
    } else {
      const uc = 2 * (a + b + 2 * h), lim = .045 * uc * h * c.fc / c.gb, Qu = (Nuc - relief * (a + h) * (b + h)) / 1000;
      R.pun = { code: "BAEL", ok: Qu <= lim, v: Qu, lim, ratio: Qu / lim, ref: "BAEL A.5.2,42" }; F.push(`Poinçonnement : Qu = ${f2(Qu, 3)} MN ≤ 0,045·uc·h·fc/γb = ${f2(lim, 3)} MN`);
    }
    if (R.pun) { if (!R.pun.ok) push(D, "erreur", `Poinçonnement sous poteau non vérifié (rapport ${f2(R.pun.ratio)}) : augmentez h ou ajoutez un chapiteau (bêche, nervure).`, R.pun.ref); else push(D, "info", `Poinçonnement vérifié (rapport ${f2(R.pun.ratio)}).`, R.pun.ref); }
    if (winkler && (nbx > 1 || nby > 1 || fr < 1)) push(D, "alerte", "Poinçonnement vérifié sous un poteau intérieur ; poteaux de rive et d'angle (majoration β de l'excentrement) à vérifier séparément.", "EN 1992-1-1 6.4.3");
    // rigidité (Winkler)
    if (o.kv > 0) {
      const E = Ecm(c.fc), I = h ** 3 / 12, le = Math.pow(4 * E * I / o.kv, .25), lmax = ly; R.le = le;
      if (!winkler) {
        if (lmax > PI / 2 * le) push(D, "alerte", `Radier trop souple pour la méthode du plancher inversé : portée ${f2(lmax)} m > π/2·le = ${f2(PI / 2 * le)} m. Passez au modèle de plaque sur sol élastique (Winkler) ou augmentez h.`, "Cours de fondations (Winkler)");
        else push(D, "info", `Radier rigide : portée ${f2(lmax)} m ≤ π/2·le = ${f2(PI / 2 * le)} m (le = ${f2(le)} m).`);
      } else push(D, "info", `Longueur élastique le = ${f2(le)} m (portée ${f2(lmax)} m) : le modèle de Winkler tient compte de la souplesse du radier.`);
    } else push(D, "info", "Rigidité relative non vérifiée (module de réaction kv non renseigné).");
    // tassement œdométrique du sol (couches renseignées)
    const couches = [[o.h1, o.E1], [o.h2, o.E2], [o.h3, o.E3]].filter(x => x[0] > 0 && x[1] > 0).map(x => ({ h: x[0], E: x[1] }));
    if (couches.length) {
      const sN = cols.reduce((s, k) => s + (o.G + o.Q) * k.f, 0), qm = sN / At + pp, Df = o.Df || 0, gs_ = o.gsol || 18, qn = qm - gs_ * Df;
      R.tassSol = { qm, qn, Lx, Ly };
      if (qn > 0) {
        const t = tassement(Lx, Ly, qn, couches); Object.assign(R.tassSol, t); R.tassSol.diff = t.sc - t.se; R.tassSol.rot = R.tassSol.diff / (Math.min(Lx, Ly) / 2); R.tassSol.kveq = qn / ((t.sc + t.se) / 2) / 1000;
        F.push(`Tassement œdométrique (Boussinesq, ${f2(Lx)} × ${f2(Ly)} m, q net = ${f2(qn)} kPa sur ${f2(t.z)} m de sol compressible) : centre ${f2(t.sc * 1000, 1)} mm, coin ${f2(t.se * 1000, 1)} mm → différentiel ${f2(R.tassSol.diff * 1000, 1)} mm ; kv équivalent ≈ ${f2(R.tassSol.kveq, 1)} MN/m³`);
        if (R.tassSol.rot > 1 / 500) push(D, "alerte", `Tassement différentiel du sol : rotation relative ${f2(R.tassSol.rot * 500, 2)}/500 ≥ 1/500 (limite usuelle, EN 1997-1 annexe H).`, "EN 1997-1 H");
        else push(D, "info", `Tassement du sol (œdométrique) : ${f2(t.sc * 1000, 1)} mm au centre, ${f2(t.se * 1000, 1)} mm au coin ; rotation relative ${f2(R.tassSol.rot * 500, 2)}/500 ≤ 1.`, "EN 1997-1 H");
        if (o.kv > 0 && (R.tassSol.kveq > 1.5 * o.kv || R.tassSol.kveq < o.kv / 1.5)) push(D, "alerte", `kv saisi (${f2(o.kv, 1)}) et kv équivalent au tassement œdométrique (${f2(R.tassSol.kveq, 1)} MN/m³) diffèrent de plus de 50 % : recaler le module de réaction.`);
      } else push(D, "info", "Pression nette sur le sol nulle (décharge de l'excavation ≥ charge du radier) : tassement négligeable.");
    }
    push(D, "info", winkler ? "Poids propre du radier inclus dans le modèle (réaction du sol et flexion par bandes). Tassement d'après kv et, si renseignées, les couches œdométriques." : "Poids propre du radier équilibré par la réaction du sol : seuls les efforts des poteaux sont repris par la flexion. Réaction du sol supposée uniforme (modèle de Winkler disponible).");
    R.ok = !D.some(x => x.g == "erreur"); return R;
  }

  /* =====================================================================================
     3. MUR DE SOUTÈNEMENT EN T RENVERSÉ (console) — V119k
     Poussée de Coulomb / Rankine (remblai horizontal ou incliné, plan virtuel au talon), nappe d'eau avec sous-pression,
     butée devant le patin (coefficient de mobilisation), séisme pseudo-statique de Mononobe-Okabe (EN 1998-5, annexe E).
     o : { H, t, hs, B, b1, gam (kN/m³), phi (°), q (kPa), mu, sig (MPa), enr, fc, fe, ...
           beta (° pente du remblai), delta (° frottement terre-mur, défaut = beta),
           hw (m, niveau d'eau au-dessus de la base de la semelle, 0 = sans eau), gsat (kN/m³), gw (kN/m³),
           fb (coefficient de mobilisation de la butée, 0 = négligée), hb (m, hauteur de terre devant le voile),
           ag (m/s², accélération de calcul, 0 = sans séisme), S, r (EN 1998-5 7.3.2.2), kvr (rapport kv/kh), kz (hauteur d'application
           de l'incrément dynamique / hauteur du mur), psi2 (surcharge en combinaison sismique), fsSis, sigSis }
     ===================================================================================== */

  /* Coefficient de poussée active de Mononobe-Okabe, mur vertical (ψ = 90°) ; angles en radians.
     θ = 0 → poussée de Coulomb ; avec δ = β c'est la poussée de Rankine d'un remblai incliné. */
  function Kae(phi, beta, delta, theta) {
    const s = Math.sin(phi + delta) * Math.sin(phi - beta - theta), r = s > 0 ? Math.sqrt(s / (Math.cos(theta + delta) * Math.cos(beta))) : 0;
    return Math.pow(Math.cos(phi - theta), 2) / (Math.cos(theta) * Math.cos(theta + delta) * Math.pow(1 + r, 2));
  }
  /* Poussée sur une hauteur Hh (m, depuis la crête) : K coefficient, g poids sec, gp poids déjaugé, zw profondeur de la nappe sous
     la crête (≥ Hh : pas d'eau). Forces en kN/m ; moments Mx par rapport à la base du plan (bras = Mx/Fx). */
  function poussee(K, Hh, zw, g, gp, gw, q) {
    let Pg = 0, Mg = 0;
    const seg = (z1, z2, s1, s2) => { const L = z2 - z1; if (!(L > 0)) return; const Fz = (s1 + s2) / 2 * L, zc = s1 + s2 > 0 ? z1 + L * (s1 + 2 * s2) / (3 * (s1 + s2)) : z1 + L / 2; Pg += Fz; Mg += Fz * (Hh - zc); };
    const za = Math.min(Math.max(zw, 0), Hh);
    seg(0, za, 0, K * g * za);
    if (zw < Hh) seg(za, Hh, K * g * za, K * (g * za + gp * (Hh - za)));
    const hwv = zw < Hh ? Hh - Math.max(zw, 0) : 0, Pw = .5 * gw * hwv * hwv;
    return { Pg, Mg, Pq: K * q * Hh, Mq: K * q * Hh * Hh / 2, Pw, Mw: Pw * hwv / 3 };
  }

  function murSoutenement(o) {
    const c = base(o), D = [], F = [], H = o.H, t = o.t, hs = o.hs, B = o.B, b1 = o.b1, bh = B - b1 - t, Ht = H + hs, g = o.gam, q = o.q || 0, gc = c.rho;
    const R = { D, F, bh, Ht };
    if (!(H > 0 && t > 0 && hs > 0 && B > 0 && b1 >= 0 && bh > 0)) { push(D, "erreur", "Dimensions invalides : le talon doit avoir une longueur positive (B > patin + épaisseur du voile)."); R.ok = false; return R; }
    const ph = o.phi * PI / 180, be = (o.beta || 0) * PI / 180, de = o.delta != null ? o.delta * PI / 180 : be, gw = o.gw || 10, hw = Math.max(o.hw || 0, 0), gsat = o.gsat || g + 2, gp = gsat - gw;
    if (!(ph > 0 && ph < PI / 2)) { push(D, "erreur", "Angle de frottement φ invalide."); R.ok = false; return R; }
    if (!(be >= 0 && be < ph)) { push(D, "erreur", `Pente du remblai β = ${f2(be * 180 / PI, 1)}° ≥ φ = ${f2(o.phi, 1)}° : talus instable, la poussée n'est pas définie.`); R.ok = false; return R; }
    if (hw > Ht + 1e-9) { push(D, "erreur", `Niveau d'eau hw = ${f2(hw)} m au-dessus de la crête du remblai (${f2(Ht)} m).`); R.ok = false; return R; }
    if (hw > 0 && !(gp > 0)) { push(D, "erreur", "Poids volumique saturé inférieur à celui de l'eau."); R.ok = false; return R; }
    const tb = Math.tan(be), cd = Math.cos(de), sd = Math.sin(de), Hv = Ht + bh * tb;             // plan virtuel vertical au bout du talon
    const Ka = Kae(ph, be, de, 0), Kah = Ka * cd; R.Ka = Ka; R.Kah = Kah; R.Hv = Hv;
    const tp = poussee(Ka, Hv, hw > 0 ? Hv - hw : Infinity, g, gp, gw, q), Pg = tp.Pg, Pq = tp.Pq, Pw = tp.Pw;
    const Phg = Pg * cd, Phq = Pq * cd, Pvg = Pg * sd, Pvq = Pq * sd, Mhg = tp.Mg * cd, Mhq = tp.Mq * cd;
    R.Pg = Pg; R.Pq = Pq; R.Pw = Pw; R.Hh = Phg + Phq + Pw; R.Mo = Mhg + Mhq + tp.Mw;
    // poids (par mètre) et positions : x depuis le bout du patin, y depuis la sous-face de la semelle
    const hwh = Math.min(Math.max(hw - hs, 0), H), W1 = t * H * gc, x1 = b1 + t / 2, y1 = hs + H / 2, W2 = B * hs * gc, x2 = B / 2, y2 = hs / 2;
    const Wr = bh * (g * (H - hwh) + gsat * hwh), Wtr = .5 * g * bh * bh * tb, W3 = Wr + Wtr, xr = B - bh / 2, xtr = B - bh / 3;
    const x3 = (Wr * xr + Wtr * xtr) / W3, y3 = (Wr * (hs + H / 2) + Wtr * (hs + H + bh * tb / 3)) / W3, Q3 = q * bh, xq = B - bh / 2;
    const U0 = hw > 0 ? .5 * gw * hw * B : 0, xU = 2 * B / 3;                                          // sous-pression linéaire talon → patin (aval sec)
    const Vp = W1 + W2 + W3; Object.assign(R, { W1, W2, W3, Q3, Vp, U: U0 });
    R.Ms = W1 * x1 + W2 * x2 + W3 * x3;
    // butée devant le patin (coefficient de mobilisation fb ; utilisée au glissement seulement, jamais pour les moments)
    const fb = o.fb || 0, hb = o.hb || 0, Kp = Math.pow(Math.tan(PI / 4 + ph / 2), 2), Pp = fb > 0 ? fb * .5 * Kp * g * (hb + hs) ** 2 : 0; R.Pp = Pp; R.Kp = Kp;
    F.push(`Ka = ${f2(Ka, 4)}${be > 0 ? ` (remblai incliné β = ${f2(o.beta, 1)}°, δ = ${f2(de * 180 / PI, 1)}°, plan virtuel Hv = ${f2(Hv)} m)` : " = tan²(45° − φ/2)"} ; Pa,terres = ${f2(Pg)} kN/m ; Pa,surcharge = ${f2(Pq)} kN/m`);
    if (hw > 0) F.push(`Nappe à hw = ${f2(hw)} m au-dessus de la base : Pw = γw·hw'²/2 = ${f2(Pw)} kN/m ; sous-pression U = γw·hw·B/2 = ${f2(U0)} kN/m (talon → patin, aval sec) ; terres déjaugées γ' = ${f2(gp)} kN/m³ sous la nappe`);
    if (Pp > 0) F.push(`Butée : Kp = tan²(45° + φ/2) = ${f2(Kp, 3)} ; Pp = fb·Kp·γ·(hb + hs)²/2 = ${f2(Pp)} kN/m (fb = ${f2(fb)} ; hb = ${f2(hb)} m) — retenue au glissement uniquement`);
    F.push(`Poids : voile ${f2(W1)} ; semelle ${f2(W2)} ; terres sur talon ${f2(W3)} kN/m — M stabilisant = ${f2(R.Ms)} kN.m/m ; M renversant = ${f2(R.Mo)} kN.m/m`);

    // ---- équilibre pour un cas de charge : facteurs fG (permanent), fQ (surcharge), fW (eau), sc = scénario sismique ou null
    const kzz = o.kz != null && o.kz > 0 ? o.kz : .5, mk = (fG, fQ, fW, sc, inclQ3) => {
      const vf = sc ? 1 + sc.s * sc.kv : 1, Vl = [[fG * W1 * vf, x1], [fG * W2 * vf, x2], [fG * W3 * vf, x3], [fG * Pvg + fQ * Pvq, B]],
        Hl = [[fG * Phg, Phg > 0 ? Mhg / Phg : 0], [fQ * Phq, Phq > 0 ? Mhq / Phq : 0], [fW * Pw, Pw > 0 ? tp.Mw / Pw : 0]];
      if (inclQ3) Vl.push([fQ * Q3, xq]);
      if (sc) { Vl.push([sc.dPv, B]); Hl.push([sc.dPh, kzz * Hv], [sc.kh * W1, y1], [sc.kh * W2, y2], [sc.kh * W3, y3]); }
      const U = fW * U0, sum = (L, k) => L.reduce((s, a) => s + (k ? a[0] * a[1] : a[0]), 0);
      return { V: sum(Vl) - U, Mst: sum(Vl, 1), Mov: sum(Hl, 1) + U * xU, Hs: sum(Hl), U };
    };
    // répartition (effective) des pressions sous la base : x depuis le patin
    const pr = (V, Mnet) => {
      const xR = Mnet / V, e = B / 2 - xR; if (!(V > 0 && xR > 0)) return null;
      if (e <= B / 6 + 1e-12) { const s0 = V / B * (1 + 6 * e / B), s1 = V / B * (1 - 6 * e / B); return { xR, e, f: x => s0 + (s1 - s0) * x / B, smax: s0, smin: s1, part: false }; }
      const L = 3 * xR, sm = 2 * V / L; return { xR, e, f: x => (x >= L ? 0 : sm * (1 - x / L)), smax: sm, smin: 0, part: true, L };
    };
    // ---- stabilité (charges permanentes seules comme éléments stabilisants ; talon chargé exclu)
    const m0 = mk(1, 1, 1, null, false); R.FSr = m0.Mst / m0.Mov; R.FSg = (o.mu * m0.V + Pp) / m0.Hs;
    if (R.FSr < 1.5) push(D, "erreur", `Renversement : FS = ${f2(R.FSr)} < 1,5. Élargissez le talon (B) ou ajoutez du poids.`, "Méthode classique"); else push(D, "info", `Renversement vérifié : FS = ${f2(R.FSr)} ≥ 1,5.`);
    if (R.FSg < 1.5) push(D, "erreur", `Glissement : FS = ${f2(R.FSg)} < 1,5. Ajoutez une bêche sous la semelle, élargissez B ou augmentez le frottement (μ).`, "Méthode classique"); else push(D, "info", `Glissement vérifié : FS = ${f2(R.FSg)} ≥ 1,5 (${Pp > 0 ? "butée prise en compte à " + f2(fb * 100, 0) + " %" : "butée négligée"}).`);
    if (hw > 0) push(D, "alerte", `Nappe derrière le mur : poussée hydrostatique ${f2(Pw)} kN/m et sous-pression ${f2(U0)} kN/m prises en compte (aval supposé sec, pas de rideau d'étanchéité). Le drainage reste préférable : il supprime ces actions.`, "Méthode classique");
    // ---- contraintes au sol, ELS (toutes charges)
    const mS = mk(1, 1, 1, null, true), pS = pr(mS.V, mS.Mst - mS.Mov); R.V = mS.V;
    if (!pS) { push(D, "erreur", "Résultante hors de la base : le mur bascule."); R.ok = false; return R; }
    R.xR = pS.xR; R.e = pS.e; if (pS.part) push(D, "alerte", "Résultante hors du tiers central : décollement partiel du talon.", "Méthode classique");
    R.smax = pS.smax / 1000; R.smin = pS.smin / 1000; R.solOk = R.smax <= o.sig + 1e-12;
    if (!R.solOk) push(D, "erreur", `Contrainte au sol ${f2(R.smax, 3)} MPa > admissible ${f2(o.sig, 3)} MPa : élargissez la semelle.`, "DTU 13.12"); else push(D, "info", `Contrainte au sol ${f2(R.smax, 3)} MPa ≤ ${f2(o.sig, 3)} MPa ; excentricité e = ${f2(pS.e)} m.`);
    // ---- ELU : pressions sous la semelle, intégrales de contrôle
    const N = 400, int = (fn, A, Bb) => { let s = 0; const dx = (Bb - A) / N; for (let i = 0; i < N; i++) { const x = A + (i + .5) * dx; s += fn(x) * dx; } return s; };
    const foot = (fG, fQ, fW, sc) => {
      const m = mk(fG, fQ, fW, sc, true), p = pr(m.V, m.Mst - m.Mov); if (!p) return null;
      const vf = sc ? 1 + sc.s * sc.kv : 1, ptot = x => p.f(x) + (hw > 0 ? fW * gw * hw * x / B : 0), wToe = fG * vf * gc * hs,
        Pvu = fG * Pvg + fQ * Pvq + (sc ? sc.dPv : 0), q0 = fG * vf * (g * (H - hwh) + gsat * hwh + gc * hs) + fQ * q, qd = y => q0 + fG * vf * g * tb * y;
      return { m, p, ptot, Mt: int(x => (ptot(x) - wToe) * (b1 - x), 0, b1), Vt: int(x => ptot(x) - wToe, 0, b1),
        Mh: int(y => (qd(y) - ptot(B - bh + y)) * y, 0, bh) + Pvu * bh, Vh: int(y => qd(y) - ptot(B - bh + y), 0, bh) + Pvu };
    };
    const fu = foot(c.gG, c.gQ, c.gG, null); if (!fu) { push(D, "erreur", "Résultante ELU hors de la base."); R.ok = false; return R; }
    const Vu = fu.m.V + fu.m.U, sig = fu.p.f; R.Vu_tot = Vu; R.xRu = fu.p.xR; R.sigU = sig;
    R.eqV = int(sig, 0, B); R.eqM = int(x => sig(x) * x, 0, B);
    // ---- voile : encastré dans la semelle (poussée sur H, nappe éventuelle, incrément sismique)
    const dSt = t - o.enr - .01, zwS = hw > 0 ? Ht - hw : Infinity, ts = poussee(Kah, H, zwS, g, gp, gw, q);
    const Mu_v = c.gG * (ts.Mg + ts.Mw) + c.gQ * ts.Mq, Ms_v = ts.Mg + ts.Mw + ts.Mq, Vu_v = c.gG * (ts.Pg + ts.Pw) + c.gQ * ts.Pq;
    const flV = flex(Mu_v, dSt, c); if (flV.err) { push(D, "erreur", "Voile : " + flV.err + ` Augmentez l'épaisseur t (actuellement ${f2(t * 100, 0)} cm).`); R.ok = false; return R; }
    const eV = asEls(dSt, Math.max(flV.As, 1e-6), Ms_v, c, 1), amV = asMin(c, dSt);
    R.stem = { Mu: Mu_v, Ms: Ms_v, Vu: Vu_v, d: dSt, asFlex: flV.As, asEls: eV.As, amin: amV, req: Math.max(flV.As, eV.As, amV), sBc: eV.sBc, sS: eV.sS, lc: eV.lc, ls: eV.ls };
    R.stem.reqStat = R.stem.req; R.stem.VuStat = Vu_v;
    F.push(`Voile (ELU) : Mu = ${f2(Mu_v)} kN.m/m ; Vu = ${f2(Vu_v)} kN/m → As = ${f2(R.stem.req)} cm²/m (face enterrée)`);
    // patin / talon : consoles sous la répartition réelle
    const dS = hs - o.enr - .01, tf = {};
    for (const [nom, M, Vv, L, face] of [["patin", fu.Mt, fu.Vt, b1, "face inférieure"], ["talon", fu.Mh, fu.Vh, bh, "face supérieure"]]) {
      const Ma = Math.abs(M), fl = flex(Ma, dS, c); if (fl.err) { push(D, "erreur", `Semelle (${nom}) : ${fl.err}`); R.ok = false; return R; }
      const Ms_ = Ma / (Vu / R.V), es = asEls(dS, Math.max(fl.As, 1e-6), Ms_, c, 1), am = asMin(c, dS);
      tf[nom] = { M, Vv, L, face, flAs: fl.As, esAs: es.As, am };
    }
    // ---- séisme pseudo-statique (Mononobe-Okabe) : kv = ± kvr·kh, deux sens du séisme vertical
    const kh = (o.ag > 0) ? o.ag * (o.S > 0 ? o.S : 1) / (9.81 * (o.r > 0 ? o.r : 1)) : 0;
    if (kh > 0) {
      const kv = (o.kvr != null && o.kvr >= 0 ? o.kvr : .5) * kh, psi2 = o.psi2 != null ? o.psi2 : .3, fsS = o.fsSis || 1.1, sigS = o.sigSis || 1.33 * o.sig, cases = [];
      R.sis = { kh, kv, kz: kzz, psi2, fsS, sigS, cases };
      for (const s of [1, -1]) {
        const th = Math.atan(kh / (1 + s * kv));
        if (!(th < ph - 1e-6)) { push(D, "erreur", `Séisme trop fort pour φ = ${f2(o.phi, 1)}° : θ = atan(kh/(1${s > 0 ? "+" : "−"}kv)) = ${f2(th * 180 / PI, 1)}° ≥ φ, la poussée active n'est pas définie.`, "EN 1998-5 E"); R.ok = false; return R; }
        const Ks = Kae(ph, be, de, th), dP = Math.max(.5 * g * Hv * Hv * ((1 + s * kv) * Ks - Ka), 0);
        cases.push({ s, th, Ks, dP, kh, kv, dPh: dP * cd, dPv: dP * sd });
      }
      let FSr = Infinity, FSg = Infinity, smax = 0, emax = 0, Msis = 0, Vsis = 0, Mts = 0, Mhs = 0, Vts = 0, Vhs = 0, Mst_ok = true;
      for (const sc of cases) {
        const a = mk(1, psi2, 1, sc, false), b = foot(1, psi2, 1, sc);
        sc.FSr = a.Mst / a.Mov; sc.FSg = (o.mu * a.V + Pp) / a.Hs; FSr = Math.min(FSr, sc.FSr); FSg = Math.min(FSg, sc.FSg);
        if (!b) { sc.hors = true; Mst_ok = false; continue; }
        sc.smax = b.p.smax / 1000; sc.e = b.p.e; smax = Math.max(smax, sc.smax); emax = Math.max(emax, b.p.e);
        Mts = Math.max(Mts, Math.abs(b.Mt)); Mhs = Math.max(Mhs, Math.abs(b.Mh)); Vts = Math.max(Vts, Math.abs(b.Vt)); Vhs = Math.max(Vhs, Math.abs(b.Vh));
        // voile : poussée statique + incrément dynamique (hauteur kz·H) + inertie du voile
        const dPs = Math.max(.5 * g * H * H * ((1 + sc.s * kv) * sc.Ks - Ka), 0) * cd;
        Msis = Math.max(Msis, ts.Mg + ts.Mw + psi2 * ts.Mq + dPs * kzz * H + kh * W1 * H / 2); Vsis = Math.max(Vsis, ts.Pg + ts.Pw + psi2 * ts.Pq + dPs + kh * W1);
      }
      Object.assign(R.sis, { FSr, FSg, smax, e: emax, stem: { M: Msis, V: Vsis } });
      push(D, "info", `Séisme (EN 1998-5, annexe E) : kh = ag·S/(g·r) = ${f2(kh, 3)} ; kv = ±${f2(kv, 3)} ; Kae = ${f2(cases[0].Ks, 3)} / ${f2(cases[1].Ks, 3)} pour (1+kv) / (1−kv) ; incrément dynamique ΔPae = ${f2(Math.max(cases[0].dP, cases[1].dP))} kN/m à ${f2(kzz * Hv)} m de la base.`, "EN 1998-5 7.3.2 / E");
      if (!Mst_ok) { push(D, "erreur", "Séisme : la résultante sort de la base (renversement)."); }
      if (FSr < fsS) push(D, "erreur", `Séisme : renversement FS = ${f2(FSr)} < ${f2(fsS)}. Élargissez le talon.`, "EN 1998-5 7.3.2.3"); else push(D, "info", `Séisme : renversement FS = ${f2(FSr)} ≥ ${f2(fsS)}.`);
      if (FSg < fsS) push(D, "erreur", `Séisme : glissement FS = ${f2(FSg)} < ${f2(fsS)}. Ajoutez une bêche ou élargissez la semelle.`, "EN 1998-5 7.3.2.3"); else push(D, "info", `Séisme : glissement FS = ${f2(FSg)} ≥ ${f2(fsS)}.`);
      if (smax > sigS + 1e-12) push(D, "erreur", `Séisme : contrainte au sol ${f2(smax, 3)} MPa > ${f2(sigS, 3)} MPa (σadm majorée pour l'accidentel).`); else push(D, "info", `Séisme : contrainte au sol ${f2(smax, 3)} MPa ≤ ${f2(sigS, 3)} MPa.`);
      if (emax > B / 3 + 1e-9) push(D, "erreur", `Séisme : excentricité ${f2(emax)} m > B/3 = ${f2(B / 3)} m.`);
      if (hw > 0) push(D, "alerte", "Séisme avec nappe : poussée hydrodynamique de l'eau non ajoutée (EN 1998-5 E.7) ; incrément dynamique des terres calculé avec le poids total sec. À compléter par l'ingénieur.", "EN 1998-5 E.7");
      push(D, "info", `Valeurs de contrôle sismique usuelles (FS ≥ ${f2(fsS)} ; σ ≤ ${f2(sigS, 3)} MPa) : à ajuster à l'annexe nationale et au rapport géotechnique. Vérification d'ensemble : la stabilité d'ensemble du talus et la liquéfaction ne sont pas traitées.`);
      // armatures sismiques : mêmes sections, combinaison accidentelle (γ = 1) avec coefficients matériaux normaux (sécurité)
      const flS = flex(Msis, dSt, c); R.sis.stem.As = flS.err ? Infinity : flS.As;
      if (R.sis.stem.As > R.stem.req) { R.stem.req = R.sis.stem.As; push(D, "info", `Voile : la combinaison sismique gouverne (As = ${f2(R.sis.stem.As)} cm²/m).`); }
      R.stem.Vu = Math.max(R.stem.Vu, Vsis);
      for (const [nom, M, V] of [["patin", Mts, Vts], ["talon", Mhs, Vhs]]) { const fl = flex(M, dS, c); tf[nom].sisAs = fl.err ? Infinity : fl.As; tf[nom].sisM = M; tf[nom].sisV = V; }
    }
    R.stem.sel = nappe(R.stem.req, t, c, o.phis); R.stem.cis = cisaillement(R.stem.Vu, dSt, R.stem.sel ? R.stem.sel.s : R.stem.req, c);
    if (!R.stem.sel) push(D, "erreur", "Voile : aucune nappe standard ne convient, augmentez l'épaisseur.");
    if (!R.stem.cis.ok) push(D, "erreur", `Voile : τ = ${f2(R.stem.cis.tau, 3)} MPa > ${f2(R.stem.cis.lim, 3)} MPa (sans armatures d'effort tranchant) : augmentez l'épaisseur t.`, R.stem.cis.ref);
    if (eV.ko) push(D, "erreur", "Voile : contraintes de service non respectées, augmentez l'épaisseur t.");
    R.stem.cis.ratio = R.stem.cis.tau / R.stem.cis.lim;
    for (const nom of ["patin", "talon"]) {
      const T = tf[nom], req = Math.max(T.flAs, T.esAs, T.am, T.sisAs || 0), Vmax = Math.max(Math.abs(T.Vv), T.sisV || 0), sel = nappe(req, hs, c, o.phis), cis = cisaillement(Vmax, dS, sel ? sel.s : req, c);
      cis.ratio = cis.tau / cis.lim; R[nom] = { M: T.M, Vu: T.Vv, d: dS, req, sel, cis, face: T.M >= 0 ? T.face : (T.face == "face inférieure" ? "face supérieure" : "face inférieure"), L: T.L, sis: T.sisAs != null ? { As: T.sisAs, M: T.sisM, V: T.sisV } : null };
      if (T.L > 0) { if (!sel) push(D, "erreur", `Semelle (${nom}) : aucune nappe standard ne convient, augmentez l'épaisseur hs.`); if (!cis.ok) push(D, "erreur", `Semelle (${nom}) : τ = ${f2(cis.tau, 3)} MPa > ${f2(cis.lim, 3)} MPa : augmentez l'épaisseur hs.`, cis.ref); }
      F.push(`Semelle, ${nom} (ELU) : M = ${f2(T.M)} kN.m/m ; V = ${f2(T.Vv)} kN/m → As = ${f2(req)} cm²/m (${R[nom].face})${T.sisAs != null ? ` — séisme : ${f2(T.sisAs)} cm²/m` : ""}`);
    }
    const non = ["poussée hydrodynamique de l'eau (séisme + nappe)", "charge en tête", "sol de fondation non homogène", "bêche calculée", "tassements", "stabilité d'ensemble (grand glissement)"];
    push(D, "info", `Hypothèses : mur vertical, ${be > 0 ? "remblai incliné (plan virtuel au talon)" : "remblai horizontal"}, ${hw > 0 ? "nappe derrière le mur" : "sans eau (drainage du remblai obligatoire : barbacanes, drain, filtre)"}, ${Pp > 0 ? "butée partielle au glissement" : "sans butée"}, ${kh > 0 ? "séisme pseudo-statique de Mononobe-Okabe" : "sans séisme"}.`);
    push(D, "alerte", `Non traités : ${non.join(", ")}.`);
    R.ok = !D.some(x => x.g == "erreur"); return R;
  }

  const api = { flex, els, asEls, nappe, cisaillement, semelleFilante, radier, murSoutenement, Kae, poussee, Icoin, tassement, plateWinkler, bandes };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.EXBO = api;
})(typeof window !== "undefined" ? window : globalThis);
