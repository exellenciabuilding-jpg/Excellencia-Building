/* V119h — Flèche, fissuration, poinçonnement et effort tranchant (poutre, dalle, semelle)
   Fonctions pures : aucune dépendance au DOM, utilisables dans le navigateur (window.EXBV) et sous Node.
   Unités internes : m, MN, MPa (moments en MN.m, courbures en 1/m).
   Calcul d'aide à l'étude : à faire vérifier par un ingénieur. */
(function (root) {
  "use strict";
  const ES = 200000; // MPa

  /* ---------- matériaux ---------- */
  const fctm = fc => (fc <= 50 ? 0.3 * Math.pow(fc, 2 / 3) : 2.12 * Math.log(1 + (fc + 8) / 10));
  const Ecm = fc => 22000 * Math.pow((fc + 8) / 10, 0.3); // EC2 tableau 3.1
  const ft28 = fc => 0.6 + 0.06 * fc; // BAEL

  /* ---------- section fissurée / non fissurée ----------
     p : { b, h, bf, h0, d, dp, As, Asc }  (m, m²) — d et dp mesurés depuis la fibre COMPRIMÉE.
     n : coefficient d'équivalence. Retourne les caractéristiques des états I et II. */
  function sec(p, n) {
    const b = p.b, h = p.h, tee = p.bf > b && p.h0 > 0 && p.h0 < h;
    const Bf = tee ? p.bf : b, H0 = tee ? p.h0 : 0;
    const As = Math.max(p.As, 1e-9), Asc = Math.max(p.Asc || 0, 0), d = p.d, dp = p.dp;
    // état I (non fissuré, section homogénéisée)
    const A = b * h + (Bf - b) * H0 + n * (As + Asc);
    const S = b * h * h / 2 + (Bf - b) * H0 * H0 / 2 + n * (As * d + Asc * dp);
    const yc = S / A;
    const I0 = b * Math.pow(h, 3) / 12 + b * h * Math.pow(h / 2 - yc, 2)
      + (Bf - b) * Math.pow(H0, 3) / 12 + (Bf - b) * H0 * Math.pow(H0 / 2 - yc, 2)
      + n * As * Math.pow(d - yc, 2) + n * Asc * Math.pow(dp - yc, 2);
    // état II (fissuré) : axe neutre dans la table (ou section rectangulaire), sinon dans l'âme
    const q = n * (As + Asc), c = n * (As * d + Asc * dp);
    let x = (-q + Math.sqrt(q * q + 2 * Bf * c)) / Bf; // (Bf/2)x² + q x − c = 0
    let I2;
    if (tee && x > H0) {
      const qa = b / 2, qb = (Bf - b) * H0 + q, qc = (Bf - b) * H0 * H0 / 2 + c;
      x = (-qb + Math.sqrt(qb * qb + 4 * qa * qc)) / (2 * qa);
      I2 = b * Math.pow(x, 3) / 3 + (Bf - b) * (Math.pow(x, 3) - Math.pow(x - H0, 3)) / 3
        + n * Asc * Math.pow(x - dp, 2) + n * As * Math.pow(d - x, 2);
    } else {
      I2 = Bf * Math.pow(x, 3) / 3 + n * Asc * Math.pow(x - dp, 2) + n * As * Math.pow(d - x, 2);
    }
    const S1 = As * (d - yc) + Asc * (dp - yc);   // moment statique des aciers / centre de gravité (état I)
    const S2 = As * (d - x) - Asc * (x - dp);     // idem / axe neutre (état II)
    return { A, yc, I0, x, I2, S1, S2, tee, Bf, H0 };
  }

  /* ---------- double intégration de la courbure ----------
     M : moments (MN.m, > 0 en travée) en NS+1 points équidistants ; kap(M, x) → courbure (1/m, même signe que M), x = abscisse (m).
     Appuis simples (flèche nulle aux extrémités). Retourne la flèche maximale vers le bas (m) et son abscisse. */
  function deflection(L, M, kap) {
    const NP = 200, n = M.length - 1, w = new Array(NP + 1);
    const k = new Array(NP + 1);
    for (let i = 0; i <= NP; i++) {
      const t = i / NP * n, j = Math.min(Math.floor(t), n - 1), f = t - j;
      k[i] = kap(M[j] * (1 - f) + M[j + 1] * f, i / NP * L);
    }
    const dx = L / NP, th = new Array(NP + 1); // th = ∫κ, w1 = ∫∫κ
    th[0] = 0; w[0] = 0;
    for (let i = 1; i <= NP; i++) {
      th[i] = th[i - 1] + (k[i - 1] + k[i]) * dx / 2;
      w[i] = w[i - 1] + (th[i - 1] + th[i]) * dx / 2;
    }
    const th0 = w[NP] / L;
    let mx = -Infinity, xm = 0;
    for (let i = 0; i <= NP; i++) { const v = th0 * i * dx - w[i]; if (v > mx) { mx = v; xm = i * dx; } }
    return { f: mx, x: xm };
  }

  /* ---------- flèche BAEL B.6.5 (méthode Ifi / Ifv, section de mi-travée) ----------
     o : { L, Mg, Mq, jr, sP:{b,h,bf,h0,d,dp,As,Asc}, fc }
     Mg, Mq : diagrammes de moments de service (MN.m) de G et de Q seuls, charges sur toutes les travées. */
  function flecheBAEL(o) {
    const fc = o.fc, ft = ft28(fc), Ei = 11000 * Math.cbrt(fc), Ev = 3700 * Math.cbrt(fc), n = 15, p = o.sP;
    const s = sec(p, n);
    const bw = p.b, bfl = s.tee ? p.bf : p.b, rho = Math.max(p.As, 1e-9) / (bw * p.d);
    const li = 0.05 * ft / (rho * (2 + 3 * bw / bfl)), lv = 0.4 * li;
    const comb = (a, b) => o.Mg.map((v, i) => a * v + b * o.Mq[i]);
    const cas = (M, E, lam, k) => {
      const Mm = Math.max(...M);
      if (!(Mm > 0)) return { f: 0, I: s.I0, mu: 0, sig: 0, M: Mm };
      const sig = n * Mm * (p.d - s.x) / s.I2;
      const mu = Math.max(0, 1 - 1.75 * ft / (4 * rho * sig + ft));
      const I = k * s.I0 / (1 + lam * mu);
      const r = deflection(o.L, M, m => m / (E * I));
      return { f: r.f, I, mu, sig, M: Mm };
    };
    const Mj = comb(o.jr, 0), Mp = comb(1, 1), Mgg = comb(1, 0);
    const gv = cas(Mgg, Ev, lv, 1), ji = cas(Mj, Ei, li, 1.1), gi = cas(Mgg, Ei, li, 1.1), pi = cas(Mp, Ei, li, 1.1);
    const delta = gv.f - ji.f + pi.f - gi.f;
    const adm = o.L <= 5 ? o.L / 500 : 0.005 + o.L / 1000;
    return { code: "BAEL", fgv: gv.f, fji: ji.f, fgi: gi.f, fpi: pi.f, delta, adm, ok: delta <= adm, ratio: delta / adm,
      I0: s.I0, rho, li, lv, mu: { gv: gv.mu, ji: ji.mu, gi: gi.mu, pi: pi.mu }, sig: { gv: gv.sig, ji: ji.sig, gi: gi.sig, pi: pi.sig },
      tot: pi.f, eqn: "Δf = fgv − fji + fpi − fgi", ref: "BAEL B.6.5,2" };
  }

  /* ---------- flèche EC2 7.4.3 (interpolation entre états I et II, fluage et retrait) ----------
     o : { L, Mg, Mq, jr, psi2, sP, sN (ou sNl / sNr : appuis gauche / droit), fc, phi, ecs } ; sP : section sous moment positif,
     sN : section sous moment négatif (d et dp mesurés depuis la fibre comprimée de chacune des deux situations). */
  function flecheEC2(o) {
    const fc = o.fc, Ec = Ecm(fc), fct = fctm(fc), phi = o.phi == null ? 2 : o.phi, ecs = o.ecs == null ? 4e-4 : o.ecs;
    const sNl = o.sNl || o.sN, sNr = o.sNr || o.sN;
    const mkKap = (Eeff, beta, shr) => {
      const n = ES / Eeff, cp = { P: sec(o.sP, n), L: sec(sNl, n), R: sec(sNr, n) };
      const hh = { P: o.sP.h, L: sNl.h, R: sNr.h };
      const mcr = { P: fct * cp.P.I0 / (hh.P - cp.P.yc), L: fct * cp.L.I0 / (hh.L - cp.L.yc), R: fct * cp.R.I0 / (hh.R - cp.R.yc) };
      return (m, x) => {
        const z = m >= 0 ? "P" : (x < o.L / 2 ? "L" : "R"), S = cp[z], am = Math.abs(m), sg = m >= 0 ? 1 : -1;
        const zeta = am > mcr[z] ? 1 - beta * Math.pow(mcr[z] / am, 2) : 0;
        const k1 = am / (Eeff * S.I0), k2 = am / (Eeff * S.I2);
        let k = zeta * k2 + (1 - zeta) * k1;
        if (shr) k += ecs * n * (zeta * S.S2 / S.I2 + (1 - zeta) * S.S1 / S.I0);
        return sg * k;
      };
    };
    const comb = (a, b) => o.Mg.map((v, i) => a * v + b * o.Mq[i]);
    const Mqp = comb(1, o.psi2), Mj = comb(o.jr, 0);
    const fl = deflection(o.L, Mqp, mkKap(Ec / (1 + phi), 0.5, true));     // long terme, quasi-permanent
    const fj = deflection(o.L, Mj, mkKap(Ec, 1, false));                   // à la construction (instantané)
    const adm1 = o.L / 250, adm2 = o.L / 500, nuis = fl.f - fj.f;
    return { code: "EC2", ftot: fl.f, fj: fj.f, nuis, adm1, adm2, ok: fl.f <= adm1 && nuis <= adm2,
      ratio: Math.max(fl.f / adm1, nuis / adm2), phi, ecs, Ec, ref: "EN 1992-1-1 7.4" };
  }

  /* ---------- ouverture des fissures EC2 7.3.4 ----------
     o : { M (MN.m, quasi-permanent), s:{b,h,bf,h0,d,dp,As,Asc} (d depuis la fibre comprimée), phi (m), c (m), e (m, entraxe barres), fc, wlim (mm) } */
  function fissEC2(o) {
    const fc = o.fc, Ec = Ecm(fc), fct = fctm(fc), n = ES / Ec, s = sec(o.s, n), p = o.s;
    const Mcr = fct * s.I0 / (p.h - s.yc), M = Math.abs(o.M);
    const base = { Mcr, M, wlim: o.wlim, ref: "EN 1992-1-1 7.3.4" };
    if (M <= Mcr) return { ...base, wk: 0, ok: true, nonFissure: true, sigS: n * M * (p.d - s.yc) / s.I0 };
    const sigS = n * M * (p.d - s.x) / s.I2;
    const hce = Math.min(2.5 * (p.h - p.d), (p.h - s.x) / 3, p.h / 2), Ace = p.b * hce, rho = Math.max(p.As, 1e-9) / Ace;
    const kt = 0.4, k1 = 0.8, k2 = 0.5, k3 = 3.4, k4 = 0.425;
    const diff = Math.max((sigS - kt * fct / rho * (1 + n * rho)) / ES, 0.6 * sigS / ES);
    const dense = o.e <= 5 * (o.c + o.phi / 2);
    const sr = dense ? k3 * o.c + k1 * k2 * k4 * o.phi / rho : 1.3 * (p.h - s.x);
    const wk = sr * diff * 1000;
    return { ...base, wk, ok: wk <= o.wlim, sigS, rho, sr: sr * 1000, dense, x: s.x, ratio: wk / o.wlim };
  }

  /* ---------- poinçonnement d'une semelle ou d'une dalle ----------
     o : { ec, a, b, d, h, Ned (MN, charge du poteau à l'ELU), A, B (dimensions de la semelle, 0 pour une dalle),
           fc, gb, rl (≤ 0,02), eA, eB (m), fe, gs } */
  const vRdc = (fc, gb, d, rl) => {
    const k = Math.min(2, 1 + Math.sqrt(0.2 / d));
    return Math.max(0.18 / gb * k * Math.pow(100 * Math.min(rl, 0.02) * fc, 1 / 3), 0.035 * Math.pow(k, 1.5) * Math.sqrt(fc));
  };
  function punchEC2(o) {
    const { a, b, d, Ned, fc, gb } = o, fnd = o.A > 0 && o.B > 0, qn = fnd ? Ned / (o.A * o.B) : 0;
    const vc = vRdc(fc, gb, d, o.rl), nu = 0.6 * (1 - fc / 250), vmax = 0.5 * nu * fc / gb;
    const beta = ak => Math.max(1.15, 1 + 1.8 * Math.sqrt(Math.pow((o.eA || 0) / (a + 2 * ak), 2) + Math.pow((o.eB || 0) / (b + 2 * ak), 2)));
    // contour au nu du poteau (écrasement des bielles)
    const u0 = 2 * (a + b), v0 = beta(0) * Ned / (u0 * d);
    // contours de 0,25d à 2d : le plus défavorable (réduction de charge pour une semelle, majoration de vRd,c si a < 2d)
    let crit = null;
    for (let k = 0.25; k <= 2.0001; k += 0.05) {
      const ak = k * d, u = 2 * (a + b) + 2 * Math.PI * ak;
      const Ac = Math.min(a * b + 2 * ak * (a + b) + Math.PI * ak * ak, fnd ? o.A * o.B : Infinity);
      const V = Math.max(Ned - qn * Ac, 0), v = beta(ak) * V / (u * d), vr = vc * Math.max(1, 2 * d / ak);
      const r = v / vr; if (!crit || r > crit.r) crit = { r, v, vr, ak, u, V };
    }
    const c2 = crit, ok1 = c2.r <= 1 + 1e-9, ok0 = v0 <= vmax + 1e-9;
    return { code: "EC2", ok: ok1 && ok0, ok1, ok0, v: c2.v, lim: c2.vr, ratio: Math.max(c2.r, v0 / vmax), aCrit: c2.ak, u1: c2.u, VEd: c2.V,
      v0, vmax, vc, beta: beta(c2.ak), unit: "MPa", ref: "EN 1992-1-1 6.4.3 / 6.4.4" };
  }
  function punchBAEL(o) {
    const { a, b, h, Ned, fc, gb } = o, fnd = o.A > 0 && o.B > 0;
    const Qu = fnd ? Math.max(Ned * (1 - (a + h) * (b + h) / (o.A * o.B)), 0) : Ned;
    const uc = 2 * (a + b + 2 * h), lim = 0.045 * uc * h * fc / gb;
    return { code: "BAEL", ok: Qu <= lim, v: Qu, lim, ratio: Qu / lim, uc, unit: "MN", ref: "BAEL A.5.2,42" };
  }
  /* épaisseur minimale (m) qui satisfait le poinçonnement : recherche par pas de 1 cm ; h = d + (h − d) conservé */
  function punchHmin(fn, o, cover) {
    for (let h = o.h; h <= o.h + 1.5; h += 0.01) {
      const q = { ...o, h, d: h - cover };
      if (fn(q).ok) return h;
    }
    return null;
  }
  /* armatures de poinçonnement (dalle) EC2 6.4.5 : Asw (cm²) par contour, sr = 0,75 d */
  function punchReinf(o, res) {
    const d = o.d, vmax = res.vc * 1.5;
    if (res.v0 > res.vmax) return { ok: false, why: "bielles du contour u0 trop sollicitées : augmenter l'épaisseur" };
    if (res.v > vmax * Math.max(1, 2 * d / res.aCrit)) return { ok: false, why: "vEd > 1,5·vRd,c : augmenter l'épaisseur" };
    const fywd = Math.min(250 + 0.25 * d * 1000, (o.fe || 500) / (o.gs || 1.15));
    const sr = 0.75 * d, Asw = Math.max(res.v - 0.75 * res.vc, 0) * res.u1 * sr / (1.5 * fywd);
    return { ok: true, Asw: Asw * 1e4, sr, fywd };
  }

  /* ---------- effort tranchant d'une semelle (section à d du nu du poteau) ----------
     o : { ec, L, W, c (dimension du poteau dans le sens L), d, Nuc, e (excentricité ELU, m), fc, gb, rl } → par sens */
  function shearFooting(o) {
    const x = (o.L - o.c) / 2 - o.d;
    const e = Math.abs(o.e || 0);
    let sig = o.Nuc / (o.L * o.W);
    if (e > 0) sig = e <= o.L / 6 ? sig * (1 + 6 * e / o.L) : 2 * o.Nuc / (3 * o.W * (o.L / 2 - e));
    if (x <= 0) return { applicable: false, x, sig, Vu: 0, tau: 0, lim: 0, ok: true };
    const Vu = sig * o.W * x, tau = Vu / (o.W * o.d);
    const lim = o.ec ? vRdc(o.fc, o.gb, o.d, o.rl) : 0.07 * o.fc / o.gb;
    return { applicable: true, x, sig, Vu, tau, lim, ok: tau <= lim, ratio: tau / lim,
      ref: o.ec ? "EN 1992-1-1 6.2.2" : "BAEL A.5.2,2" };
  }

  const api = { ES, fctm, Ecm, ft28, sec, deflection, flecheBAEL, flecheEC2, fissEC2, vRdc, punchEC2, punchBAEL, punchHmin, punchReinf, shearFooting };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else root.EXBV = api;
})(typeof window !== "undefined" ? window : globalThis);
