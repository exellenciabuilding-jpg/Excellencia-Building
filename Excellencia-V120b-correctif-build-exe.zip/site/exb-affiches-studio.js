/* Excellencia Building — Affiches : (1) logo modifiable sur les deux affiches ; (2) « Studio libre » pour créer des affiches sur n'importe quel contenu.
 * Aucune donnée existante n'est modifiée. Données : clés exb_poster_logo, exb_poster_logo_cfg, exb_studio_posters (stockage de l'appareil).
 * Pour retirer : supprimer la balise <script src="exb-affiches-studio.js"> de index.html. */
(function (w, d) {
  'use strict';
  if (w.EXB_STUDIO) return;
  var $ = function (i) { return d.getElementById(i); };
  var K_LOGO = 'exb_poster_logo', K_CFG = 'exb_poster_logo_cfg', K_LIST = 'exb_studio_posters';
  function S() { try { return typeof exbStorage !== 'undefined' ? exbStorage : w.exbStorage; } catch (e) { return null; } }
  function rd(k, def) { try { var v = S().getItem(k); return v ? JSON.parse(v) : def; } catch (e) { return def; } }
  function wr(k, v) { try { S().setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function note(t, k, ms) { try { w.notify && w.notify(t, k || 'ok', ms || 4000); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function uid() { return 'e' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function brand() {
    var I = null; try { I = w.EXBId && w.EXBId.get ? w.EXBId.get() : null; } catch (e) {}
    I = I || {};
    var has = !!I.name; return { name: I.name || (window.EXB_BRAND && EXB_BRAND.name) || 'Excellencia Building', tagline: has ? (I.tagline || '') : "L'excellence au cœur de vos constructions", phone: has ? (I.phone || '') : '+243 810 644 554', email: has ? (I.email || '') : 'Excellenciabuilding@gmail.com', address: has ? (I.address || '') : 'Kinshasa, RDC', logo: I.logo || (window.exbLogoSrc ? exbLogoSrc() : 'icon-192.png') };
  }
  /* image choisie → réduite (taille maximale) → data URL ; PNG conservé (transparence) pour les logos */
  function readImg(file, maxPx, keepPng, cb) {
    var r = new FileReader();
    r.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, maxPx / Math.max(im.naturalWidth, im.naturalHeight)), c = d.createElement('canvas');
        c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
        var x = c.getContext('2d');
        var png = keepPng || /png|webp|svg/i.test(file.type || '');
        if (!png) { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
        x.drawImage(im, 0, 0, c.width, c.height);
        cb(c.toDataURL(png ? 'image/png' : 'image/jpeg', 0.88));
      };
      im.onerror = function () { note('Image illisible.', 'error'); };
      im.src = r.result;
    };
    r.onerror = function () { note('Lecture du fichier impossible.', 'error'); };
    r.readAsDataURL(file);
  }
  function download(blob, name) {
    var u = URL.createObjectURL(blob), a = d.createElement('a');
    a.href = u; a.download = name; d.body.appendChild(a); a.click();
    setTimeout(function () { a.remove(); URL.revokeObjectURL(u); }, 5000);
  }
  function css(id, txt) { if ($(id)) return; var s = d.createElement('style'); s.id = id; s.textContent = txt; d.head.appendChild(s); }

  /* =====================================================================
   *  1) LOGO DES DEUX AFFICHES EXCELLENCIA
   *  Le logo d'origine fait partie de l'image de fond : on « efface » sa zone en reconstituant le ciel
   *  (dégradé calculé depuis les bords de la zone), puis on pose le logo choisi par-dessus.
   * ===================================================================== */
  var ZONES = {
    poster: { rect: [146, 20, 424, 200], box: [150, 24, 266, 152] },
    software: { rect: [16, 6, 496, 282], box: [22, 10, 466, 262] }
  };
  var cache = {};
  function cfg() { var c = rd(K_CFG, null) || {}; return { z: c.z || 1, dx: c.dx || 0, dy: c.dy || 0 }; }
  function logoSrc() { try { return S().getItem(K_LOGO) || ''; } catch (e) { return ''; } }

  function coons(im, rect, wref) {
    var sc = im.naturalWidth / wref, c = d.createElement('canvas');
    c.width = im.naturalWidth; c.height = im.naturalHeight;
    var x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0);
    var x0 = Math.max(3, Math.round(rect[0] * sc)), y0 = Math.max(3, Math.round(rect[1] * sc)), x1 = Math.min(c.width - 3, Math.round(rect[2] * sc)), y1 = Math.min(c.height - 3, Math.round(rect[3] * sc));
    var W = x1 - x0, H = y1 - y0; if (W < 4 || H < 4) return c.toDataURL('image/jpeg', 0.92);
    var g = x.getImageData(x0 - 3, y0 - 3, W + 6, H + 6), D = g.data, GW = W + 6;
    function P(px, py) { var o = ((py + 3) * GW + (px + 3)) * 4; return [D[o], D[o + 1], D[o + 2]]; } /* px,py relatifs au coin de la zone */
    function avg(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]; }
    var T = [], B = [], L = [], R = [], i, j;
    for (i = 0; i < W; i++) { T[i] = avg(P(i, -1), P(i, -2)); B[i] = avg(P(i, H), P(i, H + 1)); }
    for (j = 0; j < H; j++) { L[j] = avg(P(-1, j), P(-2, j)); R[j] = avg(P(W, j), P(W + 1, j)); }
    var c00 = avg(T[0], L[0]), c10 = avg(T[W - 1], R[0]), c01 = avg(B[0], L[H - 1]), c11 = avg(B[W - 1], R[H - 1]);
    for (j = 0; j < H; j++) {
      var v = (j + 0.5) / H;
      for (i = 0; i < W; i++) {
        var u = (i + 0.5) / W, o = ((j + 3) * GW + (i + 3)) * 4;
        for (var k = 0; k < 3; k++) {
          var val = (1 - v) * T[i][k] + v * B[i][k] + (1 - u) * L[j][k] + u * R[j][k] -
            ((1 - u) * (1 - v) * c00[k] + u * (1 - v) * c10[k] + (1 - u) * v * c01[k] + u * v * c11[k]);
          D[o + k] = Math.max(0, Math.min(255, val + (Math.random() - 0.5) * 2.2));
        }
        D[o + 3] = 255;
      }
    }
    x.putImageData(g, x0 - 3, y0 - 3);
    return c.toDataURL('image/jpeg', 0.93);
  }
  function patched(kind, src, cb) {
    var key = kind + '|' + src.length + '|' + src.slice(-48);
    if (cache[kind] && cache[kind].key === key) return cb(cache[kind].out);
    var im = new Image();
    im.onload = function () { try { var out = coons(im, ZONES[kind].rect, 1024); cache[kind] = { key: key, out: out }; cb(out); } catch (e) { cb(null); } };
    im.onerror = function () { cb(null); };
    im.src = src;
  }
  function overlay(kind, paper) {
    var id = 'exbLogoOv_' + kind, el = $(id);
    if (!el) {
      el = d.createElement('img'); el.id = id; el.alt = 'Logo';
      el.style.cssText = 'position:absolute;object-fit:contain;pointer-events:none;z-index:6;display:none';
      paper.appendChild(el);
    }
    return el;
  }
  function place(kind, el) {
    var b = ZONES[kind].box, c = cfg(), cx = b[0] + b[2] / 2 + c.dx, cy = b[1] + b[3] / 2 + c.dy, W = b[2] * c.z, H = b[3] * c.z;
    el.style.left = (cx - W / 2) + 'px'; el.style.top = (cy - H / 2) + 'px'; el.style.width = W + 'px'; el.style.height = H + 'px';
  }
  var tries = { poster: 0, software: 0 };
  function applyOne(kind) {
    var paper = $(kind === 'poster' ? 'posterPaper' : 'softwarePosterPaper'); if (!paper) return;
    var logo = logoSrc(), ov = overlay(kind, paper);
    if (!logo) { ov.style.display = 'none'; restore(kind, paper); return; }
    var src = '';
    if (kind === 'poster') { try { src = typeof getPosterBg === 'function' ? getPosterBg() : ''; } catch (e) {} }
    else { var im = $('softwarePosterImage'); src = (im && (im.getAttribute('data-orig') || im.src)) || ''; }
    if (!src || src === location.href) { if (tries[kind]++ < 25) setTimeout(function () { applyOne(kind); }, 400); return; }
    tries[kind] = 0;
    ov.src = logo; place(kind, ov); ov.style.display = 'block';
    patched(kind, src, function (out) {
      if (!out) return;
      if (kind === 'poster') paper.style.backgroundImage = 'url(' + out + ')';
      else { var im2 = $('softwarePosterImage'); if (im2) { if (!im2.getAttribute('data-orig')) im2.setAttribute('data-orig', im2.src); im2.src = out; } }
    });
  }
  function restore(kind, paper) {
    if (kind === 'poster') { try { paper.style.backgroundImage = 'url(' + getPosterBg() + ')'; } catch (e) {} }
    else { var im = $('softwarePosterImage'); if (im && im.getAttribute('data-orig')) { im.src = im.getAttribute('data-orig'); im.removeAttribute('data-orig'); } }
  }
  function applyAll() { applyOne('poster'); applyOne('software'); }
  function wrapRender() {
    ['renderPoster', 'renderSoftwarePoster'].forEach(function (n) {
      var f = w[n]; if (typeof f !== 'function' || f.__exbLogo) return;
      var g = function () { var r = f.apply(this, arguments); try { applyOne(n === 'renderPoster' ? 'poster' : 'software'); } catch (e) {} return r; };
      g.__exbLogo = 1; w[n] = g;
    });
  }

  function logoCard() {
    var sec = $('affiches'); if (!sec || $('exbLogoCard')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    var card = d.createElement('div'); card.className = 'card no-print'; card.id = 'exbLogoCard'; card.style.gridColumn = '1/-1';
    card.innerHTML =
      '<h2>🔷 Logo des affiches</h2>' +
      '<p style="font-size:12.5px;color:#5e6877;margin:-4px 0 10px">Changez le logo des deux affiches (générale et logiciels). Le fond, les photos et les textes ne changent pas : seule la zone du logo est remplacée.</p>' +
      '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">' +
      '<div id="exbLogoPrev" style="width:130px;height:84px;border:1px dashed #9aa6b8;border-radius:10px;background:#fff center/contain no-repeat;display:grid;place-items:center;font-size:11px;color:#6b7a99;text-align:center">Logo d’origine</div>' +
      '<div style="flex:1;min-width:240px"><input type="file" id="exbLogoFile" accept="image/png,image/jpeg,image/webp,image/svg+xml">' +
      '<div class="actions" style="margin-top:8px"><button class="muted" id="exbLogoCo">🏢 Logo de l’entreprise</button><button class="muted" id="exbLogoRs">↩ Logo d’origine</button></div></div></div>' +
      '<div id="exbLogoSl" style="display:none;margin-top:10px">' +
      '<label>Taille <b id="exbLz_v"></b></label><input type="range" id="exbLz" min="40" max="160" step="2" style="width:100%">' +
      '<label>Position horizontale</label><input type="range" id="exbLx" min="-160" max="160" step="2" style="width:100%">' +
      '<label>Position verticale</label><input type="range" id="exbLy" min="-120" max="120" step="2" style="width:100%"></div>' +
      '<div class="msg" id="exbLogoMsg"></div>';
    grid.insertBefore(card, grid.firstChild);
    function sync() {
      var l = logoSrc(), c = cfg(), pv = $('exbLogoPrev');
      pv.style.backgroundImage = l ? 'url(' + l + ')' : 'none'; pv.textContent = l ? '' : 'Logo d’origine';
      $('exbLogoSl').style.display = l ? 'block' : 'none';
      $('exbLz').value = Math.round(c.z * 100); $('exbLx').value = c.dx; $('exbLy').value = c.dy; $('exbLz_v').textContent = Math.round(c.z * 100) + ' %';
    }
    function setLogo(u) { try { S().setItem(K_LOGO, u); } catch (e) { note('Stockage plein : logo non enregistré.', 'error'); } cache = {}; sync(); applyAll(); }
    $('exbLogoFile').onchange = function (e) { var f = e.target.files && e.target.files[0]; if (!f) return; readImg(f, 900, true, function (u) { setLogo(u); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo appliqué aux deux affiches.</span>'; }); e.target.value = ''; };
    $('exbLogoCo').onclick = function () {
      var u = brand().logo; if (!u) return;
      var im = new Image(); im.onload = function () { var c = d.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); try { setLogo(c.toDataURL('image/png')); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo de l’entreprise appliqué.</span>'; } catch (e) { note('Logo de l’entreprise illisible.', 'error'); } };
      im.onerror = function () { note('Logo de l’entreprise introuvable.', 'error'); }; im.src = u;
    };
    $('exbLogoRs').onclick = function () { try { S().removeItem(K_LOGO); S().removeItem(K_CFG); } catch (e) {} cache = {}; sync(); applyAll(); $('exbLogoMsg').innerHTML = '<span class="valid">✓ Logo d’origine rétabli.</span>'; };
    function sl() { wr(K_CFG, { z: $('exbLz').value / 100, dx: +$('exbLx').value, dy: +$('exbLy').value }); $('exbLz_v').textContent = $('exbLz').value + ' %'; ['poster', 'software'].forEach(function (k) { var p = $(k === 'poster' ? 'posterPaper' : 'softwarePosterPaper'), o = p && $('exbLogoOv_' + k); if (o) place(k, o); }); }
    ['exbLz', 'exbLx', 'exbLy'].forEach(function (i) { $(i).oninput = sl; });
    sync();
  }

  /* =====================================================================
   *  2) STUDIO LIBRE
   * ===================================================================== */
  var FMT = {
    a4p: { l: 'A4 portrait', w: 794, h: 1123, mm: [210, 297], sc: 3 },
    a4l: { l: 'A4 paysage', w: 1123, h: 794, mm: [297, 210], sc: 3 },
    a3p: { l: 'A3 portrait', w: 1123, h: 1587, mm: [297, 420], sc: 2.2 },
    sq: { l: 'Carré (réseaux sociaux)', w: 1080, h: 1080, mm: null, sc: 2 },
    story: { l: 'Story / Statut (9:16)', w: 1080, h: 1920, mm: null, sc: 1.6 },
    ban: { l: 'Bannière (Facebook / LinkedIn)', w: 1200, h: 628, mm: null, sc: 2 }
  };
  var FONTS = [['Arial', 'Arial, Helvetica, sans-serif'], ['Arial Black', '"Arial Black", Arial, sans-serif'], ['Impact', 'Impact, Haettenschweiler, sans-serif'], ['Georgia', 'Georgia, serif'], ['Times', '"Times New Roman", Times, serif'], ['Trebuchet', '"Trebuchet MS", sans-serif'], ['Verdana', 'Verdana, sans-serif'], ['Manuscrit', 'Caveat, "Segoe Script", "Brush Script MT", cursive']];
  var PALETTES = {
    marine: ['#0f2a56', '#1e5fb4', 160, '#f2c94c'], ciel: ['#e8f3ff', '#7ab8f5', 170, '#12305e'], blanc: ['#ffffff', '#eef2f8', 180, '#12305e'],
    noir: ['#0b0f17', '#1d2635', 160, '#e0b54a'], vert: ['#0e3b2e', '#2e8b57', 160, '#ffd54a'], orange: ['#e8590c', '#f59f00', 150, '#ffffff'], rouge: ['#7a0c1c', '#c2283d', 160, '#ffffff']
  };
  var ST = { id: null, name: 'Mon affiche', fmt: 'a4p', bg: { c1: '#0f2a56', c2: '#1e5fb4', ang: 160, img: '', ovl: 0 }, els: [], frame: { on: false } };
  var sel = null, scale = 1, root = null, hist = [];

  function stageCss(el, e) {
    el.style.cssText = 'position:absolute;left:' + e.x + 'px;top:' + e.y + 'px;width:' + e.w + 'px;' + (e.t === 'text' ? '' : 'height:' + e.h + 'px;') +
      'opacity:' + (e.op == null ? 1 : e.op) + ';transform:rotate(' + (e.rot || 0) + 'deg);transform-origin:center;box-sizing:border-box;';
    if (e.t === 'text') {
      el.style.cssText += 'font-family:' + (FONTS[e.ff] ? FONTS[e.ff][1] : FONTS[0][1]) + ';font-size:' + e.fs + 'px;color:' + e.col + ';font-weight:' + (e.b ? 800 : 400) + ';font-style:' + (e.i ? 'italic' : 'normal') +
        ';text-align:' + (e.al || 'left') + ';line-height:' + (e.lh || 1.2) + ';white-space:pre-wrap;word-break:break-word;letter-spacing:' + (e.ls || 0) + 'px;' +
        (e.bg ? 'background:' + e.bg + ';padding:' + (e.pad || 10) + 'px;border-radius:' + (e.rad || 0) + 'px;' : '') + (e.up ? 'text-transform:uppercase;' : '') +
        (e.sh ? 'text-shadow:0 2px 8px rgba(0,0,0,.45);' : '');
    } else if (e.t === 'rect' || e.t === 'ellipse') {
      el.style.cssText += 'background:' + (e.fill || 'transparent') + ';border:' + (e.sw || 0) + 'px solid ' + (e.stroke || 'transparent') + ';border-radius:' + (e.t === 'ellipse' ? '50%' : (e.rad || 0) + 'px') + ';';
    } else if (e.t === 'line') {
      el.style.cssText += 'height:' + Math.max(1, e.h) + 'px;background:' + (e.fill || '#fff') + ';border-radius:' + (e.h / 2) + 'px;';
    }
  }
  function bgVal(b) {
    var s = 'linear-gradient(' + b.ang + 'deg,' + b.c1 + ',' + b.c2 + ')';
    if (b.img) return (b.ovl ? 'linear-gradient(rgba(0,0,0,' + b.ovl / 100 + '),rgba(0,0,0,' + b.ovl / 100 + ')),' : '') + 'url(' + b.img + ') center/cover no-repeat,' + s;
    return s;
  }
  /* construit la feuille ; interactive = vrai pour l'écran (sélection, poignées), faux pour l'export */
  function build(host, interactive) {
    var F = FMT[ST.fmt]; host.innerHTML = '';
    host.style.position = 'relative'; host.style.overflow = 'hidden'; host.style.width = F.w + 'px'; host.style.height = F.h + 'px'; host.style.background = bgVal(ST.bg);
    ST.els.forEach(function (e) {
      var el = d.createElement('div'); el.setAttribute('data-id', e.id); stageCss(el, e);
      if (e.t === 'text') el.textContent = e.tx;
      else if (e.t === 'img') {
        var im = d.createElement('img'); im.src = e.src; im.alt = ''; im.draggable = false;
        im.style.cssText = 'width:100%;height:100%;display:block;object-fit:' + (e.fit || 'contain') + ';border-radius:' + (e.rad || 0) + 'px;pointer-events:none';
        el.appendChild(im);
      }
      if (interactive) {
        el.style.cursor = 'move'; el.style.touchAction = 'none';
        if (e.id === sel) {
          el.style.outline = '2px dashed #1e88e5'; el.style.outlineOffset = '2px';
          var h = d.createElement('div'); h.setAttribute('data-h', '1');
          h.style.cssText = 'position:absolute;right:-12px;bottom:-12px;width:' + (26 / scale) + 'px;height:' + (26 / scale) + 'px;background:#1e88e5;border:2px solid #fff;border-radius:50%;cursor:nwse-resize;touch-action:none;transform:rotate(' + (-(e.rot || 0)) + 'deg)';
          el.appendChild(h);
        }
      }
      host.appendChild(el);
    });
    try { if (w.EXB_FRAME && ST.frame && ST.frame.on) w.EXB_FRAME.draw(host, F.w, F.h, Math.min(F.w, F.h) / 595, ST.frame); } catch (e) {}
  }
  function find(id) { for (var i = 0; i < ST.els.length; i++) if (ST.els[i].id === id) return ST.els[i]; return null; }
  function push() { hist.push(JSON.stringify(ST)); if (hist.length > 40) hist.shift(); }
  function undo() { if (!hist.length) return; var s = JSON.parse(hist.pop()); ST = s; if (!find(sel)) sel = null; refresh(); }

  function fit() {
    var wrap = $('exbsWrap'), F = FMT[ST.fmt]; if (!wrap) return;
    var avail = Math.max(240, ($('exbsBox').clientWidth || 700) - 4);
    scale = Math.min(1, avail / F.w);
    var maxH = Math.max(380, (w.innerHeight || 800) * 0.78);
    if (F.h * scale > maxH) scale = maxH / F.h;
    wrap.style.width = (F.w * scale) + 'px'; wrap.style.height = (F.h * scale) + 'px';
    $('exbsStage').style.transform = 'scale(' + scale + ')';
  }
  function refresh(keepProps) { fit(); build($('exbsStage'), true); if (!keepProps) props(); $('exbsFmtLbl').textContent = FMT[ST.fmt].l + ' — ' + FMT[ST.fmt].w + '×' + FMT[ST.fmt].h + ' px'; }

  /* ---------- glisser / redimensionner ---------- */
  function bindDrag() {
    var stage = $('exbsStage'), cur = null;
    stage.addEventListener('pointerdown', function (ev) {
      var h = ev.target.closest && ev.target.closest('[data-h]'), t = ev.target.closest && ev.target.closest('[data-id]');
      if (!t) { sel = null; refresh(); return; }
      var e = find(t.getAttribute('data-id')); if (!e) return;
      if (sel !== e.id) { sel = e.id; refresh(); }
      push();
      cur = { e: e, mode: h ? 'size' : 'move', x: ev.clientX, y: ev.clientY, ex: e.x, ey: e.y, ew: e.w, eh: e.h, moved: false };
      try { stage.setPointerCapture(ev.pointerId); } catch (x) {}
      ev.preventDefault();
    });
    stage.addEventListener('pointermove', function (ev) {
      if (!cur) return;
      var dx = (ev.clientX - cur.x) / scale, dy = (ev.clientY - cur.y) / scale; cur.moved = true;
      if (cur.mode === 'move') { cur.e.x = Math.round(cur.ex + dx); cur.e.y = Math.round(cur.ey + dy); }
      else { cur.e.w = Math.max(20, Math.round(cur.ew + dx)); if (cur.e.t !== 'text') cur.e.h = Math.max(cur.e.t === 'line' ? 2 : 20, Math.round(cur.eh + dy)); }
      var el = stage.querySelector('[data-id="' + cur.e.id + '"]');
      if (el) { el.style.left = cur.e.x + 'px'; el.style.top = cur.e.y + 'px'; el.style.width = cur.e.w + 'px'; if (cur.e.t !== 'text') el.style.height = cur.e.h + 'px'; }
    });
    function up() { if (!cur) return; var m = cur.moved; cur = null; if (!m) hist.pop(); refresh(); }
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
  }

  /* ---------- panneau de propriétés ---------- */
  function row(lbl, inner) { return '<label class="exbs-l">' + lbl + '</label>' + inner; }
  function props() {
    var P = $('exbsProps'); if (!P) return; var e = find(sel);
    if (!e) { P.innerHTML = '<p class="exbs-hint">Touchez un élément de l’affiche pour le modifier, ou ajoutez-en un avec les boutons ci-dessus.</p>'; return; }
    var h = '<b class="exbs-t">' + ({ text: 'Texte', img: 'Image', rect: 'Rectangle', ellipse: 'Cercle', line: 'Trait' }[e.t]) + ' sélectionné</b>';
    if (e.t === 'text') {
      h += '<textarea id="pp_tx" rows="3" class="exbs-in">' + esc(e.tx) + '</textarea>' +
        '<div class="exbs-2">' + row('Taille', '<input type="number" id="pp_fs" min="8" max="400" value="' + e.fs + '" class="exbs-in">') + row('Couleur', '<input type="color" id="pp_col" value="' + e.col + '" class="exbs-in">') + '</div>' +
        row('Police', '<select id="pp_ff" class="exbs-in">' + FONTS.map(function (f, i) { return '<option value="' + i + '"' + (i === (e.ff || 0) ? ' selected' : '') + '>' + f[0] + '</option>'; }).join('') + '</select>') +
        '<div class="exbs-btns"><button id="pp_b" class="' + (e.b ? 'on' : '') + '"><b>G</b></button><button id="pp_i" class="' + (e.i ? 'on' : '') + '"><i>I</i></button><button id="pp_up" class="' + (e.up ? 'on' : '') + '">AA</button><button id="pp_sh" class="' + (e.sh ? 'on' : '') + '">Ombre</button>' +
        '<button data-al="left" class="' + (e.al === 'left' || !e.al ? 'on' : '') + '">⬅</button><button data-al="center" class="' + (e.al === 'center' ? 'on' : '') + '">↔</button><button data-al="right" class="' + (e.al === 'right' ? 'on' : '') + '">➡</button></div>' +
        row('Interligne', '<input type="range" id="pp_lh" min="0.9" max="2" step="0.05" value="' + (e.lh || 1.2) + '" style="width:100%">') +
        '<div class="exbs-2">' + row('Fond du texte', '<input type="color" id="pp_bg" value="' + (e.bg || '#ffffff') + '" class="exbs-in">') + row('', '<button id="pp_nobg" class="exbs-mini">' + (e.bg ? 'Retirer le fond' : 'Aucun fond') + '</button>') + '</div>';
    } else if (e.t === 'rect' || e.t === 'ellipse' || e.t === 'line') {
      h += '<div class="exbs-2">' + row('Couleur', '<input type="color" id="pp_fill" value="' + (/^#/.test(e.fill) ? e.fill : '#1e5fb4') + '" class="exbs-in">') + (e.t === 'line' ? '' : row('Contour', '<input type="color" id="pp_stroke" value="' + (/^#/.test(e.stroke) ? e.stroke : '#ffffff') + '" class="exbs-in">')) + '</div>' +
        (e.t === 'rect' ? row('Coins arrondis', '<input type="range" id="pp_rad" min="0" max="200" value="' + (e.rad || 0) + '" style="width:100%">') : '') +
        (e.t === 'line' ? '' : row('Épaisseur du contour', '<input type="range" id="pp_sw" min="0" max="30" value="' + (e.sw || 0) + '" style="width:100%">'));
    } else if (e.t === 'img') {
      h += '<div class="exbs-btns"><button id="pp_swap">🖼 Changer l’image</button><button id="pp_fit">' + (e.fit === 'cover' ? 'Remplir (recadrer)' : 'Entière') + '</button></div>' +
        row('Coins arrondis (200 = rond)', '<input type="range" id="pp_rad" min="0" max="400" value="' + (e.rad || 0) + '" style="width:100%">');
    }
    h += row('Transparence', '<input type="range" id="pp_op" min="0.1" max="1" step="0.05" value="' + (e.op == null ? 1 : e.op) + '" style="width:100%">') +
      row('Rotation', '<input type="range" id="pp_rot" min="-180" max="180" value="' + (e.rot || 0) + '" style="width:100%">') +
      '<div class="exbs-btns"><button id="pp_front">⬆ Devant</button><button id="pp_back">⬇ Derrière</button><button id="pp_dup">⧉ Dupliquer</button><button id="pp_cx">⇔ Centrer</button><button id="pp_del" class="del">🗑 Supprimer</button></div>';
    P.innerHTML = h;
    var q = function (i) { return $(i); }, armed = false;
    function arm() { if (!armed) { push(); armed = true; } }
    function upd() {
      var el = $('exbsStage').querySelector('[data-id="' + e.id + '"]'); if (!el) return;
      stageCss(el, e); el.style.cursor = 'move'; el.style.touchAction = 'none'; el.style.outline = '2px dashed #1e88e5'; el.style.outlineOffset = '2px';
    }
    function on(id, ev, fn) { var x = q(id); if (x) x[ev] = fn; }
    function live(id, key, num) { on(id, 'onpointerdown', arm); on(id, 'onfocus', arm); on(id, 'oninput', function (ev) { arm(); e[key] = num ? +ev.target.value : ev.target.value; upd(); }); on(id, 'onchange', function () { refresh(true); }); }
    if (e.t === 'text') {
      on('pp_tx', 'onfocus', arm); on('pp_tx', 'oninput', function (ev) { arm(); e.tx = ev.target.value; refresh(true); });
      live('pp_fs', 'fs', 1); live('pp_col', 'col'); live('pp_lh', 'lh', 1);
      on('pp_ff', 'onchange', function (ev) { push(); e.ff = +ev.target.value; refresh(); });
      [['pp_b', 'b'], ['pp_i', 'i'], ['pp_up', 'up'], ['pp_sh', 'sh']].forEach(function (a) { on(a[0], 'onclick', function () { push(); e[a[1]] = !e[a[1]]; refresh(); }); });
      Array.prototype.forEach.call(P.querySelectorAll('[data-al]'), function (b) { b.onclick = function () { push(); e.al = b.getAttribute('data-al'); refresh(); }; });
      on('pp_bg', 'onpointerdown', arm); on('pp_bg', 'oninput', function (ev) { arm(); e.bg = ev.target.value; upd(); }); on('pp_bg', 'onchange', function () { refresh(true); });
      on('pp_nobg', 'onclick', function () { push(); e.bg = ''; refresh(); });
    } else if (e.t === 'img') {
      on('pp_swap', 'onclick', function () { pickImage(function (u) { push(); e.src = u; refresh(); }); });
      on('pp_fit', 'onclick', function () { push(); e.fit = e.fit === 'cover' ? 'contain' : 'cover'; refresh(); });
      on('pp_rad', 'onpointerdown', arm); on('pp_rad', 'oninput', function (ev) { arm(); e.rad = +ev.target.value; var im = $('exbsStage').querySelector('[data-id="' + e.id + '"] img'); if (im) im.style.borderRadius = e.rad + 'px'; });
    } else {
      live('pp_fill', 'fill'); live('pp_stroke', 'stroke'); live('pp_rad', 'rad', 1); live('pp_sw', 'sw', 1);
    }
    live('pp_op', 'op', 1); live('pp_rot', 'rot', 1);
    on('pp_front', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); ST.els.push(e); refresh(); });
    on('pp_back', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); ST.els.unshift(e); refresh(); });
    on('pp_dup', 'onclick', function () { push(); var c = JSON.parse(JSON.stringify(e)); c.id = uid(); c.x += 24; c.y += 24; ST.els.push(c); sel = c.id; refresh(); });
    on('pp_cx', 'onclick', function () { push(); e.x = Math.round((FMT[ST.fmt].w - e.w) / 2); refresh(); });
    on('pp_del', 'onclick', function () { push(); ST.els.splice(ST.els.indexOf(e), 1); sel = null; refresh(); });
  }

  function pickImage(cb, keepPng) {
    var i = d.createElement('input'); i.type = 'file'; i.accept = 'image/png,image/jpeg,image/webp,image/svg+xml';
    i.onchange = function () { var f = i.files && i.files[0]; if (f) readImg(f, 1800, keepPng !== false, cb); };
    i.click();
  }
  function add(e) { push(); e.id = uid(); ST.els.push(e); sel = e.id; refresh(); }
  function addText(tx, o) { var F = FMT[ST.fmt]; add(Object.assign({ t: 'text', tx: tx, x: Math.round(F.w * 0.08), y: Math.round(F.h * 0.12), w: Math.round(F.w * 0.84), h: 60, fs: Math.round(F.w / 16), col: bgIsDark() ? '#ffffff' : '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 }, o || {})); }
  function bgIsDark() { var c = ST.bg.c1.replace('#', ''); if (c.length === 3) c = c.replace(/./g, '$&$&'); var r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16); return (r * 299 + g * 587 + b * 114) / 1000 < 150 || !!ST.bg.img; }

  function framePn() {
    var box = $('exbsFr'); if (!box || !w.EXB_FRAME) { if (box) box.innerHTML = '<p class="exbs-hint">Module contour non chargé.</p>'; return; }
    w.EXB_FRAME.panel(box, function () { return ST.frame; }, function (v) { push(); ST.frame = v; }, function (live) { build($('exbsStage'), true); }, 'exbsF');
  }
  /* ---------- fond ---------- */
  function bgPanel() {
    var P = $('exbsBg'); var b = ST.bg;
    P.innerHTML = '<div class="exbs-pal">' + Object.keys(PALETTES).map(function (k) { var p = PALETTES[k]; return '<button data-pal="' + k + '" title="' + k + '" style="background:linear-gradient(' + p[2] + 'deg,' + p[0] + ',' + p[1] + ')"></button>'; }).join('') + '</div>' +
      '<div class="exbs-2">' + row('Couleur 1', '<input type="color" id="bg_c1" value="' + b.c1 + '" class="exbs-in">') + row('Couleur 2', '<input type="color" id="bg_c2" value="' + b.c2 + '" class="exbs-in">') + '</div>' +
      row('Angle du dégradé', '<input type="range" id="bg_ang" min="0" max="360" value="' + b.ang + '" style="width:100%">') +
      '<div class="exbs-btns"><button id="bg_img">🖼 Photo de fond</button><button id="bg_noimg">Retirer la photo</button></div>' +
      row('Assombrir la photo', '<input type="range" id="bg_ovl" min="0" max="85" value="' + b.ovl + '" style="width:100%">');
    Array.prototype.forEach.call(P.querySelectorAll('[data-pal]'), function (x) { x.onclick = function () { var p = PALETTES[x.getAttribute('data-pal')]; push(); b.c1 = p[0]; b.c2 = p[1]; b.ang = p[2]; ST.els.forEach(function (e) { if (e.t === 'text' && (e.col === '#ffffff' || e.col === '#12305e')) e.col = bgIsDark() ? '#ffffff' : '#12305e'; }); bgPanel(); refresh(); }; });
    var lv = function (id, k, n) { $(id).oninput = function (ev) { b[k] = n ? +ev.target.value : ev.target.value; $('exbsStage').style.background = bgVal(b); }; $(id).onchange = function () { push(); refresh(true); }; };
    lv('bg_c1', 'c1'); lv('bg_c2', 'c2'); lv('bg_ang', 'ang', 1); lv('bg_ovl', 'ovl', 1);
    $('bg_img').onclick = function () { pickImage(function (u) { push(); b.img = u; refresh(); }, false); };
    $('bg_noimg').onclick = function () { push(); b.img = ''; refresh(); };
  }

  /* ---------- modèles ---------- */
  function logoSrcForStudio() { return logoSrc() || brand().logo; }
  function head(F, dark) {
    var B = brand(), W = F.w, m = Math.round(W * 0.06);
    return [
      { t: 'img', src: logoSrcForStudio(), x: m, y: Math.round(W * 0.05), w: Math.round(W * 0.16), h: Math.round(W * 0.16), fit: 'contain', op: 1, rad: 0 },
      { t: 'text', tx: B.name.toUpperCase(), x: m + Math.round(W * 0.18), y: Math.round(W * 0.075), w: Math.round(W * 0.6), h: 40, fs: Math.round(W / 26), col: dark ? '#ffffff' : '#12305e', b: true, al: 'left', ff: 0, lh: 1.1, ls: 1 },
      { t: 'text', tx: B.tagline, x: m + Math.round(W * 0.18), y: Math.round(W * 0.075) + Math.round(W / 20), w: Math.round(W * 0.6), h: 30, fs: Math.round(W / 46), col: dark ? '#cfe3ff' : '#42526e', b: false, i: true, al: 'left', ff: 3, lh: 1.2 }
    ];
  }
  function foot(F, dark, gold) {
    var B = brand(), W = F.w, H = F.h, m = Math.round(W * 0.06);
    return [
      { t: 'rect', x: 0, y: H - Math.round(W * 0.16), w: W, h: Math.round(W * 0.16), fill: dark ? 'rgba(0,0,0,.35)' : '#12305e', sw: 0, rad: 0, fx: 1 },
      { t: 'text', tx: '📞 ' + B.phone + '    ✉ ' + B.email, x: m, y: H - Math.round(W * 0.135), w: W - 2 * m, h: 30, fs: Math.round(W / 36), col: '#ffffff', b: true, al: 'center', ff: 0, lh: 1.2, fx: 1 },
      { t: 'text', tx: '📍 ' + B.address, x: m, y: H - Math.round(W * 0.075), w: W - 2 * m, h: 30, fs: Math.round(W / 40), col: gold || '#f2c94c', b: false, al: 'center', ff: 0, lh: 1.2, fx: 1 }
    ];
  }
  var TPL = {
    vide: { l: 'Page vide', pal: 'marine', f: function () { return []; } },
    annonce: {
      l: 'Annonce / Événement', pal: 'marine', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06), G = PALETTES.marine[3];
        return head(F, true).concat([
          { t: 'rect', x: m, y: Math.round(H * 0.24), w: Math.round(W * 0.2), h: 8, fill: G, rad: 4, sw: 0 },
          { t: 'text', tx: "TITRE DE L'ANNONCE", x: m, y: Math.round(H * 0.27), w: W - 2 * m, h: 200, fs: Math.round(W / 10), col: '#ffffff', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: 'Sous-titre ou message d’accroche', x: m, y: Math.round(H * 0.5), w: W - 2 * m, h: 80, fs: Math.round(W / 22), col: '#cfe3ff', b: false, al: 'left', ff: 3, lh: 1.25 },
          { t: 'text', tx: '📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', x: m, y: Math.round(H * 0.6), w: W - 2 * m, h: 160, fs: Math.round(W / 24), col: '#ffffff', b: true, al: 'left', ff: 0, lh: 1.55 }
        ], foot(F, true));
      }
    },
    emploi: {
      l: 'Offre d’emploi / Recrutement', pal: 'blanc', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06);
        return [{ t: 'rect', x: 0, y: 0, w: W, h: Math.round(H * 0.3), fill: '#12305e', sw: 0, rad: 0 }].concat(head(F, true), [
          { t: 'text', tx: 'NOUS RECRUTONS', x: m, y: Math.round(H * 0.17), w: W - 2 * m, h: 100, fs: Math.round(W / 11), col: '#f2c94c', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: 'Poste : Ingénieur / Technicien…', x: m, y: Math.round(H * 0.35), w: W - 2 * m, h: 70, fs: Math.round(W / 17), col: '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'Profil recherché\n• Diplôme : …\n• Expérience : … ans\n• Compétences : …\n\nNous offrons\n• Contrat : …\n• Rémunération attractive', x: m, y: Math.round(H * 0.44), w: W - 2 * m, h: 360, fs: Math.round(W / 26), col: '#1c2b45', b: false, al: 'left', ff: 0, lh: 1.5 },
          { t: 'text', tx: 'Envoyez votre CV avant le … à ' + brand().email, x: m, y: Math.round(H * 0.77), w: W - 2 * m, h: 70, fs: Math.round(W / 24), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.25, bg: '#f2c94c', pad: 16, rad: 14 }
        ], foot(F, false));
      }
    },
    promo: {
      l: 'Promotion / Offre spéciale', pal: 'orange', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06);
        return head(F, true).concat([
          { t: 'text', tx: 'OFFRE SPÉCIALE', x: m, y: Math.round(H * 0.24), w: W - 2 * m, h: 90, fs: Math.round(W / 12), col: '#ffffff', b: true, al: 'center', ff: 1, lh: 1.05, sh: true },
          { t: 'ellipse', x: Math.round(W * 0.2), y: Math.round(H * 0.36), w: Math.round(W * 0.6), h: Math.round(W * 0.6), fill: '#ffffff', stroke: '#12305e', sw: 10 },
          { t: 'text', tx: '-20 %', x: Math.round(W * 0.2), y: Math.round(H * 0.36) + Math.round(W * 0.18), w: Math.round(W * 0.6), h: 200, fs: Math.round(W / 4.2), col: '#e8590c', b: true, al: 'center', ff: 1, lh: 1 },
          { t: 'text', tx: 'sur …  jusqu’au …', x: Math.round(W * 0.2), y: Math.round(H * 0.36) + Math.round(W * 0.44), w: Math.round(W * 0.6), h: 60, fs: Math.round(W / 24), col: '#12305e', b: true, al: 'center', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'Contactez-nous dès maintenant !', x: m, y: Math.round(H * 0.8), w: W - 2 * m, h: 60, fs: Math.round(W / 20), col: '#ffffff', b: true, al: 'center', ff: 0, lh: 1.2 }
        ], foot(F, true, '#ffffff'));
      }
    },
    avis: {
      l: 'Avis / Communiqué', pal: 'blanc', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.08);
        return head(F, false).concat([
          { t: 'rect', x: m, y: Math.round(H * 0.2), w: W - 2 * m, h: 6, fill: '#c9a227', rad: 3, sw: 0 },
          { t: 'text', tx: 'COMMUNIQUÉ', x: m, y: Math.round(H * 0.23), w: W - 2 * m, h: 100, fs: Math.round(W / 10), col: '#12305e', b: true, al: 'center', ff: 4, lh: 1.1, ls: 4 },
          { t: 'text', tx: 'Objet : …', x: m, y: Math.round(H * 0.34), w: W - 2 * m, h: 60, fs: Math.round(W / 20), col: '#12305e', b: true, al: 'left', ff: 0, lh: 1.2 },
          { t: 'text', tx: 'La direction de ' + brand().name + ' porte à la connaissance de sa clientèle et du public que …\n\nPour toute information complémentaire, veuillez nous contacter.', x: m, y: Math.round(H * 0.42), w: W - 2 * m, h: 380, fs: Math.round(W / 26), col: '#1c2b45', b: false, al: 'left', ff: 3, lh: 1.6 },
          { t: 'text', tx: 'Fait à Kinshasa, le …\nLa Direction', x: m, y: Math.round(H * 0.72), w: W - 2 * m, h: 90, fs: Math.round(W / 26), col: '#12305e', b: true, al: 'right', ff: 3, lh: 1.4 }
        ], foot(F, false));
      }
    },
    formation: {
      l: 'Formation / Séminaire', pal: 'noir', f: function (F) {
        var W = F.w, H = F.h, m = Math.round(W * 0.06), G = PALETTES.noir[3];
        return head(F, true).concat([
          { t: 'text', tx: 'SESSION DE FORMATION', x: m, y: Math.round(H * 0.23), w: W - 2 * m, h: 50, fs: Math.round(W / 26), col: G, b: true, al: 'left', ff: 0, lh: 1.2, ls: 3 },
          { t: 'text', tx: 'Thème de la formation', x: m, y: Math.round(H * 0.27), w: W - 2 * m, h: 180, fs: Math.round(W / 11), col: '#ffffff', b: true, al: 'left', ff: 1, lh: 1.05 },
          { t: 'text', tx: '• Objectif 1\n• Objectif 2\n• Objectif 3\n• Attestation de participation', x: m, y: Math.round(H * 0.47), w: W - 2 * m, h: 240, fs: Math.round(W / 22), col: '#e8edf5', b: false, al: 'left', ff: 0, lh: 1.6 },
          { t: 'text', tx: 'Frais : … $   |   Durée : …   |   Début : …', x: m, y: Math.round(H * 0.72), w: W - 2 * m, h: 60, fs: Math.round(W / 24), col: '#0b0f17', b: true, al: 'center', ff: 0, lh: 1.25, bg: G, pad: 16, rad: 14 }
        ], foot(F, true, G));
      }
    }
  };
  /* ---------- bibliothèque de modèles supplémentaires (V99 modèles-2) ---------- */
  PALETTES.jaune = ['#ffd54a', '#f5b800', 160, '#12305e'];
  PALETTES.gris = ['#f1f3f6', '#d9dee7', 180, '#12305e'];
  function flat(a) { return [].concat.apply([], a); }
  function K(F) {
    var W = F.w, H = F.h, m = Math.round(W * 0.07), iw = W - 2 * m, B = brand();
    return {
      W: W, H: H, m: m, iw: iw, B: B,
      T: function (s, yp, dv, col, o) { return Object.assign({ t: 'text', tx: s, x: m, y: Math.round(H * yp), w: iw, h: 60, fs: Math.round(W / dv), col: col, b: false, al: 'left', ff: 0, lh: 1.25 }, o || {}); },
      X: function (s, xp, yp, wp, dv, col, o) { return Object.assign({ t: 'text', tx: s, x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: 60, fs: Math.round(W / dv), col: col, b: false, al: 'left', ff: 0, lh: 1.25 }, o || {}); },
      R: function (xp, yp, wp, hp, fill, o) { return Object.assign({ t: 'rect', x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: Math.round(H * hp), fill: fill, sw: 0, rad: 0 }, o || {}); },
      E: function (xp, yp, wp, fill, o) { return Object.assign({ t: 'ellipse', x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: Math.round(W * wp), fill: fill, sw: 0 }, o || {}); },
      L: function (yp, col, o) { return Object.assign({ t: 'rect', x: m, y: Math.round(H * yp), w: iw, h: 5, fill: col, rad: 3, sw: 0 }, o || {}); },
      P: function (xp, yp, wp, hp, lb) {
        var fs = Math.round(W / 34);
        return [{ t: 'rect', x: Math.round(W * xp), y: Math.round(H * yp), w: Math.round(W * wp), h: Math.round(H * hp), fill: '#e3eaf4', stroke: '#9fb0c8', sw: 3, rad: 14 },
          { t: 'text', tx: '📷 ' + (lb || 'Photo ici (bouton « ＋ Photo »)'), x: Math.round(W * xp), y: Math.round(H * (yp + hp / 2)) - fs, w: Math.round(W * wp), h: 40, fs: fs, col: '#5e6f8c', b: true, al: 'center', ff: 0, lh: 1.2 }];
      },
      rows: function (arr, yp, dv, col, pcol) {
        var fs = Math.round(W / dv), rh = Math.round(fs * 2.15), y0 = Math.round(H * yp), out = [];
        arr.forEach(function (r, i) {
          var y = y0 + i * rh;
          out.push({ t: 'text', tx: r[0], x: m, y: y, w: Math.round(iw * 0.62), h: fs, fs: fs, col: col, b: false, al: 'left', ff: 0, lh: 1.2 });
          out.push({ t: 'text', tx: r[1], x: m + Math.round(iw * 0.62), y: y, w: Math.round(iw * 0.38), h: fs, fs: fs, col: pcol || col, b: true, al: 'right', ff: 0, lh: 1.2 });
          out.push({ t: 'rect', x: m, y: y + Math.round(fs * 1.5), w: iw, h: 2, fill: '#d5dce8', sw: 0, rad: 0 });
        });
        return out;
      }
    };
  }
  var TPL2 = {
    /* ===== Communiqués & avis ===== */
    comm_officiel: {
      g: 'Communiqués & avis', l: 'Communiqué officiel (presse / public)', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.T('COMMUNIQUÉ', 0.2, 22, '#c9a227', { b: true, al: 'right', ls: 4 }),
          k.T('POUR PUBLICATION IMMÉDIATE', 0.232, 42, '#5e6877', { al: 'right', i: true }),
          k.L(0.262, '#12305e'),
          k.T('TITRE DU COMMUNIQUÉ : L’ESSENTIEL EN UNE PHRASE', 0.29, 21, '#12305e', { b: true, al: 'center', ff: 3, lh: 1.15 }),
          k.T('Kinshasa, le … —', 0.42, 28, '#1c2b45', { b: true }),
          k.T('Dès la première phrase : qui, quoi, quand, où. ' + B.name + ' annonce que …\n\nDeuxième paragraphe : les détails, les chiffres, la citation d’un responsable.\n\nTroisième paragraphe : la suite et les prochaines étapes.', 0.455, 27, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('— 30 —', 0.69, 26, '#12305e', { al: 'center', b: true }),
          k.T('Contact presse\nNom Prénom, fonction\n📞 ' + B.phone + '    ✉ ' + B.email, 0.73, 31, '#12305e', { lh: 1.45 }),
          foot(F, false)]);
      }
    },
    avis_fermeture: {
      g: 'Communiqués & avis', l: 'Avis de fermeture / changement d’horaires', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.R(0, 0.2, 1, 0.075, '#c0392b'),
          k.T('AVIS IMPORTANT', 0.2235, 20, '#ffffff', { b: true, al: 'center', ls: 5, ff: 1 }),
          k.T('FERMETURE EXCEPTIONNELLE', 0.32, 17, '#c0392b', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('Nous informons notre aimable clientèle et nos partenaires que nos bureaux seront fermés du … au … inclus.\nReprise normale des activités le … à … h.\nPour toute urgence, contactez-nous au numéro ci-dessous.', 0.4, 29, '#1c2b45', { lh: 1.5 }),
          k.T('Horaires habituels\nLundi – vendredi : 8 h – 17 h\nSamedi : 8 h – 13 h', 0.6, 30, '#12305e', { b: true, lh: 1.5, bg: '#eef2f8', pad: 22, rad: 14 }),
          k.T('Merci de votre compréhension.', 0.8, 24, '#12305e', { b: true, al: 'center', i: true }),
          foot(F, false)]);
      }
    },
    avis_ao: {
      g: 'Communiqués & avis', l: 'Avis d’appel d’offres', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.L(0.2, '#12305e'),
          k.T('AVIS D’APPEL D’OFFRES', 0.225, 18, '#12305e', { b: true, al: 'center', ff: 3, lh: 1.1 }),
          k.T('N° …… / ' + B.name.toUpperCase() + ' / 20…', 0.285, 30, '#5e6877', { al: 'center', b: true }),
          k.T('Objet : …', 0.33, 24, '#12305e', { b: true, lh: 1.3 }),
          k.rows([['Maître d’ouvrage', '…'], ['Nature des travaux / fournitures', '…'], ['Lieu d’exécution', '…'], ['Délai d’exécution', '… mois'], ['Retrait du dossier', '… (adresse)'], ['Date limite de dépôt', '… à … h'], ['Ouverture des plis', '… à … h']], 0.395, 29, '#1c2b45', '#12305e'),
          k.T('Les soumissionnaires fourniront les pièces administratives et techniques exigées par le dossier d’appel d’offres. La Direction se réserve le droit de ne donner suite à tout ou partie du présent avis.', 0.72, 33, '#42526e', { i: true, lh: 1.4, ff: 3 }),
          k.T('Fait à Kinshasa, le …\nLa Direction', 0.795, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    avis_reunion: {
      g: 'Communiqués & avis', l: 'Convocation / avis de réunion', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.L(0.2, '#c9a227'),
          k.T('CONVOCATION', 0.225, 11, '#12305e', { b: true, al: 'center', ls: 4, ff: 4 }),
          k.T('Réunion : …', 0.31, 22, '#12305e', { b: true }),
          k.T('📅 Date : …\n🕘 Heure : … h\n📍 Lieu : …', 0.37, 24, '#1c2b45', { lh: 1.55, b: true }),
          k.T('Ordre du jour', 0.53, 24, '#c9a227', { b: true, ls: 2 }),
          k.T('1. Ouverture et adoption de l’ordre du jour\n2. Point sur l’avancement des chantiers\n3. Situation financière\n4. Divers', 0.575, 26, '#1c2b45', { lh: 1.6 }),
          k.T('Votre présence est vivement souhaitée. En cas d’empêchement, prière d’en informer le secrétariat.', 0.745, 29, '#42526e', { i: true, ff: 3, lh: 1.4 }),
          k.T('Fait à Kinshasa, le …\nLa Direction', 0.8, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    avis_adresse: {
      g: 'Communiqués & avis', l: 'Changement d’adresse / de contacts', pal: 'ciel', fmt: 'sq', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.T('NOUVELLE ADRESSE', 0.26, 14, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.R(0.08, 0.36, 0.84, 0.28, '#ffffff', { rad: 28, stroke: '#12305e', sw: 4 }),
          k.T('📍 Nouvelle adresse :\n…………………………', 0.385, 22, '#12305e', { b: true, al: 'center', lh: 1.5, x: Math.round(F.w * 0.1), w: Math.round(F.w * 0.8) }),
          k.T('Nous avons déménagé ! Retrouvez-nous dès le … à notre nouvelle adresse. Nos numéros et e-mails restent inchangés.', 0.69, 27, '#1c2b45', { al: 'center', lh: 1.4 }),
          k.T('📞 ' + B.phone + '    ✉ ' + B.email, 0.82, 33, '#12305e', { b: true, al: 'center' })]);
      }
    },
    avis_fraude: {
      g: 'Communiqués & avis', l: 'Mise en garde — fraude / faux agents', pal: 'rouge', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, true),
          k.T('⚠ ATTENTION', 0.21, 9, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('MISE EN GARDE', 0.31, 20, '#f2c94c', { b: true, al: 'center', ls: 6 }),
          k.T('Nous constatons que des personnes malveillantes utilisent frauduleusement le nom de ' + B.name + ' pour demander de l’argent.', 0.38, 26, '#ffffff', { al: 'center', lh: 1.45, b: true }),
          k.T('✔ Aucun paiement ne se fait en espèces à un agent non identifié.\n✔ Seuls nos comptes officiels sont valables.\n✔ Vérifiez toujours l’identité de l’agent avant tout versement.\n✔ En cas de doute, appelez-nous.', 0.55, 27, '#ffffff', { lh: 1.55 }),
          k.T('Signalez toute tentative de fraude : ' + B.phone, 0.78, 26, '#7a0c1c', { b: true, al: 'center', bg: '#ffffff', pad: 18, rad: 14 }),
          foot(F, true, '#ffffff')]);
      }
    },
    note_service: {
      g: 'Communiqués & avis', l: 'Note de service', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('NOTE DE SERVICE', 0.2, 14, '#12305e', { b: true, al: 'center', ff: 4, ls: 3 }),
          k.T('N° …… /…… /20…', 0.25, 32, '#5e6877', { al: 'center' }),
          k.R(0.07, 0.29, 0.86, 0.12, '#eef2f8', { rad: 12 }),
          k.X('De : …\nÀ : Tout le personnel\nDate : …', 0.09, 0.3, 0.8, 28, '#12305e', { b: true, lh: 1.5 }),
          k.T('Objet : …', 0.44, 24, '#12305e', { b: true }),
          k.T('Le Directeur informe l’ensemble du personnel que, à compter du …, …\n\nEn conséquence, il est demandé à chacun de :\n• …\n• …\n\nLa présente note est d’application immédiate.', 0.49, 27, '#1c2b45', { lh: 1.55 }),
          k.T('Fait à Kinshasa, le …\nLe Directeur', 0.76, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    /* ===== Livres ===== */
    livre_couv: {
      g: 'Livres', l: 'Couverture de livre', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3], W = F.w, H = F.h;
        return flat([
          k.R(0.07, 0.06, 0.86, 0.004, G, { rad: 2 }),
          k.T('COLLECTION · …', 0.08, 36, G, { b: true, al: 'center', ls: 4 }),
          k.T('TITRE DU LIVRE', 0.2, 8.5, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.05, sh: true }),
          k.R(0.38, 0.5, 0.24, 0.004, G, { rad: 2 }),
          k.T('Sous-titre : la promesse du livre en une phrase', 0.53, 24, '#cfe3ff', { al: 'center', ff: 3, i: true, lh: 1.3 }),
          k.E(0.32, 0.6, 0.36, '#1d2635', { stroke: G, sw: 4 }),
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.375), y: Math.round(H * 0.6) + Math.round(W * 0.055), w: Math.round(W * 0.25), h: Math.round(W * 0.25), fit: 'contain', op: 1, rad: 0 },
          k.T('PRÉNOM NOM', 0.88, 15, '#ffffff', { b: true, al: 'center', ls: 5 }),
          k.T('Éditions ' + k.B.name, 0.94, 40, G, { al: 'center', i: true })]);
      }
    },
    livre_dedic: {
      g: 'Livres', l: 'Lancement / séance de dédicace', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('LANCEMENT OFFICIEL', 0.205, 22, G, { b: true, al: 'center', ls: 4 }),
          k.T('TITRE DU LIVRE', 0.245, 12, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.05, sh: true }),
          k.T('de Prénom NOM', 0.305, 24, '#cfe3ff', { al: 'center', i: true, ff: 3 }),
          k.P(0.3, 0.355, 0.4, 0.29, 'Couverture du livre (＋ Photo)'),
          k.T('Séance de dédicace et rencontre avec l’auteur', 0.665, 27, '#ffffff', { b: true, al: 'center' }),
          k.T('📅 Date : …     🕘 Heure : …\n📍 Lieu : …', 0.715, 26, '#ffffff', { b: true, al: 'center', lh: 1.5 }),
          k.T('ENTRÉE LIBRE', 0.81, 24, '#12305e', { b: true, al: 'center', bg: G, pad: 14, rad: 12, ls: 3 }),
          foot(F, true, G)]);
      }
    },
    livre_vente: {
      g: 'Livres', l: 'Livre en vente (réseaux sociaux)', pal: 'noir', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.noir[3];
        return flat([
          k.T('NOUVEAUTÉ', 0.06, 16, G, { b: true, ls: 6, x: Math.round(F.w * 0.07), w: Math.round(F.w * 0.5) }),
          k.P(0.07, 0.13, 0.4, 0.62, 'Couverture'),
          k.X('TITRE DU LIVRE', 0.52, 0.14, 0.42, 14, '#ffffff', { b: true, ff: 3, lh: 1.1 }),
          k.X('Une phrase d’accroche qui donne envie de lire.', 0.52, 0.34, 0.42, 30, '#cfe3ff', { i: true, ff: 3, lh: 1.4 }),
          k.X('Prénom NOM', 0.52, 0.5, 0.42, 26, G, { b: true }),
          k.X('… $', 0.52, 0.58, 0.42, 9, '#ffffff', { b: true, ff: 1 }),
          k.R(0, 0.82, 1, 0.18, G),
          k.T('📍 Disponible : …\n📞 ' + k.B.phone, 0.845, 27, '#0b0f17', { b: true, lh: 1.5, al: 'center' })]);
      }
    },
    livre_cata: {
      g: 'Livres', l: 'Catalogue de livres / manuels', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), out = [head(F, false), k.T('NOS PUBLICATIONS', 0.2, 16, '#12305e', { b: true, al: 'center', ff: 1 }), k.L(0.25, '#c9a227')], i, y;
        for (i = 0; i < 3; i++) {
          y = 0.285 + i * 0.205;
          out.push(k.R(0.07, y, 0.18, 0.17, '#12305e', { rad: 8 }));
          out.push(k.X('📘', 0.115, y + 0.045, 0.1, 14, '#ffffff', { al: 'center' }));
          out.push(k.X('Titre du livre ' + (i + 1), 0.28, y + 0.005, 0.65, 24, '#12305e', { b: true }));
          out.push(k.X('Auteur · Format · … pages\nUne ligne de présentation du contenu.', 0.28, y + 0.05, 0.65, 33, '#42526e', { lh: 1.45 }));
          out.push(k.X('… $', 0.28, y + 0.115, 0.4, 24, '#c9a227', { b: true }));
        }
        out.push(foot(F, false));
        return flat(out);
      }
    },
    livre_extrait: {
      g: 'Livres', l: 'Citation / extrait de livre', pal: 'marine', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([
          k.X('“', 0.08, 0.04, 0.2, 5, G, { b: true, ff: 3, lh: 0.8 }),
          k.T('Une phrase forte du livre, celle qui reste en tête, s’affiche ici en grand.', 0.25, 16, '#ffffff', { ff: 3, i: true, al: 'center', lh: 1.3 }),
          k.R(0.4, 0.62, 0.2, 0.005, G, { rad: 2 }),
          k.T('Prénom NOM', 0.66, 22, G, { b: true, al: 'center' }),
          k.T('Titre du livre · Éditions ' + k.B.name, 0.72, 32, '#cfe3ff', { al: 'center', i: true }),
          k.T('📚 Disponible dès maintenant', 0.88, 30, '#ffffff', { al: 'center', b: true })]);
      }
    },
    livre_ebook: {
      g: 'Livres', l: 'Ebook / guide à télécharger', pal: 'ciel', fmt: 'story', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('GUIDE GRATUIT', 0.18, 14, '#c9a227', { b: true, al: 'center', ls: 5 }),
          k.T('TITRE DU GUIDE', 0.215, 9, '#12305e', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('Ce que vous allez apprendre en … pages', 0.33, 26, '#42526e', { al: 'center', i: true, ff: 3 }),
          k.P(0.2, 0.39, 0.6, 0.27, 'Couverture'),
          k.T('✔ Point clé n° 1\n✔ Point clé n° 2\n✔ Point clé n° 3', 0.69, 19, '#12305e', { b: true, lh: 1.6, x: Math.round(F.w * 0.14), w: Math.round(F.w * 0.74) }),
          k.T('TÉLÉCHARGER', 0.83, 16, '#ffffff', { b: true, al: 'center', bg: '#12305e', pad: 24, rad: 40, ls: 4 }),
          k.T('✉ ' + k.B.email, 0.92, 27, '#12305e', { al: 'center' })]);
      }
    },
    /* ===== Équipements & matériel ===== */
    eq_location: {
      g: 'Équipements & matériel', l: 'Location d’engins et d’équipements', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3], out = [head(F, true), k.T('LOCATION D’ENGINS', 0.205, 12, G, { b: true, ff: 1, lh: 1.05 }), k.T('et d’équipements de chantier', 0.27, 24, '#ffffff', { i: true, ff: 3 })], items = [['🚜', 'Excavatrice'], ['🏗', 'Grue / Levage'], ['🚛', 'Camion benne'], ['🧱', 'Bétonnière']], i, x, y;
        for (i = 0; i < 4; i++) {
          x = 0.07 + (i % 2) * 0.445; y = 0.34 + Math.floor(i / 2) * 0.25;
          out.push(k.R(x, y, 0.42, 0.22, '#1d2635', { rad: 16, stroke: G, sw: 3 }));
          out.push(k.X(items[i][0], x, y + 0.01, 0.42, 11, '#ffffff', { al: 'center' }));
          out.push(k.X(items[i][1], x, y + 0.095, 0.42, 26, '#ffffff', { al: 'center', b: true }));
          out.push(k.X('… $ / jour', x, y + 0.14, 0.42, 28, G, { al: 'center', b: true }));
        }
        out.push(k.T('Avec ou sans opérateur · Livraison sur chantier · Contrats flexibles', 0.855, 36, '#e8edf5', { al: 'center' }));
        out.push(foot(F, true, G));
        return flat(out);
      }
    },
    eq_vente: {
      g: 'Équipements & matériel', l: 'Vente de matériaux / liste de prix', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('MATÉRIAUX & ÉQUIPEMENTS', 0.2, 17, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.T('Liste de prix · valable jusqu’au …', 0.25, 32, '#5e6877', { al: 'center', i: true }),
          k.L(0.285, '#c9a227'),
          k.rows([['Ciment (sac de 50 kg)', '… $'], ['Fer à béton Ø 8 / Ø 10 / Ø 12', '… $'], ['Tôle bac alu-zinc', '… $ / m²'], ['Briques / parpaings', '… $ / pièce'], ['Sable / gravier', '… $ / m³'], ['Peinture (seau 20 L)', '… $'], ['Carrelage', '… $ / m²']], 0.31, 27, '#1c2b45', '#12305e'),
          k.T('Prix hors transport · Livraison possible sur chantier', 0.8, 32, '#42526e', { al: 'center', i: true }),
          foot(F, false)]);
      }
    },
    eq_fiche: {
      g: 'Équipements & matériel', l: 'Fiche d’un équipement', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('NOM DE L’ÉQUIPEMENT', 0.2, 15, '#12305e', { b: true, ff: 1, lh: 1.05 }),
          k.T('Marque · Modèle · Année', 0.255, 30, '#5e6877', { i: true }),
          k.P(0.07, 0.3, 0.86, 0.26),
          k.T('Caractéristiques', 0.575, 26, '#c9a227', { b: true, ls: 2 }),
          k.rows([['Puissance', '…'], ['Capacité', '…'], ['Poids', '…'], ['État', 'Neuf / Occasion']], 0.615, 28, '#1c2b45', '#12305e'),
          k.T('PRIX : … $', 0.8, 18, '#12305e', { b: true, al: 'center', bg: '#f2c94c', pad: 16, rad: 14 }),
          foot(F, false)]);
      }
    },
    eq_arrivage: {
      g: 'Équipements & matériel', l: 'Nouvel arrivage / stock disponible', pal: 'orange', fmt: 'sq', f: function (F) {
        var k = K(F);
        return flat([head(F, true),
          k.T('NOUVEL ARRIVAGE', 0.24, 13, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('Stock disponible dès maintenant', 0.33, 26, '#ffffff', { al: 'center', i: true, ff: 3 }),
          k.R(0.08, 0.42, 0.84, 0.28, '#ffffff', { rad: 26 }),
          k.T('• Équipement / produit 1 — … $\n• Équipement / produit 2 — … $\n• Équipement / produit 3 — … $', 0.45, 29, '#12305e', { b: true, lh: 1.7, x: Math.round(F.w * 0.12), w: Math.round(F.w * 0.78) }),
          k.T('Quantités limitées · Réservez dès aujourd’hui', 0.74, 30, '#ffffff', { al: 'center', b: true }),
          k.T('📞 ' + k.B.phone, 0.81, 28, '#12305e', { al: 'center', b: true, bg: '#ffffff', pad: 12, rad: 30, x: Math.round(F.w * 0.25), w: Math.round(F.w * 0.5) })]);
      }
    },
    eq_epi: {
      g: 'Équipements & matériel', l: 'Consignes de sécurité — port des EPI', pal: 'jaune', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([
          k.R(0, 0, 1, 0.14, '#12305e'),
          k.T('⚠ SÉCURITÉ SUR CHANTIER', 0.045, 21, '#ffd54a', { b: true, al: 'center', ff: 1 }),
          k.T('PORT DES EPI OBLIGATOIRE', 0.18, 11, '#12305e', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('⛑ Casque de protection\n🦺 Gilet haute visibilité\n🥾 Chaussures de sécurité\n🧤 Gants de travail\n🥽 Lunettes de protection', 0.31, 17, '#12305e', { b: true, lh: 1.55, x: Math.round(F.w * 0.14), w: Math.round(F.w * 0.76) }),
          k.T('ACCÈS INTERDIT AUX PERSONNES NON AUTORISÉES', 0.74, 24, '#ffffff', { b: true, al: 'center', bg: '#c0392b', pad: 18, rad: 12, lh: 1.25 }),
          k.T('La sécurité est l’affaire de tous.', 0.86, 24, '#12305e', { al: 'center', i: true, ff: 3 }),
          k.T(k.B.name + ' · ' + k.B.phone, 0.93, 34, '#12305e', { al: 'center', b: true })]);
      }
    },
    /* ===== Logiciels & formations ===== */
    lf_logiciel: {
      g: 'Logiciels & formations', l: 'Formation sur un logiciel (AutoCAD, Revit…)', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('FORMATION PROFESSIONNELLE', 0.205, 30, G, { b: true, ls: 4 }),
          k.T('AUTOCAD', 0.24, 7.5, '#ffffff', { b: true, ff: 1, lh: 1, sh: true }),
          k.T('Nom du logiciel — niveau : débutant à avancé', 0.35, 26, '#cfe3ff', { i: true, ff: 3 }),
          k.T('Au programme', 0.42, 24, G, { b: true, ls: 2 }),
          k.T('✔ Interface et commandes essentielles\n✔ Dessin et modification de plans 2D\n✔ Cotation, calques et mise en page\n✔ Projet pratique encadré\n✔ Attestation de formation', 0.465, 26, '#ffffff', { lh: 1.55 }),
          k.T('Durée : … sem.  |  Frais : … $  |  Début : …', 0.735, 32, '#0b1f44', { b: true, al: 'center', bg: G, pad: 18, rad: 14 }),
          k.T('Places limitées · Inscrivez-vous maintenant', 0.82, 28, '#ffffff', { b: true, al: 'center' }),
          foot(F, true, G)]);
      }
    },
    lf_programme: {
      g: 'Logiciels & formations', l: 'Programme de formation (modules)', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), out = [head(F, false), k.T('PROGRAMME DE LA FORMATION', 0.2, 23, '#12305e', { b: true, al: 'center', ff: 1 }), k.T('Nom de la formation · … semaines', 0.248, 30, '#5e6877', { al: 'center', i: true }), k.L(0.28, '#c9a227')], mods = ['Prise en main et bases', 'Dessin / modélisation', 'Détails, annotations et rendu', 'Projet final et évaluation'], i, y;
        for (i = 0; i < 4; i++) {
          y = 0.3 + i * 0.12;
          out.push(k.R(0.07, y, 0.14, 0.1, '#12305e', { rad: 14 }));
          out.push(k.X('S' + (i + 1), 0.07, y + 0.026, 0.14, 15, '#f2c94c', { b: true, al: 'center', ff: 1 }));
          out.push(k.X(mods[i], 0.24, y + 0.003, 0.69, 26, '#12305e', { b: true }));
          out.push(k.X('Contenu du module : …', 0.24, y + 0.05, 0.69, 33, '#42526e'));
        }
        out.push(k.T('📅 Début : …  ·  🕘 Horaires : …  ·  📍 Lieu : …', 0.79, 38, '#12305e', { b: true, al: 'center' }));
        out.push(foot(F, false));
        return flat(out);
      }
    },
    lf_pack: {
      g: 'Logiciels & formations', l: 'Pack de formation multi-logiciels', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3], out = [head(F, true), k.T('PACK BTP COMPLET', 0.2, 15, G, { b: true, ff: 1 }), k.T('3 logiciels · 1 seule formation', 0.26, 26, '#ffffff', { i: true, ff: 3 })], nm = ['AutoCAD', 'SketchUp', 'ArchiCAD'], de = ['Plans 2D', 'Modélisation 3D', 'BIM'], i, x;
        for (i = 0; i < 3; i++) {
          x = 0.07 + i * 0.295;
          out.push(k.R(x, 0.34, 0.27, 0.22, '#1d2635', { rad: 16, stroke: G, sw: 3 }));
          out.push(k.X(nm[i], x, 0.375, 0.27, 33, '#ffffff', { b: true, al: 'center' }));
          out.push(k.X(de[i], x, 0.43, 0.27, 38, G, { al: 'center', i: true }));
          out.push(k.X('… sem.', x, 0.485, 0.27, 38, '#ffffff', { al: 'center' }));
        }
        out.push(k.T('PRIX DU PACK : … $', 0.6, 19, '#0b0f17', { b: true, al: 'center', bg: G, pad: 18, rad: 14 }));
        out.push(k.T('au lieu de … $', 0.67, 32, '#e8edf5', { al: 'center', i: true }));
        out.push(k.T('✔ Support de cours  ✔ Projet pratique  ✔ Attestation', 0.72, 36, '#ffffff', { al: 'center', b: true }));
        out.push(foot(F, true, G));
        return flat(out);
      }
    },
    lf_liste: {
      g: 'Logiciels & formations', l: 'Logiciels enseignés', pal: 'ciel', fmt: 'a4p', f: function (F) {
        var k = K(F), L = ['AutoCAD', 'SketchUp', 'ArchiCAD', 'Revit', 'Lumion', 'Twinmotion', 'Civil 3D', 'ETABS', 'SAP2000', 'MS Project', 'Primavera P6', 'Excel pro'], out = [head(F, false), k.T('LOGICIELS ENSEIGNÉS', 0.2, 15, '#12305e', { b: true, al: 'center', ff: 1 }), k.T('Du dessin au calcul de structure, de la 3D à la planification', 0.25, 34, '#42526e', { al: 'center', i: true, ff: 3 })], i, x, y;
        for (i = 0; i < 12; i++) {
          x = 0.07 + (i % 3) * 0.295; y = 0.31 + Math.floor(i / 3) * 0.12;
          out.push(k.R(x, y, 0.27, 0.095, '#ffffff', { rad: 14, stroke: '#12305e', sw: 3 }));
          out.push(k.X(L[i], x, y + 0.032, 0.27, 34, '#12305e', { b: true, al: 'center' }));
        }
        out.push(k.T('+ 3ds Max · Robot · Tekla · Métré & devis', 0.8, 30, '#12305e', { al: 'center', b: true }));
        out.push(foot(F, false));
        return flat(out);
      }
    },
    lf_certif: {
      g: 'Logiciels & formations', l: 'Certification / test QCM', pal: 'vert', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.vert[3];
        return flat([head(F, true),
          k.T('TESTEZ VOS COMPÉTENCES', 0.25, 14, '#ffffff', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('QCM · Logiciel : …', 0.4, 21, G, { b: true, al: 'center' }),
          k.T('✔ … questions corrigées\n✔ Résultat immédiat\n✔ Attestation de réussite', 0.5, 25, '#ffffff', { b: true, lh: 1.6, x: Math.round(F.w * 0.2), w: Math.round(F.w * 0.7) }),
          k.T('PASSER LE TEST', 0.76, 17, '#0e3b2e', { b: true, al: 'center', bg: G, pad: 18, rad: 40, ls: 3, x: Math.round(F.w * 0.18), w: Math.round(F.w * 0.64) }),
          k.T('📞 ' + k.B.phone, 0.9, 26, '#ffffff', { al: 'center' })]);
      }
    },
    lf_webinaire: {
      g: 'Logiciels & formations', l: 'Webinaire / atelier en ligne', pal: 'marine', fmt: 'ban', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([
          { t: 'img', src: logoSrcForStudio(), x: Math.round(F.w * 0.04), y: Math.round(F.h * 0.07), w: Math.round(F.h * 0.2), h: Math.round(F.h * 0.2), fit: 'contain', op: 1, rad: 0 },
          k.X('WEBINAIRE GRATUIT', 0.04, 0.33, 0.6, 28, G, { b: true, ls: 4 }),
          k.X('Titre de l’atelier en ligne', 0.04, 0.42, 0.62, 17, '#ffffff', { b: true, ff: 1, lh: 1.05 }),
          k.X('📅 … à … h   ·   💻 En ligne (lien envoyé à l’inscription)', 0.04, 0.72, 0.62, 44, '#cfe3ff', { b: true }),
          k.R(0.72, 0.18, 0.25, 0.64, '#ffffff', { rad: 24 }),
          k.X('S’INSCRIRE', 0.72, 0.32, 0.25, 30, '#12305e', { b: true, al: 'center', ls: 2 }),
          k.X('✉ ' + k.B.email, 0.72, 0.5, 0.25, 62, '#42526e', { al: 'center' }),
          k.X('📞 ' + k.B.phone, 0.72, 0.62, 0.25, 62, '#42526e', { al: 'center', b: true })]);
      }
    },
    lf_inscr: {
      g: 'Logiciels & formations', l: 'Inscriptions ouvertes (story / statut)', pal: 'orange', fmt: 'story', f: function (F) {
        var k = K(F);
        return flat([head(F, true),
          k.T('INSCRIPTIONS', 0.2, 11, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('OUVERTES', 0.25, 11, '#12305e', { b: true, al: 'center', ff: 1, sh: true }),
          k.R(0.08, 0.34, 0.84, 0.3, '#ffffff', { rad: 28 }),
          k.T('Formation : …\n📅 Début : …\n⏱ Durée : …\n💵 Frais : … $', 0.355, 20, '#12305e', { b: true, lh: 1.6, x: Math.round(F.w * 0.13), w: Math.round(F.w * 0.74) }),
          k.T('Places limitées !', 0.7, 14, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('📞 ' + k.B.phone + '\n✉ ' + k.B.email, 0.78, 26, '#12305e', { b: true, al: 'center', lh: 1.5 }),
          k.T('📍 ' + k.B.address, 0.88, 28, '#ffffff', { al: 'center', b: true })]);
      }
    },
    lf_attest: {
      g: 'Logiciels & formations', l: 'Attestation de formation (paysage)', pal: 'blanc', fmt: 'a4l', f: function (F) {
        var k = K(F), W = F.w, H = F.h;
        return flat([
          k.R(0.02, 0.03, 0.96, 0.94, 'rgba(0,0,0,0)', { rad: 10, stroke: '#c9a227', sw: 6 }),
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.07), y: Math.round(H * 0.07), w: Math.round(H * 0.17), h: Math.round(H * 0.17), fit: 'contain', op: 1, rad: 0 },
          k.T(k.B.name.toUpperCase(), 0.1, 40, '#12305e', { b: true, al: 'right', ls: 2 }),
          k.T('ATTESTATION DE FORMATION', 0.27, 20, '#12305e', { b: true, al: 'center', ff: 4, ls: 3 }),
          k.T('Il est certifié que', 0.4, 36, '#5e6877', { al: 'center', i: true, ff: 3 }),
          k.T('PRÉNOM NOM', 0.46, 14, '#c9a227', { b: true, al: 'center', ff: 3 }),
          k.T('a suivi avec assiduité la formation « … » du … au …, d’une durée totale de … heures, et a satisfait aux évaluations.', 0.58, 38, '#1c2b45', { al: 'center', ff: 3, lh: 1.5 }),
          k.T('Fait à Kinshasa, le …', 0.76, 40, '#12305e', { b: true, al: 'left', ff: 3, w: Math.round(W * 0.4) }),
          k.T('La Direction', 0.76, 40, '#12305e', { b: true, al: 'right', ff: 3, x: Math.round(W * 0.53), w: Math.round(W * 0.4) })]);
      }
    },
    /* ===== Textes professionnels ===== */
    tp_lettre: {
      g: 'Textes professionnels', l: 'Lettre professionnelle', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.L(0.19, '#12305e'),
          k.T('Kinshasa, le …', 0.21, 30, '#1c2b45', { al: 'right' }),
          k.T('À l’attention de : Nom Prénom\nFonction — Société\nAdresse', 0.26, 29, '#1c2b45', { b: true, lh: 1.45 }),
          k.T('Objet : …', 0.35, 26, '#12305e', { b: true }),
          k.T('Madame, Monsieur,\n\nNous avons l’honneur de … Suite à …, nous vous proposons de …\n\nNous restons à votre disposition pour tout complément d’information et vous prions d’agréer, Madame, Monsieur, l’expression de nos salutations distinguées.', 0.4, 28, '#1c2b45', { ff: 3, lh: 1.55 }),
          k.T('Le Directeur\n\nNom Prénom', 0.72, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    tp_offre: {
      g: 'Textes professionnels', l: 'Offre de services / présentation de l’entreprise', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F), B = k.B;
        return flat([head(F, false),
          k.L(0.19, '#c9a227'),
          k.T('OFFRE DE SERVICES', 0.21, 15, '#12305e', { b: true, ff: 1 }),
          k.T('À propos', 0.285, 25, '#c9a227', { b: true, ls: 2 }),
          k.T(B.name + ' est une entreprise spécialisée en construction, architecture, études et conception. Depuis …, nous accompagnons nos clients de l’idée à la livraison.', 0.32, 29, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('Nos services', 0.445, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('✔ Construction et gros œuvre\n✔ Plans d’architecture et BIM\n✔ Études techniques et calcul de structure\n✔ Suivi de chantier, métrés et devis', 0.48, 28, '#1c2b45', { lh: 1.55 }),
          k.T('Pourquoi nous choisir ?', 0.67, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('Équipe qualifiée · Délais respectés · Devis clair et détaillé · Suivi régulier.', 0.705, 29, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('Demandez votre devis gratuit : ' + B.phone, 0.77, 31, '#ffffff', { b: true, al: 'center', bg: '#12305e', pad: 16, rad: 14 }),
          foot(F, false)]);
      }
    },
    tp_garde: {
      g: 'Textes professionnels', l: 'Page de garde (devis, rapport, dossier)', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3], W = F.w, H = F.h;
        return flat([
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.34), y: Math.round(H * 0.07), w: Math.round(W * 0.32), h: Math.round(W * 0.32), fit: 'contain', op: 1, rad: 0 },
          k.T(k.B.name.toUpperCase(), 0.33, 22, '#ffffff', { b: true, al: 'center', ls: 3 }),
          k.R(0.35, 0.39, 0.3, 0.005, G, { rad: 2 }),
          k.T('RAPPORT TECHNIQUE', 0.43, 11, '#ffffff', { b: true, al: 'center', ff: 1, lh: 1.05 }),
          k.T('Projet : …\nClient : …', 0.53, 24, '#cfe3ff', { al: 'center', i: true, ff: 3, lh: 1.5 }),
          k.T('Référence : … · Version : 1 · Date : …', 0.7, 32, G, { al: 'center', b: true }),
          k.T('Établi par : …\nVérifié par : …', 0.77, 30, '#ffffff', { al: 'center', lh: 1.5 }),
          k.T('📞 ' + k.B.phone + '   ✉ ' + k.B.email + '\n📍 ' + k.B.address, 0.89, 36, '#cfe3ff', { al: 'center', lh: 1.5 })]);
      }
    },
    tp_attest: {
      g: 'Textes professionnels', l: 'Attestation de service / de stage', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.L(0.19, '#c9a227'),
          k.T('ATTESTATION', 0.22, 12, '#12305e', { b: true, al: 'center', ff: 4, ls: 4 }),
          k.T('Je soussigné, Nom Prénom, Directeur de ' + k.B.name + ', atteste que :', 0.33, 27, '#1c2b45', { ff: 3, lh: 1.5 }),
          k.T('Madame / Monsieur NOM Prénom', 0.4, 19, '#12305e', { b: true, al: 'center', ff: 3 }),
          k.T('né(e) le … à …, a effectué au sein de notre entreprise un stage / a occupé le poste de … du … au …, pendant lequel il/elle a fait preuve de sérieux et de compétence.\n\nCette attestation est délivrée pour servir et valoir ce que de droit.', 0.47, 27, '#1c2b45', { ff: 3, lh: 1.55 }),
          k.T('Fait à Kinshasa, le …\nLe Directeur', 0.74, 28, '#12305e', { b: true, al: 'right', ff: 3, lh: 1.4 }),
          foot(F, false)]);
      }
    },
    tp_invit: {
      g: 'Textes professionnels', l: 'Invitation officielle (inauguration, cérémonie)', pal: 'noir', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.noir[3];
        return flat([head(F, true),
          k.R(0.07, 0.205, 0.86, 0.004, G, { rad: 2 }),
          k.T('VOUS ÊTES INVITÉ(E)', 0.23, 24, G, { b: true, al: 'center', ls: 5 }),
          k.T('Inauguration / Cérémonie de …', 0.29, 13, '#ffffff', { b: true, al: 'center', ff: 3, lh: 1.1 }),
          k.T('La Direction de ' + k.B.name + ' a l’honneur de vous convier à la cérémonie de …, en présence de …', 0.43, 27, '#e8edf5', { al: 'center', ff: 3, lh: 1.5, i: true }),
          k.T('📅 Date : …\n🕘 Heure : …\n📍 Lieu : …', 0.58, 22, '#ffffff', { b: true, al: 'center', lh: 1.6 }),
          k.T('Tenue de ville exigée · Merci de confirmer votre présence', 0.78, 31, G, { al: 'center', i: true }),
          foot(F, true, G)]);
      }
    },
    tp_pv: {
      g: 'Textes professionnels', l: 'Procès-verbal / compte rendu de réunion', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('PROCÈS-VERBAL DE RÉUNION', 0.2, 16, '#12305e', { b: true, al: 'center', ff: 4 }),
          k.L(0.245, '#c9a227'),
          k.T('Date : …    Lieu : …\nPrésents : …\nAbsents excusés : …', 0.27, 29, '#1c2b45', { b: true, lh: 1.5 }),
          k.T('Points discutés', 0.395, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('1. …\n2. …\n3. …', 0.435, 27, '#1c2b45', { lh: 1.6 }),
          k.T('Décisions et actions', 0.58, 25, '#c9a227', { b: true, ls: 2 }),
          k.T('• Action 1 — responsable : … — échéance : …\n• Action 2 — responsable : … — échéance : …', 0.62, 29, '#1c2b45', { lh: 1.6 }),
          k.T('Prochaine réunion : …', 0.76, 28, '#12305e', { b: true }),
          k.T('Le Secrétaire de séance          Le Président', 0.82, 30, '#12305e', { b: true, al: 'center' }),
          foot(F, false)]);
      }
    },
    tp_voeux: {
      g: 'Textes professionnels', l: 'Vœux / remerciements', pal: 'marine', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('BONNE ET HEUREUSE', 0.25, 16, '#ffffff', { b: true, al: 'center', ff: 1 }),
          k.T('ANNÉE 20…', 0.33, 8, G, { b: true, al: 'center', ff: 1, sh: true }),
          k.T('Merci pour votre confiance. Toute l’équipe de ' + k.B.name + ' vous souhaite santé, réussite et beaux projets.', 0.52, 27, '#e8edf5', { al: 'center', ff: 3, i: true, lh: 1.4 }),
          k.R(0.4, 0.72, 0.2, 0.005, G, { rad: 2 }),
          k.T('La Direction et l’équipe', 0.76, 26, '#ffffff', { b: true, al: 'center' })]);
      }
    },
    /* ===== Chantiers & réalisations ===== */
    ch_panneau: {
      g: 'Chantiers & réalisations', l: 'Panneau de chantier', pal: 'blanc', fmt: 'a4l', f: function (F) {
        var k = K(F), W = F.w, H = F.h;
        return flat([
          k.R(0, 0, 1, 0.2, '#12305e'),
          { t: 'img', src: logoSrcForStudio(), x: Math.round(W * 0.03), y: Math.round(H * 0.025), w: Math.round(H * 0.15), h: Math.round(H * 0.15), fit: 'contain', op: 1, rad: 0 },
          k.X('PANNEAU DE CHANTIER', 0.15, 0.04, 0.8, 22, '#ffffff', { b: true, ff: 1 }),
          k.X('Projet : …………………………', 0.15, 0.13, 0.8, 42, '#f2c94c', { b: true }),
          k.rows([['Maître d’ouvrage', '…'], ['Maître d’œuvre', '…'], ['Entreprise : ' + k.B.name, 'Tél. ' + k.B.phone], ['Permis de construire n°', '…'], ['Durée des travaux', 'Du … au …'], ['Coût des travaux', '… $']], 0.24, 44, '#1c2b45', '#12305e'),
          k.R(0, 0.93, 1, 0.07, '#f2c94c'),
          k.T('⚠ DANGER · CHANTIER INTERDIT AU PUBLIC', 0.945, 52, '#12305e', { b: true, al: 'center' })]);
      }
    },
    ch_realis: {
      g: 'Chantiers & réalisations', l: 'Projet réalisé (fiche réalisation)', pal: 'blanc', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.T('PROJET RÉALISÉ', 0.2, 28, '#c9a227', { b: true, ls: 4 }),
          k.T('Nom du projet', 0.23, 17, '#12305e', { b: true, ff: 1, lh: 1.05 }),
          k.P(0.07, 0.3, 0.86, 0.3),
          k.rows([['Client', '…'], ['Lieu', '…'], ['Surface', '… m²'], ['Durée', '… mois']], 0.625, 28, '#1c2b45', '#12305e'),
          k.T('Livré dans les délais · Qualité garantie', 0.84, 28, '#12305e', { b: true, al: 'center', i: true }),
          foot(F, false)]);
      }
    },
    ch_avap: {
      g: 'Chantiers & réalisations', l: 'Avant / Après', pal: 'noir', fmt: 'sq', f: function (F) {
        var k = K(F), G = PALETTES.noir[3];
        return flat([
          k.T('AVANT  /  APRÈS', 0.04, 11, '#ffffff', { b: true, al: 'center', ff: 1 }),
          k.P(0.05, 0.16, 0.435, 0.5, 'Avant'),
          k.P(0.515, 0.16, 0.435, 0.5, 'Après'),
          k.X('AVANT', 0.05, 0.69, 0.435, 24, '#ffffff', { b: true, al: 'center', ls: 4 }),
          k.X('APRÈS', 0.515, 0.69, 0.435, 24, G, { b: true, al: 'center', ls: 4 }),
          k.T('Rénovation / construction : … · Lieu : …', 0.77, 30, '#e8edf5', { al: 'center', i: true }),
          k.T(k.B.name + ' · ' + k.B.phone, 0.9, 30, G, { b: true, al: 'center' })]);
      }
    },
    ch_travaux: {
      g: 'Chantiers & réalisations', l: 'Avis de travaux (perturbation)', pal: 'jaune', fmt: 'a4p', f: function (F) {
        var k = K(F);
        return flat([
          k.R(0, 0, 1, 0.14, '#12305e'),
          k.T('⚠ ATTENTION · TRAVAUX', 0.045, 20, '#ffd54a', { b: true, al: 'center', ff: 1 }),
          k.T('AVIS DE TRAVAUX', 0.2, 12, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.T('Des travaux de … auront lieu à … du … au …, de … h à … h.', 0.31, 24, '#12305e', { b: true, al: 'center', lh: 1.4 }),
          k.T('Conséquences :\n• Circulation / accès perturbé\n• Bruit ponctuel\n• Stationnement restreint', 0.46, 25, '#12305e', { lh: 1.6, bg: 'rgba(255,255,255,.65)', pad: 24, rad: 14 }),
          k.T('Nous vous prions de nous excuser pour la gêne occasionnée.', 0.7, 27, '#12305e', { al: 'center', i: true, ff: 3 }),
          k.T('Renseignements : ' + k.B.phone, 0.8, 26, '#ffffff', { b: true, al: 'center', bg: '#12305e', pad: 16, rad: 14 }),
          k.T(k.B.name, 0.91, 28, '#12305e', { b: true, al: 'center' })]);
      }
    },
    ch_services: {
      g: 'Chantiers & réalisations', l: 'Nos services', pal: 'marine', fmt: 'a4p', f: function (F) {
        var k = K(F), G = PALETTES.marine[3], S = [['🏗', 'Construction'], ['📐', 'Architecture'], ['🧮', 'Études & conception'], ['🗺', 'Plans & BIM'], ['👷', 'Suivi de chantier'], ['🧾', 'Devis & métrés']], out = [head(F, true), k.T('NOS SERVICES', 0.2, 13, '#ffffff', { b: true, al: 'center', ff: 1 })], i, x, y;
        for (i = 0; i < 6; i++) {
          x = 0.07 + (i % 2) * 0.445; y = 0.29 + Math.floor(i / 2) * 0.185;
          out.push(k.R(x, y, 0.42, 0.16, 'rgba(255,255,255,.12)', { rad: 18, stroke: G, sw: 3 }));
          out.push(k.X(S[i][0], x, y + 0.012, 0.42, 14, '#ffffff', { al: 'center' }));
          out.push(k.X(S[i][1], x, y + 0.095, 0.42, 30, '#ffffff', { al: 'center', b: true }));
        }
        out.push(foot(F, true, G));
        return flat(out);
      }
    },
    ch_temoin: {
      g: 'Chantiers & réalisations', l: 'Témoignage client', pal: 'ciel', fmt: 'sq', f: function (F) {
        var k = K(F);
        return flat([head(F, false),
          k.X('“', 0.07, 0.22, 0.2, 6, '#c9a227', { b: true, ff: 3, lh: 0.8 }),
          k.T('Un travail soigné, des délais respectés et une équipe à l’écoute. Je recommande vivement.', 0.3, 25, '#12305e', { ff: 3, i: true, al: 'center', lh: 1.35 }),
          k.T('★ ★ ★ ★ ★', 0.58, 14, '#c9a227', { al: 'center' }),
          k.T('Prénom NOM', 0.67, 26, '#12305e', { b: true, al: 'center' }),
          k.T('Client · Projet : …', 0.73, 34, '#42526e', { al: 'center', i: true }),
          k.T('📞 ' + k.B.phone, 0.83, 30, '#12305e', { b: true, al: 'center' })]);
      }
    },
    ch_devis: {
      g: 'Chantiers & réalisations', l: 'Devis gratuit (appel à l’action)', pal: 'marine', fmt: 'story', f: function (F) {
        var k = K(F), G = PALETTES.marine[3];
        return flat([head(F, true),
          k.T('VOTRE PROJET', 0.2, 11, '#ffffff', { b: true, al: 'center', ff: 1, sh: true }),
          k.T('COMMENCE ICI', 0.25, 11, G, { b: true, al: 'center', ff: 1, sh: true }),
          k.T('Construction · Rénovation · Plans · Études', 0.34, 24, '#cfe3ff', { al: 'center', i: true, ff: 3 }),
          k.R(0.08, 0.42, 0.84, 0.26, '#ffffff', { rad: 28 }),
          k.T('DEVIS GRATUIT', 0.45, 11, '#12305e', { b: true, al: 'center', ff: 1 }),
          k.T('Réponse sous 48 h\nsans engagement', 0.55, 20, '#42526e', { al: 'center', lh: 1.4 }),
          k.T('📞 ' + k.B.phone, 0.74, 17, '#12305e', { b: true, al: 'center', bg: G, pad: 18, rad: 40 }),
          k.T('✉ ' + k.B.email + '\n📍 ' + k.B.address, 0.84, 28, '#ffffff', { al: 'center', lh: 1.6 })]);
      }
    }
  };
  Object.keys(TPL2).forEach(function (k) { TPL2[k].relax = true; TPL[k] = TPL2[k]; });
  ['vide', 'annonce', 'emploi', 'promo'].forEach(function (k) { TPL[k].g = 'Général'; });
  TPL.avis.g = 'Communiqués & avis'; TPL.formation.g = 'Logiciels & formations';
  function tplOptions() {
    var G = [], by = {};
    Object.keys(TPL).forEach(function (k) { var g = TPL[k].g || 'Général'; if (!by[g]) { by[g] = []; G.push(g); } by[g].push(k); });
    return G.map(function (g) { return '<optgroup label="' + g + '">' + by[g].map(function (k) { return '<option value="' + k + '">' + TPL[k].l + '</option>'; }).join('') + '</optgroup>'; }).join('');
  }
  /* évite les chevauchements : mesure la hauteur réelle de chaque texte puis décale vers le bas ce qui le recouvre */
  function relax() {
    var st = $('exbsStage'); if (!st) return;
    function hOf(e) { var n = st.querySelector('[data-id="' + e.id + '"]'); return n ? n.offsetHeight : 0; }
    var texts = ST.els.filter(function (e) { return e.t === 'text' && !e.fx; }).sort(function (a, b) { return a.y - b.y; });
    for (var i = 1; i < texts.length; i++) {
      var b = texts[i];
      for (var j = 0; j < i; j++) {
        var a = texts[j], ox = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x); if (ox <= 8) continue;
        var ah = hOf(a), need = a.y + ah + 8;
        if (b.y < need - 3 && b.y >= a.y) {
          var dl = need - b.y, y0 = b.y;
          ST.els.forEach(function (e) { if (!e.fx && e.y >= y0 - 1) e.y += dl; });
        }
      }
    }
  }
  function applyTpl(k) {
    var T = TPL[k]; push();
    if (T.fmt && FMT[T.fmt] && T.fmt !== ST.fmt) { ST.fmt = T.fmt; var fs_ = $('exbsFmt'); if (fs_) fs_.value = T.fmt; }
    ST.els = []; sel = null; var p = PALETTES[T.pal]; ST.bg = { c1: p[0], c2: p[1], ang: p[2], img: '', ovl: 0 };
    T.f(FMT[ST.fmt]).forEach(function (e) { e.id = uid(); e.op = e.op == null ? 1 : e.op; e.rot = e.rot || 0; ST.els.push(e); });
    bgPanel(); refresh();
    if (T.relax) {
      var base = JSON.parse(JSON.stringify(ST.els)), Hh = FMT[ST.fmt].h, lim = Hh - 8, sc, i2;
      ST.els.forEach(function (e) { if (e.fx && e.t === 'rect' && e.y < lim) lim = e.y; });
      for (sc = 1; sc >= 0.65; sc -= 0.05) {
        ST.els = JSON.parse(JSON.stringify(base));
        ST.els.forEach(function (e) { if (e.t === 'text' && !e.fx && sc < 1) e.fs = Math.max(9, Math.round(e.fs * sc)); });
        refresh(); relax(); refresh();
        var bot = 0, st2 = $('exbsStage');
        ST.els.forEach(function (e) { if (e.t === 'text' && !e.fx) { var n = st2.querySelector('[data-id="' + e.id + '"]'); bot = Math.max(bot, e.y + (n ? n.offsetHeight : 0)); } });
        if (bot <= lim - 6) break;
      }
    }
  }

  /* ---------- changement de format : tout est remis à l'échelle ---------- */
  function setFmt(k) {
    if (k === ST.fmt) return; push();
    var A = FMT[ST.fmt], B = FMT[k], sx = B.w / A.w, sy = B.h / A.h, sf = Math.min(sx, sy);
    ST.els.forEach(function (e) { e.x = Math.round(e.x * sx); e.y = Math.round(e.y * sy); e.w = Math.round(e.w * sx); e.h = Math.round(e.h * (e.t === 'img' || e.t === 'ellipse' ? sf : sy)); if (e.t === 'text') e.fs = Math.max(8, Math.round(e.fs * sf)); });
    ST.fmt = k; refresh();
  }

  /* ---------- enregistrement ---------- */
  function listAll() { return rd(K_LIST, []) || []; }
  function saveCur() {
    var nm = ($('exbsName').value || '').trim() || 'Mon affiche'; ST.name = nm;
    var L = listAll(); if (!ST.id) ST.id = uid();
    var o = JSON.parse(JSON.stringify(ST)); o.saved = new Date().toISOString();
    var i = L.map(function (x) { return x.id; }).indexOf(ST.id); if (i >= 0) L[i] = o; else L.unshift(o);
    if (!wr(K_LIST, L)) { note('Enregistrement impossible : espace de stockage plein. Supprimez d’anciennes affiches.', 'error', 7000); return; }
    note('✓ Affiche « ' + nm + ' » enregistrée.', 'ok'); mine();
  }
  function mine() {
    var L = listAll(), el = $('exbsMine'); if (!el) return;
    el.innerHTML = L.length ? L.map(function (x) {
      return '<div class="exbs-it"><div><b>' + esc(x.name) + '</b><span>' + (FMT[x.fmt] ? FMT[x.fmt].l : '') + ' · ' + (x.saved || '').slice(0, 10) + '</span></div><button data-o="' + x.id + '">Ouvrir</button><button data-x="' + x.id + '" class="del">🗑</button></div>';
    }).join('') : '<p class="exbs-hint">Aucune affiche enregistrée pour l’instant.</p>';
    Array.prototype.forEach.call(el.querySelectorAll('[data-o]'), function (b) { b.onclick = function () { var x = listAll().filter(function (y) { return y.id === b.getAttribute('data-o'); })[0]; if (x) { push(); ST = JSON.parse(JSON.stringify(x)); sel = null; $('exbsName').value = ST.name; $('exbsFmt').value = ST.fmt; if (!ST.frame) ST.frame = { on: false }; bgPanel(); framePn(); refresh(); note('Affiche ouverte.', 'ok'); } }; });
    Array.prototype.forEach.call(el.querySelectorAll('[data-x]'), function (b) { b.onclick = function () { if (!confirm('Supprimer cette affiche enregistrée ?')) return; wr(K_LIST, listAll().filter(function (y) { return y.id !== b.getAttribute('data-x'); })); mine(); }; });
  }

  /* ---------- export ---------- */
  function render(cb) {
    if (typeof w.html2canvas !== 'function') { note('Export impossible : le moteur d’image n’est pas chargé.', 'error', 7000); return; }
    var F = FMT[ST.fmt], host = d.createElement('div');
    host.style.cssText = 'position:fixed;left:-100000px;top:0;';
    var st = d.createElement('div'); host.appendChild(st); d.body.appendChild(host); build(st, false);
    note('Création de l’affiche…', 'info', 2500);
    var imgs = Array.prototype.slice.call(st.querySelectorAll('img')), n = imgs.length, go = function () {
      setTimeout(function () {
        w.html2canvas(st, { scale: F.sc, backgroundColor: '#ffffff', useCORS: false, logging: false, width: F.w, height: F.h }).then(function (c) { host.remove(); cb(c); }, function (e) { host.remove(); note('Export impossible : ' + (e && e.message || e), 'error', 8000); });
      }, 120);
    };
    if (!n) return go();
    imgs.forEach(function (im) { var f = function () { if (--n === 0) go(); }; if (im.complete) f(); else { im.onload = f; im.onerror = f; } });
  }
  function fname() { return (ST.name || 'affiche').replace(/[\\/:*?"<>|]+/g, '-').trim() || 'affiche'; }
  function exportPng() { render(function (c) { c.toBlob(function (b) { if (b) { download(b, fname() + '.png'); note('✓ Image enregistrée.', 'ok'); } }, 'image/png'); }); }
  function exportPdf() {
    var J = w.jspdf && w.jspdf.jsPDF; if (!J) { note('Export PDF impossible : le moteur PDF n’est pas chargé.', 'error', 7000); return; }
    render(function (c) {
      var F = FMT[ST.fmt], mm = F.mm || [Math.round(F.w * 0.2646), Math.round(F.h * 0.2646)];
      var pdf = new J({ orientation: mm[0] > mm[1] ? 'l' : 'p', unit: 'mm', format: mm, compress: true });
      pdf.addImage(c.toDataURL('image/jpeg', 0.93), 'JPEG', 0, 0, mm[0], mm[1]);
      download(pdf.output('blob'), fname() + '.pdf'); note('✓ PDF enregistré.', 'ok');
    });
  }

  /* ---------- interface ---------- */
  function ui() {
    css('exbsCss',
      '.exbs-tabs{display:flex;gap:8px;margin:0 0 12px;flex-wrap:wrap}.exbs-tabs button{padding:11px 16px;border-radius:999px;border:1px solid #c9d3df;background:#fff;color:#12305e;font:700 14px Arial,sans-serif;cursor:pointer}.exbs-tabs button.on{background:#12305e;color:#fff;border-color:#12305e}' +
      '#exbsRoot{display:none}#exbsRoot.on{display:block}.exbs-grid{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:14px;align-items:start}@media(max-width:980px){.exbs-grid{grid-template-columns:1fr}}' +
      '.exbs-card{background:#fff;border:1px solid #dbe3ee;border-radius:14px;padding:12px;color:#172033}.exbs-card h3{margin:0 0 8px;font-size:15px;color:#12305e}' +
      '.exbs-bar{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}.exbs-bar button,.exbs-btns button,.exbs-mini,.exbs-it button{padding:9px 12px;border-radius:9px;border:1px solid #c9d3df;background:#f4f7fb;color:#12305e;font:700 13px Arial,sans-serif;cursor:pointer}' +
      '.exbs-bar button.p{background:#12305e;color:#fff;border-color:#12305e}.exbs-bar button.g{background:#c9a227;color:#12254a;border-color:#c9a227}.exbs-btns{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.exbs-btns button.on{background:#12305e;color:#fff}.exbs-btns button.del,.exbs-it button.del{color:#b91c1c}' +
      '.exbs-in{width:100%;box-sizing:border-box;padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:14px Arial,sans-serif;background:#fff;color:#172033}input[type=color].exbs-in{padding:2px;height:38px}.exbs-2{display:grid;grid-template-columns:1fr 1fr;gap:8px}' +
      '.exbs-l{display:block;font:700 12px Arial,sans-serif;color:#12305e;margin:8px 0 3px}.exbs-t{display:block;color:#12305e;margin-bottom:6px}.exbs-hint{font-size:12.5px;color:#5e6877;margin:6px 0}' +
      '#exbsBox{background:#dfe4ec;border-radius:12px;padding:10px;overflow:auto;display:flex;justify-content:center}#exbsWrap{position:relative;box-shadow:0 4px 18px #0004;background:#fff;flex:none}#exbsStage{transform-origin:top left;user-select:none;-webkit-user-select:none}' +
      '.exbs-pal{display:flex;gap:8px;flex-wrap:wrap}.exbs-pal button{width:40px;height:40px;border-radius:10px;border:2px solid #fff;box-shadow:0 0 0 1px #c9d3df;cursor:pointer}' +
      '.exbs-it{display:flex;gap:6px;align-items:center;border-top:1px solid #e3e9f2;padding:7px 0}.exbs-it div{flex:1;min-width:0}.exbs-it b{display:block;font-size:13px;color:#12305e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.exbs-it span{font-size:11px;color:#6b7a99}' +
      '@media print{#exbsRoot,.exbs-tabs{display:none!important}}');
    var sec = $('affiches'); if (!sec || $('exbsRoot')) return;
    var grid = sec.querySelector('.grid'); if (!grid) return;
    var tabs = d.createElement('div'); tabs.className = 'exbs-tabs no-print';
    tabs.innerHTML = '<button id="exbsT1" class="on">🖼️ Affiches Excellencia</button><button id="exbsT2">🎨 Studio libre (autres contenus)</button>';
    sec.insertBefore(tabs, grid);
    root = d.createElement('div'); root.id = 'exbsRoot'; root.className = 'no-print';
    root.innerHTML =
      '<div class="exbs-card" style="margin-bottom:12px"><h3>🎨 Studio libre — créez une affiche sur n’importe quel sujet</h3>' +
      '<p class="exbs-hint" style="margin-top:0">Choisissez un modèle ou partez d’une page vide, ajoutez vos textes, photos et formes, déplacez-les du doigt ou à la souris, puis exportez en image ou en PDF.</p>' +
      '<div class="exbs-2"><div><label class="exbs-l">Nom de l’affiche</label><input id="exbsName" class="exbs-in" value="Mon affiche"></div><div><label class="exbs-l">Format</label><select id="exbsFmt" class="exbs-in">' + Object.keys(FMT).map(function (k) { return '<option value="' + k + '">' + FMT[k].l + '</option>'; }).join('') + '</select></div></div>' +
      '<label class="exbs-l">Modèle de départ (' + Object.keys(TPL).length + ' modèles)</label><select id="exbsTpl" class="exbs-in"><option value="">— Choisir un modèle —</option>' + tplOptions() + '</select></div>' +
      '<div class="exbs-grid"><div class="exbs-card"><div class="exbs-bar"><button id="ad_t">＋ Texte</button><button id="ad_i">＋ Photo</button><button id="ad_l">＋ Logo</button><button id="ad_r">▭ Rectangle</button><button id="ad_e">◯ Cercle</button><button id="ad_ln">▬ Trait</button><button id="ad_u">↶ Annuler</button></div>' +
      '<div id="exbsBox"><div id="exbsWrap"><div id="exbsStage"></div></div></div><div class="exbs-hint" id="exbsFmtLbl" style="text-align:center"></div>' +
      '<div class="exbs-bar" style="margin-top:8px"><button class="p" id="ex_save">💾 Enregistrer</button><button class="g" id="ex_png">⬇ Image (PNG)</button><button class="g" id="ex_pdf">📄 PDF</button><button id="ex_new">🆕 Nouvelle</button></div></div>' +
      '<div><div class="exbs-card" id="exbsPropsCard"><h3>Modifier</h3><div id="exbsProps"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Fond</h3><div id="exbsBg"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Contour</h3><p class="exbs-hint" style="margin-top:0">Cadre comme sur la page de garde des devis : à mettre ou à retirer.</p><div id="exbsFr"></div></div>' +
      '<div class="exbs-card" style="margin-top:12px"><h3>Mes affiches</h3><div id="exbsMine"></div></div></div></div>';
    sec.appendChild(root);
    $('exbsT1').onclick = function () { grid.style.display = ''; root.classList.remove('on'); $('exbsT1').classList.add('on'); $('exbsT2').classList.remove('on'); setTimeout(function () { w.exbFitPosters && w.exbFitPosters(); }, 50); };
    $('exbsT2').onclick = function () { grid.style.display = 'none'; root.classList.add('on'); $('exbsT2').classList.add('on'); $('exbsT1').classList.remove('on'); setTimeout(function () { fit(); refresh(true); }, 30); };
    $('exbsFmt').onchange = function () { setFmt(this.value); };
    $('exbsName').oninput = function () { ST.name = this.value; };
    $('exbsTpl').onchange = function () { if (this.value) { if (ST.els.length && !confirm('Remplacer le contenu actuel par ce modèle ?')) { this.value = ''; return; } applyTpl(this.value); this.value = ''; } };
    $('ad_t').onclick = function () { addText('Votre texte ici', {}); };
    $('ad_i').onclick = function () { pickImage(function (u) { var F = FMT[ST.fmt]; add({ t: 'img', src: u, x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.3), w: Math.round(F.w * 0.8), h: Math.round(F.w * 0.5), fit: 'cover', op: 1, rot: 0, rad: 0 }); }); };
    $('ad_l').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'img', src: logoSrcForStudio(), x: Math.round(F.w * 0.06), y: Math.round(F.h * 0.04), w: Math.round(F.w * 0.2), h: Math.round(F.w * 0.2), fit: 'contain', op: 1, rot: 0, rad: 0 }); };
    $('ad_r').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'rect', x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.4), w: Math.round(F.w * 0.8), h: Math.round(F.h * 0.12), fill: '#c9a227', stroke: '#ffffff', sw: 0, rad: 16, op: 1, rot: 0 }); };
    $('ad_e').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'ellipse', x: Math.round(F.w * 0.3), y: Math.round(F.h * 0.4), w: Math.round(F.w * 0.4), h: Math.round(F.w * 0.4), fill: '#ffffff', stroke: '#12305e', sw: 0, op: 1, rot: 0 }); };
    $('ad_ln').onclick = function () { var F = FMT[ST.fmt]; add({ t: 'line', x: Math.round(F.w * 0.1), y: Math.round(F.h * 0.5), w: Math.round(F.w * 0.8), h: 8, fill: '#f2c94c', op: 1, rot: 0 }); };
    $('ad_u').onclick = undo;
    $('ex_save').onclick = saveCur; $('ex_png').onclick = exportPng; $('ex_pdf').onclick = exportPdf;
    $('ex_new').onclick = function () { if (ST.els.length && !confirm('Commencer une nouvelle affiche ? (pensez à enregistrer l’actuelle)')) return; ST = { id: null, name: 'Mon affiche', fmt: ST.fmt, bg: { c1: '#0f2a56', c2: '#1e5fb4', ang: 160, img: '', ovl: 0 }, els: [], frame: ST.frame || { on: false } }; sel = null; hist = []; $('exbsName').value = ST.name; bgPanel(); refresh(); };
    d.addEventListener('keydown', function (ev) {
      if (!root.classList.contains('on')) return; var t = ev.target && ev.target.tagName; if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return;
      var e = find(sel); if (!e) return;
      if (ev.key === 'Delete' || ev.key === 'Backspace') { push(); ST.els.splice(ST.els.indexOf(e), 1); sel = null; refresh(); ev.preventDefault(); }
      var st = ev.shiftKey ? 20 : 4, mv = { ArrowLeft: [-st, 0], ArrowRight: [st, 0], ArrowUp: [0, -st], ArrowDown: [0, st] }[ev.key];
      if (mv) { e.x += mv[0]; e.y += mv[1]; refresh(true); ev.preventDefault(); }
    });
    w.addEventListener('resize', function () { if (root.classList.contains('on')) { fit(); build($('exbsStage'), true); } });
    bindDrag(); bgPanel(); framePn(); mine(); props();
  }

  function start() {
    try { logoCard(); } catch (e) { try { console.error('logo affiches', e); } catch (x) {} }
    try { ui(); } catch (e) { try { console.error('studio affiches', e); } catch (x) {} }
    wrapRender(); applyAll();
  }
  d.addEventListener('exb-images-ready', function () { cache = {}; tries = { poster: 0, software: 0 }; setTimeout(applyAll, 60); });
  w.EXB_STUDIO = { version: 'V99-studio-2', applyLogo: applyAll, state: function () { return ST; }, templates: function () { return Object.keys(TPL); }, applyTemplate: function (k) { applyTpl(k); } };
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { setTimeout(start, 0); }); else setTimeout(start, 0);
  /* la section peut être construite plus tard : nouvel essai discret */
  var n = 0, iv = setInterval(function () { if ($('exbsRoot') && $('exbLogoCard')) { clearInterval(iv); return; } if (++n > 40) { clearInterval(iv); return; } try { logoCard(); ui(); wrapRender(); } catch (e) {} }, 1500);
})(window, document);
