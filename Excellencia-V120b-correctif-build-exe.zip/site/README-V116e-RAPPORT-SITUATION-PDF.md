# V116e — Intelligence BTP : rapport de situation en PDF

Fichiers modifiés : `exb-intelligence-2.js`, `sw.js` (nouvelle version de cache). Vider le cache / recharger l'application après mise à jour.

- Le bouton « Télécharger le rapport (PDF) » (Accueil > Intelligence) produit désormais un PDF au lieu d'un fichier HTML.
- Même moteur que les devis et factures (`EXBPdf`) : page de garde standard, identité de l'entreprise, visa, QR de vérification, pagination.
- Contenu : activité, facturation par devise, factures en retard, stock à réapprovisionner, contrôle des données.
- Si le module PDF est indisponible, repli automatique sur l'ancien HTML.
- `EXBI.docs.situation` (HTML) reste disponible ; `EXBI.docs.situationPdf` ajouté.
