-- ===== Excellencia Building — V118 · MOTEUR DOCUMENTAIRE UNIVERSEL =====
-- Prérequis : schema-entreprise.sql (tables organisations / membres, fonction est_membre). Réexécutable sans danger.
-- Principe : tout est rattaché à une organisation (org_id) et isolé par la sécurité par lignes (RLS).
-- Le serveur du moteur appelle ces tables AVEC LE JETON DE L'UTILISATEUR : aucune clé « service » n'est nécessaire.

create table if not exists doc_profils(
  org_id uuid primary key references organisations(id) on delete cascade,
  profil jsonb not null default '{}'::jsonb,          -- identité documentaire (logo, adresse, couleurs, signature, cachet…)
  maj timestamptz not null default now(), maj_par uuid);

create table if not exists doc_parametres(             -- permissions, numérotation : réservé aux administrateurs
  org_id uuid primary key references organisations(id) on delete cascade,
  parametres jsonb not null default '{}'::jsonb,
  maj timestamptz not null default now(), maj_par uuid);

create table if not exists doc_modeles(                -- modèles personnalisés de l'organisation
  org_id uuid not null references organisations(id) on delete cascade,
  id text not null, type text not null, nom text not null, options jsonb not null default '{}'::jsonb,
  maj timestamptz not null default now(), maj_par uuid, primary key(org_id,id));

create table if not exists doc_compteurs(
  org_id uuid not null references organisations(id) on delete cascade,
  type text not null, annee int not null, dernier int not null default 0, primary key(org_id,type,annee));

create table if not exists doc_historique(
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references organisations(id) on delete cascade,
  type text not null, numero text, titre text, objet text, modele_id text, source text,
  donnees jsonb not null default '{}'::jsonb,           -- données d'origine : permettent de régénérer avec le profil à jour
  pdf_path text, taille int default 0, supprime boolean not null default false,
  cree_par uuid, cree_le timestamptz not null default now(), regenere_le timestamptz);
create index if not exists doc_hist_org_idx on doc_historique(org_id, cree_le desc);

alter table doc_profils enable row level security;
alter table doc_parametres enable row level security;
alter table doc_modeles enable row level security;
alter table doc_compteurs enable row level security;
alter table doc_historique enable row level security;

-- lecture : tout membre · écriture : administrateurs et éditeurs (le serveur affine selon les permissions de l'organisation)
drop policy if exists dp_lire on doc_profils;   create policy dp_lire on doc_profils for select using (est_membre(org_id));
drop policy if exists dp_ecrire on doc_profils; create policy dp_ecrire on doc_profils for all using (est_membre(org_id,array['admin','editeur'])) with check (est_membre(org_id,array['admin','editeur']));
drop policy if exists dq_lire on doc_parametres;   create policy dq_lire on doc_parametres for select using (est_membre(org_id));
drop policy if exists dq_ecrire on doc_parametres; create policy dq_ecrire on doc_parametres for all using (est_membre(org_id,array['admin'])) with check (est_membre(org_id,array['admin']));
drop policy if exists dm_lire on doc_modeles;   create policy dm_lire on doc_modeles for select using (est_membre(org_id));
drop policy if exists dm_ecrire on doc_modeles; create policy dm_ecrire on doc_modeles for all using (est_membre(org_id,array['admin','editeur'])) with check (est_membre(org_id,array['admin','editeur']));
drop policy if exists dh_lire on doc_historique;   create policy dh_lire on doc_historique for select using (est_membre(org_id));
drop policy if exists dh_ajouter on doc_historique; create policy dh_ajouter on doc_historique for insert with check (est_membre(org_id,array['admin','editeur']));
drop policy if exists dh_modifier on doc_historique; create policy dh_modifier on doc_historique for update using (est_membre(org_id,array['admin','editeur'])) with check (est_membre(org_id,array['admin','editeur']));
drop policy if exists dh_suppr on doc_historique; create policy dh_suppr on doc_historique for delete using (est_membre(org_id,array['admin','editeur']));
-- doc_compteurs : aucune politique = aucun accès direct ; seule la fonction ci-dessous peut l'incrémenter.

-- Numéro suivant, atomique (deux utilisateurs simultanés n'obtiennent jamais le même numéro).
create or replace function doc_prochain_numero(p_org uuid, p_type text, p_annee int)
returns int language plpgsql security definer set search_path=public as $$
declare n int;
begin
  if not est_membre(p_org, array['admin','editeur']) then raise exception 'acces refuse' using errcode='42501'; end if;
  insert into doc_compteurs(org_id,type,annee,dernier) values (p_org,p_type,p_annee,1)
    on conflict (org_id,type,annee) do update set dernier = doc_compteurs.dernier + 1 returning dernier into n;
  return n;
end $$;
revoke all on function doc_prochain_numero(uuid,text,int) from public, anon;
grant execute on function doc_prochain_numero(uuid,text,int) to authenticated;

-- Stockage des PDF archivés : bucket privé, un dossier par organisation (<org_id>/<document>.pdf).
insert into storage.buckets(id,name,public) values ('documents-generes','documents-generes',false) on conflict (id) do nothing;
drop policy if exists dg_lire on storage.objects;
create policy dg_lire on storage.objects for select using (bucket_id='documents-generes' and est_membre(((storage.foldername(name))[1])::uuid));
drop policy if exists dg_ecrire on storage.objects;
create policy dg_ecrire on storage.objects for insert with check (bucket_id='documents-generes' and est_membre(((storage.foldername(name))[1])::uuid, array['admin','editeur']));
drop policy if exists dg_maj on storage.objects;
create policy dg_maj on storage.objects for update using (bucket_id='documents-generes' and est_membre(((storage.foldername(name))[1])::uuid, array['admin','editeur']));
drop policy if exists dg_suppr on storage.objects;
create policy dg_suppr on storage.objects for delete using (bucket_id='documents-generes' and est_membre(((storage.foldername(name))[1])::uuid, array['admin','editeur']));

-- Contrôle : select count(*) from pg_tables where tablename like 'doc\_%';  → 5
