-- V116 — Code de suivi client pour un chantier créé SANS demande BTP.
-- PRÉREQUIS : migration-chantier-comptes-sync-v67.sql (fonction exb_is_admin) et le script chantier-admin déjà exécutés. Réexécutable.
alter table public.exb_sites add column if not exists suivi_code text;
create unique index if not exists exb_sites_suivi_code_uq on public.exb_sites(suivi_code) where suivi_code is not null;

-- Administrateur : donne (ou crée) le code de suivi d'un chantier. p_regen = true : nouveau code, l'ancien cesse de fonctionner.
create or replace function public.chantier_code_suivi(p_site uuid,p_regen boolean default false) returns text
language plpgsql security definer set search_path=public as $$
declare c text;
begin
  if not public.exb_is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  select suivi_code into c from exb_sites where id=p_site;
  if not found then raise exception 'Chantier introuvable'; end if;
  if c is null or p_regen then
    loop
      c:=upper(substr(replace(gen_random_uuid()::text,'-',''),1,12));
      c:=substr(c,1,4)||'-'||substr(c,5,4)||'-'||substr(c,9,4);
      exit when not exists(select 1 from exb_sites where suivi_code=c);
    end loop;
    update exb_sites set suivi_code=c where id=p_site;
  end if;
  return c;
end $$;

-- Public (client sans compte) : avancement + rapports marqués « visibles client ». Rien d'autre n'est exposé.
create or replace function public.chantier_suivi_public(p_code text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare s record; r jsonb;
begin
  select * into s from exb_sites where suivi_code=upper(trim(coalesce(p_code,'')));
  if not found then return null; end if;
  select jsonb_build_object(
    'nom',to_jsonb(s)->>'name',
    'avancement',coalesce((select j.progress from exb_field_journals j where j.site_id=s.id order by j.work_date desc limit 1),0),
    'journaux',coalesce((select jsonb_agg(jsonb_build_object('work_date',x.work_date,'work_done',x.work_done,'progress',x.progress,'weather',x.weather) order by x.work_date desc)
        from (select * from exb_field_journals where site_id=s.id and client_visible is true order by work_date desc limit 30) x),'[]'::jsonb),
    'photos',(select count(*) from exb_field_photos where site_id=s.id and client_visible is true)
  ) into r;
  return r;
end $$;

revoke all on function public.chantier_code_suivi(uuid,boolean),public.chantier_suivi_public(text) from public;
grant execute on function public.chantier_code_suivi(uuid,boolean) to authenticated;
grant execute on function public.chantier_suivi_public(text) to anon,authenticated;
-- Contrôle : select proname from pg_proc where proname in ('chantier_code_suivi','chantier_suivi_public'); -> 2 lignes
