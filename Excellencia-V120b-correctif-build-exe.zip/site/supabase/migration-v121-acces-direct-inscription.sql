-- Excellencia Building V121 — Espace apprenant : ACCÈS DIRECT dès l'inscription (sans attendre « Publier l'espace apprenant »).
-- À exécuter UNE fois (Supabase › SQL Editor › New query › coller › Run). Réexécutable sans danger.
-- Prérequis : migration-v101 et migration-v102 (table apprenants_acces, fonctions _exb_n, apprenant_connexion).
--
-- AVANT : la ligne d'accès (apprenants_acces) n'était créée que par la publication faite par l'équipe.
--         Un apprenant qui venait de s'inscrire avait son matricule mais « Matricule ou mot de passe incorrect ».
-- APRÈS : dès que l'inscription est enregistrée (table inscriptions), son accès est créé :
--         matricule reçu à l'inscription + mot de passe 1234 (à changer à la première connexion, comme avant).
--         L'apprenant entre tout de suite dans son espace ; frais, cours, planning apparaissent quand l'équipe
--         a approuvé/enregistré (mises à jour automatiques du logiciel) ; les résultats de fin de semestre et
--         finaux restent publiés par l'équipe.
--
-- Sans danger pour l'inscription : si la création de l'accès échoue, l'inscription est quand même enregistrée
-- (simple avertissement dans les journaux Supabase).
-- Un accès existant n'est JAMAIS modifié (mot de passe déjà choisi conservé).

create or replace function public.apprenant_acces_depuis_inscription() returns trigger
 language plpgsql security definer set search_path to 'public', 'extensions' as $$
declare j jsonb := to_jsonb(NEW); m text;
begin
  m := public._exb_n(coalesce(nullif(j->>'matricule',''), nullif(j->>'matricule_en_ligne',''), ''));
  if m is null or m = '' then return NEW; end if;
  begin
    insert into public.apprenants_acces(matricule, nom, formation, mdp_hash, doit_changer)
    values (m,
            left(coalesce(nullif(j->>'name',''), nullif(j->>'nom',''), ''), 120),
            left(coalesce(nullif(j->>'training',''), nullif(j->>'formation',''), ''), 200),
            extensions.crypt('1234', extensions.gen_salt('bf')), true)
    on conflict do nothing;
  exception when others then
    raise warning 'acces apprenant non cree (%): %', m, sqlerrm;
  end;
  return NEW;
end $$;
revoke all on function public.apprenant_acces_depuis_inscription() from public, anon, authenticated;

-- INSERT ET UPDATE : si le matricule est attribué juste après l'insertion, l'accès est créé à ce moment-là.
drop trigger if exists apprenant_acces_inscription on public.inscriptions;
create trigger apprenant_acces_inscription
  after insert or update on public.inscriptions
  for each row execute function public.apprenant_acces_depuis_inscription();

-- Rattrapage : les apprenants DÉJÀ inscrits (avec matricule) mais jamais publiés reçoivent leur accès maintenant.
do $$
declare r record; j jsonb; m text; n int := 0;
begin
  for r in select to_jsonb(i) as j from public.inscriptions i loop
    j := r.j;
    m := public._exb_n(coalesce(nullif(j->>'matricule',''), nullif(j->>'matricule_en_ligne',''), ''));
    if m is null or m = '' then continue; end if;
    insert into public.apprenants_acces(matricule, nom, formation, mdp_hash, doit_changer)
    values (m,
            left(coalesce(nullif(j->>'name',''), nullif(j->>'nom',''), ''), 120),
            left(coalesce(nullif(j->>'training',''), nullif(j->>'formation',''), ''), 200),
            extensions.crypt('1234', extensions.gen_salt('bf')), true)
    on conflict do nothing;
    if found then n := n + 1; end if;
  end loop;
  raise notice 'Acces apprenants crees pour les inscriptions existantes : %', n;
end $$;

-- Contrôles :
--  select tgname from pg_trigger where tgname = 'apprenant_acces_inscription';            -- 1 ligne
--  Après une inscription de TEST : select matricule, nom, doit_changer from public.apprenants_acces order by 1 desc limit 3;
--  → le matricule affiché à l'écran de confirmation doit y figurer, puis connexion sur espace-apprenant.html avec 1234.
