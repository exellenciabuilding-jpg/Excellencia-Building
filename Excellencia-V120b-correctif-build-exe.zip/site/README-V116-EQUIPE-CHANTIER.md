# V116 — Équipe du chantier (rattacher les personnes au logiciel chantier)
Demandes reçues › 🏗️ Chantiers terrain › sur un chantier : **👷 Équipe du chantier**.
1. La liste reprend vos contacts : Personnel (RH), Formateurs, Clients. Cochez, vérifiez l'e-mail (obligatoire) et la fonction (proposée d'après le poste ; modifiable).
2. « ➕ Autre personne » : nom + e-mail pour quelqu'un qui n'est pas dans vos listes.
3. **Créer les comptes et rattacher** : appelle `chantier_membre_ajouter` pour chaque personne. Compte absent = créé avec un mot de passe provisoire généré (8 caractères) ; compte existant = simplement rattaché.
4. Écran résultat : bouton 📲 WhatsApp / 📋 Copier par personne (lien du logiciel chantier + identifiant + mot de passe provisoire). Ce mot de passe n'est affiché qu'à cet écran.
Fonction -> rôle : Directeur=admin ; Conducteur/Chef de chantier=conducteur ; Ingénieur/Technicien=ingenieur ; Magasinier=magasinier ; Chef d'équipe/Pointeur/Ouvrier/HSE=terrain ; Client/Architecte/Contrôle/Comptable=lecture.
L'adresse du logiciel chantier est demandée une fois, puis mémorisée sur l'appareil.
Fichiers : `index.html`, `sw.js` (cache). Aucun SQL nouveau (utilise la fonction existante du logiciel chantier).
Non vérifié : essai sur navigateur simulé (appels serveur simulés) ; pas sur un vrai Supabase. Tester d'abord avec une personne de test.
