/* EXCELLENCIA INTELLIGENCE — lot 7 : détection des modifications et des menaces (intégrité, intrusion, fraude, injection).
 * Extension (à charger APRÈS exb-intelligence.js). LECTURE SEULE sur vos données métier : ce fichier n'écrit que ses propres clés
 * (exb_intel_sec_base = empreintes, exb_intel_sec_log = journal de sécurité). Aucune valeur sensible (mot de passe, clé, jeton) n'est copiée :
 * seulement une empreinte courte, le nom du réglage et la date.
 *  • Intégrité : réglages protégés (licence, mot de passe, droits, 2FA, autorisations de l'assistant) modifiés depuis la dernière ouverture.
 *  • Horloge : date de l'appareil reculée (contournement possible d'une licence ou d'une échéance).
 *  • Suppression massive de fiches ; journal d'audit vidé, désordonné ou daté du futur.
 *  • Connexions : rafale d'échecs, réussite juste après des échecs, compte verrouillé.
 *  • Injection : balises <script>, onerror=, javascript: ou identifiants piégés dans les fiches ; script/iframe étranger ajouté à la page.
 *  • Fraude / erreur : montants très supérieurs à l'habituel, facture déjà payée puis modifiée, rafales de modifications ou de suppressions.
 *  • Rapport de sécurité (HTML, hors ligne), recommandations, réponses de l'assistant local (« menace », « intégrité », « qui a modifié »…).
 * Pour retirer : supprimer la balise <script src="exb-intelligence-7.js"> de index.html. */
(function (w, d) {
  'use strict';
  function boot(n) {
    var I = w.EXBI; if (!I || !I.helpers) { if (n < 120) setTimeout(function () { boot((n || 0) + 1); }, 500); return; }
    if (I.lot7) return; I.lot7 = true;
    var H = I.helpers, list = H.list, lab = H.lab, num = H.num, norm = H.norm, esc = H.esc, jget = H.jget, jset = H.jset, toast = H.toast;
    var K_BASE = 'exb_intel_sec_base', K_LOG = 'exb_intel_sec_log';
    /* Réglages protégés. Volatils exclus (exb_lic_seen, exb_lic_chk, exb_lic_msg, exb_lic_backup_at, exb_lock, exb_session). */
    var SENS = /^(exb_ai_perm|exb_pass|exb_pass_h|exb_user|exb_lic_token|exb_lic_blk|exb_roles?[a-z0-9_]*|exb_droits[a-z0-9_]*|exb_rights[a-z0-9_]*|exb_perm[a-z0-9_]*|exb_mfa[a-z0-9_]*|exb_2fa[a-z0-9_]*)$/i;
    var LBL = [[/^exb_ai_perm/, 'autorisations de l’assistant IA'], [/^exb_(pass|user)/, 'identifiants de connexion'], [/^exb_lic/, 'licence'], [/^exb_(roles?|droits|rights|perm)/i, 'droits des utilisateurs'], [/^exb_(mfa|2fa)/i, 'double authentification']];
    function slabel(k) { for (var i = 0; i < LBL.length; i++) if (LBL[i][0].test(k)) return LBL[i][1]; return 'réglage protégé'; }
    function F(sev, mod, msg, id, extra) { var o = { sev: sev, mod: mod, msg: msg, ref: { col: 'sec', id: id || '' } }; if (extra) for (var k in extra) o[k] = extra[k]; return o; }
    function ls() { try { return w.localStorage; } catch (e) { return null; } }
    function fp(s) { s = String(s == null ? '' : s); var a = 5381, b = 2166136261, i, c; for (i = 0; i < s.length; i++) { c = s.charCodeAt(i); a = ((a << 5) + a + c) | 0; b = Math.imul(b ^ c, 16777619) | 0; } return (a >>> 0).toString(36) + (b >>> 0).toString(36) + ':' + s.length; }
    function sensKeys() { var S = ls(), out = []; if (!S) return out; try { for (var i = 0, n = S.length; i < n; i++) { var k = S.key(i); if (k && SENS.test(k)) out.push(k); } } catch (e) {} return out; }
    function snapshot() { var S = ls(), o = {}; sensKeys().forEach(function (k) { try { o[k] = fp(S.getItem(k)); } catch (e) {} }); return o; }
    function base() { var b = jget(K_BASE, null); return b && typeof b === 'object' ? b : null; }
    function slog() { var l = jget(K_LOG, []); return Array.isArray(l) ? l : []; }
    function note(type, msg) { var l = slog(); l.unshift({ at: new Date().toISOString(), type: type, msg: msg }); jset(K_LOG, l.slice(0, 200)); }
    function audit() { var a = jget('exb_audit', []); return Array.isArray(a) ? a : []; }
    function tms(x) { var t = Date.parse(x); return isFinite(t) ? t : 0; }

    /* ---------- état de référence (confiance à la première utilisation) ---------- */
    function counts() { var o = {}; I.collections.forEach(function (c) { o[c.k] = list(c.k).length; }); return o; }
    var B = base(), first = !B;
    if (first) { B = { at: Date.now(), sig: snapshot(), counts: counts(), audN: audit().length, clock: Date.now() }; jset(K_BASE, B); note('base', 'Empreintes de référence créées (première analyse).'); }
    B.sig = B.sig || {}; B.counts = B.counts || {}; B.clock = B.clock || 0;
    function saveBase() { B.at = Date.now(); jset(K_BASE, B); }

    /* ---------- suivi en cours de session (lecture seule) ---------- */
    var live = {}, clockJump = 0, bootClock = B.clock;
    function track() {
      var S = ls(), now = Date.now();
      if (now + 600000 < B.clock) { if (!clockJump) { clockJump = B.clock - now; note('horloge', 'Horloge reculée d’environ ' + Math.round(clockJump / 60000) + ' min.'); } }
      else if (now > B.clock + 60000) { B.clock = now; saveBase(); }
      var cur = snapshot();
      Object.keys(cur).forEach(function (k) { if (live[k] !== undefined && live[k] !== cur[k]) note('reglage', 'Modification en cours de session : ' + slabel(k) + ' (' + k + ').'); live[k] = cur[k]; });
      Object.keys(live).forEach(function (k) { if (!(k in cur)) { note('reglage', 'Suppression en cours de session : ' + slabel(k) + ' (' + k + ').'); delete live[k]; } });
    }
    live = snapshot(); setInterval(function () { if (I.tasks) I.tasks.add({ key: 'sec.track', group: 'sec', label: 'Sécurité : suivi', prio: 'normale', timeout: 20000, fn: track }); else track(); }, 5000);
    try { w.addEventListener('storage', function (e) { if (e && e.key && SENS.test(e.key)) { note('reglage', 'Modification depuis un autre onglet : ' + slabel(e.key) + ' (' + e.key + ').'); try { I.run(); } catch (x) {} } }); } catch (e) {}

    /* ---------- surveillance de la page : script / iframe étranger ---------- */
    var okOrig = {}; okOrig[location.origin] = 1;
    function origin(u) { try { return new URL(u, location.href).origin; } catch (e) { return ''; } }
    try { [].forEach.call(d.querySelectorAll('script[src],link[href],iframe[src],img[src]'), function (n) { var o = origin(n.src || n.href); if (o) okOrig[o] = 1; }); } catch (e) {}
    var DOMSEEN = {};
    function watchNode(n) {
      if (!n || n.nodeType !== 1) return; var t = n.tagName;
      if (t === 'SCRIPT' || t === 'IFRAME' || t === 'OBJECT' || t === 'EMBED') {
        var u = n.src || n.data || ''; if (!u || /^(blob:|about:)/i.test(u)) return;
        var o = origin(u); if (o && !okOrig[o] && !DOMSEEN[o]) { DOMSEEN[o] = 1; note('dom', t.toLowerCase() + ' étranger ajouté à la page (origine : ' + o + ').'); try { I.run(); } catch (e) {} }
      }
      try { [].forEach.call(n.querySelectorAll ? n.querySelectorAll('script[src],iframe[src]') : [], watchNode); } catch (e) {}
    }
    try { if (w.MutationObserver) new MutationObserver(function (ms) { ms.forEach(function (m) { [].forEach.call(m.addedNodes || [], watchNode); }); }).observe(d.documentElement, { childList: true, subtree: true }); } catch (e) {}

    /* ================= RÈGLES ================= */
    /* 1. Intégrité des réglages protégés (depuis la dernière ouverture) */
    I.registerEngine('securite.integrite', 'Intégrité des réglages protégés', function () { return []; });
    I.addRule({ id: 'sec.integrite', check: function () {
      var out = [], cur = snapshot(), seen = {};
      Object.keys(cur).forEach(function (k) { seen[k] = 1; if (B.sig[k] === undefined) { if (!first) out.push(F('alerte', 'Sécurité', 'Nouveau réglage protégé apparu depuis la dernière ouverture : ' + slabel(k) + ' (' + k + ')', k + '|new|' + cur[k])); } else if (B.sig[k] !== cur[k]) out.push(F('alerte', 'Sécurité', 'Réglage protégé modifié depuis la dernière ouverture : ' + slabel(k) + ' (' + k + '). Si ce n’est pas vous, changez votre mot de passe et vérifiez la licence.', k + '|chg|' + cur[k], { fixKey: k })); });
      Object.keys(B.sig).forEach(function (k) { if (!seen[k]) out.push(F('alerte', 'Sécurité', 'Réglage protégé supprimé depuis la dernière ouverture : ' + slabel(k) + ' (' + k + ')', k + '|del', { fixKey: k })); });
      return out; } });
    I.addFixer('sec.integrite', function (f) {
      if (!f.fixKey) return null; return { label: 'Valider ce changement', run: function () { return I.confirm('Valider le changement', 'Confirmez que vous êtes à l’origine de la modification de « ' + slabel(f.fixKey) + ' ». L’empreinte de référence sera mise à jour.', 'Valider').then(function (ok) { if (!ok) return; var cur = snapshot(); if (f.fixKey in cur) B.sig[f.fixKey] = cur[f.fixKey]; else delete B.sig[f.fixKey]; saveBase(); I.log('securite', 'Changement validé : ' + slabel(f.fixKey)); }); } };
    });

    /* 2. Horloge reculée */
    I.addRule({ id: 'sec.horloge', check: function () {
      var out = [], now = Date.now(), jump = clockJump || (bootClock - now > 600000 ? bootClock - now : 0);
      if (jump) out.push(F('erreur', 'Sécurité', 'L’horloge de l’appareil semble reculée d’environ ' + Math.max(1, Math.round(jump / 3600000)) + ' h (' + Math.round(jump / 60000) + ' min). Une licence ou une échéance peut être contournée : vérifiez la date de l’appareil.', 'clock'));
      var fut = audit().filter(function (a) { return tms(a.at) > now + 600000; }).length;
      if (fut) out.push(F('alerte', 'Sécurité', fut + ' entrée(s) du journal d’audit sont datées du futur (horloge modifiée ou journal altéré).', 'audfut|' + fut));
      return out; } });

    /* 3. Suppression massive de fiches */
    I.addRule({ id: 'sec.suppression', check: function () {
      var out = [], cur = counts(), dirty = false; I.collections.forEach(function (c) {
        var p = num(B.counts[c.k]), n = cur[c.k];
        if (p >= 8 && n <= p * 0.5) out.push(F('erreur', 'Sécurité', c.l + ' : ' + (p - n) + ' fiche(s) disparues d’un coup (' + p + ' → ' + n + '). Suppression massive, import ou synchronisation défaillante ?', c.k + '|' + p + '>' + n, { fixCol: c.k }));
        else if (n !== p) { B.counts[c.k] = n; dirty = true; }
      }); if (dirty) saveBase(); return out; } });
    I.addFixer('sec.suppression', function (f) { if (!f.fixCol) return null; return { label: 'C’est normal', run: function () { B.counts[f.fixCol] = list(f.fixCol).length; saveBase(); I.log('securite', 'Baisse d’effectif acceptée : ' + f.fixCol); } }; });

    /* 4. Journal d'audit : vidé / désordonné */
    I.addRule({ id: 'sec.audit', check: function () {
      var out = [], a = audit(), n = a.length, bad = 0, i;
      if (num(B.audN) >= 20 && n <= num(B.audN) * 0.5) out.push(F('erreur', 'Sécurité', 'Le journal d’audit a été vidé ou fortement réduit (' + B.audN + ' → ' + n + ' entrées).', 'audcut|' + B.audN + '>' + n, { fixAud: 1 }));
      else if (n > num(B.audN)) { B.audN = n; saveBase(); }
      for (i = 1; i < a.length; i++) if (tms(a[i].at) && tms(a[i - 1].at) && tms(a[i].at) > tms(a[i - 1].at) + 1000) bad++;
      if (bad) out.push(F('alerte', 'Sécurité', 'Le journal d’audit est dans le désordre (' + bad + ' entrée(s) plus récentes que celles qui les précèdent) : il a peut-être été modifié à la main.', 'audord|' + bad));
      return out; } });
    I.addFixer('sec.audit', function (f) { if (!f.fixAud) return null; return { label: 'C’est normal', run: function () { B.audN = audit().length; saveBase(); I.log('securite', 'Réduction du journal d’audit acceptée'); } }; });

    /* 5. Connexions : rafale d'échecs, réussite après échecs, verrou */
    I.addRule({ id: 'sec.connexion', check: function () {
      var out = [], a = audit(), now = Date.now(), win = 15 * 60000, fails = 0, lastFail = 0, okAfter = 0, i, A, t;
      for (i = a.length - 1; i >= 0; i--) { A = a[i]; t = tms(A.at); if (!t || now - t > win) continue; var act = norm(A.action || '');
        if (act.indexOf('connexion_echec') === 0 || act === 'connexion echec') { fails++; lastFail = t; }
        else if (/^connexion/.test(act) && fails >= 5 && t >= lastFail) okAfter = fails; }
      if (fails >= 10) out.push(F('erreur', 'Sécurité', fails + ' échecs de connexion en 15 minutes : tentative d’intrusion probable.', 'bf|' + fails));
      else if (fails >= 5) out.push(F('alerte', 'Sécurité', fails + ' échecs de connexion en 15 minutes.', 'bf|' + fails));
      if (okAfter) out.push(F('alerte', 'Sécurité', 'Une connexion a réussi juste après ' + okAfter + ' échecs : vérifiez que c’était bien vous.', 'okaf|' + okAfter + '|' + lastFail));
      var L = jget('exb_lock', null); if (L && num(L.until) > now) out.push(F('alerte', 'Sécurité', 'Le compte est actuellement verrouillé après des échecs de connexion (' + num(L.n) + ' tentatives).', 'lock|' + L.until));
      return out; } });

    /* 6. Injection : contenu suspect dans les fiches */
    var SUSP = /<\s*(script|iframe|object|embed|svg[^>]*onload)|\bon(error|load|click|dblclick|mouse[a-z]+|pointer[a-z]+|key[a-z]+|focus|blur|change|submit|toggle|animation[a-z]*|begin|start)\s*=\s*["']?[^>\s]|javascript\s*:|data\s*:\s*text\/html|<\s*img[^>]+onerror/i, BADID = /['"<>`\\${}();&\r\n]/;
    function scan(v, depth) { if (depth > 3 || v == null) return 0; if (typeof v === 'string') return v.length < 20000 && SUSP.test(v) ? 1 : 0; if (Array.isArray(v)) { for (var i = 0; i < v.length && i < 60; i++) if (scan(v[i], depth + 1)) return 1; return 0; } if (typeof v === 'object') { var ks = Object.keys(v); for (var j = 0; j < ks.length && j < 80; j++) { if (ks[j] === '__proto__' || ks[j] === 'constructor' && v[ks[j]] && typeof v[ks[j]] === 'object') return 1; if (scan(v[ks[j]], depth + 1)) return 1; } } return 0; }
    function badId(o) { return ['id', 'client_id', 'project_id', 'matricule'].some(function (k) { return typeof o[k] === 'string' && BADID.test(o[k]); }); }
    I.addRule({ id: 'sec.injection', check: function () {
      var out = []; I.collections.forEach(function (c) {
        var arr = list(c.k), hit = 0, ids = 0, firstN = -1;
        arr.forEach(function (o, n) { if (!o || typeof o !== 'object') return; if (scan(o, 0)) { hit++; if (firstN < 0) firstN = n + 1; } if (badId(o)) ids++; });
        if (hit) out.push(F('erreur', 'Sécurité', c.l + ' : ' + hit + ' fiche(s) contiennent du code ou une balise suspecte (script, onerror=, javascript:), première : fiche n° ' + firstN + '. Ne les ouvrez pas dans d’autres modules avant vérification.', c.k + '|inj|' + hit, { }));
        if (ids) out.push(F('alerte', 'Sécurité', c.l + ' : ' + ids + ' identifiant(s) contiennent des caractères dangereux (guillemets, chevrons, parenthèses) — import ou synchronisation hostile possible.', c.k + '|id|' + ids));
      }); return out; } });
    I.addRule({ id: 'sec.dom', check: function () {
      return slog().filter(function (l) { return l.type === 'dom'; }).slice(0, 3).map(function (l) { return F('erreur', 'Sécurité', l.msg + ' (' + l.at.slice(0, 16).replace('T', ' ') + ')', 'dom|' + l.at); }); } });

    /* 7. Fraude / erreur de saisie */
    function median(a) { a = a.slice().sort(function (x, y) { return x - y; }); var m = a.length >> 1; return a.length ? (a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2) : 0; }
    I.addRule({ id: 'sec.montants', check: function () {
      var out = [], cash = list('exb_cash').filter(function (c) { return num(c.amount) > 0; });
      if (cash.length >= 8) { var med = median(cash.map(function (c) { return num(c.amount); })); cash.forEach(function (c, n) { if (med > 0 && num(c.amount) > med * 20) out.push(F('alerte', 'Sécurité ↔ Caisse', 'Écriture de caisse « ' + lab(c) + ' » : montant ' + Math.round(num(c.amount)).toLocaleString('fr-FR') + ' soit plus de 20 fois la médiane (' + Math.round(med).toLocaleString('fr-FR') + ') : erreur de saisie ou fraude ?', 'exb_cash', c.id)); }); }
      var inv = list('exb_invoices').map(function (i) { return { i: i, t: I.calc.invoice(i).ttc }; }).filter(function (x) { return x.t > 0; });
      if (inv.length >= 8) { var mi = median(inv.map(function (x) { return x.t; })); inv.forEach(function (x) { if (mi > 0 && x.t > mi * 20) out.push(F('alerte', 'Sécurité ↔ Factures', 'Facture ' + lab(x.i) + ' : total ' + Math.round(x.t).toLocaleString('fr-FR') + ', plus de 20 fois la médiane (' + Math.round(mi).toLocaleString('fr-FR') + ').', 'exb_invoices', x.i.id)); }); }
      return out.slice(0, 20); } });
    I.addRule({ id: 'sec.historique', check: function () {
      var out = [], h = I.history ? I.history() : [], now = Date.now(), r = h.filter(function (e) { return e && e.col && now - tms(e.at) < 120000; }), dels = r.filter(function (e) { return e.op === 'suppression'; }).length;
      if (r.length >= 25) out.push(F('alerte', 'Sécurité', r.length + ' modifications de fiches en moins de 2 minutes (import, synchronisation ou action automatisée ?).', 'burst|' + (r[0] ? r[0].at : '')));
      if (dels >= 5) out.push(F('erreur', 'Sécurité', dels + ' suppressions de fiches en moins de 2 minutes.', 'burstdel|' + (r[0] ? r[0].at : '')));
      var inv = list('exb_invoices'), seen = {};
      h.filter(function (e) { return e && e.col === 'exb_invoices' && e.op === 'modification'; }).forEach(function (e) {
        var iv = inv.filter(function (x) { return x.id === e.id; })[0]; if (!iv || seen[e.id] || !(iv.payments || []).some(function (p) { return num(p.amount) > 0; })) return;
        if ((e.fields || []).some(function (f) { return /^(lines|tva|total|no|date|client|client_id)$/.test(f.f); })) { seen[e.id] = 1; out.push(F('alerte', 'Sécurité ↔ Factures', 'Facture ' + lab(iv) + ' déjà payée puis modifiée (' + e.fields.map(function (f) { return f.f; }).join(', ') + ') le ' + String(e.at).slice(0, 16).replace('T', ' ') + '.', 'exb_invoices', e.id)); }
      }); return out; } });

    /* ================= DOCUMENT, RECOMMANDATIONS, ASSISTANT ================= */
    function secFindings() { return I.findings().filter(function (f) { return f.mod && f.mod.indexOf('Sécurité') === 0; }); }
    function score() { var s = 100; secFindings().forEach(function (f) { s -= f.sev === 'erreur' ? 25 : f.sev === 'alerte' ? 10 : 2; }); return Math.max(0, s); }
    function secHtml() {
      var f = secFindings(), rows = f.map(function (x) { return '<tr><td>' + esc(x.sev) + '</td><td>' + esc(x.msg) + '</td></tr>'; }).join(''), lg = slog().slice(0, 40).map(function (l) { return '<tr><td>' + esc(l.at.slice(0, 16).replace('T', ' ')) + '</td><td>' + esc(l.type) + '</td><td>' + esc(l.msg) + '</td></tr>'; }).join('');
      return '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Rapport de sécurité</title><body style="font-family:Arial;margin:24px;color:#12254a"><h1>Rapport de sécurité</h1><p>' + new Date().toLocaleString('fr-FR') + ' — indice de sécurité : <b>' + score() + ' / 100</b> — ' + f.length + ' constat(s)</p><h2>Constats</h2><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Gravité</th><th>Constat</th></tr>' + (rows || '<tr><td colspan="2">Aucun constat</td></tr>') + '</table><h2>Journal de sécurité (40 derniers événements)</h2><table border="1" cellpadding="6" style="border-collapse:collapse;width:100%"><tr><th>Date</th><th>Type</th><th>Événement</th></tr>' + (lg || '<tr><td colspan="3">Aucun événement</td></tr>') + '</table><p style="font-size:12px;color:#556">Surveillance côté navigateur : elle détecte les altérations simples et les erreurs, elle ne remplace ni un antivirus ni la sécurité du serveur (RLS, 2FA).</p></body></html>';
    }
    I.docs = I.docs || {}; I.docs.securite = secHtml;
    function dl(name, html) { try { var b = new Blob([html], { type: 'text/html' }), a = d.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; d.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); I.log('document', 'Rapport de sécurité exporté'); } catch (e) { toast('Export impossible.'); } }
    I.addReco(function () {
      var r = [], lb = num(jget('exb_last_backup', 0)), t = lb ? (typeof lb === 'number' && lb > 1e11 ? lb : tms(lb)) : 0, days = t ? Math.floor((Date.now() - t) / 864e5) : null;
      if (days === null || days > 7) r.push({ ic: '💾', t: days === null ? 'Aucune sauvegarde récente enregistrée' : 'Dernière sauvegarde il y a ' + days + ' jours', x: 'Une sauvegarde récente est la meilleure parade à une suppression massive ou à une altération.', acts: [{ l: 'Ouvrir les paramètres', f: function () { H.go('parametres'); } }] });
      r.push({ ic: '🛡️', t: 'Indice de sécurité : ' + score() + ' / 100', x: secFindings().length ? secFindings().length + ' constat(s) de sécurité à examiner.' : 'Aucune menace détectée par la surveillance locale.', acts: [{ l: 'Télécharger le rapport de sécurité', f: function () { dl('rapport-securite-' + H.today() + '.html', secHtml()); } }] });
      return r; });
    I.sec = { score: score, journal: slog, report: secHtml, findings: secFindings, scan: function (o) { return scan(o, 0); },
      accept: function (k) { var c = snapshot(); if (k in c) B.sig[k] = c[k]; else delete B.sig[k]; live[k] = c[k]; saveBase(); } };
    function answer() { var f = secFindings(), s = f.filter(function (x) { return x.sev !== 'info'; }).slice(0, 6).map(function (x) { return '• ' + x.msg; }); return 'Indice de sécurité : ' + score() + ' / 100. ' + (f.length ? f.length + ' constat(s) de sécurité :\n' + s.join('\n') : 'Aucune menace détectée par la surveillance locale (intégrité des réglages, horloge, journal d’audit, connexions, injection, montants).') + '\nLa surveillance locale ne remplace pas la sécurité du serveur.'; }
    function hookSec() { try { if (typeof w.localAI === 'function' && !(w.__exbAIHooks = w.__exbAIHooks || {}).sec) { (w.__exbAIHooks = w.__exbAIHooks || {}).sec = 1; var l = w.localAI; w.localAI = function (raw) { try { if (/\b(menace|securite|intrusion|piratage|pirate|virus|integrite|horloge|qui a modifie|journal de securite|fraude|injection|attaque)/.test(norm(raw))) { I.run(); return { answer: answer(), actions: [] }; } } catch (e) {} return l.apply(this, arguments); }; w.localAI.__sec = 1; } } catch (e) {} }
    var n2 = 0, t2 = setInterval(function () { hookSec(); if (++n2 > 40) clearInterval(t2); }, 750);
    I.run();
  }
  boot(0);
})(window, document);
