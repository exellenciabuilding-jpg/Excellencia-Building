/* Excellencia Building V64 — Planning de Gantt (semaine par semaine) + Budget de construction (26 postes, prévisionnel / réel / écart).
 * Reprend les feuilles « Planning Gantt » (classeur Metrec 2026) et « Budget_Construction_Immeuble ». */
(function(){'use strict';
var K={g:'exb_gantt',b:'exb_budgets'};
var $=i=>document.getElementById(i),ST={tab:'g',pid:''};
var esc=v=>String(v==null?'':v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
var fx=(x,d)=>Number(x||0).toLocaleString('fr-FR',{minimumFractionDigits:d==null?2:d,maximumFractionDigits:d==null?2:d}).replace(/[\u202f\u00a0]/g,' ');
var today=()=>new Date().toISOString().slice(0,10);
var say=(t,k)=>{try{notify(t,k||'info',4500)}catch(e){alert(t)}};
var L=k=>{try{return load(K[k],[])}catch(e){return[]}},S=(k,a)=>save(K[k],a);
var projs=()=>typeof exbProjects!=='undefined'?exbProjects:[],proj=id=>projs().find(p=>p.id===id);
var rec=(k,pid)=>L(k).find(x=>x.project_id===pid);
var put=(k,o)=>{var a=L(k),i=a.findIndex(x=>x.id===o.id);if(i>=0)a[i]=o;else a.push(o);S(k,a)};
var popt=s=>'<option value="">— Choisir un chantier —</option>'+projs().map(p=>`<option value="${esc(p.id)}"${p.id===s?' selected':''}>${esc(p.name)}</option>`).join('');
var btn=(t,c,cl)=>`<button class="${cl||'muted'}" onclick="EXBPL.${c}">${t}</button>`;
var num=(v,c,w)=>`<input type="number" step="any" value="${esc(v)}" onchange="EXBPL.${c.replace('§','this.value')}" style="width:${w||'70px'}">`;
var txt=(v,c,w)=>`<input value="${esc(v)}" onchange="EXBPL.${c.replace('§','this.value')}" style="width:${w||'100%'}">`;
var dstr=(s,add)=>{var d=new Date(s+'T00:00:00');d.setDate(d.getDate()+add);return d.toISOString().slice(0,10)};
var dfr=s=>s?s.slice(8,10)+'/'+s.slice(5,7):'';

/* =================== GANTT =================== */
var MODEL=[['Implantation & terrassement',1,1,0],['Fondations',1,2,0],['Élévation des murs et chaînage bas RDC',2,2,0],['Poteaux & chaînage haut RDC',3,3,0],['Dalle / plancher haut RDC',4,2,0],['Élévation des murs étage',6,7,0],['Poteaux, chaînage haut & toiture',7,2,0],['Enduits intérieurs & extérieurs',8,2,0],['Plomberie & électricité',9,2,0],['Peinture & finitions',10,2,0]];
var G=pid=>rec('g',pid);
function nW(g){var m=20;g.tasks.forEach(t=>{m=Math.max(m,(+t.start||1)+(+t.dur||1)-1)});return m}
/* même règle que la feuille Excel : 0 = rien, 1 = planifié, 2 = réalisé */
function cell(t,w){var s=+t.start||1,d=+t.dur||0,p=Math.min(Math.max((+t.pct||0)/100,0),1);if(!(w>=s&&w<s+d))return 0;return w<s+d*p?2:1}
function gAv(g){var sd=g.tasks.reduce((a,t)=>a+(+t.dur||0),0);return sd>0?g.tasks.reduce((a,t)=>a+(+t.dur||0)*(+t.pct||0),0)/sd:0}
function curWeek(g){if(!g.date)return 0;return Math.floor((new Date(today())-new Date(g.date))/6048e5)+1}
function tStat(g,t){var p=+t.pct||0;if(p>=100)return['Terminé','#15803d'];var cw=curWeek(g),s=+t.start||1,d=+t.dur||1;if(cw){var plan=Math.min(Math.max((cw-s+1)/d,0),1)*100;if(cw>=s+d||plan-p>10)return['En retard','#b91c1c'];if(cw<s)return['À venir','#6b7280']}return p>0?['En cours','#1d4ed8']:['À venir','#6b7280']}
var COL=['transparent','#cbd5e1','#1a3a6b'];
function gTable(g,edit,printing){var n=nW(g),cw=curWeek(g),cp=(typeof EXBCPM!=='undefined')?EXBCPM.compute(g.tasks,cw):{tasks:[]},h='<table class="exb-table" style="border-collapse:collapse;font-size:'+(printing?9:12)+'px"><thead><tr><th>N°</th><th style="min-width:'+(printing?160:170)+'px">Tâche</th><th>Début<br>(sem.)</th><th>Durée<br>(sem.)</th><th>Avanc.<br>%</th><th>Préd.</th><th>Marge<br>(sem.)</th><th>État</th>';
 for(var w=1;w<=n;w++)h+=`<th style="padding:2px 3px;text-align:center;${w===cw?'background:#fde68a;color:#000':''}">S${w}${g.date?'<br><small style="font-weight:400">'+dfr(dstr(g.date,(w-1)*7))+'</small>':''}</th>`;
 h+=(edit?'<th></th>':'')+'</tr></thead><tbody>';
 g.tasks.forEach((t,i)=>{var st=tStat(g,t),o=cp.tasks[i]||{};h+=`<tr><td>${i+1}</td><td>${o.critique?'🔴 ':''}${edit?txt(t.name,"tf("+i+",'name',§)"):esc(t.name)}</td><td>${edit?num(t.start,"tf("+i+",'start',+§)",'52px'):esc(t.start)}</td><td>${edit?num(t.dur,"tf("+i+",'dur',+§)",'52px'):esc(t.dur)}</td><td>${edit?num(t.pct,"tf("+i+",'pct',+§)",'56px'):esc(t.pct)}</td><td>${edit?txt(t.pred||'',"tf("+i+",'pred',§)",'70px'):esc(t.pred||'')}${o.conflit?'<span title="Début saisi avant la fin des prédécesseurs (au plus tôt : semaine '+o.conflit+')"> ⚠</span>':''}</td><td style="text-align:center;white-space:nowrap">${o.marge==null?'':(o.critique?'<b style="color:#b91c1c">0</b>':o.marge)}</td><td style="color:${st[1]};font-weight:700;white-space:nowrap">${st[0]}</td>`;
  for(var w=1;w<=n;w++){var c=cell(t,w);h+=`<td style="min-width:${printing?13:20}px;border:1px solid #e5e7eb;background:${(o.critique&&c)?(c===2?'#b91c1c':'#fca5a5'):COL[c]};-webkit-print-color-adjust:exact;print-color-adjust:exact"></td>`}
  h+=(edit?`<td>${btn('×',"delT("+i+")",'danger')}</td>`:'')+'</tr>'});
 return h+'</tbody></table>'}
function vGantt(){var pid=ST.pid;if(!pid)return '<p class="exb-muted">Choisissez un chantier pour afficher son planning.</p>';var g=G(pid);
 if(!g)return `<p class="exb-muted">Aucun planning pour ce chantier.</p><div class="exb-actions">${btn('📋 Créer avec le modèle (10 tâches du classeur)','newG(true)','primary')}${btn('➕ Planning vide','newG(false)')}</div>`;
 var av=gAv(g),late=g.tasks.filter(t=>tStat(g,t)[0]==='En retard').length,p=proj(pid),cp=EXBCPM.compute(g.tasks,curWeek(g)),bad=g.tasks.reduce((a,t,i)=>a.concat(EXBCPM.parsePred(t.pred,g.tasks.length,i).bad.map(b=>(i+1)+' : « '+b+' »')),[]);
 return `<div class="exb-grid"><div class="exb-card"><b style="font-size:20px">${fx(av,1)} %</b><br><small>Avancement global (pondéré par les durées)</small></div><div class="exb-card"><b style="font-size:20px;color:${late?'#b91c1c':'#15803d'}">${late}</b><br><small>Tâche(s) en retard${g.date?'':' (indiquez la date de la semaine 1)'}</small></div><div class="exb-card"><b style="font-size:20px">${nW(g)}</b><br><small>Semaines${g.date?' — S1 le '+esc(g.date.split('-').reverse().join('/')):''}</small></div>${cp.error?'<div class="exb-card"><b style="font-size:20px;color:#b91c1c">⛔</b><br><small>Dépendances circulaires (tâches '+cp.cycle.join(', ')+')</small></div>':'<div class="exb-card"><b style="font-size:20px;color:#b91c1c">'+cp.critiques.length+'</b><br><small>Tâche(s) sur le chemin critique'+(cp.critiques.length?' : '+cp.critiques.join(' → '):'')+'</small></div><div class="exb-card"><b style="font-size:20px;color:'+(cp.retardProjet?'#b91c1c':'#15803d')+'">'+(cp.finPrevue===null?'—':(cp.retardProjet?'+'+cp.retardProjet+' sem.':'0'))+'</b><br><small>Retard prévisionnel du projet'+(cp.finPrevue===null?' (indiquez la date de la semaine 1)':' (fin prévue S'+cp.finPrevue+' pour S'+cp.fin+')')+'</small></div>'}</div>${cp.conflits&&cp.conflits.length?'<p style="color:#b45309">⚠ Tâche(s) '+cp.conflits.join(', ')+' : le début saisi précède la fin des prédécesseurs. Utilisez « Recaler ».</p>':''}${bad.length?'<p style="color:#b45309">⚠ Prédécesseur(s) invalide(s) — tâche '+bad.map(esc).join(' ; ')+'</p>':''}
 <div class="exb-actions" style="align-items:end"><div><label>Date de début (semaine 1)</label><input type="date" value="${esc(g.date||'')}" onchange="EXBPL.gdate(this.value)"></div>${btn('➕ Tâche','addT()','primary')}${btn('🔗 Enchaîner','chain()')}${btn('↻ Recaler selon les liens','recal()')}${btn('🖨 Imprimer / PDF','printG()')}${p?btn('⬆ Avancement → projet ('+fx(av,0)+' %)','toProj()'):''}${btn('🗑 Supprimer','delG()','danger')}</div>
 <div class="exb-scroll" style="overflow-x:auto">${gTable(g,true)}</div><p class="exb-muted"><span style="display:inline-block;width:12px;height:12px;background:${COL[1]}"></span> planifié &nbsp; <span style="display:inline-block;width:12px;height:12px;background:${COL[2]}"></span> réalisé &nbsp; Semaine en cours surlignée. Modifiez « Début », « Durée » et « Avancement » : le diagramme se met à jour. <b>Préd.</b> : numéros des tâches à terminer avant (ex. « 1, 3+1 » = après la 1, et après la 3 avec 1 semaine de décalage). 🔴 = chemin critique (marge 0 : tout retard retarde la fin). Le « Début » saisi est une contrainte « pas avant ».</p>`}

/* =================== BUDGET =================== */
var POSTES=[["COÛT D'ACHAT DU TERRAIN",40000],['COÛTS PRÉPARATOIRES (études, géotechnique, topo)',8000],['PRÉPARATION DU TERRAIN',3000],['ASSAINISSEMENT (si non collectif)',6000],['SERVICES COLLECTIFS (raccordements eau/élec/égouts)',4600],['TERRASSEMENT',6000],['FONDATIONS',12000],['MAÇONNERIE (GROS ŒUVRE)',20000],['CHARPENTE ET TOITURE',34000],['FAÇADE',16000],['FENÊTRES / PORTES (menuiseries extérieures)',17200],['PLOMBERIE',11500],['ÉLECTRICITÉ',5800],['CLIMATISATION ET CHAUFFAGE',14500],['ISOLATION',30000],['PLACO-PLÂTRE / CLOISONS',18000],['SOLS ET FINITION INTÉRIEURE',24000],['CUISINE & SALLE DE BAINS',25000],['PORCHES & TERRASSES',2850],['ÉQUIPEMENT ÉLECTRO-MÉNAGER',0],['PEINTURE & FINITIONS',9000],["HONORAIRES (architecte, bureau d'études)",15000],['ASSURANCES & GARANTIES (dommage-ouvrage, décennale)',6000],['FRAIS ADMINISTRATIFS (permis, taxes)',4000],['IMPRÉVUS / PROVISION POUR ALÉAS',0],['RÉCEPTION DES TRAVAUX (contrôle final, levée réserves)',1500]];
var ALEA=24; /* index du poste « imprévus » */
var B=pid=>rec('b',pid);
function bTot(b){var r={b:0,r:0};b.postes.forEach(p=>{r.b+=+p.b||0;r.r+=+p.r||0});r.e=r.r-r.b;r.pct=r.b>0?r.r/r.b*100:0;return r}
function cashOut(pid){return (typeof exbCash!=='undefined'?exbCash:[]).filter(c=>c.type==='out'&&c.project_id===pid).reduce((a,c)=>a+(+c.amount||0),0)}
function vBudget(){var pid=ST.pid;if(!pid)return '<p class="exb-muted">Choisissez un chantier pour gérer son budget de construction.</p>';var b=B(pid);
 if(!b)return `<p class="exb-muted">Aucun budget pour ce chantier.</p><div class="exb-actions">${btn('➕ Budget vide (26 postes)','newB(false)','primary')}${btn('📋 Répartir un budget total selon le modèle Excel','newB(true)')}</div>`;
 var t=bTot(b),ca=cashOut(pid),p=proj(pid),over=b.postes.filter(x=>(+x.r||0)>(+x.b||0)&&(+x.b||0)>0).length;
 var h=`<div class="exb-grid"><div class="exb-card"><b style="font-size:18px">${fx(t.b)} $</b><br><small>Budget prévisionnel</small></div><div class="exb-card"><b style="font-size:18px">${fx(t.r)} $</b><br><small>Coût réel (${fx(t.pct,1)} %)</small></div><div class="exb-card"><b style="font-size:18px;color:${t.e>0?'#b91c1c':'#15803d'}">${t.e>0?'+':''}${fx(t.e)} $</b><br><small>Écart (réel − budget)${t.e>0?' : dépassement':''}</small></div><div class="exb-card"><b style="font-size:18px">${fx(t.b-t.r)} $</b><br><small>Reste à dépenser</small></div></div>`;
 if(over)h+=`<p style="color:#b91c1c">⛔ ${over} poste(s) dépassent leur budget.</p>`;
 if(ca>0)h+=`<p class="exb-muted">Dépenses de caisse imputées à ce projet : <b>${fx(ca)} $</b>${ca>t.r+0.005?' — supérieures au coût réel saisi ci-dessous ('+fx(ca-t.r)+' $ non affectés à un poste).':'.'}</p>`;
 h+=`<div class="exb-actions" style="align-items:end"><div><label>Provision pour aléas (%)</label>${num(b.alea,"bAlea(+§)",'70px')}</div>${btn('🧮 Calculer la provision','calcAlea()')}${btn('➕ Poste','addP()')}${btn('📄 PDF','pdfB()')}${p?btn('⬆ Budget → projet','toBud()'):''}${btn('🗑','delB()','danger')}</div>`;
 h+=`<div class="exb-scroll"><table class="exb-table"><thead><tr><th>N°</th><th>Poste de dépense</th><th>Budget ($)</th><th>Coût réel ($)</th><th>Écart ($)</th><th>%</th><th>Commentaire</th><th></th></tr></thead><tbody>`+b.postes.map((x,i)=>{var e=(+x.r||0)-(+x.b||0),pc=(+x.b||0)>0?(+x.r||0)/(+x.b)*100:0;return `<tr><td>${i+1}</td><td style="min-width:190px">${txt(x.label,"pf("+i+",'label',§)")}</td><td>${num(x.b,"pf("+i+",'b',+§)",'95px')}</td><td>${num(x.r,"pf("+i+",'r',+§)",'95px')}</td><td style="color:${e>0?'#b91c1c':'inherit'};white-space:nowrap">${e>0?'+':''}${fx(e)}</td><td style="min-width:70px"><div style="background:#e5e7eb;border-radius:4px;height:8px"><div style="width:${Math.min(pc,100)}%;height:8px;border-radius:4px;background:${pc>100?'#b91c1c':pc>85?'#d97706':'#15803d'}"></div></div><small>${fx(pc,0)} %</small></td><td>${txt(x.c,"pf("+i+",'c',§)",'130px')}</td><td>${btn('×',"delP("+i+")",'danger')}</td></tr>`}).join('')+`<tr style="font-weight:700"><td></td><td>TOTAL GÉNÉRAL</td><td>${fx(t.b)}</td><td>${fx(t.r)}</td><td>${fx(t.e)}</td><td></td><td></td><td></td></tr></tbody></table></div><p class="exb-muted">Écart positif = dépassement du budget (même règle que le classeur Excel).</p>`;
 return h}

/* =================== ACTIONS =================== */
function head(){return `<div class="exb-actions" style="flex-wrap:wrap">${[['g','📅 Planning de Gantt'],['b','💰 Budget de construction']].map(x=>`<button class="${x[0]===ST.tab?'primary':'muted'}" onclick="EXBPL.tab('${x[0]}')">${x[1]}</button>`).join('')}</div><label>Chantier</label><select onchange="EXBPL.pid(this.value)">${popt(ST.pid)}</select>`}
function render(){var b=$('exbpl_box');if(!b)return;b.innerHTML=head()+(ST.tab==='g'?vGantt():vBudget())}
function cur(k){return k==='g'?G(ST.pid):B(ST.pid)}
var A={render:render,_cell:cell,_av:gAv,_bTot:bTot,
 tab:t=>{ST.tab=t;render()},pid:v=>{ST.pid=v;render()},
 newG:m=>{if(!ST.pid)return;put('g',{id:exbId('GA'),project_id:ST.pid,date:today(),tasks:m?MODEL.map((x,i)=>({id:exbId('T'),name:x[0],start:x[1],dur:x[2],pct:x[3]})):[{id:exbId('T'),name:'Nouvelle tâche',start:1,dur:1,pct:0}]});render()},
 gdate:v=>{var g=G(ST.pid);g.date=v;put('g',g);render()},
 tf:(i,k,v)=>{var g=G(ST.pid);g.tasks[i][k]=(k==='name')?v:(k==='pred')?String(v).replace(/[^0-9,;+\-\s]/g,''):Math.max(0,+v||0);if(k==='pct')g.tasks[i].pct=Math.min(100,g.tasks[i].pct);if((k==='start'||k==='dur')&&g.tasks[i][k]<1)g.tasks[i][k]=1;put('g',g);render()},
 addT:()=>{var g=G(ST.pid),l=g.tasks[g.tasks.length-1];g.tasks.push({id:exbId('T'),name:'Nouvelle tâche',start:l?(+l.start||1)+(+l.dur||1):1,dur:1,pct:0});put('g',g);render()},
 delT:i=>{var g=G(ST.pid),pr=EXBCPM.apresSuppression(g.tasks,i+1);g.tasks.splice(i,1);g.tasks.forEach((t,j)=>{t.pred=pr[j<i?j:j+1]});put('g',g);render()},
 chain:()=>{var g=G(ST.pid),p=EXBCPM.enchainer(g.tasks);g.tasks.forEach((t,i)=>{t.pred=p[i]});put('g',g);render()},
 recal:()=>{var g=G(ST.pid),r=EXBCPM.recaler(g.tasks);if(r.error)return say('Dépendances circulaires : corrigez les liens (tâches '+r.cycle.join(', ')+').','warn');if(!confirm('Recaler les débuts de toutes les tâches selon les dépendances ?'))return;g.tasks.forEach((t,i)=>{t.start=r.starts[i]});put('g',g);render()},
 delG:()=>{if(confirm('Supprimer le planning de ce chantier ?')){S('g',L('g').filter(x=>x.project_id!==ST.pid));render()}},
 toProj:()=>{var g=G(ST.pid),p=proj(ST.pid),v=Math.round(gAv(g));if(!p||!confirm('Mettre l\'avancement du projet à '+v+' % ?'))return;p.progress=v;exbSave(EXB_ECO_KEYS.projects,exbProjects);try{renderExbProjects()}catch(e){}say('Avancement du projet mis à jour.','success')},
 printG:()=>{var g=G(ST.pid);EXBPrint.html('Planning de Gantt — '+pname(),'<!doctype html><meta charset="utf-8"><title>Planning '+esc(proj(ST.pid)&&proj(ST.pid).name)+'</title><style>@page{size:A4 landscape;margin:10mm}body{font-family:Arial,sans-serif;color:#111}h1{font-size:16px;margin:0 0 4px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #d1d5db;padding:2px 4px;text-align:left}th{background:#1a3a6b;color:#fff}</style><h1>EXCELLENCIA BUILDING — Planning de Gantt</h1><p style="font-size:11px;margin:0 0 8px">Chantier : '+esc(pname())+' — avancement global : <b>'+fx(gAv(g),1)+' %</b> — édité le '+today().split('-').reverse().join('/')+'</p>'+gTable(g,false,true)+'<p style="font-size:10px">Gris : planifié — Bleu : réalisé.</p>',{landscape:true})},
 /* budget */
 newB:sc=>{if(!ST.pid)return;var p=proj(ST.pid),tot=0,al=8;if(sc){var d=prompt('Budget total du projet ($), provision pour aléas incluse :',(p&&+p.budget)||333950);if(d===null)return;tot=+String(d).replace(/\s/g,'').replace(',','.')||0;if(!(tot>0))return say('Montant invalide.','warn')}
  var base=POSTES.reduce((a,x)=>a+x[1],0),f=sc?tot/(base*(1+al/100)):0,po=POSTES.map((x,i)=>({label:x[0]+(i===ALEA?' ('+al+' %)':''),b:i===ALEA?0:Math.round(x[1]*f),r:0,c:''}));
  if(sc){var s0=po.reduce((a,x,j)=>a+(j===ALEA?0:x.b),0);po[ALEA].b=Math.max(0,tot-s0)}
  put('b',{id:exbId('BU'),project_id:ST.pid,alea:al,postes:po});render()},
 bAlea:v=>{var b=B(ST.pid);b.alea=Math.max(0,v);put('b',b)},
 calcAlea:()=>{var b=B(ST.pid),i=ALEA;if(!b.postes[i])return say('Poste « imprévus » introuvable.','warn');var s=b.postes.reduce((a,x,j)=>a+(j===i?0:+x.b||0),0);b.postes[i].b=Math.round(s*(+b.alea||0)/100);b.postes[i].label=b.postes[i].label.replace(/\s*\([\d.,]+\s*%\)\s*$/,'')+' ('+b.alea+' %)';put('b',b);say('Provision de '+fx(b.postes[i].b)+' $ calculée.','success');render()},
 pf:(i,k,v)=>{var b=B(ST.pid);b.postes[i][k]=(k==='label'||k==='c')?v:Math.max(0,+v||0);put('b',b);render()},
 addP:()=>{var b=B(ST.pid);b.postes.push({label:'Nouveau poste',b:0,r:0,c:''});put('b',b);render()},
 delP:i=>{var b=B(ST.pid);if(confirm('Supprimer ce poste ?')){b.postes.splice(i,1);put('b',b);render()}},
 delB:()=>{if(confirm('Supprimer le budget de ce chantier ?')){S('b',L('b').filter(x=>x.project_id!==ST.pid));render()}},
 toBud:()=>{var b=B(ST.pid),p=proj(ST.pid),t=bTot(b);if(!p||!confirm('Définir le budget du projet à '+fx(t.b)+' $ ? (utilisé dans « Chantiers & finances »)'))return;p.budget=+t.b.toFixed(2);exbSave(EXB_ECO_KEYS.projects,exbProjects);try{renderExbProjects()}catch(e){}say('Budget du projet mis à jour.','success')},
 pdfB:()=>{var b=B(ST.pid),t=bTot(b),rows=[['Chantier',pname()],['Budget / réel / écart',fx(t.b)+' $ / '+fx(t.r)+' $ / '+(t.e>0?'+':'')+fx(t.e)+' $'],['Part du budget consommée',fx(t.pct,1)+' %']];
  b.postes.forEach((x,i)=>rows.push([(i+1)+'. '+x.label,'Budget '+fx(x.b)+' $  |  Réel '+fx(x.r)+' $  |  Écart '+((+x.r||0)-(+x.b||0)>0?'+':'')+fx((+x.r||0)-(+x.b||0))+' $'+(x.c?'  —  '+x.c:'')]));
  EXBPdf.make({titre:'BUDGET DE CONSTRUCTION',sousTitre:pname()+' — édité le '+today().split('-').reverse().join('/'),rows:rows,notes:['Écart positif = dépassement du budget prévisionnel.'],footer:'Budget — '+pname()+' — Excellencia Building'}).then(x=>EXBPdf.save(x,'budget-construction.pdf'))}
};
function pname(){var p=proj(ST.pid);return p?p.name:'—'}
A._cpm=function(){return EXBCPM.compute(G(ST.pid).tasks,curWeek(G(ST.pid)))};window.EXBPL=A;
function mount(){if($('plangantt'))return;var ref=$('terrain')||$('chantiers')||$('projets'),host=document.querySelector('.wrap')||document.querySelector('main')||document.body,s=document.createElement('section');s.id='plangantt';s.style.display='none';
 s.innerHTML='<div class="card"><div class="exb-module-head"><div><h2>📅 Planning &amp; budget</h2><p class="exb-muted">Diagramme de Gantt semaine par semaine et budget de construction (prévisionnel, réel, écart) par chantier.</p></div></div><div id="exbpl_box"></div></div>';
 if(ref&&ref.parentNode)ref.parentNode.insertBefore(s,ref.nextSibling);else host.appendChild(s);
 var b=$('bterr')||$('bchan')||$('bprj');if(b&&!$('bplan')){var n=document.createElement('button');n.id='bplan';n.textContent='📅 Planning & budget';n.setAttribute('onclick',"show('plangantt')");b.parentNode.insertBefore(n,b.nextSibling)}
 var os=window.show;if(typeof os==='function'&&!window.__exbPlShow){window.__exbPlShow=1;window.show=function(x){var r=os.apply(this,arguments),e=$('plangantt');if(e)e.style.display=(x==='plangantt')?'':'none';if(x==='plangantt')render();return r}}
 render()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(mount,700)});else setTimeout(mount,700);
})();
