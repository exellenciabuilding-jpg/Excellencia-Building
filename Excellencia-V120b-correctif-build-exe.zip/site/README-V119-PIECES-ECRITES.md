# V119 — Pièces écrites renforcées + PDF officiel Excellencia Building

## Nouveautés
- **10 types de pièces** : CCTP, CCAP, Lettre, Compte rendu, Ordre de service, **Procès-verbal, Attestation, Contrat / convention, Note / rapport / fiche, Texte libre**.
- **Plus de 60 modèles** pré-remplis (projet, client, maître d'ouvrage, lieu, phase, société, Directeur Général, ville, contacts) : lettres (mise en demeure, relance de paiement, non-conformité, offre de services…), PV (réception provisoire/définitive, levée de réserves, constat contradictoire…), contrats (sous-traitance, prestation d'études, suivi de chantier…), attestations, rapports de visite, rapport d'accident, bon de commande, présentation de l'entreprise…
- **CCTP à la carte** : 19 lots à cocher (au lieu de 11 questions successives).
- **Texte libre / texte vierge** pour chaque type : on écrit ce qu'on veut.
- **Barre d'outils de rédaction** : titre, sous-titre, puce, liste numérotée, gras, tableau (colonnes/lignes au choix), saut de page, insertion de données {{projet}}, {{lieu}}…, **aperçu** avant PDF.
- **« Mes modèles »** : « ⭐ Enregistrer comme modèle » sur n'importe quelle pièce → réutilisable sur d'autres projets (renommer, supprimer).
- **PDF officiel Excellencia Building** : en-tête (logo, nom, slogan, adresse, téléphone, e-mail) et pied de page (mentions légales RCCM/Id. Nat., référence, pagination « Page 1 / 3 ») sur **chaque page** ; bloc de référence ; signature du Directeur Général **avec signature + cachet** quand l'état est « émis » ou « signé » (en « brouillon », l'espace reste vide pour signature manuelle) ; choix « Directeur Général / les 3 parties / aucune ».
- **QR code de vérification** dans le pied de page de chaque page (même système que les devis et reçus : le scan ouvre la page publique de vérification ; le code court est imprimé à côté).
- Les informations viennent de **Identité des documents** (Logo Excellencia Building) : une seule saisie, reprise partout.

## Fichiers
Nouveau : `site/exb-v81-pieces-modeles.js` · Modifiés : `site/exb-v81-pieces.js`, `site/index.html`, `site/sw.js` (cache v119), `site/tools/check.js`.
Les pièces déjà enregistrées restent lisibles (même stockage `exb_pieces`).
Retour en arrière : restaurer l'ancien `exb-v81-pieces.js` et retirer la balise `<script src="exb-v81-pieces-modeles.js">`.

## Tests
`node tools/check.js` : 509 contrôles, 0 échec. Rendu PDF vérifié dans Chromium (lettre, CCTP 3 pages, PV, texte libre).
Les modèles sont des bases à adapter : faire valider les clauses contractuelles par votre conseil juridique.

## V119b — QR de vérification sur la PAGE DE GARDE de tous les PDF
Avant : le générateur commun `exb-pdf.js` dessinait le QR sur les pages suivantes mais pas sur la page de garde.
Maintenant : QR + « Scannez ce QR pour vérifier l'authenticité de ce document » + code, en bas à gauche de la page de garde, face à la signature et au cachet. Concerne tous les PDF fabriqués par `EXBPdf.make` (fiches, budgets, décomptes, planning, chantiers, études, réception, facility, contrôles, terrain…). Les devis/factures, attestations TFL, notes de calcul de structure et cartes avaient déjà leur QR.
Désactivation éventuelle pour un document précis : `verify:false` dans les options du PDF.
