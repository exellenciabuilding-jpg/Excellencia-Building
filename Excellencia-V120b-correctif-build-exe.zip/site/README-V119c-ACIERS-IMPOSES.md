# V119c — Aciers imposés (module de calcul de structure)

Principe repris de Robot Structural Analysis : l'utilisateur impose le diamètre des barres, le calcul n'utilise que ce diamètre et indique quoi faire si la section d'acier fournie est inférieure à la section requise.

## Où régler
- Poutre : carte « Aciers imposés » (Ø longitudinal, Ø cadres).
- Poteau : carte « Aciers imposés » (Ø longitudinal, Ø cadres).
- Plus d'options : les quatre réglages. Le Bâtiment les utilise aussi (poutres et poteaux).
- « Automatique » = comportement précédent (diamètre le plus économique).

## Ce que fait le calcul
- Poutre : As requise comparée à As fournie (nombre de barres limité par la largeur et l'espacement libre ≥ max(Ø ; 25 mm)).
- Si insuffisant, message de solutions chiffrées : diamètre supérieur, deux lits, largeur b, hauteur h.
- Cadres imposés : contrôle φt ≥ φl/3 (BAEL) ou ≥ max(6 ; φl/4) (EC2) et φt ≤ maximum admis.
- Poteau : mêmes principes, avec solution « élargir la section » (BAEL et EC2).

## Extension (étriers, épingles, dalle, semelle, escalier)
- Poutre : Ø des étriers, nombre de brins (2 à 4), espacement imposé (alerte s'il dépasse le maximum calculé).
- Poteau : Ø des cadres, espacement imposé, Ø des épingles (utilisé dans le métré et sur le plan).
- Dalle et plancher multi-travées : Ø et espacement des nappes. Escalier : Ø et espacement des nappes. Semelle : Ø des nappes.
- Si la disposition imposée ne suffit pas : message avec solutions chiffrées (diamètre supérieur, espacement réduit, épaisseur ou hauteur).

## Plan de la poutre selon les brins (reporté sur V119g)
- 3 brins : une épingle verticale à chaque position de cadre (coupes, élévation, tableau des aciers, poids).
- 4 brins : un cadre intérieur à chaque position (coupes, tableau, poids).
- Le nombre de cadres est recalculé avec la section d'acier transversale réelle (brins × section), donc le plan et le métré suivent le résultat.

## Diamètres disponibles
- Dans chaque carte « Aciers imposés » : cases HA6 à HA32 pour les diamètres présents sur le chantier.
- Le choix automatique (poutre, poteau, dalle, semelle, escalier, cadres, Bâtiment) se fait uniquement parmi les diamètres cochés, et les conseils proposent seulement ces diamètres.
- Un diamètre imposé reste prioritaire sur la liste. Tout coché = aucune restriction.
- Si aucun diamètre de la famille voulue n'est coché (ex. aucun cadre φ6 à φ12), la liste standard est utilisée pour cette famille.

## Deux lits d'aciers (poutre)
- Si un seul lit ne suffit pas, le calcul essaie deux lits : diamètre et répartition n1 + n2 les plus économiques, avec la hauteur utile réduite (axe équivalent relevé), puis recalcul complet (cisaillement, cadres, ELS).
- Coupes du plan : les deux lits sont dessinés, la cote d est corrigée ; le tableau des aciers et le métré indiquent « 2 lits n1+n2 ».
- Espacement vertical libre entre lits : max(φ ; 2,5 cm). Si deux lits ne suffisent pas, le message propose un diamètre supérieur, une largeur ou une hauteur plus grande.

## Ancrages et recouvrements
- Calculés selon la norme active : BAEL A.6.1 (ls = φ·fe / 4τs, τs = 0,6·ψs²·ft28, ψs = 1,5 ; lr = ls en traction, 0,6·ls en compression ; crochet normal 0,4·ls hors crochet) ou EC2 8.4 (lbd, l0 avec α6 = 1,5 en traction, crochet 0,7·lbd).
- Utilisés dans la note de calcul et le plan de la poutre, le métré (ancrage des filants) et les attentes du poteau (recouvrement des barres comprimées). Ils remplacent l'ancien forfait 50φ.
- Dalle, semelle et escalier gardent l'ancrage forfaitaire de 0,30 m dans le métré.

## Synthèse des taux de travail (Bâtiment)
- Tableau classé du plus chargé au moins chargé : acier requis / acier fourni, barre colorée (vert sous 90 %, orange 90 à 100 %, rouge au-delà ou section insuffisante), nombre d'éléments à 90 % ou plus, taux maximal.
- Poteaux : compression. Poutres : flexion en travée et sur appui. Le taux de travail est aussi affiché dans les résultats de la poutre et du poteau.

## Limites connues
- Les valeurs d'ancrage et de recouvrement sont des formules simplifiées : à faire confirmer par l'ingénieur du projet.
- Le taux de travail ne couvre ni l'effort tranchant ni la flèche.
- Étriers à 4 brins : le cadre intérieur est dessiné avec une largeur forfaitaire de 55 % de b − 2c (à ajuster sur le plan d'atelier).
- Plan d'exécution et métré du poteau : épingles selon le Ø imposé ; les autres modules (dalle, semelle, escalier) reprennent directement les diamètres et espacements calculés.
- Les solutions « h » et « section » recalculent avec les charges saisies (poids propre non recalculé pour la poutre) : relancer le calcul avec la nouvelle valeur pour confirmer.
- Calcul d'aide à l'étude : à faire vérifier par un ingénieur.
