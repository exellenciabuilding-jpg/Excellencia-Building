/* Excellencia Building V81 — Pilotage direction.
 * · Vue consolidée des factures (anciens « Chantiers & finances » V61 + « Finance USD/FC » V78) : lecture seule, aucune donnée modifiée.
 * · Tableau de bord : marge par chantier, retards (calendrier et avancement), impayés, alertes budget.
 * · Exports CSV (ouverts par Excel) · rappels de paiement WhatsApp / e-mail (message préparé, jamais envoyé automatiquement)
 * · Rapport d'avancement client (impression / PDF) : sans coûts ni marges.
 * Les montants sont ramenés en USD avec le taux enregistré sur chaque pièce V78, ou le dernier taux du jour pour les pièces V61 en FC. */
(function(w,d){'use strict';
var st={pid:''};
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function say(m,t){try{if(w.notify)w.notify(m,t||'success')}catch(e){}}
function G(k){try{return w.EXBS.get(k)}catch(e){return[]}}
function can(c){try{return !w.EXBDB||!w.EXBDB.can||w.EXBDB.can(c,'lire')}catch(e){return true}}
function canR(){return can('projets')&&can('factures')&&can('caisse')}
function today(){return new Date().toISOString().slice(0,10)}
function r2(n){return Math.round((Number(n)+Number.EPSILON)*100)/100}
function m(n){return Number(n||0).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2})+' $'}
function frDate(s){var x=/^(\d{4})-(\d\d)-(\d\d)/.exec(s||'');return x?x[3]+'/'+x[2]+'/'+x[1]:(s||'')}
function days(a,b){return Math.floor((Date.parse(a)-Date.parse(b))/864e5)}
function rate(){var t=G('exb_finance').filter(function(x){return x.type==='taux'&&x.rate>0}).sort(function(a,b){return a.date<b.date?-1:1});return t.length?Number(t[t.length-1].rate):0}
function usd(a,cur,r,R){a=Number(a)||0;if(!cur||cur==='USD')return a;r=Number(r)||R;return r>0?a/r:null}
function pname(id){var p=G('exb_projects').find(function(x){return String(x.id)===String(id)});return p?(p.name||p.nom||id):(id||'')}

/* ---------- factures unifiées (V61 + V78), en USD ---------- */
function mk(src,id,no,project,client,date,due,cur,ht,ttc,paid,miss){
  var t=today(),reste=Math.max(0,r2(ttc-paid)),late=!!(due&&due<t&&reste>0.005),s=(ttc>0&&paid>=ttc-0.005)?'Payée':late?'En retard':paid>0?'Partielle':'Émise';
  return{src:src,id:id,no:no||'',project:project||'',client:client||'',date:date||'',due:due||'',cur:cur||'USD',ht:r2(ht),ttc:r2(ttc),paid:r2(paid),reste:reste,status:s,lateDays:late?days(t,due):0,missing:!!miss}}
function invoices(){
  var R=rate(),out=[];
  G('exb_invoices').forEach(function(i){
    var ht=0,paid=0,cur=i.currency||'USD';(i.lines||[]).forEach(function(l){ht+=(+l.q||0)*(+l.pu||0)});(i.payments||[]).forEach(function(p){paid+=+p.amount||0});
    var ttc=ht*(1+(+i.tva||0)/100),a=usd(ht,cur,0,R),b=usd(ttc,cur,0,R),c=usd(paid,cur,0,R),miss=(a==null||b==null||c==null);
    out.push(mk('V61',i.id,i.no,i.project_id,i.client,i.date,i.due,cur,miss?0:a,miss?0:b,miss?0:c,miss))});
  var F=G('exb_finance');
  F.filter(function(x){return x.type==='facture'}).forEach(function(f){
    var miss=false,ht=usd(f.ht,f.cur,f.rate,R),ttc=usd(f.ttc,f.cur,f.rate,R),paid=0;
    F.forEach(function(p){if(p.type==='paiement'&&p.parent===f.id){var u=usd(p.ttc,p.cur,p.rate,R);if(u==null)miss=true;else paid+=u}});
    if(ht==null||ttc==null){miss=true;ht=0;ttc=0}
    out.push(mk('V78',f.id,f.no,f.project,f.client||'',f.date,f.due||'',f.cur,ht,ttc,paid,miss))});
  return out}

/* ---------- calcul du tableau de bord ---------- */
function calc(){
  var P=G('exb_projects'),I=invoices(),C=G('exb_cash'),t=today(),T={ht:0,ttc:0,paid:0,reste:0,late:0,lateN:0,dep:0,budget:0,missing:0};
  I.forEach(function(i){T.ht+=i.ht;T.ttc+=i.ttc;T.paid+=i.paid;T.reste+=i.reste;if(i.status==='En retard'){T.late+=i.reste;T.lateN++}if(i.missing)T.missing++});
  C.forEach(function(x){if(x.type==='out')T.dep+=+x.amount||0});
  var rows=P.map(function(p){
    var inv=I.filter(function(i){return String(i.project)===String(p.id)}),ht=0,ttc=0,paid=0,reste=0,late=0;
    inv.forEach(function(i){ht+=i.ht;ttc+=i.ttc;paid+=i.paid;reste+=i.reste;if(i.status==='En retard')late+=i.reste});
    var dep=0;C.forEach(function(x){if(x.type==='out'&&String(x.project_id)===String(p.id))dep+=+x.amount||0});
    var bud=+p.budget||0,prog=+p.progress||0,fin=/termin|cl[oô]tur|livr/i.test(p.status||'')||prog>=100,al=[],retard=0,gap=0;
    if(p.end&&p.end<t&&!fin){retard=days(t,p.end);al.push('⛔ Date de fin dépassée de '+retard+' j')}
    if(p.start&&p.end&&p.end>p.start&&!fin){var exp=Math.min(100,Math.max(0,(Date.parse(t)-Date.parse(p.start))/(Date.parse(p.end)-Date.parse(p.start))*100));gap=Math.round(exp-prog);if(gap>15&&!retard)al.push('⚠ Avancement en retard sur le calendrier ('+prog+' % pour '+Math.round(exp)+' % du temps écoulé)')}
    if(bud&&dep>bud)al.push('⛔ Dépenses supérieures au budget');else if(bud&&dep>0.9*bud)al.push('⚠ Plus de 90 % du budget consommé');
    else if(bud&&prog&&dep/bud*100>prog+15)al.push('⚠ Dépenses ('+Math.round(dep/bud*100)+' %) en avance sur le chantier ('+prog+' %)');
    if(late>0.005)al.push('⚠ Impayés échus : '+m(late));
    T.budget+=bud;
    return{id:p.id,name:p.name||p.nom||p.id,client:p.client||'',status:p.status||'',start:p.start||'',end:p.end||'',budget:bud,progress:prog,ht:r2(ht),ttc:r2(ttc),paid:r2(paid),reste:r2(reste),late:r2(late),dep:r2(dep),margeReelle:r2(paid-dep),margePrevue:r2(ht-dep),retard:retard,gap:gap,alerts:al}});
  ['ht','ttc','paid','reste','late','dep','budget'].forEach(function(k){T[k]=r2(T[k])});T.marge=r2(T.paid-T.dep);
  return{rows:rows,T:T,I:I,late:I.filter(function(i){return i.status==='En retard'}).sort(function(a,b){return b.lateDays-a.lateDays})}}

/* ---------- CSV ---------- */
function cell(v){if(typeof v==='number')return String(v).replace('.',',');var s=String(v==null?'':v);if(/^[=+\-@\t\r]/.test(s))s="'"+s;if(/[;"\n\r]/.test(s))s='"'+s.replace(/"/g,'""')+'"';return s}
function csvText(rows,cols){return '\ufeff'+[cols.map(cell).join(';')].concat(rows.map(function(r){return cols.map(function(c){return cell(r[c])}).join(';')})).join('\r\n')}
function plain(a){var cols=[];var rows=a.map(function(o){var r={};Object.keys(o||{}).forEach(function(k){var v=o[k];if(v&&typeof v==='object')v=/data:image|data:application/.test(JSON.stringify(v))?'[fichier non exporté]':JSON.stringify(v);else if(typeof v==='string'&&v.indexOf('data:')===0)v='[fichier non exporté]';else if(typeof v==='string'&&v.length>1500)v=v.slice(0,1500);else if(typeof v==='boolean')v=v?'oui':'non';r[k]=v;if(cols.indexOf(k)<0)cols.push(k)});return r});return{rows:rows,cols:cols}}
var EXPORTS={
 projets:{n:'synthese-projets',t:function(){var c=calc().rows.map(function(r){return{Projet:r.name,Client:r.client,Statut:r.status,Debut:r.start,Fin:r.end,'Budget USD':r.budget,'Avancement %':r.progress,'Facture HT USD':r.ht,'Facture TTC USD':r.ttc,'Encaisse USD':r.paid,'Reste a encaisser USD':r.reste,'Impayes echus USD':r.late,'Depenses USD':r.dep,'Marge reelle USD':r.margeReelle,'Marge prevue USD':r.margePrevue,'Jours de retard':r.retard,Alertes:r.alerts.join(' | ')}});return{rows:c,cols:c.length?Object.keys(c[0]):['Projet']}}},
 factures:{n:'factures',t:function(){var c=invoices().map(function(i){return{Source:i.src,Numero:i.no,Projet:pname(i.project),Client:i.client,Date:i.date,Echeance:i.due,Devise:i.cur,'HT USD':i.ht,'TTC USD':i.ttc,'Paye USD':i.paid,'Reste USD':i.reste,Statut:i.status,'Jours de retard':i.lateDays,'Conversion impossible':i.missing?'oui':'non'}});return{rows:c,cols:c.length?Object.keys(c[0]):['Numero']}}},
 caisse:{n:'caisse',t:function(){return plain(G('exb_cash'))}},
 pointages:{n:'pointages',t:function(){return plain(G('exb_timesheets'))}},
 situations:{n:'situations-travaux',t:function(){return plain(G('exb_situations'))}},
 journal:{n:'journal-chantier',t:function(){var a=G('exb_site_journal').map(function(j){var o=Object.assign({},j);o.photos=(j.photos||[]).length+' photo(s)';return o});return plain(a)}},
 clients:{n:'clients',t:function(){return plain(G('exb_clients'))}}
};
function exportCsv(kind){if(!canR())return say('Accès non autorisé.','error');var e=EXPORTS[kind];if(!e)return;var t=e.t();if(!t.rows.length)return say('Rien à exporter pour le moment.','warn');
  var txt=csvText(t.rows,t.cols);try{var b=new Blob([txt],{type:'text/csv;charset=utf-8'}),a=d.createElement('a');a.href=URL.createObjectURL(b);a.download='EXB-'+e.n+'-'+today()+'.csv';d.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1500);say('Export CSV prêt ('+t.rows.length+' lignes).')}catch(x){say('Export impossible sur cet appareil.','error')}return txt}

/* ---------- rappels de paiement ---------- */
function phoneNorm(p){var raw=String(p||''),dg=raw.replace(/\D/g,''),cc=(function(){try{return localStorage.getItem('exb_cc')||'243'}catch(e){return'243'}})();if(!dg)return'';if(/^\s*\+/.test(raw))return dg;if(dg.indexOf('00')===0)return dg.slice(2);if(dg[0]==='0')return cc+dg.slice(1);if(dg.length<=9)return cc+dg;return dg}
function findClient(name){var n=String(name||'').trim().toLowerCase();if(!n)return null;return G('exb_clients').find(function(c){return String(c.id)===String(name)||String(c.full_name||'').toLowerCase()===n||String(c.company||'').toLowerCase()===n||String(c.contact||'').toLowerCase()===n})||null}
function company(){try{return(w.EXB_BRAND&&w.EXB_BRAND.name)||'Excellencia Building'}catch(e){return'Excellencia Building'}}
function message(i){var nm=i.client||'Madame, Monsieur';return 'Bonjour '+nm+',\n\nSauf erreur de notre part, la facture '+i.no+(i.project?' (projet '+pname(i.project)+')':'')+' présente un solde de '+m(i.reste)+', échu depuis le '+frDate(i.due)+' ('+i.lateDays+' jour'+(i.lateDays>1?'s':'')+').\nMerci de bien vouloir procéder au règlement ou de nous indiquer la date prévue.\n\nCordialement,\n'+company()}
function remind(idx,how){var L=calc().late,i=L[idx];if(!i)return;var c=findClient(i.client)||{},msg=message(i);
  if(how==='wa'){var num=phoneNorm(c.phone);w.open('https://wa.me/'+(num||'')+'?text='+encodeURIComponent(msg),'_blank')}
  else{var u='mailto:'+encodeURIComponent(c.email||'')+'?subject='+encodeURIComponent('Rappel de paiement — facture '+i.no)+'&body='+encodeURIComponent(msg);w.location.href=u}}

/* ---------- rapport d'avancement client ---------- */
function logo(){try{var l=localStorage.getItem('exb_logo')||localStorage.getItem('rdc_logo')||'';if(/^data:image/.test(l))return l}catch(e){}return new URL((window.exbLogoSrc?exbLogoSrc():'icon-192.png'),location.href).href}
function reportHtml(pid){
  var p=G('exb_projects').find(function(x){return String(x.id)===String(pid)});if(!p)return'';
  var I=invoices().filter(function(i){return String(i.project)===String(pid)}),ttc=0,paid=0,reste=0;I.forEach(function(i){ttc+=i.ttc;paid+=i.paid;reste+=i.reste});
  var S=G('exb_situations').filter(function(x){return String(x.project_id)===String(pid)}).sort(function(a,b){return String(a.date)<String(b.date)?-1:1});
  var J=G('exb_site_journal').filter(function(x){return String(x.project_id)===String(pid)}).sort(function(a,b){return String(b.date)<String(a.date)?-1:1}).slice(0,5);
  var R=G('exb_reserves').filter(function(x){return String(x.project)===String(pid)&&!/cl[oô]tur|lev|solde|r[ée]solu|ferm/i.test(String(x.status||x.statut||''))});
  var photos=[],off=0;J.forEach(function(j){(j.photos||[]).forEach(function(ph){if(/^data:image/.test(ph)&&photos.length<6)photos.push(ph);else if(!/^data:image/.test(ph))off++})});
  var prog=Math.max(0,Math.min(100,+p.progress||0));
  return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Rapport — '+esc(p.name)+'</title><style>@page{size:A4;margin:12mm}body{font:12px Arial,sans-serif;color:#172033;margin:0}h1{font-size:20px;margin:0}h2{font-size:14px;border-bottom:2px solid #173565;padding-bottom:3px;margin:16px 0 6px;color:#173565}table{border-collapse:collapse;width:100%}td,th{border:1px solid #cbd5e1;padding:5px;text-align:left}.bar{background:#e2e8f0;border-radius:6px;height:16px}.bar i{display:block;height:16px;background:#15803d;border-radius:6px}.ph{display:flex;flex-wrap:wrap;gap:6px}.ph img{height:110px;border-radius:4px}.nb{position:fixed;top:6px;right:6px;background:#fff;padding:6px;box-shadow:0 2px 8px #777}@media print{.nb{display:none}}</style></head><body><div class="nb"><button onclick="print()">🖨 Imprimer / PDF</button></div>'
   +'<div style="display:flex;align-items:center;gap:12px"><img src="'+logo()+'" style="height:54px"><div><h1>Rapport d’avancement</h1><div>'+esc(company())+' — établi le '+frDate(today())+'</div></div></div>'
   +'<h2>Projet</h2><table><tr><th>Projet</th><td>'+esc(p.name)+'</td><th>Client</th><td>'+esc(p.client||'—')+'</td></tr><tr><th>Lieu</th><td>'+esc(p.location||'—')+'</td><th>Période</th><td>'+esc(frDate(p.start)||'—')+' → '+esc(frDate(p.end)||'—')+'</td></tr></table>'
   +'<h2>Avancement</h2><div class="bar"><i style="width:'+prog+'%"></i></div><p><b>'+prog+' %</b> réalisé'+(p.status?' — statut : '+esc(p.status):'')+'</p>'
   +'<h2>Situation financière</h2><table><tr><th>Facturé TTC</th><th>Réglé</th><th>Reste à régler</th></tr><tr><td>'+m(ttc)+'</td><td>'+m(paid)+'</td><td>'+m(reste)+'</td></tr></table>'
   +(S.length?'<h2>Situations de travaux</h2><table><tr><th>N°</th><th>Date</th><th>Avancement cumulé</th></tr>'+S.map(function(s){return'<tr><td>'+esc(s.no)+'</td><td>'+esc(frDate(s.date))+'</td><td>'+esc(s.pct)+' %</td></tr>'}).join('')+'</table>':'')
   +(J.length?'<h2>Dernières activités de chantier</h2><table><tr><th>Date</th><th>Travaux</th><th>Observations</th></tr>'+J.map(function(j){return'<tr><td>'+esc(frDate(j.date))+'</td><td>'+esc(j.work||'—')+'</td><td>'+esc(j.incident||j.notes||'—')+'</td></tr>'}).join('')+'</table>':'')
   +(photos.length?'<h2>Photos</h2><div class="ph">'+photos.map(function(s){return'<img src="'+s+'">'}).join('')+'</div>'+(off?'<p style="color:#64748b">'+off+' autre(s) photo(s) enregistrée(s) en ligne non reprise(s) ici.</p>':''):'')
   +'<h2>Réserves</h2><p>'+R.length+' réserve(s) ouverte(s).</p></body></html>'}
function report(pid){if(!canR())return say('Accès non autorisé.','error');var h=reportHtml(pid||st.pid);if(!h)return say('Choisissez un projet.','warn');w.EXBPrint.html('Rapport de pilotage',h)}

/* ---------- affichage ---------- */
function open(){if(!canR())return say('Accès non autorisé.','error');if(!st.pid){var P=G('exb_projects');st.pid=(P[0]&&P[0].id)||''}draw()}
function kpi(l,v,c){return'<div style="flex:1 1 140px;border:1px solid #e2e8f0;border-radius:10px;padding:8px"><div style="font-size:11px;color:#64748b">'+l+'</div><b style="font-size:16px;color:'+(c||'#172033')+'">'+v+'</b></div>'}
function draw(){var o=d.getElementById('exbPil');if(!o){o=d.createElement('div');o.id='exbPil';o.style.cssText='position:fixed;inset:0;z-index:99998;background:#0007;display:flex;align-items:flex-start;justify-content:center;padding:10px;overflow:auto';o.onclick=function(e){if(e.target===o)o.remove()};d.body.appendChild(o)}
  var C=calc(),T=C.T,P=G('exb_projects'),btn='padding:8px 10px;margin:2px';
  o.innerHTML='<div style="background:#fff;border-radius:14px;padding:16px;max-width:980px;width:100%;font:14px Arial;color:#172033"><div style="display:flex;justify-content:space-between"><b style="font-size:17px">📊 Pilotage direction</b><button onclick="document.getElementById(\'exbPil\').remove()">✕</button></div>'
   +'<p style="font-size:12px;color:#64748b">Montants en USD (taux du jour : '+(rate()?m(rate()).replace(' $','')+' FC pour 1 $':'non défini')+'). Vue consolidée des factures V61 + V78, lecture seule.'+(T.missing?' <b style="color:#b45309">'+T.missing+' pièce(s) en FC sans taux : non comptée(s).</b>':'')+'</p>'
   +'<div style="display:flex;flex-wrap:wrap;gap:6px">'+kpi('Facturé TTC',m(T.ttc))+kpi('Encaissé',m(T.paid),'#15803d')+kpi('Reste à encaisser',m(T.reste),'#b45309')+kpi('Impayés échus ('+T.lateN+')',m(T.late),T.late?'#b91c1c':'#172033')+kpi('Dépenses',m(T.dep))+kpi('Marge réelle',m(T.marge),T.marge<0?'#b91c1c':'#15803d')+'</div>'
   +'<h3 style="margin:14px 0 4px">Chantiers</h3><div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:12px;min-width:640px"><tr style="background:#f1f5f9">'+['Projet','Budget','Avanc.','Encaissé','Dépenses','Marge réelle','Impayés','Alertes'].map(function(h){return'<th style="border:1px solid #e2e8f0;padding:5px;text-align:left">'+h+'</th>'}).join('')+'</tr>'
   +(C.rows.length?C.rows.map(function(r){return'<tr><td style="border:1px solid #e2e8f0;padding:5px"><b>'+esc(r.name)+'</b></td><td style="border:1px solid #e2e8f0;padding:5px">'+m(r.budget)+'</td><td style="border:1px solid #e2e8f0;padding:5px">'+r.progress+' %</td><td style="border:1px solid #e2e8f0;padding:5px">'+m(r.paid)+'</td><td style="border:1px solid #e2e8f0;padding:5px">'+m(r.dep)+'</td><td style="border:1px solid #e2e8f0;padding:5px;color:'+(r.margeReelle<0?'#b91c1c':'#15803d')+'">'+m(r.margeReelle)+'</td><td style="border:1px solid #e2e8f0;padding:5px">'+m(r.late)+'</td><td style="border:1px solid #e2e8f0;padding:5px">'+(r.alerts.map(esc).join('<br>')||'✅')+'</td></tr>'}).join(''):'<tr><td colspan="8" style="padding:8px">Aucun projet.</td></tr>')+'</table></div>'
   +'<h3 style="margin:14px 0 4px">Impayés à relancer</h3>'+(C.late.length?C.late.map(function(i,k){return'<div style="border-bottom:1px solid #e2e8f0;padding:6px 0"><b>'+esc(i.no)+'</b> — '+esc(i.client||'client ?')+' — '+esc(pname(i.project))+'<br>Reste '+m(i.reste)+' · échue le '+esc(frDate(i.due))+' ('+i.lateDays+' j)<br><button style="'+btn+'" onclick="EXBPIL.remind('+k+',\'wa\')">📲 WhatsApp</button><button style="'+btn+'" onclick="EXBPIL.remind('+k+',\'mail\')">✉ E-mail</button></div>'}).join('')+'<p style="font-size:12px;color:#64748b">Le message est préparé : vous le vérifiez puis l’envoyez vous-même. Les factures V78 n’ont pas d’échéance : elles ne passent pas en retard.</p>':'<p>Aucun impayé échu. ✅</p>')
   +'<h3 style="margin:14px 0 4px">Exports (CSV, s’ouvre dans Excel)</h3><div>'+[['projets','Synthèse projets'],['factures','Factures'],['caisse','Caisse'],['pointages','Pointages'],['situations','Situations'],['journal','Journal'],['clients','Clients']].map(function(e){return'<button style="'+btn+'" onclick="EXBPIL.exp(\''+e[0]+'\')">⬇ '+e[1]+'</button>'}).join('')+'</div>'
   +'<h3 style="margin:14px 0 4px">Rapport d’avancement client</h3><p><select onchange="EXBPIL.proj(this.value)" style="padding:8px;max-width:100%">'+P.map(function(p){return'<option value="'+esc(p.id)+'"'+(String(p.id)===String(st.pid)?' selected':'')+'>'+esc(p.name||p.nom||p.id)+'</option>'}).join('')+'</select> <button style="'+btn+'" onclick="EXBPIL.report()">📄 Générer le rapport (PDF)</button></p><p style="font-size:12px;color:#64748b">Le rapport montre avancement, facturation, situations, activités, photos et réserves — jamais les coûts ni les marges.</p></div>'}
w.EXBPIL={open:open,proj:function(v){st.pid=v;draw()},exp:exportCsv,remind:remind,report:report,
  _calc:calc,_invoices:invoices,_csv:csvText,_phone:phoneNorm,_message:message,_reportHtml:reportHtml,_exports:EXPORTS};
function ui(){var b=d.getElementById('badm');if(!b||d.getElementById('exbPilBtn'))return;var k=d.createElement('button');k.id='exbPilBtn';k.className='muted';k.textContent='📊 Pilotage direction';k.onclick=open;if(!canR())k.setAttribute('data-exbrole','hide');b.parentNode.appendChild(k)}
if(typeof MutationObserver!=='undefined')new MutationObserver(ui).observe(d.documentElement,{childList:true,subtree:true});d.addEventListener('DOMContentLoaded',ui);
})(window,document);
