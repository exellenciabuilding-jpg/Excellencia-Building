/* Réglages de la licence — généré par scripts/apply-licence.js à partir de licence-serveur.json (V120o). Ne contient que des informations publiques.
   requireToken:true → sans licence valide, le logiciel reste verrouillé. */
window.EXB_LICENSE_CONFIG = {
  "requireToken": true,
  "warnDays": 7,
  "defaultGrace": 7,
  "contact": "Excellencia",
  "server": "https://oidryaavueywszzlshca.supabase.co/functions/v1/licence",
  "serverPub": {
    "kty": "EC",
    "crv": "P-256",
    "x": "gCpjrY7LwHWYrCh9gdvZyC2wgFF7ghdI4vRWdXHfh0c",
    "y": "99QF0mj8LF9emZjQvRcjSKooAqP0tSZBOD-T-IdtgJ4"
  },
  "offlineDays": 7,
  "checkEveryMin": 30
};
