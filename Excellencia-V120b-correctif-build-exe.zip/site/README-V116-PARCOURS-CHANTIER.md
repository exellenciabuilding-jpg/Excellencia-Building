# V116 — Parcours chantier (sans demande BTP)
Lieu unique : Demandes reçues › 🏗️ Chantiers terrain.

## Parcours en 3 étapes
1. **➕ Nouveau chantier** (assistant) : nom, code automatique (CH-AAAA-NNN, modifiable), projet du logiciel central à lier (facultatif). Aucune demande BTP nécessaire (numéro de suivi laissé vide).
2. **🔑 Code de suivi client** : code du type `AB12-CD34-EF56` généré pour CE chantier. Le client ouvre `/suivi-chantier` (ou le lien du message), saisit le code et voit l'avancement + les rapports marqués « visibles client ». Lecture seule, sans compte. Bouton « Nouveau code » : l'ancien cesse de fonctionner. Disponible aussi plus tard sur chaque chantier.
3. **👷 Équipe du chantier** : contacts (Personnel, Formateurs, Clients) ou « Autre personne » (nom + e-mail) -> compte créé si besoin (mot de passe provisoire généré) + rattachement + message WhatsApp.
Paramètres › 👥 Équipe : bouton 🏗️ Chantiers pour rattacher un membre de l'entreprise à des chantiers (compte déjà existant).

## Mise en service
1. Supabase › SQL Editor : exécuter `supabase/migration-v116-chantier-code-suivi.sql` (réexécutable ; prérequis : scripts chantier V67 / admin déjà exécutés). Contrôle : `select proname from pg_proc where proname in ('chantier_code_suivi','chantier_suivi_public');` -> 2 lignes.
2. Déployer le dossier `site/`. Recharger (Ctrl+Maj+R).

## Limites / à vérifier
- Chantier lié à une demande BTP : le client continue d'utiliser son numéro de suivi + téléphone (`resultats.html`). Le code de suivi est un second accès, indépendant.
- Le code de suivi n'a pas de limite d'essais côté serveur (12 caractères aléatoires, ~48 bits). Ne l'envoyer qu'au client concerné ; « Nouveau code » en cas de fuite.
- Les photos ne sont pas affichées sur cette page (seulement leur nombre) : elles sont dans un stockage privé.
- Non testé sur un vrai Supabase : les noms de colonnes `exb_sites.name`, `exb_field_journals.client_visible`, `exb_field_photos.client_visible` viennent du code existant ; si le SQL signale une colonne inconnue, envoyer le message.
