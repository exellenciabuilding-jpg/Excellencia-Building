/* Adresse du serveur du moteur documentaire (Chromium / PDF). Laisser vide = mode local (impression par l'application).
 * Exemple : window.EXB_DOCENGINE_URL = 'https://documents.mon-domaine.com';
 * Modifiable aussi depuis Centre documentaire › Paramètres et permissions. */
window.EXB_DOCENGINE_URL = window.EXB_DOCENGINE_URL || '';
