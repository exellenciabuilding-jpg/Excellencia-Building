/* Excellencia Building — MOTEUR DOCUMENTAIRE · adaptateurs des modules existants (fusion V118 → V119d)
 * Fournit window.EXBDocEngine : l'interface qu'utilisent exb-pdf.js (EXBPdf.make), exb-docs.js (devis / factures / reçus) et exb-print.js (EXBPrint.full),
 * au-dessus du client EXBDoc de V119d. Les ~22 appels EXBPdf.make et les 3 appels EXBDocs.build passent par ici SANS être modifiés.
 *   - avec le serveur documentaire configuré et une session en ligne : rendu Chromium (modèles doc-devis / doc-module, profil de l'organisation) ;
 *   - sinon, ou si le serveur échoue : repli sur l'ancien écrivain local (jamais de blocage de l'utilisateur) ;
 *   - dans tous les cas : inscription à l'historique commun du Centre documentaire.
 * Retrait : supprimer la balise <script> de ce fichier ; exb-pdf.js / exb-docs.js retombent sur leur écrivain local (E absent). */
(function (w) {
  'use strict';
  if (w.EXBDocEngine) return;
  var K_HIST = 'EXB_DOCHIST_V1';
  function D() { return w.EXBDoc; }
  function lsGet(k, def) { try { var v = JSON.parse(w.localStorage.getItem(k) || 'null'); return v == null ? def : v; } catch (e) { return def; } }
  function lsSet(k, v) { try { w.localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function s(v) { return v == null ? '' : String(v); }
  function img(u) { return /^data:image\/(png|jpe?g|gif|webp);base64,/.test(u || '') ? u : ''; }
  function listeners() { return w.__exbDocListeners || (w.__exbDocListeners = []); }
  function emit(type, v) { listeners().slice().forEach(function (f) { try { f(type, v); } catch (e) {} }); }

  /* serveur utilisable ? (URL du serveur + session + en ligne + pas en mode public) */
  function canServer() { var d = D(); try { return !!(d && d.config && d.config.connected() && !w.EXB_DOCENGINE_PUBLIC); } catch (e) { return false; } }

  /* historique commun : serveur → déjà enregistré par /render ; local → inscrit ici (même clé que le Centre documentaire) */
  function noteHistory(e) {
    e = e || {};
    var rec = { id: 'l' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), type: e.type || e.modele || 'module', number: e.numero || e.number || '', title: e.titre || e.title || '',
      subject: e.titre || '', created_at: new Date().toISOString(), source: e.module || 'modules', local: true, status: e.statut || 'impression', payload: null };
    var h = lsGet(K_HIST, []); h.unshift(rec); lsSet(K_HIST, h.slice(0, 300)); return rec;
  }
  function noteWarn(err) { emit('warn', 'Service PDF indisponible (' + (err && err.message || err) + ') : PDF produit sur l’appareil.'); }

  function moduleOf(o) {
    var t = s(o.titre).toUpperCase();
    var map = [[/DEVIS/, 'devis'], [/FACTURE|DÉCOMPTE|DECOMPTE/, 'facturation'], [/BON DE COMMANDE|ACHAT/, 'achats'], [/CHANTIER|RÉCEPTION|RECEPTION|PLANNING|BUDGET|PILOTAGE/, 'chantiers'],
      [/NOTE DE CALCUL|BORDEREAU|HEURES|HONORAIRES|PLAN/, 'etudes'], [/PERSONNEL|FICHE/, 'personnel'], [/ATTESTATION|CERTIFICAT|FORMATION|PARTICIPANT/, 'formations'], [/GÉOTECH|GEOTECH/, 'geotechnique']];
    for (var i = 0; i < map.length; i++) if (map[i][0].test(t)) return map[i][1];
    return o.module || 'modules';
  }
  function qrFor(o) {
    try {
      if (o.verify === false || !w.EXBVerif || !w.EXBVerif.docUrl || !w.EXBQR) return null;
      var dg = (o.rows || []).map(function (r) { return r[0] + ':' + r[1]; }).join('|');
      var v = w.EXBVerif.docUrl({ title: o.titre || '', sub: o.sousTitre || '', digest: dg, nom: o.clientName || '', no: o.verifyNo });
      if (!v || !v.url) return null;
      return { svg: 'data:image/svg+xml;base64,' + btoa(w.EXBQR.svg(v.url, { px: 160 })), code: v.code || '' };
    } catch (e) { return null; }
  }
  /* appel direct du serveur (pas de repli local ici : l'échec remonte et l'ancien écrivain prend le relais, sans double inscription à l'historique) */
  function render(type, doc, opt) {
    opt = opt || {};
    try { if (w.exbRebrandDeep) doc = w.exbRebrandDeep(doc); } catch (e) {}
    var body = { type: type, data: { doc: doc, status: opt.statut || '' }, options: opt.watermark ? { watermark: 'custom', watermark_text: String(opt.watermark).slice(0, 40) } : {}, source: opt.module || 'modules', numbering: false };
    return D().api('POST', '/render', body, true).then(function (r) { return r.blob(); }).then(function (blob) { return { blob: blob }; });
  }

  /* EXBPdf.make(o) -> moteur. `local(o)` = ancien écrivain ; renvoie un Blob PDF. */
  function make(o, local) {
    o = o || {}; var mod = moduleOf(o);
    function done(blob, how) { try { if (how === 'PDF local') noteHistory({ type: 'doc-module', numero: s(o.verifyNo || o.numero), titre: s(o.titre) + (o.sousTitre ? ' — ' + s(o.sousTitre).slice(0, 60) : ''), module: mod, statut: how }); } catch (e) {} return blob; }
    if (!canServer()) return local(o).then(function (b) { return done(b, 'PDF local'); });
    var qr = qrFor(o);
    return Promise.resolve(o.sign !== false && w.EXBSign && w.EXBSign.anyVisa ? w.EXBSign.anyVisa('png').catch(function () { return ''; }) : '').then(function (visa) {
      var doc = { titre: o.titre || 'DOCUMENT', sousTitre: o.sousTitre || '', clientName: o.clientName || '', rows: o.rows || [], notes: o.notes || [], images: (o.images || []).map(img).filter(Boolean), footer: o.footer || '',
        cover: o.cover !== false, sigLabels: o.sigLabels || undefined, signBlock: o.signBlock, visa: img(visa), clientSig: img(o.clientSig), qr: qr ? qr.svg : '', qrCode: qr ? qr.code : '', numero: s(o.verifyNo || o.numero) || '-' };
      return render('doc-module', doc, { module: mod });
    }).then(function (res) { return res.blob; }, function (err) { noteWarn(err); return local(o).then(function (b) { return done(b, 'PDF local'); }); });
  }

  /* EXBDocs.build -> modèle doc-devis. JSON perd la propriété .k (lot / sous-total) des lignes : transmise explicitement. */
  function renderDoc(d, o) {
    o = o || {};
    var qr = ''; try { if (d.qrUrl && w.EXBQR) qr = 'data:image/svg+xml;base64,' + btoa(w.EXBQR.svg(d.qrUrl, { px: 160 })); } catch (e) {}
    var payload = Object.assign({}, d, { qr: qr, visa: img(d.visa), clientSig: img(d.clientSig), logo: img(d.logo), lines: (d.lines || []).map(function (r) { return { k: r.k || '', c: Array.prototype.slice.call(r) }; }) });
    delete payload.qrUrl;
    return render('doc-devis', payload, { module: o.module || 'devis', watermark: o.watermark || '', statut: d.statut || d.status || '' }).then(function (res) {
      return { blob: res.blob, pages: 0 };
    });
  }
  /* Pièces écrites -> modèle doc-piece (texte sélectionnable, identité du profil). Pas de repli ici : l'échec remonte, le module garde son PDF local. */
  function renderPiece(d, o) {
    o = o || {};
    var payload = Object.assign({}, d, { visa: img(d.visa), qr: img(d.qr) });
    return render('doc-piece', payload, { module: o.module || 'pieces', statut: d.statut || '' }).then(function (res) { return { blob: res.blob }; });
  }
  /* V120i : fiches / épreuves / listes du module Formations -> modèle doc-fiche. `fallback()` = ancien chemin (image) ; appelé si pas de serveur ou en cas d'échec du rendu.
   * Renvoie une promesse de booléen (true = fichier remis à l'utilisateur). Pas de double sortie : si le rendu a réussi, le repli n'est jamais lancé. */
  function renderFiche(d, o) {
    o = o || {};
    var payload = Object.assign({}, d, { photo: img(d.photo), qr: img(d.qr) });
    return render('doc-fiche', payload, { module: o.module || 'formations', statut: o.statut || '' }).then(function (res) { return { blob: res.blob }; });
  }
  function fichePdf(doc, name, fallback, o) {
    function fb() { return Promise.resolve(fallback ? fallback() : false).then(function (r) { return r !== false; }); }
    if (!canServer()) return fb();
    return renderFiche(doc, o).then(function (r) {
      var done = typeof w.saveFile === 'function' ? w.saveFile(name, r.blob) : download({ blob: r.blob, name: name });
      return Promise.resolve(done).then(function (ok) { return ok !== false; });
    }, function (err) { noteWarn(err); return fb(); });
  }
  function download(res) { if (w.EXBPrint && w.EXBPrint.blob) return w.EXBPrint.blob(res.blob, res.name); var a = w.document.createElement('a'); a.href = URL.createObjectURL(res.blob); a.download = res.name; a.click(); return true; }
  function on(fn) { listeners().push(fn); return function () { var l = listeners(); l.splice(l.indexOf(fn), 1); }; }

  w.EXBDocEngine = { version: 'V120i', make: make, canServer: canServer, renderDoc: renderDoc, renderPiece: renderPiece, renderFiche: renderFiche, fichePdf: fichePdf, noteHistory: noteHistory, noteWarn: noteWarn, download: download, on: on };
})(window);
