/* Excellencia Building — MOTEUR DOCUMENTAIRE UNIVERSEL · catalogue des modèles (V118)
 * Isomorphe (navigateur + serveur). Chaque modèle déclare :
 *   - ses champs (fields) et tableaux (tables) → le formulaire de saisie et la validation en sont déduits ;
 *   - sa mise en page (render) ; l'en-tête, le pied de page, la numérotation, le filigrane et les signatures sont fournis par le noyau.
 * Pour ajouter un document à la plateforme : EXBDocCore.register({...}) — aucun autre fichier à modifier.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'));
  else factory(root.EXBDocCore);
})(typeof self !== 'undefined' ? self : this, function (C) {
  'use strict';
  var esc = C.esc;

  var T = function (k, label, extra) { return Object.assign({ k: k, label: label, type: 'text' }, extra || {}); };
  var TA = function (k, label, extra) { return Object.assign({ k: k, label: label, type: 'textarea' }, extra || {}); };
  var D = function (k, label, extra) { return Object.assign({ k: k, label: label, type: 'date' }, extra || {}); };
  var N = function (k, label, extra) { return Object.assign({ k: k, label: label, type: 'number' }, extra || {}); };
  var S = function (k, label, options, extra) { return Object.assign({ k: k, label: label, type: 'select', options: options }, extra || {}); };
  var Col = function (k, label, extra) { return Object.assign({ k: k, label: label, type: 'text' }, extra || {}); };

  var CLIENT = [T('client_nom', 'Client', { required: true, group: 'Client' }), TA('client_adresse', 'Adresse du client', { group: 'Client' }), T('client_tel', 'Téléphone', { group: 'Client' }), T('client_email', 'E-mail', { group: 'Client' }), T('client_ref', 'N° d’identification du client (RCCM, NIF…)', { group: 'Client' })];
  var LIGNES = { k: 'lignes', label: 'Lignes', required: true, columns: [Col('designation', 'Désignation', { w: '46%' }), Col('unite', 'Unité', { align: 'center', w: '9%' }), { k: 'qte', label: 'Qté', type: 'number', align: 'right', w: '9%' }, { k: 'pu', label: 'Prix unitaire', type: 'number', align: 'right', w: '16%' }] };
  var MONEY_OPTS = [S('devise', 'Devise', ['USD', 'EUR', 'CDF', 'XOF', 'XAF']), N('remise_pct', 'Remise (%)'), N('tva_pct', 'TVA (%)')];

  function clientBlock(ctx, d, title) {
    return '<b>' + esc(d.client_nom) + '</b>' + (d.client_adresse ? '<br>' + C.helpers.nl2br(d.client_adresse) : '') + (d.client_tel ? '<br>Tél : ' + esc(d.client_tel) : '') + (d.client_email ? '<br>' + esc(d.client_email) : '') + (d.client_ref ? '<br>Réf. : ' + esc(d.client_ref) : '');
  }
  function cur(ctx) { return ctx.data.devise || ctx.profile.currency || 'USD'; }
  function financeBody(ctx, kind) {
    var h = ctx.h, d = ctx.data, c = cur(ctx), tt = h.computeTotals(d.lignes, d), out = '';
    out += h.parties(ctx, 'Émetteur', kind === 'bc' ? 'Fournisseur' : 'Client', clientBlock(ctx, d));
    if (d.objet) out += '<div class="note"><b>Objet :</b> ' + h.nl2br(d.objet) + (d.reference ? '<br><b>Référence / projet :</b> ' + esc(d.reference) : '') + '</div>';
    out += h.table([
      { label: 'N°', align: 'center', w: '5%', get: function (r, i) { return i + 1; } },
      { label: 'Désignation', k: 'designation' }, { label: 'Unité', k: 'unite', align: 'center' },
      { label: 'Qté', align: 'right', get: function (r) { return r.qte; }, fmt: function (v) { return String(v).replace('.', ','); } },
      { label: 'Prix unitaire', align: 'right', get: function (r) { return r.pu; }, fmt: function (v) { return h.money(v); } },
      { label: 'Total (' + c + ')', align: 'right', get: function (r) { return r.total; }, fmt: function (v) { return h.money(v); } }
    ], tt.rows, { empty: 'Aucune ligne' });
    var rows = [['Sous-total', h.money(tt.sous_total)]];
    if (tt.remise) rows.push(['Remise (' + tt.remise_pct + ' %)', '− ' + h.money(tt.remise)]);
    rows.push([tt.tva_pct ? 'Total HT' : 'Total', h.money(tt.ht)]);
    if (tt.tva_pct) { rows.push(['TVA (' + tt.tva_pct + ' %)', h.money(tt.tva)]); }
    var html = '<table class="tot">' + rows.map(function (r) { return '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>'; }).join('') +
      '<tr class="g"><td>' + (tt.tva_pct ? 'TOTAL TTC' : 'TOTAL À PAYER') + '</td><td>' + h.money(tt.ttc) + ' ' + esc(c) + '</td></tr>' +
      (tt.acompte ? '<tr><td>Acompte versé</td><td>− ' + h.money(tt.acompte) + '</td></tr><tr class="s"><td>Reste à payer</td><td>' + h.money(tt.reste) + ' ' + esc(c) + '</td></tr>' : '') + '</table>';
    out += html + '<p class="words">Arrêté le présent document à la somme de : <b>' + esc(h.amountWords(tt.ttc, c)) + '</b>.</p>';
    ctx.totals = tt; return out;
  }
  var FIN_TARGET = { devis: 'devis', facture: 'facture', bc: 'bon de commande' };

  /* ═════════════ FINANCE ═════════════ */
  C.register({
    id: 'devis', label: 'Devis', category: 'finance', prefix: 'DEV', description: 'Devis chiffré avec totaux, remise, TVA et bon pour accord.', showBank: false,
    fields: CLIENT.concat([T('objet', 'Objet du devis', { required: true }), T('reference', 'Référence / projet'), N('validite', 'Validité (jours)')]).concat(MONEY_OPTS).concat([TA('conditions', 'Conditions particulières (paiement, délais…)')]),
    tables: [LIGNES], signatures: ['Bon pour accord — Le Client', { label: 'Le Prestataire', issuer: true }], defaults: { validite: 30, devise: '' },
    subtitle: function (ctx) { return ctx.data.objet; },
    meta: function (ctx) { return [ctx.data.validite ? 'Valable ' + ctx.data.validite + ' jours' : '']; },
    render: function (ctx) { return financeBody(ctx, 'devis') + C.helpers.section('Conditions', C.helpers.para(ctx.data.conditions || 'Paiement : 50 % à la commande, solde à la réception des travaux. Délais courant à compter de la réception de l’acompte.')); }
  });
  C.register({
    id: 'facture', label: 'Facture', category: 'finance', prefix: 'FAC', description: 'Facture avec totaux, acompte, reste à payer et coordonnées bancaires.', showBank: true,
    fields: CLIENT.concat([T('objet', 'Objet', { required: true }), T('reference', 'Référence / projet'), T('ref_devis', 'Devis associé'), D('echeance', 'Date d’échéance'), N('acompte', 'Acompte déjà versé')]).concat(MONEY_OPTS).concat([TA('conditions', 'Mentions / conditions de paiement')]),
    tables: [LIGNES], signatures: [{ label: 'Pour l’entreprise', issuer: true }], defaults: { devise: '' },
    subtitle: function (ctx) { return ctx.data.objet; },
    meta: function (ctx) { return [ctx.data.echeance ? 'Échéance : <b>' + esc(ctx.h.dateFr(ctx.data.echeance)) + '</b>' : '', ctx.data.ref_devis ? 'Devis : ' + esc(ctx.data.ref_devis) : '']; },
    render: function (ctx) { return financeBody(ctx, 'facture') + C.helpers.section('Conditions de paiement', C.helpers.para(ctx.data.conditions || 'Paiement à réception de la facture, par virement ou en espèces contre reçu.')); }
  });
  C.register({
    id: 'bon-commande', label: 'Bon de commande', category: 'finance', prefix: 'BC', description: 'Bon de commande fournisseur avec lieu et date de livraison.', showBank: false,
    fields: [T('client_nom', 'Fournisseur', { required: true, group: 'Fournisseur' }), TA('client_adresse', 'Adresse du fournisseur', { group: 'Fournisseur' }), T('client_tel', 'Téléphone', { group: 'Fournisseur' }), T('client_email', 'E-mail', { group: 'Fournisseur' }), T('client_ref', 'N° d’identification', { group: 'Fournisseur' }),
      T('objet', 'Objet de la commande', { required: true }), T('reference', 'Projet / chantier'), D('livraison_date', 'Livraison souhaitée le'), T('livraison_lieu', 'Lieu de livraison'), T('paiement', 'Conditions de paiement')].concat(MONEY_OPTS),
    tables: [LIGNES], signatures: [{ label: 'Le Demandeur', issuer: true }, 'Bon pour exécution — Le Fournisseur'], defaults: { devise: '' },
    meta: function (ctx) { return [ctx.data.livraison_date ? 'Livraison : <b>' + esc(ctx.h.dateFr(ctx.data.livraison_date)) + '</b>' : '']; },
    render: function (ctx) { var d = ctx.data; return financeBody(ctx, 'bc') + ctx.h.section('Livraison et paiement', ctx.h.kv([['Lieu de livraison', d.livraison_lieu], ['Date souhaitée', d.livraison_date ? ctx.h.dateFr(d.livraison_date) : ''], ['Conditions de paiement', d.paiement]])); }
  });
  C.register({
    id: 'recu', label: 'Reçu de paiement', category: 'finance', prefix: 'REC', description: 'Reçu de paiement avec montant en lettres.',
    fields: [T('payeur', 'Reçu de', { required: true }), N('montant', 'Montant reçu', { required: true }), S('devise', 'Devise', ['USD', 'EUR', 'CDF', 'XOF', 'XAF']), T('motif', 'Motif du paiement', { required: true }),
      S('mode', 'Mode de paiement', ['Espèces', 'Virement bancaire', 'Mobile money', 'Chèque', 'Carte']), T('reference', 'Référence / n° de transaction'), N('solde', 'Solde restant dû (facultatif)')],
    signatures: [{ label: 'Le Caissier / Le Responsable', issuer: true }, 'Le Payeur'], defaults: { mode: 'Espèces' },
    render: function (ctx) {
      var d = ctx.data, c = cur(ctx), h = ctx.h;
      return '<div class="note" style="font-size:12pt"><b>Montant reçu : ' + h.money(d.montant) + ' ' + esc(c) + '</b></div>' +
        h.kv([['Reçu de', d.payeur], ['La somme de', h.amountWords(d.montant, c)], ['Motif', d.motif], ['Mode de paiement', d.mode], ['Référence', d.reference], ['Solde restant dû', d.solde ? h.money(d.solde) + ' ' + c : '']]);
    }
  });

  /* ═════════════ TECHNIQUE ═════════════ */
  C.register({
    id: 'rapport-technique', label: 'Rapport technique', category: 'technique', prefix: 'RT', description: 'Rapport technique structuré : objet, sections, conclusion, recommandations.',
    fields: [T('titre', 'Titre du rapport', { required: true }), T('projet', 'Projet'), T('localisation', 'Localisation'), T('auteur', 'Auteur / bureau d’études'), T('destinataire', 'Destinataire / maître d’ouvrage'), TA('objet', 'Objet et contexte'), TA('conclusion', 'Conclusion'), TA('recommandations', 'Recommandations')],
    tables: [{ k: 'sections', label: 'Sections du rapport', columns: [Col('titre', 'Titre de la section', { w: '28%' }), { k: 'contenu', label: 'Contenu', type: 'textarea' }] }],
    signatures: [{ label: 'L’Ingénieur / L’Auteur', issuer: true }, 'Visa du Maître d’ouvrage'],
    subtitle: function (ctx) { return ctx.data.titre; },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h;
      return h.kv([['Projet', d.projet], ['Localisation', d.localisation], ['Établi par', d.auteur], ['Destinataire', d.destinataire]]) + h.section('Objet et contexte', h.para(d.objet)) +
        d.sections.map(function (s, i) { return h.section((i + 1) + '. ' + (s.titre || 'Section'), h.para(s.contenu)); }).join('') + h.section('Conclusion', h.para(d.conclusion)) + h.section('Recommandations', h.para(d.recommandations));
    }
  });
  C.register({
    id: 'rapport-chantier', label: 'Rapport de chantier', category: 'technique', prefix: 'RC', description: 'Rapport journalier / hebdomadaire de chantier avec effectifs, avancement et photos.',
    fields: [T('chantier', 'Chantier', { required: true }), T('localisation', 'Localisation'), S('periode', 'Type de rapport', ['Journalier', 'Hebdomadaire', 'Mensuel']), T('meteo', 'Météo / conditions'), T('redige_par', 'Rédigé par'), N('avancement', 'Avancement global (%)'),
      TA('travaux', 'Travaux réalisés', { required: true }), TA('difficultes', 'Difficultés rencontrées'), TA('materiel', 'Matériel et approvisionnements'), TA('securite', 'Hygiène, sécurité, environnement'), TA('prevus', 'Travaux prévus à la prochaine période')],
    tables: [{ k: 'effectifs', label: 'Effectifs', columns: [Col('corps', 'Corps de métier'), { k: 'effectif', label: 'Effectif', type: 'number', align: 'right' }, { k: 'heures', label: 'Heures', type: 'number', align: 'right' }] },
      { k: 'photos', label: 'Photos', columns: [{ k: 'photo', label: 'Photo', type: 'image' }, Col('legende', 'Légende')] }],
    signatures: [{ label: 'Le Conducteur de travaux', issuer: true }, 'Visa du Chef de projet'], defaults: { periode: 'Journalier' },
    subtitle: function (ctx) { return ctx.data.chantier + (ctx.data.periode ? ' — ' + ctx.data.periode : ''); },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, tot = d.effectifs.reduce(function (a, r) { return a + h.num(r.effectif); }, 0);
      return h.kv([['Chantier', d.chantier], ['Localisation', d.localisation], ['Météo', d.meteo], ['Rédigé par', d.redige_par]]) +
        (d.avancement !== '' ? h.section('Avancement global', h.progress(d.avancement)) : '') +
        h.section('Travaux réalisés', h.para(d.travaux)) +
        h.section('Effectifs' + (tot ? ' (' + tot + ' personnes)' : ''), h.table([{ label: 'Corps de métier', k: 'corps' }, { label: 'Effectif', k: 'effectif', align: 'right' }, { label: 'Heures', k: 'heures', align: 'right' }], d.effectifs)) +
        h.section('Difficultés rencontrées', h.para(d.difficultes)) + h.section('Matériel et approvisionnements', h.para(d.materiel)) + h.section('Hygiène, sécurité, environnement', h.para(d.securite)) +
        h.section('Travaux prévus', h.para(d.prevus)) + h.section('Photographies', h.gallery(d.photos));
    }
  });
  C.register({
    id: 'fiche-technique', label: 'Fiche technique', category: 'technique', prefix: 'FT', description: 'Fiche technique d’un produit, d’un matériau ou d’un ouvrage.',
    fields: [T('produit', 'Désignation', { required: true }), T('reference', 'Référence'), T('fabricant', 'Fabricant / fournisseur'), TA('description', 'Description'), TA('mise_en_oeuvre', 'Mise en œuvre'), TA('precautions', 'Précautions et stockage'), { k: 'photo', label: 'Photo', type: 'image' }],
    tables: [{ k: 'caracteristiques', label: 'Caractéristiques', columns: [Col('propriete', 'Propriété'), Col('valeur', 'Valeur'), Col('norme', 'Norme / méthode')] }],
    signatures: [{ label: 'Validé par', issuer: true }],
    subtitle: function (ctx) { return ctx.data.produit; },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h;
      return (d.photo ? '<div style="float:right;width:48mm;margin:0 0 3mm 5mm"><img src="' + esc(d.photo) + '" style="width:100%;border:.3mm solid #d6dce6" alt=""></div>' : '') + h.kv([['Désignation', d.produit], ['Référence', d.reference], ['Fabricant', d.fabricant]]) + h.section('Description', h.para(d.description)) +
        '<div style="clear:both"></div>' + h.section('Caractéristiques', h.table([{ label: 'Propriété', k: 'propriete' }, { label: 'Valeur', k: 'valeur' }, { label: 'Norme / méthode', k: 'norme' }], d.caracteristiques)) + h.section('Mise en œuvre', h.para(d.mise_en_oeuvre)) + h.section('Précautions et stockage', h.para(d.precautions));
    }
  });
  C.register({
    id: 'rapport-geotechnique', label: 'Rapport géotechnique', category: 'geotechnique', prefix: 'GEO', description: 'Rapport de reconnaissance géotechnique : sondages, essais, portance et recommandations de fondations.',
    fields: [T('projet', 'Projet', { required: true }), T('site', 'Site / localisation', { required: true }), T('client', 'Maître d’ouvrage'), D('date_investigation', 'Date des investigations'), T('methode', 'Méthodes de reconnaissance (SPT, pénétromètre, puits…)'), TA('contexte', 'Contexte géologique et hydrogéologique'),
      TA('interpretation', 'Interprétation et paramètres de calcul'), TA('fondations', 'Recommandations de fondations'), TA('precautions', 'Précautions d’exécution'), T('ingenieur', 'Ingénieur géotechnicien')],
    tables: [{ k: 'sondages', label: 'Sondages', columns: [Col('id', 'Sondage'), { k: 'profondeur', label: 'Prof. (m)', type: 'number', align: 'right' }, Col('nature', 'Nature du sol'), { k: 'spt', label: 'N (SPT)', type: 'number', align: 'right' }, { k: 'portance', label: 'q adm (kPa)', type: 'number', align: 'right' }, Col('nappe', 'Nappe')] },
      { k: 'essais', label: 'Essais de laboratoire', columns: [Col('echantillon', 'Échantillon'), Col('essai', 'Essai'), Col('resultat', 'Résultat'), Col('norme', 'Norme')] }],
    signatures: [{ label: 'L’Ingénieur géotechnicien', issuer: true }, 'Visa du Maître d’ouvrage'],
    subtitle: function (ctx) { return ctx.data.projet; },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h;
      return h.kv([['Projet', d.projet], ['Site', d.site], ['Maître d’ouvrage', d.client], ['Investigations', d.date_investigation ? h.dateFr(d.date_investigation) : ''], ['Méthodes', d.methode], ['Établi par', d.ingenieur]]) + h.section('Contexte géologique et hydrogéologique', h.para(d.contexte)) +
        h.section('Résultats des sondages', h.table([{ label: 'Sondage', k: 'id' }, { label: 'Prof. (m)', k: 'profondeur', align: 'right' }, { label: 'Nature du sol', k: 'nature' }, { label: 'N (SPT)', k: 'spt', align: 'right' }, { label: 'q adm (kPa)', k: 'portance', align: 'right' }, { label: 'Nappe', k: 'nappe' }], d.sondages)) +
        h.section('Essais de laboratoire', h.table([{ label: 'Échantillon', k: 'echantillon' }, { label: 'Essai', k: 'essai' }, { label: 'Résultat', k: 'resultat' }, { label: 'Norme', k: 'norme' }], d.essais)) +
        h.section('Interprétation et paramètres de calcul', h.para(d.interpretation)) + h.section('Recommandations de fondations', h.para(d.fondations)) + h.section('Précautions d’exécution', h.para(d.precautions));
    }
  });

  /* ═════════════ ADMINISTRATIF ═════════════ */
  C.register({
    id: 'document-administratif', label: 'Document administratif', category: 'administratif', prefix: 'DA', description: 'Lettre, note de service, procès-verbal ou courrier administratif.', noTitle: true,
    fields: [S('nature', 'Nature du document', ['Lettre', 'Note de service', 'Procès-verbal', 'Communiqué', 'Décision']), T('objet', 'Objet', { required: true }), T('reference', 'Référence'), T('destinataire', 'Destinataire (nom et fonction)'), TA('destinataire_adresse', 'Adresse du destinataire'), T('lieu', 'Lieu d’émission'), TA('corps', 'Texte du document', { required: true }), T('pj', 'Pièces jointes')],
    signatures: [{ label: 'Pour l’organisation', issuer: true }], defaults: { nature: 'Lettre' },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, p = ctx.profile, lieu = d.lieu || p.city;
      return '<div class="lt-meta"><div>' + (ctx.number ? 'N° <b>' + esc(ctx.number) + '</b>' : '') + (d.reference ? '<br>Réf. : ' + esc(d.reference) : '') + '</div><div>' + (lieu ? esc(lieu) + ', le ' : 'Le ') + esc(h.dateFr(d.date || ctx.date)) + '</div></div>' +
        (d.nature !== 'Lettre' ? '<div class="tb"><div class="ty" style="font-size:16pt">' + esc(d.nature) + '</div></div>' : '') +
        (d.destinataire ? '<div class="lt-to"><b>' + esc(d.destinataire) + '</b>' + (d.destinataire_adresse ? '<br>' + h.nl2br(d.destinataire_adresse) : '') + '</div>' : '') +
        '<div class="lt-obj">Objet : ' + esc(d.objet) + '</div>' + h.para(d.corps) + (d.pj ? '<p class="muted" style="margin-top:4mm">P.J. : ' + esc(d.pj) + '</p>' : '');
    }
  });
  C.register({
    id: 'attestation', label: 'Attestation', category: 'administratif', prefix: 'ATT', description: 'Attestation (travail, stage, service fait, participation…).',
    fields: [T('beneficiaire', 'Bénéficiaire', { required: true }), T('qualite', 'Fonction / qualité'), T('naissance', 'Né(e) le / à'), TA('texte', 'Objet de l’attestation', { required: true }), T('lieu', 'Fait à'), TA('mention', 'Mention (« Pour servir et valoir ce que de droit »)')],
    signatures: [{ label: 'La Direction', issuer: true }],
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, p = ctx.profile;
      return '<p class="txt" style="font-size:11pt;margin:8mm 0 5mm">Je soussigné(e), <b>' + esc(p.signatory.name || 'la Direction') + '</b>, ' + esc(p.signatory.role || '') + ' de <b>' + esc(p.legal_name || p.name) + '</b>, atteste que :</p>' +
        '<div class="note" style="font-size:12pt"><b>' + esc(d.beneficiaire) + '</b>' + (d.qualite ? ' — ' + esc(d.qualite) : '') + (d.naissance ? '<br><span class="muted" style="font-size:9pt">Né(e) : ' + esc(d.naissance) + '</span>' : '') + '</div>' +
        '<p class="txt" style="font-size:11pt;line-height:1.7">' + h.nl2br(d.texte) + '</p><p class="txt" style="margin-top:6mm">' + esc(d.mention || 'La présente attestation est délivrée pour servir et valoir ce que de droit.') + '</p>' +
        '<p style="margin-top:8mm;text-align:right">Fait à ' + esc(d.lieu || p.city || '…') + ', le ' + esc(h.dateFr(d.date || ctx.date)) + '</p>';
    }
  });
  C.register({
    id: 'certificat', label: 'Certificat', category: 'formation', prefix: 'CERT', description: 'Certificat de formation (format paysage, cadre institutionnel).', bare: true, page: { size: 'A4', orientation: 'landscape' },
    fields: [T('beneficiaire', 'Nom du bénéficiaire', { required: true }), T('formation', 'Intitulé de la formation', { required: true }), T('debut', 'Du'), T('fin', 'Au'), T('duree', 'Durée'), T('lieu', 'Lieu'), T('mention', 'Mention (Bien, Très bien…)'), TA('programme', 'Matières / programme')],
    signatures: [{ label: 'Le Directeur Général', issuer: true }, 'Le Formateur'],
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, p = ctx.profile;
      return '<div class="cert">' + (p.logo ? '<img class="lg" src="' + esc(p.logo) + '" alt="">' : '') + '<div class="org">' + esc(p.name) + '</div>' + (p.tagline ? '<div class="muted" style="font-size:9pt">' + esc(p.tagline) + '</div>' : '') +
        '<h1>Certificat</h1><p class="muted">décerné à</p><div class="rcp">' + esc(d.beneficiaire) + '</div>' +
        '<p>pour avoir suivi avec assiduité la formation professionnelle <b>' + esc(d.formation) + '</b>' + (d.debut ? ', du ' + esc(h.dateShort(d.debut)) + (d.fin ? ' au ' + esc(h.dateShort(d.fin)) : '') : '') + (d.lieu ? ', à ' + esc(d.lieu) : '') + (d.duree ? ', d’une durée de ' + esc(d.duree) : '') + '.</p>' +
        (d.programme ? '<p class="muted" style="font-size:9.5pt">' + h.nl2br(d.programme) + '</p>' : '') + (d.mention ? '<div class="mn">Mention : ' + esc(d.mention) + '</div>' : '') +
        '<p class="muted" style="margin-top:6mm;font-size:9pt">Certificat n° <b>' + esc(ctx.number || '—') + '</b> · délivré le ' + esc(h.dateFr(d.date || ctx.date)) + '</p>' + C._internals.signatures(ctx, ctx.tpl.signatures) + '</div>';
    }
  });
  C.register({
    id: 'document-libre', label: 'Document libre', category: 'administratif', prefix: 'DOC', description: 'Document sur mesure composé de blocs : titres, paragraphes, listes et tableaux.',
    fields: [T('titre', 'Titre du document', { required: true }), T('soustitre', 'Sous-titre')],
    tables: [{ k: 'blocs', label: 'Contenu', columns: [S('type', 'Type de bloc', ['titre', 'paragraphe', 'liste', 'tableau', 'saut de page']), { k: 'contenu', label: 'Contenu (liste : une ligne par puce · tableau : colonnes séparées par « ; »)', type: 'textarea' }] }],
    signatures: [{ label: 'Le Responsable', issuer: true }],
    subtitle: function (ctx) { return ctx.data.titre; },
    render: function (ctx) {
      var h = ctx.h; return (ctx.data.soustitre ? '<p class="txt muted">' + esc(ctx.data.soustitre) + '</p>' : '') + ctx.data.blocs.map(function (b) {
        var c = b.contenu || '';
        if (b.type === 'titre') return '<section class="blk"><h2>' + esc(c) + '</h2></section>';
        if (b.type === 'liste') return '<ul>' + c.split(/\r?\n/).filter(Boolean).map(function (l) { return '<li>' + esc(l) + '</li>'; }).join('') + '</ul>';
        if (b.type === 'saut de page') return '<div style="break-after:page"></div>';
        if (b.type === 'tableau') {
          var rows = c.split(/\r?\n/).filter(Boolean).map(function (l) { return l.split(';').map(function (x) { return x.trim(); }); }); if (!rows.length) return '';
          var head = rows.shift(); return h.table(head.map(function (t, i) { return { label: t, get: function (r) { return r[i] || ''; } }; }), rows);
        }
        return h.para(c);
      }).join('');
    }
  });

  /* ═════════════ FORMATION & SÉANCES ═════════════ */
  C.register({
    id: 'formulaire-inscription', label: 'Formulaire d’inscription', category: 'formation', prefix: 'INS', interactive: true, noTitle: false, public: { categories: ['apprenant'], slug: 'inscription-formation', title: 'Inscription à une formation', intro: 'Remplissez la fiche en ligne ou téléchargez un PDF à compléter à la main ou à l’écran.' },
    description: 'Fiche d’inscription à une formation ; PDF interactif avec champs remplissables.',
    fields: [T('formation', 'Formation souhaitée'), T('session', 'Session / période'), T('nom', 'Nom et prénoms', { required: true }), D('naissance', 'Date de naissance'), T('lieu_naissance', 'Lieu de naissance'), T('nationalite', 'Nationalité'), T('profession', 'Profession / niveau d’études'),
      T('tel', 'Téléphone'), T('email', 'E-mail'), TA('adresse', 'Adresse'), T('urgence', 'Personne à prévenir (nom et téléphone)'), TA('observations', 'Observations')],
    signatures: ['Signature du candidat', { label: 'Visa de l’administration', issuer: true }],
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, F = function (n, o, v) { o = o || {}; o.value = o.value != null ? o.value : v; return h.field(ctx, n, o); };
      var rows = [['Formation souhaitée', 'formation', d.formation, 120], ['Session / période', 'session', d.session, 120], ['Nom et prénoms', 'nom', d.nom, 120], ['Date de naissance', 'naissance', d.naissance ? h.dateShort(d.naissance) : '', 50], ['Lieu de naissance', 'lieu_naissance', d.lieu_naissance, 90], ['Nationalité', 'nationalite', d.nationalite, 70],
        ['Profession / études', 'profession', d.profession, 120], ['Téléphone', 'tel', d.tel, 70], ['E-mail', 'email', d.email, 120], ['Adresse', 'adresse', d.adresse, 120, 14], ['Personne à prévenir', 'urgence', d.urgence, 120]];
      return h.section('Informations du candidat', '<table class="frm">' + rows.map(function (r) { return '<tr><td class="l">' + esc(r[0]) + '</td><td>' + F('f_' + r[1], { w: r[3], h: r[4] || 7, type: r[4] ? 'textarea' : 'text' }, r[2]) + '</td></tr>'; }).join('') + '</table>') +
        h.section('Observations', F('f_observations', { w: 176, h: 17, type: 'textarea' }, d.observations)) +
        '<p class="muted" style="font-size:8.4pt;margin-top:3mm">Je certifie l’exactitude des renseignements ci-dessus et m’engage à respecter le règlement intérieur de la formation.</p>';
    }
  });
  C.register({
    id: 'document-formation', label: 'Document de formation', category: 'formation', prefix: 'FOR', description: 'Programme, convocation ou fiche de formation avec modules.',
    fields: [S('nature', 'Nature', ['Programme de formation', 'Convocation', 'Fiche de formation', 'Règlement intérieur']), T('formation', 'Intitulé de la formation', { required: true }), T('dates', 'Dates / période'), T('lieu', 'Lieu'), T('public', 'Public visé'), T('prerequis', 'Prérequis'), T('duree', 'Durée totale'), T('tarif', 'Tarif'),
      TA('objectifs', 'Objectifs pédagogiques'), TA('modalites', 'Modalités pédagogiques et d’évaluation'), TA('informations', 'Informations pratiques / observations')],
    tables: [{ k: 'modules', label: 'Modules', columns: [Col('module', 'Module'), Col('contenu', 'Contenu'), Col('duree', 'Durée', { align: 'center' }), Col('formateur', 'Formateur')] }],
    signatures: [{ label: 'La Direction', issuer: true }], defaults: { nature: 'Programme de formation' },
    subtitle: function (ctx) { return ctx.data.formation; },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h;
      return '<div class="note"><b>' + esc(d.nature) + '</b></div>' + h.kv([['Formation', d.formation], ['Dates', d.dates], ['Lieu', d.lieu], ['Public visé', d.public], ['Prérequis', d.prerequis], ['Durée', d.duree], ['Tarif', d.tarif]]) + h.section('Objectifs pédagogiques', h.para(d.objectifs)) +
        h.section('Programme', h.table([{ label: 'Module', k: 'module' }, { label: 'Contenu', k: 'contenu' }, { label: 'Durée', k: 'duree', align: 'center' }, { label: 'Formateur', k: 'formateur' }], d.modules)) + h.section('Modalités', h.para(d.modalites)) + h.section('Informations pratiques', h.para(d.informations));
    }
  });
  C.register({
    id: 'planning-seances', label: 'Planning des séances', category: 'formation', prefix: 'SEA', page: { size: 'A4', orientation: 'landscape' }, description: 'Planning de séances (formation, cours, TP/TD) destiné aux apprenants et aux formateurs. Utilisé par le module Séances.',
    fields: [T('titre', 'Titre du planning'), T('periode', 'Période'), TA('consignes', 'Consignes aux participants')],
    tables: [{ k: 'seances', label: 'Séances', required: true, columns: [{ k: 'date', label: 'Date', type: 'date' }, Col('debut', 'Début'), Col('fin', 'Fin'), Col('formation', 'Formation'), Col('module', 'Module'), Col('formateur', 'Formateur'), Col('salle', 'Salle / lieu')] }],
    signatures: [{ label: 'La Direction pédagogique', issuer: true }], defaults: { titre: 'Planning des séances', consignes: 'Veuillez vous préparer à l’avance pour chaque module indiqué et vous présenter 10 minutes avant le début de la séance.' },
    subtitle: function (ctx) { return ctx.data.titre + (ctx.data.periode ? ' — ' + ctx.data.periode : ''); },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, rows = d.seances.slice().sort(function (a, b) { return (a.date + a.debut).localeCompare(b.date + b.debut); });
      return h.table([{ label: 'Date', get: function (r) { return h.dateShort(r.date); }, raw: false }, { label: 'Horaire', get: function (r) { return (r.debut || '') + (r.fin ? ' – ' + r.fin : ''); } }, { label: 'Formation', k: 'formation' }, { label: 'Module', k: 'module' }, { label: 'Formateur', k: 'formateur' }, { label: 'Salle / lieu', k: 'salle' }], rows, { empty: 'Aucune séance planifiée.' }) +
        (d.consignes ? '<div class="note">' + h.nl2br(d.consignes) + '</div>' : '');
    }
  });
  C.register({
    id: 'feuille-presence', label: 'Feuille de présence', category: 'formation', prefix: 'PRE', page: { size: 'A4', orientation: 'portrait' }, interactive: true, description: 'Feuille d’émargement d’une séance ; cases à cocher interactives en PDF.',
    fields: [T('formation', 'Formation', { required: true }), T('module', 'Module / thème'), D('seance_date', 'Date de la séance'), T('horaire', 'Horaire'), T('lieu', 'Lieu / salle'), T('formateur', 'Formateur')],
    tables: [{ k: 'participants', label: 'Participants', required: true, columns: [Col('nom', 'Nom et prénoms'), Col('matricule', 'Matricule')] }],
    signatures: [{ label: 'Le Formateur', issuer: false }, { label: 'La Direction', issuer: true }],
    subtitle: function (ctx) { return ctx.data.formation; },
    render: function (ctx) {
      var d = ctx.data, h = ctx.h;
      return h.kv([['Formation', d.formation], ['Module', d.module], ['Date', d.seance_date ? h.dateFr(d.seance_date) : ''], ['Horaire', d.horaire], ['Lieu', d.lieu], ['Formateur', d.formateur]]) +
        h.table([{ label: 'N°', align: 'center', w: '5%', get: function (r, i) { return i + 1; } }, { label: 'Nom et prénoms', k: 'nom' }, { label: 'Matricule', k: 'matricule' },
          { label: 'Présent', align: 'center', raw: true, get: function (r, i) { return h.field(ctx, 'present_' + (i + 1), { w: 6, h: 6, type: 'checkbox' }); } }, { label: 'Signature', raw: true, w: '26%', get: function () { return '<span style="display:block;height:7mm"></span>'; } }], d.participants);
    }
  });

  /* ═════════════ FORMULAIRES PUBLICS (client / chantier) ═════════════ */
  C.register({
    id: 'demande-devis', label: 'Demande de devis', category: 'commercial', prefix: 'DD', interactive: true, public: { categories: ['client'], slug: 'demande-devis', title: 'Demande de devis', intro: 'Décrivez votre projet : le document généré peut être envoyé à l’entreprise de votre choix.' },
    description: 'Demande de devis adressée à une entreprise ; PDF interactif.',
    fields: [T('nom', 'Nom / raison sociale', { required: true }), T('tel', 'Téléphone'), T('email', 'E-mail'), TA('adresse', 'Adresse'), S('type_projet', 'Nature du projet', ['Construction neuve', 'Rénovation', 'Extension', 'Étude technique', 'Plans / permis', 'Suivi de chantier', 'Formation', 'Autre']), T('localisation', 'Localisation du projet'), N('surface', 'Surface approximative (m²)'), T('budget', 'Budget estimé'), T('delai', 'Délai souhaité'), TA('description', 'Description du besoin', { required: true })],
    signatures: ['Le Demandeur'],
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, F = function (n, o, v) { o.value = v; return h.field(ctx, n, o); };
      var rows = [['Nom / raison sociale', 'nom', d.nom, 110], ['Téléphone', 'tel', d.tel, 70], ['E-mail', 'email', d.email, 110], ['Adresse', 'adresse', d.adresse, 110], ['Nature du projet', 'type_projet', d.type_projet, 90], ['Localisation', 'localisation', d.localisation, 110], ['Surface (m²)', 'surface', d.surface, 40], ['Budget estimé', 'budget', d.budget, 70], ['Délai souhaité', 'delai', d.delai, 70]];
      return h.section('Le demandeur et le projet', '<table class="frm">' + rows.map(function (r) { return '<tr><td class="l">' + esc(r[0]) + '</td><td>' + F('f_' + r[1], { w: r[3] }, r[2]) + '</td></tr>'; }).join('') + '</table>') + h.section('Description du besoin', F('f_description', { w: 176, h: 50, type: 'textarea' }, d.description));
    }
  });
  C.register({
    id: 'fiche-incident', label: 'Fiche d’incident de chantier', category: 'technique', prefix: 'INC', interactive: true, public: { categories: ['chantier'], slug: 'fiche-incident', title: 'Fiche d’incident de chantier', intro: 'Déclarez un incident, un presque-accident ou un constat de sécurité.' },
    description: 'Déclaration d’incident / constat de sécurité sur chantier.',
    fields: [T('chantier', 'Chantier', { required: true }), D('date_incident', 'Date de l’incident'), T('heure', 'Heure'), T('lieu', 'Lieu précis'), S('gravite', 'Gravité', ['Presque-accident', 'Bénin', 'Sérieux', 'Grave']), T('personnes', 'Personnes concernées'), TA('description', 'Description des faits', { required: true }), TA('causes', 'Causes probables'), TA('mesures', 'Mesures immédiates et actions correctives'), T('declarant', 'Déclarant')],
    signatures: ['Le Déclarant', { label: 'Le Responsable sécurité', issuer: false }],
    render: function (ctx) {
      var d = ctx.data, h = ctx.h, F = function (n, o, v) { o.value = v; return h.field(ctx, n, o); };
      var rows = [['Chantier', 'chantier', d.chantier, 110], ['Date', 'date_incident', d.date_incident ? h.dateShort(d.date_incident) : '', 40], ['Heure', 'heure', d.heure, 30], ['Lieu précis', 'lieu', d.lieu, 110], ['Gravité', 'gravite', d.gravite, 60], ['Personnes concernées', 'personnes', d.personnes, 110], ['Déclarant', 'declarant', d.declarant, 90]];
      return h.section('Circonstances', '<table class="frm">' + rows.map(function (r) { return '<tr><td class="l">' + esc(r[0]) + '</td><td>' + F('f_' + r[1], { w: r[3] }, r[2]) + '</td></tr>'; }).join('') + '</table>') +
        h.section('Description des faits', F('f_description', { w: 176, h: 36, type: 'textarea' }, d.description)) + h.section('Causes probables', F('f_causes', { w: 176, h: 20, type: 'textarea' }, d.causes)) + h.section('Mesures immédiates et actions correctives', F('f_mesures', { w: 176, h: 24, type: 'textarea' }, d.mesures));
    }
  });

  return C;
});
