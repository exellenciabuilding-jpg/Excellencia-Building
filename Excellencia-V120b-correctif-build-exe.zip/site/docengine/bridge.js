/* Excellencia Building — MOTEUR DOCUMENTAIRE · pont avec le logiciel existant (reprise de V118 sur le moteur V119d)
 * Ne remplace et ne supprime rien. Il :
 *   1. fournit à TOUS les modules un point d'entrée unique : window.exbDocument(modele, données, options) ;
 *   2. inscrit les impressions historiques (EXBPrint.html) à l'historique commun ; en-tête du profil ajouté aux pièces qui n'affichent pas déjà l'identité (V120f) ;
 *   3. inscrit les exports « capture d'écran » (savePdf : html2canvas + jsPDF) à l'historique commun — ce sont des PDF-images, non refaits en modèles.
 * Retrait : supprimer la balise <script> de ce fichier. */
(function (w) {
  'use strict';
  if (w.__exbDocBridge) return; w.__exbDocBridge = true;
  function D() { return w.EXBDoc; }
  function E() { return w.EXBDocEngine; }

  /* exbDocument('devis', { client_nom:'…', lignes:[…] }, { module:'metre' })                -> télécharge / imprime
   * exbDocument('facture', data, { module:'facturation', mode:'blob' })                    -> { blob, number } (serveur) ou { html, number } (local)
   * exbDocument('attestation', data, { mode:'html' })                                      -> { html, number } sans impression */
  w.exbDocument = function (modele, data, o) {
    o = o || {}; var d = D();
    if (!d) return Promise.reject(new Error('Moteur documentaire indisponible'));
    if (o.mode === 'html') {
      try { var r = d.core.render(modele, data || {}, { profile: d.profile.get(), options: o.options || {}, number: o.number || '', mode: 'print' }); return Promise.resolve({ html: r.html, number: r.number, title: r.title }); }
      catch (e) { return Promise.reject(e); }
    }
    return d.generate(modele, data || {}, { source: o.module || 'modules', options: o.options, action: o.mode === 'blob' ? 'none' : (o.action || 'print') });
  };

  function moduleOfTitle(t) {
    t = String(t || '').toUpperCase();
    var m = [[/QCM|ÉPREUVE|EPREUVE/, 'formations'], [/PAIEMENT|REÇU|RECU|BORDEREAU|ATTESTATION|CARTE|PARTICIPANT/, 'formations'], [/PLANNING|GANTT|PILOTAGE|CHANTIER/, 'chantiers'], [/PLAN|CARTOUCHE/, 'plans'], [/DEVIS|FACTURE/, 'devis']];
    for (var i = 0; i < m.length; i++) if (m[i][0].test(t)) return m[i][1];
    return 'modules';
  }
  function note(e) { try { var en = E(); if (en && en.noteHistory) en.noteHistory(e); } catch (x) {} }

  /* la pièce affiche-t-elle déjà l'identité de l'entreprise (nom du profil, de la marque ou nom d'origine) ? */
  function showsIdentity(html) {
    try {
      var txt = String(html).replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<[^>]+>/g, ' ').toLowerCase();
      var names = ['excellencia building'];
      var p = D() && D().profile && D().profile.get && D().profile.get(); if (p && p.name) names.push(String(p.name).toLowerCase());
      var b = w.EXB_BRAND; if (b && b.name) names.push(String(b.name).toLowerCase());
      return names.some(function (n) { return n.length > 2 && txt.indexOf(n) >= 0; });
    } catch (e) { return false; }
  }
  w.EXBDocShowsIdentity = showsIdentity;
  /* EXBPrint.html : mise en page propre à chaque module conservée ; inscription à l'historique + habillage optionnel */
  function wrapLegacy() {
    var P = w.EXBPrint; if (!P || P.__docWrapped || !P.html || !P.full) return false;
    var orig = P.html; P.__docWrapped = true;
    P.html = function (title, body, o) {
      /* V120g : l'identité d'origine codée en dur dans les pièces est remplacée par celle de l'entreprise (srcdoc/blob ne passent pas par exb-brand.js) */
      try { if (typeof w.exbRebrand === 'function') { title = w.exbRebrand(String(title == null ? '' : title)); body = w.exbRebrand(String(body == null ? '' : body)); } } catch (e0) {}
      note({ type: 'module', titre: String(title || 'Document').slice(0, 120), module: (o && o.module) || moduleOfTitle(title), statut: 'impression' });
      var on = true; try { on = w.localStorage.getItem('EXB_DOC_HABILLAGE') !== '0'; } catch (e) {}
      var html = String(body == null ? '' : body);
      /* pièces qui portent déjà leur propre en-tête ou qui sont des images / plans : laissées telles quelles */
      /* V120f : décision selon le CONTENU et non plus selon le seul titre.
       *  - images / plans / cartes / cartouches : jamais d'en-tête ajouté (la pièce EST l'image ou porte son cartouche) ;
       *  - reçus, bordereaux, suivi des paiements, attestations de signature : l'en-tête commun est ajouté seulement si la pièce
       *    n'affiche pas déjà le nom de l'entreprise (sinon doublon) ; le nom d'origine est aussi reconnu (exb-brand.js le remplace ensuite). */
      var t0 = String(title || '');
      var imageOrPlan = /^(Carte\b|Plans?\b)|cartouche/i.test(t0) || (/<img\b/i.test(html) && !/<(table|p|h[1-6]|ul|ol)\b/i.test(html));
      var ownKind = /^(Re[çc]u|Bordereau|Suivi des paiements|Attestation de signature)/i.test(t0);
      var skip = imageOrPlan || html.indexOf('data-exb-habillage') >= 0 || (o && o.nativeLayout) || (ownKind && showsIdentity(html));
      if (!on || skip || !D()) return orig.call(P, title, body, o);
      try {
        var p = D().profile.get(), esc = D().core.esc, c = p.colors || {};
        if (!p.name && !p.logo) return orig.call(P, title, body, o);
        var head = '<div data-exb-habillage="1" style="display:flex;align-items:center;gap:10px;background:' + esc(c.primary || '#173565') + ';color:#fff;padding:8px 12px;border-bottom:3px solid ' + esc(c.accent || '#b8923a') + ';margin:0 0 10px;-webkit-print-color-adjust:exact;print-color-adjust:exact">' +
          (p.logo ? '<img src="' + esc(p.logo) + '" style="height:36px;background:#fff;border-radius:3px;padding:2px">' : '') + '<b style="font-size:13pt;text-transform:uppercase">' + esc(p.name) + '</b>' +
          '<span style="margin-left:auto;font-size:8pt;text-align:right">' + esc([p.address, (p.phones || [])[0], (p.emails || [])[0]].filter(Boolean).join(' · ')) + '</span></div>';
        var m = html.match(/<body[^>]*>/i), out;
        if (m) out = html.slice(0, m.index + m[0].length) + head + html.slice(m.index + m[0].length);
        else if (/<\/head>/i.test(html)) out = html.replace(/<\/head>/i, '</head><body>' + head) ;
        else if (/<!doctype|<html/i.test(html)) out = html.replace(/(<html[^>]*>)/i, '$1<body>' + head);
        else out = head + html;
        return orig.call(P, title, out, o);
      } catch (e3) { return orig.call(P, title, body, o); }
    };
    return true;
  }
  /* savePdf (html2canvas + jsPDF) : PDF-images, inscrits à l'historique commun */
  function wrapSavePdf() {
    if (typeof w.savePdf !== 'function' || w.savePdf.__doc) return false;
    var orig = w.savePdf;
    w.savePdf = function (pdf, filename) {
      note({ type: 'module', titre: String(filename || 'document.pdf').replace(/\.pdf$/i, '').slice(0, 120), module: moduleOfTitle(filename), statut: 'PDF image' });
      return orig.apply(this, arguments);
    };
    w.savePdf.__doc = true; return true;
  }
  /* « Identité de l'entreprise » enregistrée → met à jour le profil documentaire (un seul endroit à remplir) */
  function wrapIdentity() {
    var E0 = w.EXBEntreprise; if (!E0 || E0.__docWrapped || !E0.save) return false;
    var orig = E0.save; E0.__docWrapped = true;
    E0.save = function () { var r = orig.apply(this, arguments); try { var d = D(); if (d && d.profile.fromIdentity) setTimeout(function () { d.profile.fromIdentity(); }, 0); } catch (e) {} return r; };
    return true;
  }
  /* V120j : la configuration peut aussi venir de l'écran de premier lancement (exb-brand.js), de entreprise.json ou d'un autre onglet : le profil documentaire suit au chargement
   * et à chaque modification de l'identité enregistrée sur l'appareil. */
  function followIdentity() { try { var d = D(); if (d && d.profile && d.profile.fromIdentity) d.profile.fromIdentity(); } catch (e) {} }
  try { if (typeof w.setTimeout === "function") w.setTimeout(followIdentity, 800); } catch (e) {}
  try { w.addEventListener('storage', function (ev) { if (ev && /^EXB_(BRAND|IDENTITE)_V1$/.test(ev.key || '')) followIdentity(); }); } catch (e) {}
  var t3 = 0, i3 = setInterval(function () { if (wrapIdentity() || ++t3 > 40) clearInterval(i3); }, 500);
  var t1 = 0, i1 = setInterval(function () { if (wrapLegacy() || ++t1 > 40) clearInterval(i1); }, 500);
  var t2 = 0, i2 = setInterval(function () { if (wrapSavePdf() || ++t2 > 60) clearInterval(i2); }, 700);
  w.EXBDocHabillage = function (on) { try { if (on === undefined) return w.localStorage.getItem('EXB_DOC_HABILLAGE') !== '0'; w.localStorage.setItem('EXB_DOC_HABILLAGE', on ? '1' : '0'); return !!on; } catch (e) { return false; } };
})(window);
