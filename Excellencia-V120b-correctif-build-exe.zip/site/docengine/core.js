/* Excellencia Building — MOTEUR DOCUMENTAIRE UNIVERSEL · noyau (V118)
 *
 * Fichier ISOMORPHE : le même code tourne dans le navigateur (aperçu, mode hors connexion) et sur le serveur
 * (Node + Chromium/Playwright pour le PDF final). Un seul moteur, un seul jeu de modèles.
 *
 *   EXBDocCore.register(modele)                    enregistre un modèle de document
 *   EXBDocCore.list() / describe(type)             catalogue des modèles (schémas des champs)
 *   EXBDocCore.validate(type, data)                contrôle + nettoyage des données
 *   EXBDocCore.render(type, data, opts)            → { html, title, filename, number, fields, page }
 *   EXBDocCore.normalizeProfile(p)                 profil documentaire nettoyé (couleurs, images, textes)
 *   EXBDocCore.computeTotals(lignes, opts)         totaux devis / factures
 *   EXBDocCore.numberFormat(...)                   numérotation automatique
 *
 * Le noyau ne lit AUCUNE donnée par lui-même : le profil de l'organisation, les options du modèle et le numéro
 * lui sont fournis par l'appelant (serveur : base centralisée ; navigateur : client.js).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.EXBDocCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var VERSION = '1.0.0';
  var TEMPLATES = {}, ORDER = [];
  var LIMITS = { str: 20000, shortStr: 300, rows: 500, image: 1800000, fields: 400 };

  /* ───────────────────────── utilitaires ───────────────────────── */
  function s(v) { return v == null ? '' : String(v); }
  function esc(v) { return s(v).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function cssStr(v) { return '"' + s(v).replace(/[\\"]/g, '\\$&').replace(/[\r\n]+/g, ' ').replace(/</g, '\\3C ') + '"'; }
  function nl2br(v) { return esc(v).replace(/\r?\n/g, '<br>'); }
  function num(v) {
    if (typeof v === 'number') return isFinite(v) ? v : 0;
    var t = s(v).replace(/\s| /g, '').replace(',', '.');
    var n = parseFloat(t); return isFinite(n) ? n : 0;
  }
  function round2(n) { return Math.round((n + Number.EPSILON) * 100) / 100; }
  function money(v, cur) {
    var n = round2(num(v)), neg = n < 0; n = Math.abs(n);
    var parts = n.toFixed(2).split('.'), ip = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    return (neg ? '-' : '') + ip + ',' + parts[1] + (cur ? ' ' + esc(cur) : '');
  }
  var MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  function parseDate(d) {
    if (d instanceof Date) return d;
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s(d)); if (m) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 12));
    m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s(d)); if (m) return new Date(Date.UTC(+m[3], +m[2] - 1, +m[1], 12));
    return null;
  }
  function dateFr(d) { var x = parseDate(d); return x ? x.getUTCDate() + (x.getUTCDate() === 1 ? 'er' : '') + ' ' + MOIS[x.getUTCMonth()] + ' ' + x.getUTCFullYear() : s(d); }
  function dateShort(d) { var x = parseDate(d); return x ? ('0' + x.getUTCDate()).slice(-2) + '/' + ('0' + (x.getUTCMonth() + 1)).slice(-2) + '/' + x.getUTCFullYear() : s(d); }
  function todayISO() { var n = new Date(); return n.getFullYear() + '-' + ('0' + (n.getMonth() + 1)).slice(-2) + '-' + ('0' + n.getDate()).slice(-2); }
  function slug(v) { return s(v).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-+|-+$/g, '').toLowerCase().slice(0, 60) || 'document'; }

  var HEX = /^#[0-9a-fA-F]{6}$/;
  function color(c, def) { c = s(c).trim(); if (/^#[0-9a-fA-F]{3}$/.test(c)) c = '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]; return HEX.test(c) ? c.toLowerCase() : def; }
  /* images : uniquement des « data: » PNG/JPEG/WebP/GIF/SVG (aucune URL externe : pas de requête réseau depuis le moteur) */
  var IMG = /^data:image\/(png|jpe?g|webp|gif|svg\+xml);base64,[A-Za-z0-9+/=\s]+$/i;
  function img(u, max) { u = s(u).trim(); return u && u.length <= (max || LIMITS.image) && IMG.test(u) ? u.replace(/\s+/g, '') : ''; }
  function clip(v, n) { return s(v).slice(0, n || LIMITS.str); }

  /* ───────────────────────── nombre en lettres (français) ───────────────────────── */
  var U = ['zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix', 'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf'];
  var T = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante'];
  function below100(n) {
    if (n < 20) return U[n];
    var d = Math.floor(n / 10), u = n % 10;
    if (d === 7 || d === 9) { var b = d === 7 ? 'soixante' : 'quatre-vingt'; var r = 10 + u; return b + (d === 7 && u === 1 ? ' et ' : '-') + U[r]; }
    if (d === 8) return u === 0 ? 'quatre-vingts' : 'quatre-vingt-' + U[u];
    return T[d] + (u === 0 ? '' : (u === 1 ? ' et un' : '-' + U[u]));
  }
  function below1000(n, final) {
    var c = Math.floor(n / 100), r = n % 100, out = '';
    if (c) out = (c === 1 ? 'cent' : U[c] + ' cent') + (r === 0 && c > 1 && final ? 's' : '');
    if (r) out += (out ? ' ' : '') + below100(r);
    return out;
  }
  function wordsFr(n) {
    n = Math.floor(Math.abs(n)); if (n === 0) return 'zéro';
    if (n > 999999999999) return String(n);
    var out = [], mil = Math.floor(n / 1e9), m = Math.floor((n % 1e9) / 1e6), k = Math.floor((n % 1e6) / 1000), r = n % 1000;
    if (mil) out.push((mil === 1 ? 'un' : below1000(mil)) + ' milliard' + (mil > 1 ? 's' : ''));
    if (m) out.push(below1000(m) + ' million' + (m > 1 ? 's' : ''));
    if (k) out.push(k === 1 ? 'mille' : below1000(k) + ' mille');
    if (r) out.push(below1000(r, true));
    return out.join(' ');
  }
  var CUR = { USD: ['dollar américain', 'dollars américains', 'cent', 'cents'], EUR: ['euro', 'euros', 'centime', 'centimes'], CDF: ['franc congolais', 'francs congolais', 'centime', 'centimes'], XOF: ['franc CFA', 'francs CFA', 'centime', 'centimes'], XAF: ['franc CFA', 'francs CFA', 'centime', 'centimes'] };
  function amountWords(v, cur) {
    var n = round2(Math.abs(num(v))), ent = Math.floor(n), cts = Math.round((n - ent) * 100), c = CUR[s(cur).toUpperCase()] || [s(cur), s(cur), 'centime', 'centimes'];
    var t = wordsFr(ent) + ' ' + (ent > 1 ? c[1] : c[0]); if (cts) t += ' et ' + wordsFr(cts) + ' ' + (cts > 1 ? c[3] : c[2]);
    return t.charAt(0).toUpperCase() + t.slice(1);
  }

  /* ───────────────────────── profil documentaire ───────────────────────── */
  var DEFAULT_PROFILE = {
    name: '', legal_name: '', tagline: '', logo: '',
    address: '', city: '', country: '', phones: [], emails: [], website: '',
    ids: [],                       /* [{label:'RCCM', value:'…'}, …] numéros d'identification & informations légales */
    legal: '',                     /* mentions légales libres (pied de page) */
    colors: { primary: '#173565', accent: '#c49a38', secondary: '#0f4aa8' },
    signature: '', stamp: '',
    signatory: { name: '', role: 'Directeur Général' },
    bank: '', currency: 'USD', footer_text: '', extra: []
  };
  function list(a, n, len) { return (Array.isArray(a) ? a : s(a).split(/[\n;]+/)).map(function (x) { return clip(x, len || 120).trim(); }).filter(Boolean).slice(0, n || 10); }
  function pairs(a, n) {
    return (Array.isArray(a) ? a : []).map(function (x) { return x && typeof x === 'object' ? { label: clip(x.label, 60).trim(), value: clip(x.value, 200).trim() } : null; })
      .filter(function (x) { return x && (x.label || x.value); }).slice(0, n || 20);
  }
  function normalizeProfile(p) {
    p = p && typeof p === 'object' ? p : {};
    var c = p.colors || {}, sg = p.signatory || {};
    return {
      name: clip(p.name, 120).trim(), legal_name: clip(p.legal_name, 160).trim(), tagline: clip(p.tagline, 160).trim(), logo: img(p.logo),
      address: clip(p.address, 240).trim(), city: clip(p.city, 80).trim(), country: clip(p.country, 80).trim(),
      phones: list(p.phones, 6, 40), emails: list(p.emails, 6, 120), website: clip(p.website, 160).trim(),
      ids: pairs(p.ids, 12), legal: clip(p.legal, 1000).trim(),
      colors: { primary: color(c.primary, DEFAULT_PROFILE.colors.primary), accent: color(c.accent, DEFAULT_PROFILE.colors.accent), secondary: color(c.secondary, DEFAULT_PROFILE.colors.secondary) },
      signature: img(p.signature), stamp: img(p.stamp),
      signatory: { name: clip(sg.name, 120).trim(), role: clip(sg.role || 'Directeur Général', 80).trim() },
      bank: clip(p.bank, 600).trim(), currency: /^[A-Z]{3}$/.test(s(p.currency).toUpperCase()) ? s(p.currency).toUpperCase() : 'USD',
      footer_text: clip(p.footer_text, 300).trim(), extra: pairs(p.extra, 20),
      updated_at: s(p.updated_at).slice(0, 40)
    };
  }

  /* ───────────────────────── modèles : enregistrement, schéma, validation ───────────────────────── */
  function register(t) {
    if (!t || !/^[a-z0-9-]+$/.test(t.id || '') || typeof t.render !== 'function') throw new Error('modèle invalide');
    t.fields = t.fields || []; t.tables = t.tables || [];
    if (!TEMPLATES[t.id]) ORDER.push(t.id);
    TEMPLATES[t.id] = t; return t;
  }
  function describe(type) {
    var t = TEMPLATES[type]; if (!t) return null;
    return {
      id: t.id, label: t.label, category: t.category, description: t.description || '', prefix: t.prefix || 'DOC',
      fields: t.fields, tables: t.tables, signatures: t.signatures || [], page: t.page || { size: 'A4', orientation: 'portrait' },
      interactive: !!t.interactive, public: t.public || null, defaults: t.defaults || {}, hidden: !!t.hidden
    };
  }
  function listTemplates() { return ORDER.map(describe); }

  function cleanField(f, v) {
    var t = f.type || 'text';
    if (t === 'number') return v === '' || v == null ? '' : num(v);
    if (t === 'textarea') return clip(v, LIMITS.str);
    if (t === 'image') return img(v);
    if (t === 'select') { var ok = (f.options || []).map(function (o) { return typeof o === 'object' ? o.value : o; }); return ok.indexOf(v) >= 0 ? v : (f.options && f.options.length && !v ? '' : clip(v, 120)); }
    if (t === 'checkbox') return v === true || v === 'true' || v === 'on' || v === 1 || v === '1';
    return clip(v, 400);
  }
  function validate(type, data) {
    var t = TEMPLATES[type], errors = [], out = {};
    if (!t) return { ok: false, errors: ['Modèle inconnu : ' + type], data: {} };
    data = data && typeof data === 'object' ? data : {};
    var defs = t.defaults || {};
    t.fields.forEach(function (f) {
      var v = data[f.k]; if (v === undefined || v === null || v === '') v = defs[f.k] != null && (data[f.k] === undefined) ? defs[f.k] : v;
      v = cleanField(f, v); out[f.k] = v;
      if (f.required && (v === '' || v == null)) errors.push('Champ obligatoire : ' + (f.label || f.k));
    });
    t.tables.forEach(function (tb) {
      var rows = Array.isArray(data[tb.k]) ? data[tb.k] : (Array.isArray(defs[tb.k]) ? defs[tb.k] : []);
      out[tb.k] = rows.slice(0, LIMITS.rows).map(function (r) {
        r = r && typeof r === 'object' ? r : {}; var o = {};
        tb.columns.forEach(function (c) { o[c.k] = cleanField(c, r[c.k]); }); return o;
      }).filter(function (o) { return tb.columns.some(function (c) { return o[c.k] !== '' && o[c.k] !== false; }); });
      if (tb.required && !out[tb.k].length) errors.push('Au moins une ligne est requise : ' + (tb.label || tb.k));
    });
    /* V118 fusion : modèles « passthrough » (devis/facture/reçu du métré, pièces des modules) — charge utile structurée, nettoyée ici,
     * échappée par le modèle au rendu. Taille bornée ; les modèles doivent traiter chaque valeur comme non fiable. */
    if (t.passthrough) {
      var doc = data.doc && typeof data.doc === 'object' ? data.doc : {}, js = '';
      try { js = JSON.stringify(doc); } catch (e) { js = ''; }
      if (js.length > 6000000) errors.push('Document trop volumineux.');
      else out.doc = js ? JSON.parse(js) : {};
    }
    /* champs transverses acceptés par tous les modèles */
    out.date = out.date || (data.date ? clip(data.date, 20) : '');
    out.status = /^(brouillon|annulé|annule|duplicata|copie|original)$/i.test(s(data.status)) ? s(data.status).toLowerCase().replace('annule', 'annulé') : '';
    out.fieldValues = {};
    if (data.fieldValues && typeof data.fieldValues === 'object') Object.keys(data.fieldValues).slice(0, LIMITS.fields).forEach(function (k) { out.fieldValues[k.replace(/[^A-Za-z0-9_]/g, '_')] = clip(data.fieldValues[k], 400); });
    if (data.sign === false) out.sign = false;
    return { ok: !errors.length, errors: errors, data: out };
  }

  /* ───────────────────────── totaux (devis, factures, bons de commande) ───────────────────────── */
  function computeTotals(lignes, o) {
    o = o || {}; var sub = 0, rows = (lignes || []).map(function (l) {
      var q = num(l.qte), pu = num(l.pu), t = round2(q * pu); sub += t; return { designation: s(l.designation), unite: s(l.unite), qte: q, pu: pu, total: t };
    });
    sub = round2(sub);
    var rem = Math.min(100, Math.max(0, num(o.remise_pct))), remise = round2(sub * rem / 100), ht = round2(sub - remise);
    var tvaP = Math.max(0, num(o.tva_pct)), tva = round2(ht * tvaP / 100), ttc = round2(ht + tva), acompte = Math.max(0, num(o.acompte));
    return { rows: rows, sous_total: sub, remise_pct: rem, remise: remise, ht: ht, tva_pct: tvaP, tva: tva, ttc: ttc, acompte: acompte, reste: round2(ttc - acompte) };
  }

  /* ───────────────────────── numérotation ───────────────────────── */
  function numberFormat(prefix, n, year, o) {
    o = o || {}; var pad = Math.min(8, Math.max(1, +o.pad || 4)), pat = s(o.pattern || '{P}-{Y}-{N}');
    return pat.replace('{P}', s(prefix).replace(/[^A-Za-z0-9]/g, '').toUpperCase().slice(0, 8)).replace('{Y}', String(year)).replace('{N}', ('00000000' + n).slice(-pad));
  }

  /* ───────────────────────── composants de mise en page ───────────────────────── */
  function fieldHtml(ctx, name, o) {
    o = o || {}; name = s(name).replace(/[^A-Za-z0-9_]/g, '_').slice(0, 60);
    var w = o.w || 60, h = o.h || (o.type === 'textarea' ? 20 : 7), type = o.type || 'text';
    var val = ctx.data.fieldValues && ctx.data.fieldValues[name] != null ? ctx.data.fieldValues[name] : (o.value != null ? s(o.value) : '');
    if (ctx.interactive && ctx.fields.length < LIMITS.fields) {
      var idx = ctx.fields.length;
      ctx.fields.push({ idx: idx, name: name, type: type, w: w, h: h, value: s(val), options: o.options || [], multiline: type === 'textarea' });
      return '<span class="fld" style="width:' + w + 'mm;height:' + h + 'mm"><i class="fm">§F' + idx + '§</i></span>';
    }
    return '<span class="fld' + (val ? ' filled' : '') + '" style="width:' + w + 'mm;min-height:' + h + 'mm">' + (type === 'checkbox' ? (val === 'true' || val === 'on' ? '✔' : '') : nl2br(val)) + '</span>';
  }
  function kv(rows) {
    rows = rows.filter(function (r) { return r && s(r[1]).trim() !== ''; });
    if (!rows.length) return '';
    return '<table class="kv">' + rows.map(function (r) { return '<tr><th>' + esc(r[0]) + '</th><td>' + (r[2] === 'raw' ? r[1] : nl2br(r[1])) + '</td></tr>'; }).join('') + '</table>';
  }
  function section(title, inner) { return inner ? '<section class="blk"><h2>' + esc(title) + '</h2>' + inner + '</section>' : ''; }
  function para(v) { v = s(v).trim(); return v ? '<p class="txt">' + nl2br(v) + '</p>' : ''; }
  function table(cols, rows, o) {
    o = o || {};
    if (!rows.length && !o.empty) return '';
    var head = '<tr>' + cols.map(function (c) { return '<th' + (c.align ? ' class="a-' + c.align + '"' : '') + (c.w ? ' style="width:' + c.w + '"' : '') + '>' + esc(c.label) + '</th>'; }).join('') + '</tr>';
    var body = rows.map(function (r, i) {
      return '<tr>' + cols.map(function (c) {
        var v = c.get ? c.get(r, i) : r[c.k]; var inner = c.raw ? s(v) : (c.fmt ? esc(c.fmt(v, r)) : nl2br(v));
        return '<td' + (c.align ? ' class="a-' + c.align + '"' : '') + '>' + inner + '</td>';
      }).join('') + '</tr>';
    }).join('') || '<tr><td colspan="' + cols.length + '" class="a-center muted">' + esc(o.empty) + '</td></tr>';
    return '<table class="t' + (o.cls ? ' ' + o.cls : '') + '"><thead>' + head + '</thead><tbody>' + body + '</tbody></table>';
  }
  function parties(ctx, leftTitle, rightTitle, right) {
    var p = ctx.profile;
    var left = '<b>' + esc(p.legal_name || p.name) + '</b><br>' + nl2br([p.address, [p.city, p.country].filter(Boolean).join(', ')].filter(Boolean).join('\n')) + (p.phones.length ? '<br>Tél : ' + esc(p.phones.join(' / ')) : '') + (p.emails.length ? '<br>' + esc(p.emails[0]) : '');
    return '<div class="parties"><div class="party"><h3>' + esc(leftTitle) + '</h3>' + left + '</div><div class="party"><h3>' + esc(rightTitle) + '</h3>' + right + '</div></div>';
  }
  function progress(pct) { pct = Math.max(0, Math.min(100, num(pct))); return '<div class="bar"><i style="width:' + pct + '%"></i><b>' + pct + ' %</b></div>'; }
  function gallery(items) {
    items = items.filter(function (x) { return x.photo; });
    return items.length ? '<div class="gal">' + items.map(function (x) { return '<figure><img src="' + esc(x.photo) + '" alt=""><figcaption>' + esc(x.legende) + '</figcaption></figure>'; }).join('') + '</div>' : '';
  }

  var H = { esc: esc, nl2br: nl2br, money: money, dateFr: dateFr, dateShort: dateShort, num: num, kv: kv, section: section, para: para, table: table, parties: parties,
    progress: progress, gallery: gallery, field: fieldHtml, amountWords: amountWords, computeTotals: computeTotals, round2: round2 };

  /* ───────────────────────── feuille de style ───────────────────────── */
  function css(ctx) {
    var p = ctx.profile, c = p.colors, o = ctx.opt, tpl = ctx.tpl, land = (tpl.page && tpl.page.orientation === 'landscape');
    var mtop = land ? 16 : 18, mside = land ? 14 : 16, mbot = 20;
    var running = (p.name || '') + (ctx.number ? '  ·  ' + ctx.number : '');
    var footL = o.footer_left != null && o.footer_left !== '' ? o.footer_left : (o.show_legal_footer === false ? '' : footerLine(p));
    return '@page{size:A4' + (land ? ' landscape' : '') + ';margin:' + (mtop + 8) + 'mm ' + mside + 'mm ' + mbot + 'mm;' +
      '@top-right{content:' + cssStr(running) + ';font:7.5pt "Helvetica Neue",Arial,sans-serif;color:#6b7280;vertical-align:bottom;padding-bottom:3mm}' +
      '@bottom-left{content:' + cssStr(footL) + ';font:7pt "Helvetica Neue",Arial,sans-serif;color:#6b7280;vertical-align:top;padding-top:3mm;width:78%}' +
      (o.show_page_numbers === false ? '' : '@bottom-right{content:"Page " counter(page) " / " counter(pages);font:7.5pt "Helvetica Neue",Arial,sans-serif;color:' + c.primary + ';vertical-align:top;padding-top:3mm}') + '}' +
      '@page :first{@top-right{content:none}}' +
      ':root{--p:' + c.primary + ';--a:' + c.accent + ';--s:' + c.secondary + ';--ink:#1b2433;--mut:#6b7280;--line:#d6dce6;--soft:#f3f6fb}' +
      '*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
      'html,body{margin:0;padding:0}body{font:9.6pt/1.45 "Helvetica Neue","Segoe UI",Arial,"Liberation Sans",sans-serif;color:var(--ink)}' +
      'h1,h2,h3{margin:0}p{margin:0}.muted{color:var(--mut)}.a-right{text-align:right}.a-center{text-align:center}' +
      /* en-tête */
      '.lh{display:flex;align-items:center;gap:6mm;padding-bottom:4mm;border-bottom:.9mm solid var(--a);margin-bottom:6mm}' +
      '.lh .logo{width:26mm;height:26mm;flex:none;display:flex;align-items:center;justify-content:center}.lh .logo img{max-width:100%;max-height:100%;object-fit:contain}' +
      '.lh .id{flex:1;min-width:0}.lh .nm{font-size:15pt;font-weight:800;color:var(--p);letter-spacing:.2pt;text-transform:uppercase;line-height:1.15}' +
      '.lh .tg{font-size:8.5pt;color:var(--a);font-weight:600;margin-top:.6mm}.lh .ct{font-size:8pt;color:var(--mut);margin-top:1.2mm;line-height:1.4}' +
      '.layout-bandeau .lh{background:var(--p);color:#fff;padding:5mm 6mm;border-radius:2mm;border-bottom:1.4mm solid var(--a)}' +
      '.layout-bandeau .lh .nm{color:#fff}.layout-bandeau .lh .ct{color:#d9e1ef}.layout-bandeau .lh .logo{background:#fff;border-radius:2mm;padding:1.5mm;width:24mm;height:24mm}' +
      '.layout-sobre .lh{border-bottom:.3mm solid var(--line)}.layout-sobre .lh .nm{color:var(--ink);font-size:13pt}' +
      /* titre du document */
      '.tb{display:flex;justify-content:space-between;align-items:flex-end;margin:0 0 5mm;gap:6mm}.tb .ty{font-size:19pt;font-weight:800;color:var(--p);letter-spacing:.6pt;text-transform:uppercase;line-height:1.1}' +
      '.tb .sub{font-size:10pt;color:var(--a);font-weight:700;margin-top:1mm}.tb .mt{text-align:right;font-size:8.6pt;color:var(--mut);line-height:1.5;white-space:nowrap}.tb .mt b{color:var(--ink)}' +
      /* blocs */
      '.blk{margin:0 0 5mm;break-inside:auto}.blk>h2{font-size:10.5pt;color:var(--p);text-transform:uppercase;letter-spacing:.5pt;padding-bottom:1.2mm;margin-bottom:2.4mm;border-bottom:.3mm solid var(--a);break-after:avoid}' +
      '.txt{margin:0 0 2.4mm;text-align:left}.parties{display:flex;gap:6mm;margin-bottom:5mm}.party{flex:1;border:.3mm solid var(--line);border-radius:1.5mm;padding:3mm 3.5mm;background:var(--soft);font-size:9pt}' +
      '.party h3{font-size:7.8pt;text-transform:uppercase;letter-spacing:.6pt;color:var(--a);margin-bottom:1.5mm}' +
      'table{width:100%;border-collapse:collapse}table.kv th{width:36%;text-align:left;vertical-align:top;font-weight:600;color:var(--mut);padding:1.4mm 3mm 1.4mm 0;font-size:9pt}table.kv td{padding:1.4mm 0;border-bottom:.2mm solid var(--line)}' +
      'table.t{font-size:8.8pt;margin-bottom:3mm}table.t th{background:var(--p);color:#fff;text-align:left;padding:1.8mm 2mm;font-size:8pt;text-transform:uppercase;letter-spacing:.3pt}' +
      'table.t td{padding:1.8mm 2mm;border-bottom:.2mm solid var(--line);vertical-align:top}table.t tbody tr:nth-child(even) td{background:#f8fafd}table.t thead{display:table-header-group}table.t tr{break-inside:avoid}' +
      'table.t th.a-right,table.t td.a-right{text-align:right}table.t th.a-center,table.t td.a-center{text-align:center}' +
      '.tot{margin:2mm 0 5mm auto;width:78mm;font-size:9.2pt}.tot td{padding:1.3mm 2mm;border-bottom:.2mm solid var(--line)}.tot td:last-child{text-align:right;white-space:nowrap}' +
      '.tot tr.g td{background:var(--p);color:#fff;font-weight:800;font-size:10.2pt;border:0}.tot tr.s td{font-weight:700;color:var(--p)}' +
      '.words{font-size:8.6pt;font-style:italic;color:var(--mut);margin:-2mm 0 4mm}' +
      '.bar{position:relative;height:5.5mm;border:.3mm solid var(--p);border-radius:3mm;overflow:hidden;background:#fff;max-width:90mm}.bar i{position:absolute;inset:0 auto 0 0;background:var(--a)}.bar b{position:relative;display:block;text-align:center;font-size:8pt;line-height:5mm;color:var(--p)}' +
      '.gal{display:flex;flex-wrap:wrap;gap:3mm}.gal figure{margin:0;width:calc(50% - 1.5mm);break-inside:avoid}.gal img{width:100%;max-height:62mm;object-fit:cover;border:.3mm solid var(--line)}.gal figcaption{font-size:8pt;color:var(--mut);margin-top:.8mm}' +
      '.note{border-left:1mm solid var(--a);background:var(--soft);padding:2.4mm 3.5mm;font-size:8.8pt;margin-bottom:4mm}' +
      /* signatures */
      '.sigs{display:flex;gap:8mm;margin-top:8mm;break-inside:avoid}.sig{flex:1;min-height:30mm;position:relative;font-size:8.8pt}.sig .lb{font-weight:700;color:var(--p);border-bottom:.3mm solid var(--ink);padding-bottom:1.2mm;margin-bottom:1mm}' +
      '.sig .who{font-size:8.4pt;color:var(--mut)}.sig img.sg{position:absolute;left:2mm;top:11mm;max-height:17mm;max-width:44mm;object-fit:contain}.sig img.st{position:absolute;right:2mm;top:5mm;max-height:23mm;max-width:23mm;object-fit:contain;opacity:.92}' +
      /* filigrane */
      '.wm{position:fixed;left:0;right:0;top:42%;text-align:center;font-size:' + (land ? 70 : 68) + 'pt;font-weight:900;letter-spacing:2pt;color:' + (o._wmColor || 'rgba(160,0,0,.10)') + ';transform:rotate(-28deg);z-index:0;pointer-events:none;white-space:nowrap}' +
      'main{position:relative;z-index:1}' +
      /* champs de formulaire */
      '.fld{display:inline-block;vertical-align:middle;border:.3mm solid #9aa6b8;border-radius:.8mm;background:#fbfcfe;padding:.6mm 1.6mm;font-size:9pt;line-height:1.3;overflow:hidden}.fld.filled{border-color:var(--line);background:#fff}' +
      '.fm{display:block;font-size:2px;line-height:2px;color:rgba(255,255,255,.01);font-style:normal;overflow:hidden;white-space:nowrap}' +
      '.frm{width:100%}.frm td{padding:1.2mm 0;vertical-align:middle}.frm td.l{width:38mm;font-weight:600;color:var(--p);font-size:9pt}' +
      /* certificat */
      '.cert{border:1.6mm double var(--p);outline:.6mm solid var(--a);outline-offset:-4.2mm;padding:7mm 14mm 5mm;text-align:center;height:158mm;overflow:hidden}.cert h1{font-size:26pt;color:var(--p);letter-spacing:3pt;text-transform:uppercase;margin:2mm 0 1mm}' +
      '.cert .rcp{font-size:21pt;font-weight:800;color:var(--ink);margin:3mm 0 3mm;border-bottom:.4mm solid var(--a);display:inline-block;padding:0 10mm 1.5mm}.cert p{font-size:11.5pt;margin:2mm 0}.cert .mn{margin-top:3mm;font-weight:800;color:var(--p);font-size:13pt}' +
      '.cert .lg{max-height:16mm;max-width:44mm;object-fit:contain}.cert .org{font-size:13pt;font-weight:800;color:var(--p);text-transform:uppercase;letter-spacing:1pt}' +
      '.cert .sigs{margin-top:2mm}.cert .sig{min-height:22mm;text-align:left}.cert .sig img.sg{top:9mm;max-height:12mm}.cert .sig img.st{top:3mm;max-height:15mm;max-width:15mm}.cert p{margin:1.4mm 0}' +
      '.doc-end{margin-top:6mm;font-size:7.6pt;color:var(--mut);border-top:.2mm solid var(--line);padding-top:2mm;break-inside:avoid}' +
      '.lt-meta{display:flex;justify-content:space-between;margin-bottom:6mm;font-size:9.4pt}.lt-to{margin:0 0 6mm 90mm;font-size:9.6pt}.lt-obj{font-weight:800;color:var(--p);margin:0 0 5mm}' +
      '@media screen{body{background:#e8ecf3;padding:8mm 0}.sheet{background:#fff;width:' + (land ? 297 : 210) + 'mm;margin:0 auto;padding:' + (mtop + 8) + 'mm ' + mside + 'mm ' + mbot + 'mm;box-shadow:0 2mm 10mm rgba(20,35,70,.18);min-height:' + (land ? 210 : 297) + 'mm}.sheet>*{max-width:none}}' +
      '@media print{.sheet{padding:0;width:auto;box-shadow:none;min-height:0;background:none}body{background:none;padding:0}}';
  }
  function footerLine(p) {
    var a = [];
    if (p.legal_name || p.name) a.push(p.legal_name || p.name);
    p.ids.slice(0, 3).forEach(function (i) { a.push(i.label + ' ' + i.value); });
    if (p.footer_text) a.push(p.footer_text);
    return a.join('  ·  ');
  }

  /* ───────────────────────── enveloppe commune : en-tête, titre, signatures, filigrane ───────────────────────── */
  function letterhead(ctx) {
    var p = ctx.profile, o = ctx.opt;
    if (!p.name && !p.logo) return '';
    var contact = [
      [p.address, [p.city, p.country].filter(Boolean).join(', ')].filter(Boolean).join(' — '),
      [p.phones.length ? 'Tél : ' + p.phones.join(' / ') : '', p.emails.join(' / '), p.website].filter(Boolean).join('  ·  '),
      p.ids.slice(0, 3).map(function (i) { return i.label + ' : ' + i.value; }).join('  ·  ')
    ].filter(Boolean);
    return '<header class="lh">' + (p.logo && o.show_logo !== false ? '<div class="logo"><img src="' + esc(p.logo) + '" alt=""></div>' : '') +
      '<div class="id"><div class="nm">' + esc(p.name) + '</div>' + (p.tagline ? '<div class="tg">' + esc(p.tagline) + '</div>' : '') +
      '<div class="ct">' + contact.map(esc).join('<br>') + '</div></div></header>';
  }
  function titleBlock(ctx, label, sub, extraMeta) {
    var meta = [];
    if (ctx.number) meta.push('N° <b>' + esc(ctx.number) + '</b>');
    meta.push('Date : <b>' + esc(dateFr(ctx.data.date || ctx.date)) + '</b>');
    (extraMeta || []).forEach(function (m) { if (m) meta.push(m); });
    return '<section class="tb"><div><div class="ty">' + esc(ctx.opt.title_override || label) + '</div>' + (sub ? '<div class="sub">' + esc(sub) + '</div>' : '') + '</div><div class="mt">' + meta.join('<br>') + '</div></section>';
  }
  function signatures(ctx, labels) {
    var o = ctx.opt, p = ctx.profile; labels = (o.signature_labels && o.signature_labels.length ? o.signature_labels : labels) || [];
    if (!labels.length || o.show_signatures === false) return '';
    return '<div class="sigs">' + labels.map(function (l) {
      var issuer = typeof l === 'object' ? !!l.issuer : false, label = typeof l === 'object' ? l.label : l, show = issuer && ctx.data.sign !== false && o.use_signature !== false;
      return '<div class="sig"><div class="lb">' + esc(label) + '</div>' +
        (issuer ? '<div class="who">' + esc([p.signatory.name, p.signatory.role].filter(Boolean).join(' — ')) + '</div>' : '<div class="who">&nbsp;</div>') +
        (show && p.signature ? '<img class="sg" src="' + esc(p.signature) + '" alt="">' : '') + (show && p.stamp ? '<img class="st" src="' + esc(p.stamp) + '" alt="">' : '') + '</div>';
    }).join('') + '</div>';
  }
  function watermark(ctx) {
    var o = ctx.opt, st = s(ctx.data.status).toLowerCase(), txt = '';
    if (o.watermark === 'none') return '';
    if (o.watermark === 'custom' && o.watermark_text) txt = o.watermark_text;
    else if (st === 'brouillon') txt = 'BROUILLON'; else if (st === 'annulé') txt = 'ANNULÉ'; else if (st === 'duplicata') txt = 'DUPLICATA'; else if (st === 'copie') txt = 'COPIE';
    else if (o.watermark === 'name' && ctx.profile.name) txt = ctx.profile.name.toUpperCase();
    if (!txt) return '';
    if (/^(brouillon|annulé)$/i.test(txt)) ctx.opt._wmColor = 'rgba(180,20,20,.11)'; else ctx.opt._wmColor = 'rgba(23,53,101,.07)';
    return '<div class="wm">' + esc(txt) + '</div>';
  }

  function render(type, data, opts) {
    opts = opts || {};
    var tpl = TEMPLATES[type]; if (!tpl) throw new Error('Modèle inconnu : ' + type);
    var v = validate(type, data);
    if (!v.ok && !opts.lenient) { var e = new Error(v.errors.join(' ; ')); e.code = 'VALIDATION'; e.errors = v.errors; throw e; }
    var profile = normalizeProfile(opts.profile), opt = {};
    var m = opts.options && typeof opts.options === 'object' ? opts.options : {};
    Object.keys(m).forEach(function (k) { opt[k] = m[k]; });
    opt.layout = /^(classique|bandeau|sobre)$/.test(opt.layout) ? opt.layout : 'classique';
    if (!Array.isArray(opt.signature_labels)) opt.signature_labels = null;
    var date = v.data.date || opts.date || todayISO();
    var ctx = { profile: profile, data: v.data, tpl: tpl, opt: opt, number: s(opts.number), date: date, interactive: !!opts.interactive && !!tpl.interactive, fields: [], h: H, mode: opts.mode || 'pdf' };
    var body = tpl.render(ctx);
    var intro = opt.intro ? '<div class="note">' + nl2br(opt.intro) + '</div>' : '', concl = opt.conclusion ? '<div class="note">' + nl2br(opt.conclusion) + '</div>' : '';
    var wm = watermark(ctx), style = css(ctx);
    var head = tpl.bare ? '' : letterhead(ctx) + (tpl.noTitle ? '' : titleBlock(ctx, tpl.label, tpl.subtitle ? tpl.subtitle(ctx) : '', tpl.meta ? tpl.meta(ctx) : []));
    var tail = tpl.bare ? '' : signatures(ctx, tpl.signatures) + (ctx.profile.bank && tpl.showBank ? '<div class="doc-end"><b>Coordonnées bancaires</b><br>' + nl2br(ctx.profile.bank) + '</div>' : '');
    var title = (tpl.label + (ctx.number ? ' ' + ctx.number : (v.data.doc && v.data.doc.no ? ' ' + String(v.data.doc.no).slice(0, 40) : ''))).trim();
    var html = '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(title) + '</title><style>' + style + '</style></head>' +
      '<body class="layout-' + opt.layout + ' mode-' + esc(ctx.mode) + '">' + wm + '<div class="sheet">' + head + '<main>' + intro + body + concl + '</main>' + tail + '</div></body></html>';
    return { html: html, title: title, filename: slug(tpl.label + (ctx.number ? '-' + ctx.number : '')) + '.pdf', number: ctx.number, fields: ctx.fields,
      page: tpl.page || { size: 'A4', orientation: 'portrait' }, profile: profile, data: v.data, type: type, label: tpl.label };
  }

  return { VERSION: VERSION, register: register, list: listTemplates, describe: describe, validate: validate, render: render, normalizeProfile: normalizeProfile,
    computeTotals: computeTotals, numberFormat: numberFormat, amountWords: amountWords, esc: esc, helpers: H, slug: slug, todayISO: todayISO, DEFAULT_PROFILE: DEFAULT_PROFILE, LIMITS: LIMITS,
    _internals: { letterhead: letterhead, titleBlock: titleBlock, signatures: signatures, css: css, img: img, color: color, parseDate: parseDate } };
});
