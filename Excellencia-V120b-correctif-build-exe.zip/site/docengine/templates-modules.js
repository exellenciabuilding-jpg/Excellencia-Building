/* Excellencia Building — MOTEUR DOCUMENTAIRE · modèles « modules » (fusion V118 → V119d)
 * Isomorphe (navigateur + serveur). Deux modèles à charge utile structurée (`doc`), masqués du catalogue :
 *   - doc-devis  : devis / facture / reçu du métré (lots, sous-totaux, USD + FC, divers & imprévus, acompte / solde, reçu cumulé, CGV, signatures, QR, filigrane)
 *   - doc-module : pièce des modules existants (EXBPdf.make) : page de garde, tableau de rubriques, notes, photos, visa, QR
 * Ils reprennent la mise en page du moteur V118, alimentée par le PROFIL V119d (en-tête, pied, signature, cachet, identifiants légaux).
 * Toutes les valeurs de `doc` sont traitées comme non fiables : échappées ; images limitées à data:image / https. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'));
  else factory(root.EXBDocCore);
})(typeof self !== 'undefined' ? self : this, function (C) {
  'use strict';
  var esc = C.esc, H = C.helpers;
  function nl(v) { return esc(v).replace(/\r?\n/g, '<br>'); }
  function num(v) { var n = parseFloat(String(v == null ? '' : v).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : 0; }
  function fnum(v, dec) {
    var n = num(v), s;
    try { s = new Intl.NumberFormat('fr-FR', { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(n); } catch (e) { s = n.toFixed(dec); }
    return s.replace(/[\u202f\u00a0]/g, ' ');
  }
  function safeImg(u) {
    u = String(u || '').trim();
    if (/^data:image\/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$/.test(u)) return u;
    if (/^https:\/\/[^\s"'<>]+$/i.test(u)) return u;
    return '';
  }
  /* QR de vérification : l'adaptateur le fournit en SVG (EXBQR.svg). Un SVG chargé via <img> n'exécute aucun script : accepté pour le QR seulement. */
  function safeQr(u) {
    u = String(u || '').trim();
    if (/^data:image\/svg\+xml;base64,[A-Za-z0-9+/=]+$/.test(u)) return u;
    return safeImg(u);
  }
  function dateFr(v) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(v || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] : esc(v || ''); }
  function today() { return C.todayISO(); }

  /* styles propres à ces deux modèles (préfixe .xm : aucun conflit avec les modèles du noyau) */
  var CSS = '<style>' +
    '.xm .cov{height:243mm;border:2mm double var(--p);outline:.6mm solid var(--a);outline-offset:-3.6mm;padding:12mm 12mm;text-align:center;display:flex;flex-direction:column;align-items:center;break-after:page;position:relative}' +
    '.xm .cov .org{font-size:20pt;font-weight:800;color:var(--p);text-transform:uppercase;letter-spacing:1.5px}.xm .cov .sl{color:var(--mut);font-size:9.5pt}.xm .cov img.lg{max-height:46mm;max-width:70mm;object-fit:contain;margin:8mm 0}' +
    '.xm .cov h1{font-size:24pt;color:var(--p);margin:10mm 0 3mm;letter-spacing:1px;text-transform:uppercase;line-height:1.2}.xm .cov .sb{color:var(--a);font-size:11pt;font-weight:700}.xm .cov .cl{margin-top:8mm;font-weight:800;color:var(--p);font-size:13pt}' +
    '.xm .cov .ct{margin-top:auto;color:var(--mut);font-size:8.5pt;line-height:1.5}.xm .cov .gl{width:50mm;height:.5mm;background:var(--a);margin:5mm auto}' +
    '.xm h1.tt{font-size:17pt;margin:3mm 0 1mm;color:var(--p);letter-spacing:.8px;text-transform:uppercase}.xm .sub2{color:var(--a);font-weight:700;margin-bottom:2mm}.xm .gold{height:.6mm;background:var(--a);margin:2mm 0 4mm}' +
    '.xm .meta{display:flex;gap:5mm;margin:2mm 0 4mm}.xm .box{flex:1;border:.3mm solid var(--line);border-radius:1.5mm;padding:2.5mm 3.5mm;background:var(--soft);font-size:9pt}.xm .box b.lb{display:block;color:var(--p);font-size:7.8pt;text-transform:uppercase;letter-spacing:.5px;margin-bottom:1mm}' +
    '.xm table.dv{width:100%;border-collapse:collapse;margin:2mm 0;font-size:8.8pt}.xm table.dv th{background:var(--p);color:#fff;font-size:8pt;text-align:left;padding:1.8mm 2mm;text-transform:uppercase}.xm table.dv td{padding:1.8mm 2mm;border-bottom:.2mm solid var(--line);vertical-align:top}.xm table.dv tr{break-inside:avoid}' +
    '.xm table.dv tr.sec td{background:#eef2f9;color:var(--p);font-weight:700}.xm table.dv tr.sub td{background:#f7f9fd;font-weight:700;color:var(--p)}.xm .r{text-align:right}.xm .c{text-align:center}' +
    '.xm table.xtot{margin:2mm 0 2mm auto;width:75%;border-collapse:collapse;font-size:9.2pt;break-inside:avoid}.xm table.xtot td{padding:1.3mm 2mm;border-bottom:.2mm solid var(--line)}.xm table.xtot tr.g td{background:var(--p);color:#fff;font-weight:800;border-bottom:.8mm solid var(--a)}' +
    '.xm table.kv2{width:100%;border-collapse:collapse;margin:2mm 0}.xm table.kv2 td{padding:1.8mm 2.2mm;border-bottom:.2mm solid var(--line);vertical-align:top}.xm table.kv2 td:first-child{width:34%;font-weight:700;color:var(--p);background:var(--soft)}.xm table.kv2 tr{break-inside:avoid}' +
    '.xm .sec2{margin:3mm 0}.xm .sec2 h3{margin:0 0 1mm;color:var(--p);font-size:11pt;border-left:1.2mm solid var(--a);padding-left:2mm}.xm .sec2 p{text-align:justify}' +
    '.xm .photos{display:flex;flex-wrap:wrap;gap:2.5mm;margin-top:3mm}.xm .photos img{width:48%;max-height:62mm;object-fit:cover;border:.3mm solid var(--line);border-radius:1mm;break-inside:avoid}' +
    '.xm .xsig{display:flex;gap:7mm;margin-top:7mm;break-inside:avoid}.xm .xsig>div{flex:1;text-align:center;font-size:9pt}.xm .xsig .lb{border-bottom:.3mm solid var(--ink);padding-bottom:1mm;margin-bottom:1mm;color:var(--p);font-weight:700}.xm .xsig .zone{height:18mm;display:flex;align-items:center;justify-content:center;gap:2mm}.xm .xsig .zone img{max-height:17mm;max-width:46%;object-fit:contain}' +
    '.xm .xnote{margin-top:3mm;font-size:8.6pt;color:var(--mut);border-top:.3mm dashed var(--line);padding-top:2mm}' +
    '.xm .xqr{display:flex;align-items:center;gap:3mm;margin-top:4mm;break-inside:avoid}.xm .xqr img{width:22mm;height:22mm}.xm .xqr b{color:var(--p);font-size:8.5pt}' +
    '</style>';

  function contactLines(P) {
    return [[P.phones.length ? P.phones.join(' / ') : '', P.emails.join(' / ')].filter(Boolean).join('   '), [P.address, P.city, P.country].filter(Boolean).join(', '),
      P.ids.slice(0, 3).map(function (i) { return i.label + ' : ' + i.value; }).join('  ·  ')].filter(Boolean).map(esc).join('<br>');
  }
  function coverStart(P, logo, h1, sub, extra) {
    return '<div class="cov"><div class="org">' + esc(P.name) + '</div>' + (P.tagline ? '<div class="sl">' + esc(P.tagline) + '</div>' : '') + '<div class="gl"></div>' + (logo ? '<img class="lg" src="' + esc(logo) + '" alt="">' : '') +
      '<h1>' + h1 + '</h1>' + (sub ? '<div class="sb">' + esc(sub) + '</div>' : '') + '<div class="gl"></div>' + extra + '<div class="ct">' + contactLines(P) + '</div></div>';
  }
  function qrBlock(d) {
    var qr = safeQr(d.qr); if (!qr) return '';
    return '<div class="xqr"><img src="' + esc(qr) + '" alt="QR de vérification"><div><b>Scannez ce QR pour vérifier</b><br>l’authenticité de ce document' + ((d.hash || d.qrCode) ? '<br>Code : ' + esc(String(d.hash || d.qrCode).toUpperCase()) : '') + '</div></div>';
  }
  function footer(P) {
    var a = [P.legal_name || P.name].concat(P.ids.slice(0, 3).map(function (i) { return i.label + ' ' + i.value; })); if (P.footer_text) a.push(P.footer_text);
    return '<div class="xnote" style="text-align:center">' + esc(a.filter(Boolean).join('  ·  ')) + '</div>';
  }

  /* ───────────── DEVIS / FACTURE / REÇU ───────────── */
  function renderDevis(ctx) {
    var P = ctx.profile, d = ctx.data.doc || {}, kind = { devis: 'devis', facture: 'facture', recu: 'recu' }[d.kind] || 'devis';
    var TT = { devis: 'DEVIS', facture: 'FACTURE', recu: 'REÇU' }[kind], cl = d.client || {}, T = d.T || {}, no = d.no || ctx.number || '';
    var cover = d.cover !== false && d.noCover !== true, logo = d.noLogo ? '' : (safeImg(d.logo) || P.logo), pre = '';
    var infoRows = [['Projet', d.project], ['Lieu', d.place], ['Dossier', d.dossier], ['Validité', kind === 'devis' ? d.validity : ''], ['Devis', kind !== 'devis' ? d.devisNo : ''], ['Date', d.date ? dateFr(d.date) : '']].filter(function (r) { return String(r[1] || '').trim(); });
    if (cover) {
      pre = coverStart(P, logo, TT + ' N° ' + esc(no), d.title,
        '<div class="cl">' + esc(cl.name || '') + '</div>' + [cl.address, cl.phone, cl.email].filter(Boolean).map(function (x) { return '<div class="sl">' + esc(x) + '</div>'; }).join('') +
        (d.project ? '<div class="sl" style="margin-top:6mm"><b>Projet :</b> ' + esc(d.project) + '</div>' : '') + (d.place ? '<div class="sl"><b>Lieu :</b> ' + esc(d.place) + '</div>' : '') +
        '<div class="sl" style="margin-top:4mm">' + (d.date ? 'Émis le ' + dateFr(d.date) : '') + (kind === 'devis' && d.validity ? ' — validité : ' + esc(d.validity) : '') + '</div>');
      if (d.company) pre = pre.replace('<div class="org">' + esc(P.name) + '</div>', '<div class="org">' + esc(d.company) + '</div>');
    }
    var h = '<h1 class="tt">' + TT + ' N° ' + esc(no) + '</h1><div class="sub2">' + esc(cover ? (kind === 'recu' ? 'Détail du paiement' : kind === 'facture' ? 'Détail de la facture' : 'Détail des postes') : (d.title || '')) + '</div><div class="gold"></div>';
    if (!cover) h += '<div class="meta"><div class="box"><b class="lb">Client</b><b>' + esc(cl.name || '') + '</b>' + [cl.address, cl.phone, cl.email].filter(Boolean).map(function (x) { return '<br>' + esc(x); }).join('') + '</div>' +
      '<div class="box"><b class="lb">' + (kind === 'devis' ? 'Projet' : 'Références') + '</b>' + infoRows.map(function (r) { return esc(r[0]) + ' : <b>' + esc(r[1]) + '</b>'; }).join('<br>') + '</div></div>';
    if (kind !== 'recu') {
      var body = (d.lines || []).map(function (r) {
        /* JSON perd la propriété .k portée par les tableaux de lignes : le client l'envoie sous la forme { k, c:[…] } */
        var k = r && r.k, c = Array.isArray(r) ? r : (r && Array.isArray(r.c) ? r.c : []);
        if (k === 'sec') return '<tr class="sec"><td colspan="6">' + esc(c[0]) + '</td></tr>';
        if (k === 'sub') return '<tr class="sub"><td colspan="4" class="r">' + esc(c[0]) + '</td><td class="r">' + fnum(c[4], 2) + '</td><td class="r">' + fnum(c[5], 0) + '</td></tr>';
        return '<tr><td>' + nl(c[0] || '—') + '</td><td class="c">' + esc(c[1] || '') + '</td><td class="r">' + fnum(c[2], 3).replace(/,?0+$/, '') + '</td><td class="r">' + fnum(c[3], 2) + '</td><td class="r">' + fnum(c[4], 2) + '</td><td class="r">' + fnum(c[5], 0) + '</td></tr>';
      }).join('');
      h += '<table class="dv"><thead><tr><th style="width:36%">Désignation</th><th class="c" style="width:8%">Unité</th><th class="r" style="width:10%">Qté</th><th class="r" style="width:14%">PU ($)</th><th class="r" style="width:16%">Montant ($)</th><th class="r" style="width:16%">Montant (FC)</th></tr></thead><tbody>' + (body || '<tr><td colspan="6" class="c">—</td></tr>') + '</tbody></table>';
    }
    var rows = [];
    if (kind === 'recu') { var p = d.paid || {}; rows = [['MONTANT REÇU', p.usd, p.fc, 'tot'], ['Total du dossier', T.tot, T.totfc, 'n'], ['Total déjà réglé (reçus cumulés)', p.cumulUsd, p.cumulFc, 'n'], ['Reste à payer', p.resteUsd, p.resteFc, 'b']]; }
    else {
      rows.push(['Sous-total', T.sub, T.subfc, 'b']);
      if (num(T.imp) > 0) rows.push(['Divers & imprévus (' + (Math.round(num(T.imp) * 10000) / 100) + ' %)', T.impv, T.impfc, 'n']);
      rows.push(['TOTAL GÉNÉRAL', T.tot, T.totfc, 'tot']);
      if (kind === 'facture' && d.acompte) { rows.push(['Acompte (' + num(d.acompte.pct) + ' %)', d.acompte.usd, d.acompte.fc, 'n']); rows.push(['SOLDE À PAYER', num(T.tot) - num(d.acompte.usd), num(T.totfc) - num(d.acompte.fc), 'b']); }
    }
    h += '<table class="xtot">' + rows.map(function (r) { return '<tr' + (r[3] === 'tot' ? ' class="g"' : '') + '><td' + (r[3] === 'n' ? '' : ' style="font-weight:700"') + '>' + esc(r[0]) + '</td><td class="r">' + fnum(r[1], 2) + ' $</td><td class="r">' + fnum(r[2], 0) + ' FC</td></tr>'; }).join('') + '</table>';
    if (num(T.taux) > 0) h += '<div class="xnote" style="border:0">Taux de change appliqué : 1 USD = ' + fnum(T.taux, 0) + ' FC</div>';
    if (kind === 'recu' && d.paid) h += '<div class="xnote" style="border:0">Mode de paiement : ' + esc(d.paid.mode || '—') + ' — Date : ' + dateFr(d.paid.date) + '</div>';
    if (d.note) h += '<div class="sec2"><p>' + nl(d.note) + '</p></div>';
    if (d.cgv && (kind === 'devis' || kind === 'facture')) h += '<div class="sec2"><h3>Conditions générales</h3><p style="font-size:7.6pt;color:var(--mut)">' + nl(d.cgv) + '</p></div>';
    var L = kind === 'devis' ? ['Le prestataire', 'Le client — « Bon pour accord »'] : kind === 'facture' ? ['Le prestataire', 'Le client'] : ['Pour ' + (d.company || P.name), 'Le client'];
    var vs = safeImg(d.visa) || ((ctx.data.sign !== false && ctx.opt.use_signature !== false) ? P.signature : ''), cs = safeImg(d.clientSig), st = (ctx.data.sign !== false && ctx.opt.use_signature !== false) ? P.stamp : '';
    h += '<div class="xsig"><div><div class="lb">' + esc(L[0]) + '</div><div class="zone">' + (vs ? '<img src="' + esc(vs) + '" alt="">' : '') + (st ? '<img src="' + esc(st) + '" alt="">' : '') + '</div>' + ((d.signerName || P.signatory.name) ? '<div><b>' + esc(d.signerName || P.signatory.name) + '</b>' + ((d.signerRole || P.signatory.role) ? '<br>' + esc(d.signerRole || P.signatory.role) : '') + '</div>' : '') + '</div>' +
      '<div><div class="lb">' + esc(L[1]) + '</div><div class="zone">' + (cs ? '<img src="' + esc(cs) + '" alt="">' : '') + '</div><div><b>' + esc(d.clientSigner || cl.name || '') + '</b></div></div></div>';
    h += '<div class="xnote" style="border:0">Fait à ' + esc(P.city || '…………………') + ', le ' + dateFr(d.date || today()) + '</div>' + qrBlock(d);
    return CSS + '<div class="xm">' + pre + C._internals.letterhead(ctx) + h + footer(P) + '</div>';
  }

  /* ───────────── PIÈCE DES MODULES (EXBPdf.make) ───────────── */
  function renderModule(ctx) {
    var P = ctx.profile, d = ctx.data.doc || {};
    var rows = (d.rows || []).filter(function (r) { return r && (String(r[0] || '').trim() || String(r[1] || '').trim()); }), cover = d.cover !== false, pre = '';
    if (cover) {
      var extra = (d.clientName ? '<div class="cl">' + esc(String(d.clientName).slice(0, 60)) + '</div>' : '') +
        rows.filter(function (r) { return /t[ée]l|mail|adresse|phone|contact/i.test(String(r[0] || '')) && String(r[1] || '').trim(); }).slice(0, 4).map(function (r) { return '<div class="sl">' + esc(r[0]) + ' : ' + esc(String(r[1]).slice(0, 70)) + '</div>'; }).join('');
      pre = coverStart(P, P.logo, esc(d.titre || 'DOCUMENT'), d.sousTitre, extra);
    }
    var h = '<h1 class="tt">' + esc(d.titre || '') + '</h1>' + (d.sousTitre ? '<div class="sub2">' + esc(d.sousTitre) + '</div>' : '') + '<div class="gold"></div>';
    if (rows.length) h += '<table class="kv2">' + rows.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + nl(r[1]) + '</td></tr>'; }).join('') + '</table>';
    (d.notes || []).forEach(function (n) { if (String(n || '').trim()) h += '<div class="sec2"><p>' + nl(n) + '</p></div>'; });
    var ph = (d.images || []).map(safeImg).filter(Boolean);
    if (ph.length) h += '<div class="photos">' + ph.map(function (u) { return '<img src="' + esc(u) + '" alt="">'; }).join('') + '</div>';
    if (d.signBlock !== false && (d.sigLabels || d.visa || d.clientSig || d.signBlock)) {
      var L = d.sigLabels || ['Le Client', 'Le Directeur Général'], vs = safeImg(d.visa), cs = safeImg(d.clientSig);
      h += '<div class="xsig"><div><div class="lb">' + esc(L[0] || '') + '</div><div class="zone">' + (cs ? '<img src="' + esc(cs) + '" alt="">' : '') + '</div>' + (d.clientName ? '<div><b>' + esc(String(d.clientName).slice(0, 40)) + '</b></div>' : '') + '</div>' +
        '<div><div class="lb">' + esc(L[1] || P.signatory.role || 'La Direction') + '</div><div class="zone">' + (vs ? '<img src="' + esc(vs) + '" alt="">' : (P.signature ? '<img src="' + esc(P.signature) + '" alt="">' : '') + (P.stamp ? '<img src="' + esc(P.stamp) + '" alt="">' : '')) + '</div>' + (P.signatory.name ? '<div><b>' + esc(P.signatory.name) + '</b></div>' : '') + '</div></div>';
    }
    h += qrBlock(d);
    if (d.footer) h += '<div class="xnote">' + esc(d.footer) + '</div>';
    return CSS + '<div class="xm">' + pre + C._internals.letterhead(ctx) + h + footer(P) + '</div>';
  }


  /* ───────────── PIÈCE ÉCRITE (CCTP, lettres, ordres de service, attestations… — module Pièces écrites) ───────────── */
  function inlP(t) { return esc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>'); }
  function mdBody(txt) {
    var out = [], tb = [], ul = '', first = true;
    function cl() { if (ul) { out.push('</' + ul + '>'); ul = ''; } }
    function fl() {
      if (!tb.length) return;
      var sg = tb.some(function (r) { return r.some(function (c) { return /Lu et approuvé/.test(c); }); });
      out.push('<table class="pt' + (sg ? ' sigt' : '') + '">' + tb.map(function (r, i) { var g = i === 0 ? 'th' : 'td'; return '<tr>' + r.map(function (c) { return '<' + g + '>' + inlP(c.trim()) + '</' + g + '>'; }).join('') + '</tr>'; }).join('') + '</table>'); tb = [];
    }
    String(txt || '').split(/\r?\n/).forEach(function (l) {
      var m;
      if (/^\s*\|/.test(l)) { cl(); tb.push(l.replace(/^\s*\||\|\s*$/g, '').split('|')); return; }
      fl();
      if (/^\[saut de page\]\s*$/i.test(l)) { cl(); out.push('<div class="pgb"></div>'); }
      else if (/^---+\s*$/.test(l)) { cl(); out.push('<hr class="ph">'); }
      else if (/^###\s/.test(l)) { cl(); out.push('<h4 class="pp">' + inlP(l.slice(4)) + '</h4>'); }
      else if (/^##\s/.test(l)) { cl(); out.push('<h3 class="pp">' + inlP(l.slice(3)) + '</h3>'); }
      else if (/^#\s/.test(l)) { cl(); out.push(first ? '<h2 class="pp doct">' + inlP(l.slice(2)) + '</h2>' : '<h2 class="pp">' + inlP(l.slice(2)) + '</h2>'); first = false; }
      else if (/^\s*-\s/.test(l)) { if (ul !== 'ul') { cl(); out.push('<ul>'); ul = 'ul'; } out.push('<li>' + inlP(l.replace(/^\s*-\s/, '')) + '</li>'); }
      else if ((m = /^\s*(\d+)[.)]\s+(.*)$/.exec(l))) { if (ul !== 'ol') { cl(); out.push('<ol>'); ul = 'ol'; } out.push('<li>' + inlP(m[2]) + '</li>'); }
      else if (/^>>\s?/.test(l)) { cl(); out.push('<p class="c">' + inlP(l.replace(/^>>\s?/, '')) + '</p>'); }
      else if (/^<<\s?/.test(l)) { cl(); out.push('<p class="r">' + inlP(l.replace(/^<<\s?/, '')) + '</p>'); }
      else if ((m = /^(Objet|Réf\.? projet|Référence)\s*:\s*(.*)$/.exec(l))) { cl(); out.push('<p class="obj"><b>' + esc(m[1]) + ' :</b> ' + inlP(m[2]) + '</p>'); }
      else if (l.trim()) { cl(); out.push('<p>' + inlP(l) + '</p>'); }
    });
    cl(); fl(); return out.join('');
  }
  var CSSP = '<style>.xp .pp{color:var(--p)}.xp h2.pp{font-size:13pt;border-bottom:.3mm solid var(--p);margin:5mm 0 2mm;padding-bottom:.7mm;break-after:avoid}' +
    '.xp h2.doct{font-size:16pt;text-align:center;text-transform:uppercase;border-top:.3mm solid var(--a);border-bottom:.3mm solid var(--a);padding:2.5mm 0;margin:2mm 0 4mm}' +
    '.xp h3.pp{font-size:11.5pt;margin:4mm 0 1mm;break-after:avoid}.xp h4.pp{font-size:11pt;margin:3mm 0 1mm;color:var(--ink);break-after:avoid}' +
    '.xp p{margin:0 0 2mm;text-align:justify}.xp p.c{text-align:center}.xp p.r{text-align:right}.xp p.obj{margin:1mm 0}.xp ul,.xp ol{margin:1mm 0 3mm;padding-left:7mm}' +
    '.xp table.pt{border-collapse:collapse;width:100%;margin:2mm 0}.xp table.pt tr{break-inside:avoid}.xp table.pt td,.xp table.pt th{border:.25mm solid #777;padding:1.4mm 2mm;font-size:10pt;vertical-align:top;text-align:left}.xp table.pt th{background:#e8edf5;color:var(--p)}' +
    '.xp table.sigt td,.xp table.sigt th{text-align:center}.xp table.sigt tr+tr td{height:26mm;vertical-align:bottom}.xp hr.ph{border:0;border-top:.3mm solid #999;margin:3mm 0}.xp .pgb{break-after:page;height:0}' +
    '.xp .rf{display:flex;justify-content:space-between;gap:4mm;font-size:10pt;margin-bottom:3mm}.xp .dest{margin:0 0 4mm auto;width:46%;font-size:11pt}' +
    '</style>';
  function renderPiece(ctx) {
    var P = ctx.profile, d = ctx.data.doc || {}, sig = '', top = '', lettre = d.kind === 'lettre', vs = safeImg(d.visa);
    var addTitle = !/^#\s/m.test(String(d.body || ''));
    if (lettre) {
      top = '<div class="rf"><div><b>Réf. :</b> ' + esc(d.numero || '') + (d.project ? '<br><b>Projet :</b> ' + esc(d.project) : '') + '</div><div style="text-align:right">' + (d.ville ? esc(d.ville) + ', ' : '') + 'le ' + dateFr(d.date) + '</div></div>' +
        (d.dest ? '<div class="dest"><b>' + nl(d.dest) + '</b></div>' : '');
    } else {
      top = (addTitle ? '<h2 class="pp doct">' + esc(d.titre || '') + '</h2>' : '') + '<div class="meta"><div class="box"><b class="lb">Référence</b><b>' + esc(d.numero || '') + '</b><br>Date : <b>' + dateFr(d.date) + '</b>' + (d.project ? '<br>Projet : <b>' + esc(d.project) + '</b>' : '') + (d.lieu ? '<br>Lieu : <b>' + esc(d.lieu) + '</b>' : '') + '</div></div>';
    }
    var zone = vs ? '<img src="' + esc(vs) + '" alt="">' : (d.noSignSpace ? '' : '<div style="height:20mm"></div>');
    if (d.sign === 'dg') {
      sig = '<div class="xsig" style="justify-content:flex-end"><div style="max-width:56%"><div class="lb">' + esc(d.dgRole || P.signatory.role || 'La Direction') + '</div><div class="zone">' + zone + '</div>' + ((d.dgName || P.signatory.name) ? '<div><b>' + esc(d.dgName || P.signatory.name) + '</b></div>' : '') + '<div style="font-size:9pt;color:var(--mut)">' + esc(P.name) + '</div></div></div>';
      if (d.osReceipt) sig += '<div class="xsig"><div><div class="lb">Reçu par l’entreprise (' + esc(d.entreprise || 'nom, date et signature') + ')</div><div class="zone"></div></div></div>';
    } else if (d.sign === 'two') {
      sig = '<div class="xsig"><div><div class="lb">Le maître d’ouvrage</div><div class="zone"></div><div>' + esc(d.moa || '') + '</div></div><div><div class="lb">L’entreprise</div><div class="zone"></div><div>' + esc(d.entreprise || '') + '</div></div>' +
        '<div><div class="lb">Le maître d’œuvre</div><div class="zone">' + (vs ? '<img src="' + esc(vs) + '" alt="">' : '') + '</div><div>' + esc(P.name) + (d.dgName ? '<br><b>' + esc(d.dgName) + '</b>' : '') + '</div></div></div>';
    }
    return CSS + CSSP + '<div class="xm xp">' + C._internals.letterhead(ctx) + top + mdBody(d.body) + sig + qrBlock(d) + footer(P) + '</div>';
  }


  /* ───────────── FICHE / ÉPREUVE / LISTE (V120i — module Formations : épreuves, copies, résultats, listes, présence, cotation, rapport, dossier participant) ─────────────
   * Charge utile : { titre, sousTitre, meta:[[libellé,valeur]], photo, consignes, sections:[{titre, paras:[], kv:[[l,v]], table:{heads:[], rows:[[]], align:[]}}],
   *                  questions:[{number, points, text, lines, answer, result}], totals:[[l,v]], sign:[libellés], qr, numero, date }
   * Toutes les valeurs sont non fiables : échappées. L'identité (nom, logo, contacts, pied) vient du profil de l'organisation. */
  var CSSF = '<style>.xf h2.ft{font-size:16pt;text-align:center;text-transform:uppercase;color:var(--p);border-top:.3mm solid var(--a);border-bottom:.3mm solid var(--a);padding:2.5mm 0;margin:2mm 0 2mm}' +
    '.xf .fsub{text-align:center;color:var(--a);font-weight:700;margin-bottom:3mm}.xf .fhead{display:flex;gap:5mm;align-items:flex-start;margin:2mm 0 3mm}.xf .fhead .box{flex:1}' +
    '.xf .fph{width:30mm;height:38mm;object-fit:cover;border:.3mm solid var(--line);border-radius:1.5mm}.xf .fph0{width:30mm;height:38mm;border:.3mm dashed var(--line);display:flex;align-items:center;justify-content:center;font-size:8pt;color:var(--mut);text-align:center}' +
    '.xf .cons{border:.3mm solid var(--line);padding:2.5mm 3mm;font-size:9.5pt;margin:2mm 0 3mm;white-space:pre-wrap;background:var(--soft)}' +
    '.xf h3.fs{margin:4mm 0 1.5mm;color:var(--p);font-size:11.5pt;border-left:1.2mm solid var(--a);padding-left:2mm;break-after:avoid}.xf p{margin:0 0 2mm}' +
    '.xf table.ft{width:100%;border-collapse:collapse;margin:1.5mm 0 3mm;font-size:9pt}.xf table.ft th{background:var(--p);color:#fff;text-align:left;padding:1.7mm 2mm;font-size:8.4pt}.xf table.ft td{border-bottom:.25mm solid var(--line);padding:1.6mm 2mm;vertical-align:top}.xf table.ft tr{break-inside:avoid}.xf table.ft tr:nth-child(even) td{background:#f7f9fd}' +
    '.xf .q{margin-top:4mm;break-inside:avoid}.xf .q b.qt{color:var(--p)}.xf .ln{border-bottom:.25mm solid #777;height:7.5mm}.xf .ans{background:var(--soft);padding:2mm 2.5mm;white-space:pre-wrap;margin-top:1mm;border-radius:1mm}.xf .qres{font-size:9.5pt;margin-top:1mm}' +
    '.xf .tots{display:flex;gap:3mm;margin:4mm 0;break-inside:avoid}.xf .tots>div{flex:1;border:.3mm solid var(--line);border-radius:1.5mm;padding:2mm 3mm;text-align:center;background:var(--soft)}.xf .tots b{display:block;color:var(--p);font-size:8pt;text-transform:uppercase}.xf .tots span{font-size:12pt;font-weight:800}' +
    '</style>';
  function renderFiche(ctx) {
    var P = ctx.profile, d = ctx.data.doc || {}, h = '', i;
    function arr(v, n) { return Array.isArray(v) ? v.slice(0, n) : []; }
    h += '<h2 class="ft">' + esc(d.titre || 'Document') + '</h2>' + (d.sousTitre ? '<div class="fsub">' + esc(d.sousTitre) + '</div>' : '');
    var meta = arr(d.meta, 40).filter(function (r) { return Array.isArray(r) && String(r[1] == null ? '' : r[1]).trim() !== ''; });
    var ph = safeImg(d.photo);
    if (meta.length || ph || d.photoSlot) {
      h += '<div class="fhead"><div class="box">' + meta.map(function (r) { return '<div><b>' + esc(r[0]) + ' :</b> ' + nl(r[1]) + '</div>'; }).join('') + '</div>' +
        (ph ? '<img class="fph" src="' + esc(ph) + '" alt="">' : (d.photoSlot ? '<div class="fph0">Aucune photo</div>' : '')) + '</div>';
    }
    if (d.consignes) h += '<div class="cons"><b>Consignes :</b> ' + nl(d.consignes) + '</div>';
    arr(d.sections, 60).forEach(function (sc) {
      sc = sc || {};
      if (sc.titre) h += '<h3 class="fs">' + esc(sc.titre) + '</h3>';
      arr(sc.paras, 200).forEach(function (t) { h += '<p>' + nl(t) + '</p>'; });
      var kv = arr(sc.kv, 100); if (kv.length) h += '<table class="kv2">' + kv.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + nl(r[1]) + '</td></tr>'; }).join('') + '</table>';
      var t = sc.table;
      if (t && Array.isArray(t.heads)) {
        var al = arr(t.align, 40);
        h += '<table class="ft"><thead><tr>' + arr(t.heads, 40).map(function (x, k) { return '<th' + (al[k] === 'r' ? ' class="r"' : al[k] === 'c' ? ' class="c"' : '') + '>' + esc(x) + '</th>'; }).join('') + '</tr></thead><tbody>' +
          arr(t.rows, 3000).map(function (r) { return '<tr>' + arr(r, 40).map(function (c, k) { return '<td' + (al[k] === 'r' ? ' class="r"' : al[k] === 'c' ? ' class="c"' : '') + '>' + nl(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table>';
      }
    });
    arr(d.questions, 300).forEach(function (q) {
      q = q || {}; var n = Math.max(0, Math.min(12, parseInt(q.lines, 10) || 0));
      h += '<div class="q"><b class="qt">Question ' + esc(q.number) + (q.points ? ' (' + esc(q.points) + ' pt)' : '') + ' — ' + nl(q.text) + '</b>';
      if (q.answer != null) h += '<div class="ans">' + (String(q.answer).trim() ? nl(q.answer) : '— aucune réponse —') + '</div>';
      for (i = 0; i < n; i++) h += '<div class="ln"></div>';
      if (q.result) h += '<div class="qres">' + nl(q.result) + '</div>';
      h += '</div>';
    });
    if (d.closing) h += '<p style="margin-top:6mm">' + nl(d.closing) + '</p>';
    var tots = arr(d.totals, 8);
    if (tots.length) h += '<div class="tots">' + tots.map(function (r) { return '<div><b>' + esc(r[0]) + '</b><span>' + esc(r[1]) + '</span></div>'; }).join('') + '</div>';
    var sg = arr(d.sign, 4);
    if (sg.length) h += '<div class="xsig">' + sg.map(function (l) { return '<div><div class="lb">' + esc(l) + '</div><div class="zone"></div></div>'; }).join('') + '</div>';
    return CSS + CSSF + '<div class="xm xf">' + C._internals.letterhead(ctx) + h + qrBlock(d) + footer(P) + '</div>';
  }

  var T = function (k, label) { return { k: k, label: label, type: 'text' }; };
  C.register({ id: 'doc-devis', label: 'Devis / facture / reçu (métré)', category: 'Modules', prefix: 'DEV', hidden: true, passthrough: true, bare: true, noTitle: true,
    description: 'Devis, facture ou reçu produit par le module Métré & devis.', fields: [], signatures: [], render: renderDevis });
  C.register({ id: 'doc-module', label: 'Document de module', category: 'Modules', prefix: 'DOC', hidden: true, passthrough: true, bare: true, noTitle: true,
    description: 'Pièce produite par les modules existants (fiches, décomptes, rapports, PV…).', fields: [], signatures: [], render: renderModule });
  C.register({ id: 'doc-piece', label: 'Pièce écrite (module Pièces écrites)', category: 'Modules', prefix: 'PIE', hidden: true, passthrough: true, bare: true, noTitle: true,
    description: 'CCTP, lettre, ordre de service, attestation… rédigés dans le module Pièces écrites (texte sélectionnable, identité du profil).', fields: [], signatures: [], render: renderPiece });
  C.register({ id: 'doc-fiche', label: 'Fiche / épreuve / liste (module Formations)', category: 'Modules', prefix: 'FCH', hidden: true, passthrough: true, bare: true, noTitle: true,
    description: 'Épreuves, copies corrigées, résultats, listes de participants, présence, cotation, rapport d’activité et dossier participant (texte sélectionnable, identité du profil).', fields: [], signatures: [], render: renderFiche });
  return { renderDevis: renderDevis, renderModule: renderModule, renderPiece: renderPiece, renderFiche: renderFiche };
});
