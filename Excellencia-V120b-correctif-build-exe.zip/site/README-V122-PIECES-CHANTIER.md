# V122 — « 📂 Documents de chantier » : tous les documents du chantier au même endroit

## Où le trouver
Menu latéral, **juste en dessous de « 🏗️ Projet 360° »** : bouton **📂 Documents de chantier**. (Les « ✍️ Pièces écrites » existantes restent en place et partagent les mêmes documents.)

## Comment ça marche
1. Choisir le chantier (projet) en haut ; les compteurs montrent documents / brouillons / émis / signés.
2. Chercher un modèle (« béton », « réception », « retard »…) ou ouvrir une famille : 📊 Rapports · 📝 Procès-verbaux · 🗒️ Comptes rendus · 📣 Ordres de service · ⚖️ Clauses · 🧾 Fiches et contrôles · ✉️ Lettres · 🤝 Contrats et avenants · 🏅 Attestations · 📋 Notes, plans, méthodes · 📂 Dossier de chantier · 📐 CCTP · ✍️ Texte libre.
3. Un clic sur un modèle crée le document (numérotation automatique, données du chantier pré-remplies) et ouvre l'éditeur ; « ← Liste » ramène au hub.
4. **📂 Générer le sommaire du dossier** : crée automatiquement le sommaire de tous les documents du chantier (n°, famille, titre, date, état).
5. **📄 PDF officiel** : bleu et or, logo et en-tête de l'entreprise, QR code « Vérifier ce document » en pied de page, signature et cachet du DG selon l'état (émis / signé).

## Modèles : 193 au total (48 avant), dont 145 ajoutés
Rapports 23 · Clauses 28 (+2 CCAP) · Fiches et contrôles 31 · PV 29 · Lettres 24 · Comptes rendus 10 · Ordres de service 14 · Notes 12 · Attestations 8 · Contrats 7 · Dossier de chantier 4 · Texte libre 3. Détail dans `exb-v122-pieces-chantier.js`.

## Fichiers
Nouveaux : `site/exb-v122-docs-chantier.js` (hub) · `site/exb-v122-pieces-chantier.js` (modèles, ajoutés sans jamais remplacer un modèle existant).
Modifiés : `site/index.html` (2 balises script) · `site/sw.js` (cache v122 + hors ligne) · `site/tools/check.js` (contrôles).
Retour en arrière : retirer les 2 balises `<script>` `exb-v122-*` de `index.html`.

## Tests
`node tools/check.js` : tous les contrôles V122 passent ; 1 échec déjà présent avant V122 (« licence-config : commentaire cohérent »).
Testé dans Chromium (logiciel réel) : bouton placé après « Projet 360° », 13 familles, recherche, création depuis un modèle, retour au hub, sommaire automatique, aperçu de tous les modèles sans erreur, page officielle avec QR, bleu et or.
**Non vérifié** : l'enregistrement du fichier PDF final dans cet environnement (l'export a dépassé le délai du test), le rendu sur téléphone, un vrai projet avec des données (test fait sans projet).
Les clauses sont des bases courantes : à faire valider par votre conseil juridique.
