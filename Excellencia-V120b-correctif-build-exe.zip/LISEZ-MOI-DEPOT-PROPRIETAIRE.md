# Dépôt PROPRIÉTAIRE — privé, pour vous seul
Contient tout : site, application propriétaire (EXE), serveur de licences, génération de licences, workflows.
Ne jamais le donner à un client. Les clés (ADMIN-KEY-LICENCES.txt, CLE-PRIVEE-ADMIN.txt, SAUVEGARDE-CLE-*.json) ne vont JAMAIS sur GitHub (.gitignore).
Pour fabriquer les livrables : `node scripts/make-livrables.js nom-du-client`.
