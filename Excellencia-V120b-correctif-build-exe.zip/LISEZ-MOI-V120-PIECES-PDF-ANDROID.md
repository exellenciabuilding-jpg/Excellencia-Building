# V120 — PDF des Pièces écrites sur Android

Problème : « 📄 PDF officiel » passait par l'impression du navigateur (aperçu + window.print), qui ne fait rien dans Chrome Android / PWA / WebView.
Correction : sur Android, navigateur et PWA, le PDF est maintenant fabriqué dans l'appareil (en-tête, corps paginé sans coupure au milieu d'un paragraphe, signature/visa, pied de page avec QR de vérification, « Page n / N ») puis proposé : Partager/Enregistrer, Télécharger, Ouvrir.
Windows (application) et nouvelle APK (impression native) gardent leur chemin d'origine. En cas d'échec, retour automatique à l'ancien aperçu.
Après dépôt : vider le cache / Ctrl+Maj+R (le service worker passe en v120).

## Ajout V119k (calcul de structure)
Mur de soutènement (remblai incliné, nappe, butée, séisme de Mononobe-Okabe) et radier (sol de Winkler en éléments finis, tassements) : voir `site/calcul-structure/README-V119k-LIMITES-LEVEES-MUR-RADIER.md`. `exb-ouvrages.js` est maintenant dans le cache hors ligne (service worker) ; vider le cache / Ctrl+Maj+R après dépôt.

V119l : plan d'armatures, vue 3D, DXF et IFC pour la semelle filante, le radier et le mur de soutènement (voir le README V119k, section V119l).
