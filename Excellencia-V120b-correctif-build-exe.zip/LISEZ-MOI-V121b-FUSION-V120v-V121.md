# V121b — Fusion V120v + V121 sur le dépôt V120u

Base : 1-PROPRIETAIRE-GITHUB-depot-prive-v120u.

- V120v (notes TP / TD automatiques) : site/index.html, site/espace-apprenant.html
- V121 (accès direct dès l\x27inscription) : site/inscription.html, site/supabase/migration-v121-acces-direct-inscription.sql, site/supabase/ORDRE-D-EXECUTION.md, site/README-V121-ACCES-DIRECT.md
- site/sw.js : seul fichier touché par les deux ; version de cache combinée (v121-acces-direct-v120v-notes-tp-td-auto-v120u-...).

Aucun autre fichier du dépôt n\x27a été modifié. Les modifications des deux lots portent sur des fichiers et des lignes distincts : pas de conflit.

À faire : exécuter migration-v121-acces-direct-inscription.sql une fois dans Supabase (après v101 et v102), puis déployer le site.
