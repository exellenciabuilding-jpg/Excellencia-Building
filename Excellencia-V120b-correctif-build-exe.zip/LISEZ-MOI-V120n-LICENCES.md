# V120n — Licences séparées : ce que le client reçoit / ce qui reste chez vous

## Étude : état de la V120m
- Licence = code signé ECDSA P-256 (clé publique dans le logiciel, clé privée chez vous) : le client **ne peut pas fabriquer ni modifier un code** (test automatique).
- **Défaut 1 (corrigé)** : le générateur (`exb-generator.html`), le bouton 🔑 (`exb-admin.js`), l'espace propriétaire (`exb-proprietaire.js`) et la saisie de clé privée sur l'écran verrouillé étaient **livrés dans l'APK, l'EXE et le site Netlify du client**.
- **Défaut 2 (corrigé)** : le mode administrateur s'activait avec une fausse clé écrite dans le stockage local (`{"d":"x","x":<clé publique>}`) → plus aucun blocage. Il faut maintenant une clé qui signe réellement.
- **Défaut 3 (corrigé)** : un code n'était lié à aucun appareil → un client pouvait le donner à tout le monde. Un code peut maintenant être lié à 1 à 10 appareils.
- Pas de clé privée dans le ZIP (vérifié).

## Ce qui change
| | Avant | Maintenant |
|---|---|---|
| APK / EXE / site client | tout `site/` | **édition client** : vérification de licence seulement |
| Générateur de licences | dans le logiciel | **`owner-licences/Excellencia-Licences.html`**, sur votre PC |
| Clé privée | stockage de l'appareil | chargée en mémoire pour la session, jamais enregistrée |
| Code de licence | utilisable partout | **lié au code appareil du client** (recommandé) |

Le build **échoue** si un générateur ou du code de signature reste dans le résultat (`scripts/strip-owner.js`).

## Tests
`node scripts/test-licence.js` (inclus dans les workflows APK, EXE, Netlify) : fausse clé admin, code modifié, expiré, signé par un tiers, lié à un autre appareil, copié sur un autre appareil. `site/tools/check.js` : 514 réussis, 0 échec (le cache hors ligne manquait `exb-notify-pro.js` et `exb-maj-auto.js` : corrigé).

## Limites honnêtes
- Le code d'une application web/APK/EXE reste lisible : un informaticien déterminé peut retirer la vérification. On rend la copie inutile pour l'utilisateur ordinaire ; le contrat de vente complète.
- Le code appareil est enregistré dans l'application : si le client efface les données de l'app, il obtient un nouveau code appareil et doit vous demander une nouvelle licence.
- Seule une activation en ligne (serveur) permettrait de révoquer un code à distance avant l'échéance.
- Gardez le projet Supabase de chaque client dans **votre** compte.
- Non testé ici : compilation réelle APK/EXE (pas de réseau) ni installation sur téléphone.
