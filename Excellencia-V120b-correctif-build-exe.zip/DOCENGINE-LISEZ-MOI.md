# V118 — Moteur documentaire universel (Centre documentaire)

Un seul moteur de documents PDF pour toute la plateforme : devis, factures, reçus, bons de commande, rapports, attestations,
certificats, formulaires, séances, géotechnique… configuré **une fois** par organisation.

## 1. Ce qui existait (analyse)
La plateforme est un site statique (Netlify) + Supabase, avec enveloppes Android (Capacitor) et Windows (Electron). Il n'y avait **aucun serveur**.
Les PDF étaient produits par au moins 7 mécanismes indépendants :

| Mécanisme | Où | Technique |
|---|---|---|
| `EXBPdf` | `exb-pdf.js` | PDF écrit à la main (opérateurs PDF) : reçus, rapports, pages de garde |
| `EXBDocs` | `exb-docs.js` | idem : devis / factures / reçus, QR de vérification, CGV |
| `elementToPdf` | `index.html` | html2canvas + jsPDF : planning (Séances), dossier participant |
| exports métré / budget | `exb-metre.js`, `exb-budgetfin.js` | html2canvas + jsPDF |
| affiches, cartes de travail | `exb-affiches-studio.js`, `exb-carte-travail.js` | html2canvas + jsPDF |
| notes de calcul | `calcul-structure/exb-pdf-direct.js`, `exb-calcul-doc.js` | PDF direct / html2canvas |
| `EXBPrint` | `exb-print.js` | impression HTML (Electron `printToPDF`, Android, aperçu navigateur) |

L'identité (nom, logo, contacts) est déjà centralisée côté navigateur (`EXBId` + `EXB_BRAND`) mais n'est pas multi-organisation côté serveur.
Le module **Séances** = « Planning des cours » (`index.html`, `exportPlanningPdf`). Son seul export documentaire était le planning ; il dépend de
`schedules`, `trainers`, `elementToPdf`. Je n'ai pas trouvé d'autre fonction « documents de ressources » dans ce dépôt.

## 2. Architecture livrée
```
site/docengine/            (navigateur ET serveur : même code)
  core.js                  noyau : profil, validation, numérotation, mise en page commune (en-tête, pied, filigrane, signatures, pagination)
  templates.js             17 modèles : devis, facture, bon-commande, recu, rapport-technique, rapport-chantier, fiche-technique,
                           rapport-geotechnique, document-administratif, attestation, certificat, document-libre, formulaire-inscription,
                           document-formation, planning-seances, feuille-presence, demande-devis, fiche-incident
  client.js                API navigateur  EXBDoc  (profil, génération, historique, formulaires publics, repli local)
  centre.js / centre.css   interface du Centre documentaire (9 rubriques)
  config.js                adresse du serveur (EXB_DOCENGINE_URL)
site/centre-documentaire.html      interface (tableau de bord, profil, entreprise, identité visuelle, modèles, générateur, formulaires publics, historique, paramètres)
site/formulaires-publics.html      formulaires sans compte (?cat=client · ?f=demande-devis)
site/supabase/migration-v118-moteur-documentaire.sql   tables + RLS + numérotation atomique + bucket de stockage
docengine-server/          serveur Node : HTML/CSS → Chromium (Playwright) → PDF ; champs AcroForm (pdf-lib) ; API REST
```
Deux modes, mêmes modèles :
* **Centralisé** : serveur + compte en ligne → profil, modèles, numéros et historique par organisation (Supabase, RLS) ; PDF Chromium, PDF interactifs.
* **Local** : pas de serveur → profil/historique sur l'appareil ; le document HTML identique est envoyé à `EXBPrint` (PDF direct Windows, impression Android, aperçu navigateur).

**Synchronisation automatique** : enregistrer le profil met aussi à jour `EXBId` et `EXB_BRAND` ⇒ les modules historiques (devis, reçus, certificats…) reprennent
immédiatement téléphone, adresse, logo, couleurs, mentions légales. Les documents déjà émis se **régénèrent** avec le profil à jour (même numéro) : bouton « ↻ Mettre à jour » de l'historique.

## 3. Mise en service
1. Supabase › SQL Editor : exécuter `site/supabase/migration-v118-moteur-documentaire.sql` (après `schema-entreprise.sql`). Contrôle : `select count(*) from pg_tables where tablename like 'doc\_%';` → 5.
2. Héberger le serveur (Docker conseillé, voir `docengine-server/Dockerfile` ; Render, Fly.io, VPS…). Variables : `docengine-server/.env.example`
   (`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `ALLOWED_ORIGINS`). Test : `GET /api/v1/health`.
3. Renseigner l'adresse du serveur dans `site/docengine/config.js` (`EXB_DOCENGINE_URL`) ou dans Centre documentaire › Paramètres.
4. Déployer le site comme d'habitude (le dossier `docengine/` est copié automatiquement dans l'APK/Windows par `build-www.js`).
   Dans l'application : Paramètres › « Ouvrir le Centre documentaire ».

## 4. Utiliser le moteur depuis un module
```js
EXBDoc.generate('facture', { client_nom:'…', objet:'…', lignes:[{designation:'…', unite:'m3', qte:2, pu:100}], tva_pct:16 }, { source:'facturation' });
EXBDoc.generate('planning-seances', { seances:[…] }, { source:'seances' });
EXBDoc.generate('formulaire-inscription', {}, { interactive:true });         // PDF avec champs remplissables
```
Le module ne passe ni logo, ni adresse, ni numéro : tout vient du profil et de la numérotation de l'organisation.
Ajouter un document : `EXBDocCore.register({ id, label, category, prefix, fields, tables, signatures, render(ctx){…} })` dans `templates.js`.

## 5. API (extrait) — `/api/v1`
`GET /templates` · `GET|PUT /profile` · `GET|PUT /settings` · `GET|PUT /models`, `DELETE /models/:id` · `POST /render` ({type, data, model_id, options, interactive, format:'html'|'pdf'}) ·
`GET /documents`, `GET /documents/:id/pdf`, `POST /documents/:id/regenerate`, `DELETE /documents/:id` · publics : `GET /public/categories|forms|forms/:slug`, `POST /public/forms/:slug/render`.

## 6. Sécurité
* L'organisation vient de l'appartenance (table `membres`, jeton Supabase vérifié), jamais du corps de la requête. Le serveur appelle Supabase **avec le jeton de l'utilisateur** : l'isolation est garantie par la RLS, pas seulement par le code.
* Rôles admin / éditeur / lecteur ; matrice de permissions modifiable par l'administrateur.
* Rendu Chromium : JavaScript désactivé, toute requête réseau refusée (pas de SSRF), contexte jetable, contenus HTML échappés, images uniquement `data:` validées, couleurs validées.
* Limitation de débit (publics : 20/min/IP), taille de requête bornée, CORS restreint. Les jetons « dev: » sont refusés hors `DOCENGINE_DEV=1`.

## 7. Tests (réellement exécutés)
* `cd docengine-server && npm install && npx playwright install chromium && npm test` → 17 tests API (droits, isolation entre organisations, numérotation, synchronisation du profil, régénération, PDF interactifs, pagination, sécurité du rendu, formulaires publics, limites) dont l'adaptateur Supabase contre une imitation de PostgREST.
* `node tests/e2e-ui.js` → parcours navigateur : 9 rubriques, enregistrement du profil, synchronisation vers `EXBId`, génération et téléchargement de PDF, formulaire public interactif, module Séances.
* `node site/tools/check.js` (contrôle existant du dépôt) : 507 réussis, 0 échec (identique à avant).

## 8. Limites connues / suite
* **Non testé sur un vrai projet Supabase** : la migration SQL et l'adaptateur n'ont été validés que contre une imitation. Exécutez la migration et faites un essai (profil → devis → historique) avant mise en production ; vérifiez les politiques `storage.objects`.
* **Migration progressive** : seul le module Séances (planning) est branché. `exb-docs.js` (devis/factures/reçus), `EXBPdf`, métré, budget, certificats, notes de calcul conservent leur générateur pour ne rien casser ; chacun peut basculer en remplaçant son export par `EXBDoc.generate(...)` (les modèles `devis`, `facture`, `recu`, `certificat`, `rapport-technique`… existent déjà). Les anciennes fonctions sont gardées en secours.
* QR de vérification, conditions générales du devis et page de garde : **repris** dans les modèles `doc-devis` / `doc-module` (`templates-modules.js`, V119e). Correctif V119f : le QR (SVG) était rejeté par le filtre d'images et absent des PDF rendus par le serveur ; test `tests/qr-svg.test.js`.
* Le serveur doit être hébergé (Netlify seul ne peut pas exécuter Chromium). Sans serveur : mode local (pas de PDF interactif, pas de numérotation partagée).
* Chromium n'écrit pas de champs de formulaire : ils sont ajoutés après coup par repérage (testé : positions exactes) ; les champs multi-lignes utilisent la police Helvetica (caractères latins).
* Aperçu visuel vérifié sur les modèles principaux (devis, formulaire, certificat, mises en page « bandeau »/classique) ; vérifiez les autres modèles avec vos vraies données.

## V120e — moteur unique, un seul endroit à remplir
- L'en-tête du profil (logo, nom, coordonnées) est appliqué par défaut aux impressions des modules (EXBPrint.html). Désactivable par client : Centre documentaire › Paramètres. Les reçus, bordereaux, cartes, plans et attestations de signature, qui ont leur propre en-tête, sont laissés tels quels.
- « Identité de l'entreprise » (Paramètres) alimente le profil documentaire : toute modification se répercute (cachet, signature et identifiants légaux du profil sont conservés).
- Sans compte en ligne, les paramètres et modèles s'enregistrent sur l'appareil même si le serveur PDF est configuré mais sans Supabase.
- Limite : les ~6 exports « capture d'écran » (savePdf : affiches, carte de travail, métré, pièces, thème) restent des PDF-images, inscrits à l'historique mais non refaits en modèles.
- Voir GUIDE-NOUVEAU-CLIENT.md.

## V120f — en-tête commun selon le contenu
- Reçus, bordereaux, suivi des paiements et attestations de signature reçoivent l'en-tête du profil **seulement s'ils n'affichent pas déjà le nom de l'entreprise** (plus de doublon, plus d'oubli). Cartes, plans, cartouches et pièces-images restent sans en-tête.
- État détaillé de chaque chemin PDF : `AUDIT-MOTEUR-PDF-V120f.md`.
