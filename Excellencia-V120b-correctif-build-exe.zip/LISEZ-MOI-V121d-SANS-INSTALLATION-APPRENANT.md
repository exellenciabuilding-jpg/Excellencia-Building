# V121d — Espace apprenant non installable

Cause : exb-brand.js ajoutait un manifeste d'application sur chaque page qui le charge, y compris l'espace apprenant ; Chrome proposait donc « Installer ».

Corrections :
1. exb-brand.js : aucune injection de manifeste (et suppression de tout manifeste existant) sur espace-apprenant, apprenant, epreuve, resultats, demande-tp-td, tfl-portail. Chrome ne propose plus « Installer ».
2. espace-apprenant.html : carte « Application » et bouton « Installer l'application » retirés (Paramètres) ; l'invite automatique du navigateur est bloquée.
3. sw.js : version de cache v121d (force le rechargement chez tous les appareils).

Limites :
- « Créer un raccourci » de Chrome (simple signet) ne peut pas être bloqué par un site web ; il ouvre la page dans Chrome, sous la même connexion obligatoire.
- Un apprenant qui a DÉJÀ installé l'application doit la désinstaller de son téléphone ; elle ne fait que charger le site, donc l'accès reste contrôlé par le matricule et le mot de passe.
- Le logiciel principal (index.html, pour l'équipe) reste installable.


## V121e — Extension à tous les espaces publics
Règle inversée dans exb-brand.js : seul index.html (logiciel de l'équipe, racine du site) garde le manifeste et reste installable. Toutes les autres pages — apprenants, clients, formateurs, TFL, formulaires publics, portails, suivi de chantier, vérification, carte de visite — n'ont plus de manifeste. sw.js : version v121e.
