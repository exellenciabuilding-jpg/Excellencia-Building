-- Excellencia — SERVEUR DE LICENCES (V120o). À exécuter UNE FOIS dans VOTRE projet Supabase (SQL Editor › Run). Réexécutable.
-- Les tables ne sont lisibles ni par les clients ni par le public : seule la fonction « licence » (clé service) y accède.

create extension if not exists pgcrypto;

create table if not exists licence_clients (
  id            uuid primary key default gen_random_uuid(),
  slug          text unique not null,
  nom           text not null,
  statut        text not null default 'actif' check (statut in ('actif','suspendu','revoque')),
  expire_le     timestamptz not null,
  grace_jours   int  not null default 7  check (grace_jours between 0 and 365),
  max_appareils int  not null default 2  check (max_appareils between 1 and 10),
  code_hash     text unique not null,            -- empreinte SHA-256 du code d'activation (le code lui-même n'est jamais stocké)
  code_fin      text,                            -- 4 derniers caractères, pour le reconnaître
  config        jsonb not null default '{}'::jsonb,   -- identité + serveur du client, repris dans la licence signée
  notes         text,
  cree_le       timestamptz not null default now(),
  modifie_le    timestamptz not null default now()
);

create table if not exists licence_appareils (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid not null references licence_clients(id) on delete cascade,
  device_id   text not null check (device_id ~ '^[A-Z2-9]{12}$'),
  libelle     text,
  plateforme  text,
  version     text,
  premier_vu  timestamptz not null default now(),
  dernier_vu  timestamptz not null default now(),
  unique (client_id, device_id)
);

create table if not exists licence_journal (
  id         bigserial primary key,
  client_id  uuid references licence_clients(id) on delete cascade,
  quand      timestamptz not null default now(),
  evenement  text not null,
  detail     jsonb not null default '{}'::jsonb
);
create index if not exists licence_journal_client on licence_journal (client_id, quand desc);

create table if not exists licence_tentatives (   -- tentatives de code ratées (frein contre les essais au hasard)
  id      bigserial primary key,
  ip      text not null,
  quand   timestamptz not null default now()
);
create index if not exists licence_tentatives_ip on licence_tentatives (ip, quand desc);

alter table licence_clients    enable row level security;
alter table licence_appareils  enable row level security;
alter table licence_journal    enable row level security;
alter table licence_tentatives enable row level security;
-- aucune politique : ni « anon » ni « authenticated » ne peuvent lire ou écrire ; la clé service (fonction) contourne la sécurité par ligne.
revoke all on licence_clients, licence_appareils, licence_journal, licence_tentatives from anon, authenticated;

-- Enregistrement ATOMIQUE d'un appareil : deux appareils qui s'activent en même temps ne peuvent pas dépasser la limite.
create or replace function licence_enregistrer(p_client uuid, p_device text, p_libelle text, p_plateforme text, p_version text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_max int; v_n int; v_deja boolean;
begin
  select max_appareils into v_max from licence_clients where id = p_client for update;   -- verrou : sérialise les activations d'un même client
  if v_max is null then return jsonb_build_object('ok', false, 'raison', 'inconnu'); end if;
  select exists(select 1 from licence_appareils where client_id = p_client and device_id = p_device) into v_deja;
  if v_deja then
    update licence_appareils set dernier_vu = now(), libelle = coalesce(p_libelle, libelle), plateforme = coalesce(p_plateforme, plateforme), version = coalesce(p_version, version)
      where client_id = p_client and device_id = p_device;
  else
    select count(*) into v_n from licence_appareils where client_id = p_client;
    if v_n >= v_max then return jsonb_build_object('ok', false, 'raison', 'limite', 'n', v_n, 'max', v_max); end if;
    insert into licence_appareils (client_id, device_id, libelle, plateforme, version) values (p_client, p_device, p_libelle, p_plateforme, p_version);
  end if;
  select count(*) into v_n from licence_appareils where client_id = p_client;
  return jsonb_build_object('ok', true, 'deja', v_deja, 'n', v_n, 'max', v_max);
end $$;
revoke all on function licence_enregistrer(uuid, text, text, text, text) from public, anon, authenticated;
grant execute on function licence_enregistrer(uuid, text, text, text, text) to service_role;

create or replace function licence_touch() returns trigger language plpgsql as $$ begin new.modifie_le = now(); return new; end $$;
drop trigger if exists licence_clients_touch on licence_clients;
create trigger licence_clients_touch before update on licence_clients for each row execute function licence_touch();
