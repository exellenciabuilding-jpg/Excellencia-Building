/* Accès à la base Supabase par l'API REST (PostgREST) avec la clé service. Aucune dépendance. */
export function postgrestDb(url, serviceKey, fetchImpl = fetch) {
  const base = url.replace(/\/+$/, '') + '/rest/v1/';
  const H = { apikey: serviceKey, Authorization: 'Bearer ' + serviceKey, 'Content-Type': 'application/json' };
  const q = (v) => encodeURIComponent(v);
  async function call(method, path, body, prefer) {
    const r = await fetchImpl(base + path, { method, headers: Object.assign({}, H, prefer ? { Prefer: prefer } : {}), body: body === undefined ? undefined : JSON.stringify(body) });
    const t = await r.text(); let j = null; try { j = t ? JSON.parse(t) : null; } catch (e) { /* texte */ }
    if (!r.ok) throw new Error(method + ' ' + path.split('?')[0] + ' → ' + r.status + ' ' + t.slice(0, 160));
    return j;
  }
  const one = async (path) => { const a = await call('GET', path + (path.includes('?') ? '&' : '?') + 'limit=1'); return a && a[0] || null; };
  return {
    clientByHash: (h) => one('licence_clients?select=*&code_hash=eq.' + q(h)),
    client: (id) => one('licence_clients?select=*&id=eq.' + q(id)),
    clientBySlug: (s) => one('licence_clients?select=id&slug=eq.' + q(s)),
    async listClients() {
      const a = await call('GET', 'licence_clients?select=*,licence_appareils(device_id,libelle,plateforme,version,premier_vu,dernier_vu)&order=nom.asc');
      return (a || []).map((c) => { const ap = c.licence_appareils || []; delete c.licence_appareils; c.appareils = ap; c.code_hash = undefined; return c; });
    },
    async insertClient(row) { const a = await call('POST', 'licence_clients', row, 'return=representation'); const c = a[0]; c.code_hash = undefined; return c; },
    async updateClient(id, patch) { const a = await call('PATCH', 'licence_clients?id=eq.' + q(id), patch, 'return=representation'); const c = a[0]; c.code_hash = undefined; return c; },
    async deleteClient(id) { await call('DELETE', 'licence_clients?id=eq.' + q(id)); },
    async register(id, device, m) {
      return call('POST', 'rpc/licence_enregistrer', { p_client: id, p_device: device, p_libelle: m.libelle, p_plateforme: m.plateforme, p_version: m.version });
    },
    async touch(id, device, version) {
      const a = await call('PATCH', 'licence_appareils?client_id=eq.' + q(id) + '&device_id=eq.' + q(device), Object.assign({ dernier_vu: new Date().toISOString() }, version ? { version } : {}), 'return=representation');
      return a && a.length ? a[0] : null;
    },
    async deleteDevice(id, device) { const a = await call('DELETE', 'licence_appareils?client_id=eq.' + q(id) + '&device_id=eq.' + q(device), undefined, 'return=representation'); return a ? a.length : 0; },
    async log(id, evenement, detail) { try { await call('POST', 'licence_journal', { client_id: id, evenement, detail: detail || {} }); } catch (e) { /* le journal ne doit jamais bloquer */ } },
    journal: (id, n) => call('GET', 'licence_journal?select=quand,evenement,detail&client_id=eq.' + q(id) + '&order=quand.desc&limit=' + Number(n || 50)),
    async failures(ip, sinceIso) {
      const r = await fetchImpl(base + 'licence_tentatives?select=id&ip=eq.' + q(ip) + '&quand=gte.' + q(sinceIso), { headers: Object.assign({}, H, { Prefer: 'count=exact', Range: '0-0' }) });
      const cr = r.headers.get('content-range') || ''; const n = Number(cr.split('/')[1]); return isNaN(n) ? 0 : n;
    },
    async addFailure(ip) { try { await call('POST', 'licence_tentatives', { ip }); } catch (e) { /* idem */ } },
  };
}
