// Excellencia — serveur de licences (V120o). Fonction Supabase (Deno) : POST JSON { action, ... }.
//   public      : activate, check, ping
//   propriétaire: admin.list / admin.create / admin.update / admin.renew / admin.release_device / admin.new_code / admin.journal / admin.remove
//                 (en-tête x-admin-key)
// Secrets à définir (voir licence-server/LISEZ-MOI.md) : LICENCE_SIGNING_JWK, LICENCE_ADMIN_KEY_HASH.
// SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY sont fournis automatiquement par Supabase.
import { createHandler, makeSigner } from './core.mjs';
import { postgrestDb } from './postgrest.mjs';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type, x-admin-key, authorization, apikey',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
};
const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });

let handler: ((b: unknown, c: { ip?: string; adminKey?: string }) => Promise<{ status: number; body: unknown }>) | null = null;
async function init() {
  if (handler) return handler;
  const jwk = Deno.env.get('LICENCE_SIGNING_JWK'), adminHash = Deno.env.get('LICENCE_ADMIN_KEY_HASH');
  if (!jwk || !adminHash) throw new Error('Secrets manquants : LICENCE_SIGNING_JWK et/ou LICENCE_ADMIN_KEY_HASH');
  handler = createHandler({
    db: postgrestDb(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!),
    sign: await makeSigner(JSON.parse(jwk)),
    adminKeyHash: adminHash.trim().toLowerCase(),
    offlineDays: Number(Deno.env.get('LICENCE_OFFLINE_DAYS') || 7),
    defaultMax: Number(Deno.env.get('LICENCE_DEFAULT_DEVICES') || 2),
  });
  return handler;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (req.method !== 'POST') return json(405, { ok: false, raison: 'methode', msg: 'POST uniquement.' });
  try {
    const h = await init();
    let body: unknown = null; try { body = await req.json(); } catch (_) { /* corps invalide */ }
    const ip = (req.headers.get('x-forwarded-for') || '').split(',')[0].trim() || req.headers.get('cf-connecting-ip') || 'inconnue';
    const r = await h(body, { ip, adminKey: req.headers.get('x-admin-key') || '' });
    return json(r.status, r.body);
  } catch (e) {
    console.error(e);
    return json(500, { ok: false, raison: 'erreur_serveur', msg: 'Serveur de licences mal configuré.' });
  }
});
