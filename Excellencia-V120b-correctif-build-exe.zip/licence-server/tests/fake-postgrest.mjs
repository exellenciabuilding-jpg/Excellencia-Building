/* Faux PostgREST en mémoire : reproduit le sous-ensemble utilisé par postgrest.mjs et les règles de schema.sql
 * (contraintes d'unicité, limite d'appareils, valeurs par défaut). Sert aux tests sans vrai Supabase. */
export function fakePostgrest(opts = {}) {
  const T = { licence_clients: [], licence_appareils: [], licence_journal: [], licence_tentatives: [] };
  let seq = 1; const calls = [];
  const now = () => (opts.now ? opts.now() : new Date()).toISOString();
  const json = (status, body, headers = {}) => new Response(body === undefined || status === 204 ? null : JSON.stringify(body), { status, headers: Object.assign({ 'content-type': 'application/json' }, headers) });
  function filt(rows, params) {
    for (const [k, v] of params) {
      if (['select', 'order', 'limit'].includes(k)) continue;
      const m = /^(eq|gte)\.(.*)$/.exec(v); if (!m) throw new Error('filtre non géré : ' + k + '=' + v);
      rows = rows.filter((r) => m[1] === 'eq' ? String(r[k]) === m[2] : String(r[k]) >= m[2]);
    }
    return rows;
  }
  function insert(table, row) {
    const r = Object.assign({}, row);
    if (table === 'licence_clients') {
      Object.assign(r, { id: crypto.randomUUID(), statut: 'actif', grace_jours: 7, max_appareils: 2, config: {}, cree_le: now(), modifie_le: now() }, row);
      if (T[table].some((x) => x.slug === r.slug || x.code_hash === r.code_hash)) throw Object.assign(new Error('unique'), { code: 409 });
      if (!['actif', 'suspendu', 'revoque'].includes(r.statut)) throw Object.assign(new Error('check'), { code: 400 });
    } else if (table === 'licence_journal') Object.assign(r, { id: seq++, quand: now() }, row);
    else if (table === 'licence_tentatives') Object.assign(r, { id: seq++, quand: now() });
    else throw new Error('insert non géré ' + table);
    T[table].push(r); return r;
  }
  const fetchImpl = async (url, init = {}) => {
    const u = new URL(url), method = init.method || 'GET', h = init.headers || {}, path = u.pathname.replace(/^.*\/rest\/v1\//, '');
    calls.push(method + ' ' + path + u.search);
    if (!/^Bearer .+/.test(h.Authorization || '') || !h.apikey) return json(401, { message: 'no key' });
    const body = init.body ? JSON.parse(init.body) : undefined, wantRep = /return=representation/.test(h.Prefer || '');
    try {
      if (path === 'rpc/licence_enregistrer') {
        const c = T.licence_clients.find((x) => x.id === body.p_client); if (!c) return json(200, { ok: false, raison: 'inconnu' });
        let a = T.licence_appareils.find((x) => x.client_id === c.id && x.device_id === body.p_device);
        if (a) { a.dernier_vu = now(); a.libelle = body.p_libelle || a.libelle; a.plateforme = body.p_plateforme || a.plateforme; a.version = body.p_version || a.version; }
        else {
          const n = T.licence_appareils.filter((x) => x.client_id === c.id).length;
          if (n >= c.max_appareils) return json(200, { ok: false, raison: 'limite', n, max: c.max_appareils });
          if (!/^[A-Z2-9]{12}$/.test(body.p_device)) return json(400, { message: 'check device_id' });
          T.licence_appareils.push({ id: crypto.randomUUID(), client_id: c.id, device_id: body.p_device, libelle: body.p_libelle, plateforme: body.p_plateforme, version: body.p_version, premier_vu: now(), dernier_vu: now() });
        }
        return json(200, { ok: true, deja: !!a, n: T.licence_appareils.filter((x) => x.client_id === c.id).length, max: c.max_appareils });
      }
      const table = path.split('?')[0]; if (!T[table]) return json(404, { message: 'table ' + table });
      const params = [...u.searchParams.entries()];
      if (method === 'POST') { const r = insert(table, body); return wantRep ? json(201, [r]) : json(201); }
      let rows = filt(T[table], params);
      if (method === 'PATCH') { rows.forEach((r) => { Object.assign(r, body); if (table === 'licence_clients') r.modifie_le = now(); }); return wantRep ? json(200, rows) : json(204); }
      if (method === 'DELETE') {
        T[table] = T[table].filter((r) => !rows.includes(r));
        if (table === 'licence_clients') for (const k of ['licence_appareils', 'licence_journal']) T[k] = T[k].filter((r) => T.licence_clients.some((c) => c.id === r.client_id));
        return wantRep ? json(200, rows) : json(204);
      }
      if (method === 'GET') {
        const ord = u.searchParams.get('order'); if (ord) { const [c, d] = ord.split('.'); rows = rows.slice().sort((a, b) => (String(a[c]) < String(b[c]) ? -1 : 1) * (d === 'desc' ? -1 : 1)); }
        const lim = Number(u.searchParams.get('limit')); const total = rows.length; if (lim) rows = rows.slice(0, lim);
        if ((u.searchParams.get('select') || '').includes('licence_appareils(')) rows = rows.map((c) => Object.assign({}, c, { licence_appareils: T.licence_appareils.filter((a) => a.client_id === c.id) }));
        return json(200, rows, /count=exact/.test(h.Prefer || '') ? { 'content-range': '0-0/' + total } : {});
      }
      return json(405, {});
    } catch (e) { return json(e.code || 500, { message: e.message }); }
  };
  return { fetch: fetchImpl, tables: T, calls };
}
