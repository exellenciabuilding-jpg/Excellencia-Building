/* Tests du serveur de licences : node licence-server/tests/core.test.mjs */
import { createHandler, makeSigner, sha256 } from '../supabase/functions/licence/core.mjs';
import { postgrestDb } from '../supabase/functions/licence/postgrest.mjs';
import { fakePostgrest } from './fake-postgrest.mjs';

let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) fail++; };
let clock = Date.parse('2026-11-02T08:00:00Z'); const now = () => new Date(clock);
const DAY = 864e5;

const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
const pg = fakePostgrest({ now });
const ADMIN = 'cle-admin-de-test-' + 'x'.repeat(20);
const h = createHandler({ db: postgrestDb('https://x.supabase.co', 'service-key', pg.fetch), sign: await makeSigner(priv), adminKeyHash: await sha256(ADMIN), now });
const adm = (action, o = {}, key = ADMIN) => h(Object.assign({ action: 'admin.' + action }, o), { adminKey: key, ip: '1.1.1.1' }).then((r) => r.body);
const act = (code, device, ip = '9.9.9.9') => h({ action: 'activate', code, device, label: 'Test', platform: 'web', version: '120o' }, { ip });
const chk = (cid, device) => h({ action: 'check', cid, device }, {});
const PC = 'ABCD-EFGH-JKMN', TEL = 'PQRS-TUVW-XYZ2', TAB = 'ZZZZ-3333-4444';
async function verify(tok) {
  const [p, s] = tok.split('.'); const un = (x) => Uint8Array.from(atob(x.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
  const good = await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, kp.publicKey, un(s), un(p));
  return good ? JSON.parse(new TextDecoder().decode(un(p))) : null;
}

console.log('Propriétaire — sécurité');
ok((await adm('list', {}, 'mauvaise')).raison === 'non_autorise', 'clé administrateur fausse : refusée');
ok((await h({ action: 'admin.list' }, {})).status === 401, 'sans clé : 401');
ok((await h({ action: 'admin.create', nom: 'X' }, { adminKey: '' })).status === 401, 'création sans clé : 401');

console.log('Création d\'un client');
const c1 = await adm('create', { nom: 'Bâtiment Plus SARL', jours: 365, config: { brand: { name: 'Bâtiment Plus' }, srv: { url: 'https://c1.supabase.co', key: 'anon' } } });
ok(c1.ok && /^EXC-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(c1.code), 'code d\'activation généré : ' + c1.code);
ok(c1.client.slug === 'batiment-plus-sarl' && c1.client.max_appareils === 2 && c1.client.grace_jours === 7, 'valeurs par défaut : 2 appareils, tolérance 7 j');
ok(!JSON.stringify(c1.client).includes(await sha256(c1.code.replace(/-/g, ''))), 'l\'empreinte du code n\'est pas renvoyée');
ok(!pg.tables.licence_clients.some((c) => JSON.stringify(c).includes(c1.code)), 'le code n\'est stocké nulle part en clair');
ok((await adm('create', { nom: 'Bâtiment Plus SARL' })).raison === 'slug_existe', 'doublon refusé');
ok((await adm('create', { nom: 'Z', max_appareils: 11 })).raison === 'max_invalide', 'plus de 10 appareils refusé');

console.log('Activation : 2 appareils enregistrés tout seuls');
let r = (await act(c1.code, PC)).body;
ok(r.ok && r.appareils.n === 1 && r.appareils.max === 2, '1er appareil enregistré (1/2)');
const p1 = await verify(r.jeton);
ok(p1 && p1.v === 2 && p1.cid === c1.client.id && p1.dev[0] === PC && p1.off === 7 && p1.brand.name === 'Bâtiment Plus' && p1.srv.url, 'licence signée : appareil, 7 jours hors ligne, identité, serveur du client');
ok(Math.abs(Date.parse(p1.exp) - (clock + 365 * DAY)) < 2 * DAY, 'échéance à 365 jours');
r = (await act(c1.code.toLowerCase().replace(/-/g, ' '), PC)).body;
ok(r.ok && r.appareils.n === 1, 'ré-activation du même appareil (code saisi en minuscules) : toujours 1/2');
r = (await act(c1.code, TEL)).body;
ok(r.ok && r.appareils.n === 2, '2e appareil enregistré (2/2)');
r = (await act(c1.code, TAB)).body;
ok(!r.ok && r.raison === 'limite_appareils' && /2 appareils/.test(r.msg), '3e appareil : refusé, message clair');
ok(!(await act(c1.code, 'court')).body.ok, 'identifiant d\'appareil invalide refusé');

console.log('Concurrence : jamais plus que la limite');
const c2 = await adm('create', { nom: 'Concurrent', max_appareils: 2 });
const devs = ['AAAA-AAAA-AAA2', 'BBBB-BBBB-BBB2', 'CCCC-CCCC-CCC2', 'DDDD-DDDD-DDD2', 'EEEE-EEEE-EEE2'];
const rs = await Promise.all(devs.map((d) => act(c2.code, d)));
ok(pg.tables.licence_appareils.filter((a) => a.client_id === c2.client.id).length <= 2, '5 activations simultanées : 2 acceptées au plus (la garantie réelle vient du verrou SQL « for update » de licence_enregistrer)');

console.log('Vérification en ligne');
r = (await chk(c1.client.id, PC)).body;
ok(r.ok && (await verify(r.jeton)).iat === new Date(clock).toISOString(), 'appareil enregistré : nouvelle licence signée, horodatée');
r = (await chk(c1.client.id, TAB)).body;
ok(!r.ok && r.raison === 'appareil_inconnu', 'appareil non enregistré : refusé');
r = (await chk('00000000-0000-0000-0000-000000000000', PC)).body;
ok(!r.ok && r.raison === 'inconnu', 'client inconnu : refusé');
ok((await chk('pas-un-uuid', PC)).status === 400, 'requête mal formée : 400');

console.log('Libérer un appareil');
ok((await adm('release_device', { id: c1.client.id, device: TEL })).ok, 'appareil libéré par le propriétaire');
ok((await chk(c1.client.id, TEL)).body.raison === 'appareil_inconnu', 'l\'appareil libéré est refusé à la prochaine vérification');
r = (await act(c1.code, TAB)).body;
ok(r.ok && r.appareils.n === 2, 'le nouvel appareil prend la place libérée');

console.log('Suspension / réactivation / révocation');
await adm('update', { id: c1.client.id, patch: { statut: 'suspendu' } });
r = (await chk(c1.client.id, PC)).body; ok(!r.ok && r.raison === 'suspendu', 'suspendu : refusé à la prochaine vérification');
ok((await act(c1.code, PC)).body.raison === 'suspendu', 'suspendu : activation refusée aussi');
await adm('update', { id: c1.client.id, patch: { statut: 'actif' } });
ok((await chk(c1.client.id, PC)).body.ok, 'réactivé : accepté de nouveau, sans nouveau code');
await adm('update', { id: c1.client.id, patch: { statut: 'revoque' } });
ok((await chk(c1.client.id, PC)).body.raison === 'revoque', 'révoqué : refusé');
ok((await adm('remove', { id: c2.client.id })).raison === 'revoquer_d_abord', 'suppression refusée tant que non révoqué');
await adm('update', { id: c1.client.id, patch: { statut: 'actif' } });

console.log('Échéance et renouvellement');
clock += 366 * DAY;                                                       // 1 jour après l'échéance : dans la tolérance de 7 jours
r = (await chk(c1.client.id, PC)).body; ok(r.ok && Date.parse(r.exp) < clock, 'après l\'échéance : le serveur renvoie l\'échéance réelle (le logiciel gère avertissement puis blocage)');
const c3 = await adm('create', { nom: 'Ancien', jours: 1, grace_jours: 0 });
clock += 3 * DAY;
r = (await act(c3.code, PC)).body; ok(!r.ok && r.raison === 'expire', 'activation d\'un abonnement expiré : refusée');
const ren = await adm('renew', { id: c1.client.id, jours: 30 });
ok(ren.ok && Date.parse(ren.client.expire_le) > clock + 25 * DAY, 'renouvellement +30 jours depuis maintenant (échéance dépassée)');
const e0 = Date.parse(ren.client.expire_le);
const ren2 = await adm('renew', { id: c1.client.id, jours: 30 });
ok(Math.abs(Date.parse(ren2.client.expire_le) - (e0 + 30 * DAY)) < 2 * DAY, 'renouvellement avant l\'échéance : s\'ajoute à la fin de l\'abonnement');
r = (await chk(c1.client.id, PC)).body; ok(r.ok && Date.parse((await verify(r.jeton)).exp) === Date.parse(ren2.client.expire_le), 'le logiciel reçoit la nouvelle échéance tout seul à la vérification suivante');

console.log('Modifications');
ok((await adm('update', { id: c1.client.id, patch: { max_appareils: 3 } })).client.max_appareils === 3, 'passer à 3 appareils');
r = (await act(c1.code, 'TTTT-UUUU-VVV2')).body; ok(r.ok && r.appareils.n === 3, 'le 3e appareil est alors accepté');
const nc = await adm('new_code', { id: c1.client.id });
ok(nc.ok && nc.code !== c1.code, 'nouveau code d\'activation');
ok((await act(c1.code, 'WWWW-XXXX-YYY2')).body.raison === 'code_invalide', 'l\'ancien code ne fonctionne plus');
ok((await chk(c1.client.id, PC)).body.ok, 'mais les appareils déjà enregistrés continuent de fonctionner');
const L = await adm('list'); const l1 = L.clients.find((c) => c.slug === 'batiment-plus-sarl');
ok(l1.appareils.length === 3 && l1.code_hash === undefined, 'liste : appareils joints, aucune empreinte de code');
const J = await adm('journal', { id: c1.client.id }); ok(J.journal.length >= 8 && J.journal.some((j) => j.evenement === 'appareil_libere') && J.journal.some((j) => j.evenement === 'renouvele'), 'journal : ' + J.journal.length + ' événements');

console.log('Licence organisation (espace propriétaire / invitations)');
const ot = (await adm('org_token', { nom: 'Bureau Kasa', expire_le: new Date(clock + 30 * DAY).toISOString(), grace_jours: 3 }));
const op = ot.ok && await verify(ot.jeton);
ok(op && op.v === 2 && op.org === 1 && op.name === 'Bureau Kasa' && op.grace === 3 && !op.cid && !op.dev, 'jeton organisation signé par le serveur, non lié à un appareil');
ok((await adm('org_token', { nom: 'x', expire_le: 'pas une date' })).raison === 'date_invalide', 'date invalide refusée');
ok((await adm('org_token', { nom: 'x', expire_le: new Date().toISOString() }, 'fausse')).raison === 'non_autorise', 'sans clé d\'administration : refusé');

console.log('Frein contre les essais au hasard');
let last; for (let i = 0; i < 12; i++) last = await act('EXC-AAAA-BBBB-CCC' + (i % 9 + 2), PC, '8.8.8.8');
ok(last.status === 429 && last.body.raison === 'trop_de_tentatives', 'après 10 codes faux depuis la même adresse : 429');
const c4 = await adm('create', { nom: 'Autre adresse' });
ok((await act(c4.code, 'AAAA-AAAA-AAA3', '7.7.7.7')).body.ok, 'les autres adresses ne sont pas touchées');

console.log('Divers');
ok((await h({ action: 'ping' }, {})).body.service === 'excellencia-licences', 'ping');
ok((await h({ action: 'nimporte' }, {})).status === 400, 'action inconnue : 400');
ok((await h(null, {})).status === 400, 'corps vide : 400');
const bad = createHandler({ db: { clientByHash: async () => { throw new Error('base en panne'); }, failures: async () => 0, addFailure: async () => {} }, sign: async () => 't', adminKeyHash: 'x' });
ok((await bad({ action: 'activate', code: 'EXC-AAAA-BBBB-CCCC', device: PC }, {})).status === 500, 'panne de base : 500 propre, sans planter');

console.log(fail ? '\n' + fail + ' ÉCHEC(S)' : '\nTous les tests du serveur de licences passent.');
process.exit(fail ? 1 : 0);
