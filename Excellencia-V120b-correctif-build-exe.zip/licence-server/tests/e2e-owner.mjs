/* Test de bout en bout de l'application propriétaire : vrai serveur HTTP (logique du serveur de licences + faux PostgREST) + vrai navigateur.
 *   node licence-server/tests/e2e-owner.mjs [dossier-de-captures]            (nécessite Playwright + Chromium) */
import http from 'node:http';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHandler, makeSigner, sha256 } from '../supabase/functions/licence/core.mjs';
import { postgrestDb } from '../supabase/functions/licence/postgrest.mjs';
import { fakePostgrest } from './fake-postgrest.mjs';
const { chromium } = createRequire(import.meta.url)('playwright');
const here = path.dirname(fileURLToPath(import.meta.url)), shots = process.argv[2];

let fail = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) fail++; };
const kp = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const ADMIN = 'adm_test_' + 'k'.repeat(30), pg = fakePostgrest();
const h = createHandler({ db: postgrestDb('https://x.supabase.co', 'k', pg.fetch), sign: await makeSigner(await crypto.subtle.exportKey('jwk', kp.privateKey)), adminKeyHash: await sha256(ADMIN) });
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type, x-admin-key', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
  let b = ''; for await (const c of req) b += c;
  const r = await h(JSON.parse(b || 'null'), { ip: '2.2.2.2', adminKey: req.headers['x-admin-key'] || '' });
  res.writeHead(r.status, Object.assign({ 'Content-Type': 'application/json' }, CORS)); res.end(JSON.stringify(r.body));
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const URL_ = 'http://127.0.0.1:' + server.address().port;
const act = (code, device) => h({ action: 'activate', code, device }, { ip: '3.3.3.3' }).then((r) => r.body);
const renderer = pathToFileURL(path.join(here, '../../owner-app/renderer/index.html')).href;

const browser = await chromium.launch(); const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 }, locale: 'fr-FR' })).newPage();
const errs = []; page.on('pageerror', (e) => errs.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });   // les 401/400 attendus (clé fausse, valeur invalide) sont journalisés par Chromium
const snap = async (n) => { if (shots) await page.screenshot({ path: path.join(shots, n + '.png') }); };

console.log('Application propriétaire (navigateur)');
await page.goto(renderer + '?url=' + encodeURIComponent(URL_) + '&key=mauvaise-cle');
await page.waitForSelector('#welcome:not([hidden])');
ok(true, 'clé fausse : l\'écran de connexion reste affiché');
await snap('0-connexion');
await page.click('#bWelcome'); await page.fill('#cu', URL_); await page.fill('#ck', 'encore-fausse'); await page.click('#fok');
await page.waitForFunction(() => document.getElementById('ferr').textContent.length > 0);
ok(/invalide/i.test(await page.textContent('#ferr')), 'connexion refusée avec message : « ' + (await page.textContent('#ferr')) + ' »');
await page.fill('#ck', ADMIN); await page.click('#fok');
await page.waitForSelector('#main:not([hidden])');
ok(/serveur connecté/.test(await page.textContent('#net')), 'connexion réussie avec la bonne clé');
ok((await page.textContent('#empty')).includes('Nouveau client'), 'liste vide : invitation à créer un client');

await page.click('#bNew'); await page.fill('#fn', 'Bâtiment Plus SARL'); await page.fill('#ft', 'a payé le 12/10');
await page.selectOption('#fd', '90'); await page.click('#fok');
await page.waitForSelector('#cbx');
const code = await page.textContent('#cbx');
ok(/^EXC-[A-Z2-9]{4}-[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(code), 'code affiché : ' + code);
const msg = await page.inputValue('#cmsg');
ok(msg.includes(code) && msg.includes('Bâtiment Plus SARL') && /2 appareils/.test(msg), 'message prêt à envoyer (nom, code, 2 appareils)');
await snap('1-code');
await page.click('#cc3');

ok((await page.textContent('#rows')).includes('Bâtiment Plus SARL') && (await page.textContent('#tiles')).includes('1'), 'le client apparaît dans la liste');
ok(/jamais activé/.test(await page.textContent('#rows')), '« jamais activé » tant qu\'aucun appareil');

/* le client active ses 2 appareils */
const a1 = await act(code, 'AAAA-AAAA-AAA2'), a2 = await act(code, 'BBBB-BBBB-BBB2'), a3 = await act(code, 'CCCC-CCCC-CCC2');
ok(a1.ok && a2.ok && !a3.ok, 'le client enregistre 2 appareils, le 3e est refusé');
await page.click('#bConn'); await page.click('#fok'); await page.waitForFunction(() => /2 \/ 2/.test(document.getElementById('rows').textContent));   // rafraîchit
ok(/2 \/ 2/.test(await page.textContent('#rows')), 'liste : 2 / 2 appareils');
await page.click('#rows tr'); await page.waitForSelector('#drawer:not([hidden]) .dev');
ok((await page.$$('#drawer .dev')).length === 2, 'fiche : 2 appareils listés');
await page.waitForFunction(() => /Appareil enregistré/.test(document.getElementById('jr').textContent));
ok(true, 'journal affiché');
await snap('2-fiche');

/* libérer un appareil */
await page.click('#drawer [data-act="release"]'); await page.click('#okb');
await page.waitForFunction(() => document.querySelectorAll('#drawer .dev').length === 1);
ok(true, 'appareil libéré : 1 restant');
const a4 = await act(code, 'CCCC-CCCC-CCC2'); ok(a4.ok, 'le client peut enregistrer un autre appareil à la place');

/* suspendre / réactiver */
await page.click('#drawer [data-act="suspend"]'); await page.click('#okb');
await page.waitForFunction(() => /Suspendu/.test(document.getElementById('rows').textContent));
ok(pg.tables.licence_clients[0].statut === 'suspendu', 'suspendu côté serveur');
await page.click('#chips [data-f="suspended"]'); ok((await page.$$('#rows tr')).length === 1, 'filtre « Suspendus »');
await page.click('#drawer [data-act="resume"]');
await page.waitForFunction(() => document.querySelectorAll('#rows tr').length === 0);   // n'est plus « suspendu » : sort du filtre
await page.click('#chips [data-f="all"]');
await page.waitForFunction(() => /Actif/.test(document.getElementById('rows').textContent));
ok(pg.tables.licence_clients[0].statut === 'actif', 'réactivé');

/* renouveler */
const e0 = Date.parse(pg.tables.licence_clients[0].expire_le);
await page.click('#drawer [data-act="renew"]'); await page.selectOption('#rj', '365');
ok(/Nouvelle échéance/.test(await page.textContent('#rp')), 'aperçu de la nouvelle échéance');
await snap('3-renouveler');
await page.click('#fok'); await page.waitForFunction(() => document.getElementById('dlg').open === false);
ok(Date.parse(pg.tables.licence_clients[0].expire_le) - e0 > 360 * 864e5, 'renouvelé de 365 jours');

/* nouveau code / recherche / modification */
await page.click('#drawer [data-act="newcode"]'); await page.click('#okb'); await page.waitForSelector('#cbx');
const code2 = await page.textContent('#cbx'); ok(code2 !== code, 'nouveau code généré'); await page.click('#cc3');
await page.fill('#q', 'zzz'); ok(await page.isVisible('#empty'), 'recherche sans résultat'); await page.fill('#q', 'plus'); ok((await page.$$('#rows tr')).length === 1, 'recherche « plus » : 1 résultat'); await page.fill('#q', '');
await page.click('#drawer [data-act="edit"]'); await page.fill('#em', '3'); await page.click('#fok'); await page.waitForFunction(() => document.getElementById('dlg').open === false);
ok(pg.tables.licence_clients[0].max_appareils === 3, 'limite d\'appareils portée à 3');
await page.click('#drawer [data-act="edit"]'); await page.fill('#em', '12'); await page.click('#fok');
await page.waitForFunction(() => document.getElementById('ferr').textContent.length > 0); ok(/entre 1 et 10/.test(await page.textContent('#ferr')), 'valeur invalide : message du serveur affiché'); await page.click('#fno');

/* révoquer puis supprimer */
await page.click('#drawer [data-act="revoke"]'); await page.click('#okb');
await page.waitForFunction(() => /Révoqué/.test(document.getElementById('rows').textContent));
await page.click('#drawer [data-act="remove"]'); await page.click('#okb');
await page.waitForFunction(() => document.querySelectorAll('#rows tr').length === 0);
ok(pg.tables.licence_clients.length === 0, 'client supprimé après révocation');

/* sécurité de l'interface : aucun HTML injecté depuis un nom */
await page.click('#bNew'); await page.fill('#fn', '<img src=x onerror="window.__pwn=1">'); await page.click('#fok'); await page.waitForSelector('#cbx'); await page.click('#cc3');
ok(!(await page.evaluate(() => window.__pwn)) && (await page.textContent('#rows')).includes('<img'), 'un nom contenant du HTML est affiché tel quel, sans être exécuté');
await snap('4-liste');
ok(errs.length === 0, 'aucune erreur dans la console' + (errs.length ? ' : ' + errs.join(' | ') : ''));

await browser.close(); server.close();
console.log(fail ? '\n' + fail + ' ÉCHEC(S)' : '\nTous les tests de l\'application propriétaire passent.');
process.exit(fail ? 1 : 0);
