/* V193/V194 — Reçu de paiement des frais (étudiants TFL, apprenants inscription/formation) au format « carte paysage » : double cadre, filigrane, photo,
 * champs à gauche, N° de reçu + date + QR de vérification + code à droite, motif / montant en rouge, cases de signature.
 * Un seul gabarit pour l'espace étudiant (tfl-portail.html) et l'écran administrateur (exb-tfl.js).
 * API : EXBRecuTFL.html(o) → page HTML complète (A4 paysage) · EXBRecuTFL.visaPublic() → Promise<dataURL cachet+signature publiés> ·
 *       EXBRecuTFL.dataUrl(src) → Promise<dataURL> (logo). Tout le texte est échappé. */
(function (w) {
  'use strict';
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function img(u) { return /^data:image\/(png|jpe?g|webp|gif);base64,/i.test(String(u || '')) ? String(u) : ''; }
  function row(k, v) { return '<tr><th>' + esc(k) + '</th><td>: ' + esc(v || '—') + '</td></tr>'; }
  /* filigrane répété (texte en diagonale) — image SVG intégrée, aucun fichier externe */
  var WM = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="230" height="150"><text x="115" y="80" text-anchor="middle" font-family="Arial,sans-serif" font-weight="700" font-size="24" fill="#c9ced6" fill-opacity=".55" transform="rotate(-38 115 75)">EXCELLENCIA</text></svg>');
  var CSS = '@page{size:A4 landscape;margin:8mm}*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact}html,body{margin:0;background:#fff}body{font-family:Arial,Helvetica,sans-serif;color:#111}'
    + '.rc{position:relative;width:281mm;height:194mm;border:1.1mm double #111;padding:5mm 8mm 5mm;background:#fff url("' + WM + '") repeat;overflow:hidden;page-break-inside:avoid;margin:0 auto}'
    + '.top{display:flex;justify-content:space-between;align-items:flex-start;height:43mm}.top .tl,.top .tr{flex:0 0 62mm}.top .tr{display:flex;justify-content:flex-end}.org{flex:1 1 auto;text-align:center;font-weight:700;font-size:22pt;letter-spacing:.3mm;margin-top:7mm}'
    + '.lg{display:block;height:39mm;max-width:60mm;object-fit:contain;margin:0 0 0 4mm}.ph{width:28mm;height:31mm;object-fit:cover;border:.3mm solid #999;background:#eef1f5;display:block}.ph0{width:28mm;height:31mm;border:.3mm dashed #aab;display:block}'
    + '.gc{font-size:13pt;text-align:center;margin:0}.ti{text-align:center;font-weight:700;font-size:24pt;margin:5mm 0 3mm;letter-spacing:.2mm}'
    + '.bx{display:flex;border:.35mm dashed #333;margin:0 6mm;padding:3mm 4mm;min-height:60mm;background:rgba(255,255,255,.55)}.bx .l{flex:1 1 0;min-width:0}.bx table{border-collapse:collapse}.bx th{text-align:left;font-size:13.5pt;padding:.7mm 5mm .7mm 0;white-space:nowrap;width:42mm}.bx td{font-size:14.5pt;padding:.7mm 0;overflow-wrap:anywhere}'
    + '.bx .r{flex:0 0 78mm;border-left:.35mm dashed #e0c400;padding-left:4mm;text-align:center}.no{color:#d00000;font-weight:700;font-size:13.5pt;text-align:left;white-space:nowrap}.dt{font-weight:700;font-size:13pt;text-align:left;margin-bottom:1.5mm}.qr svg,.qr img{width:36mm;height:36mm;display:block;margin:0 auto}'
    + '.cd{display:inline-flex;border:.3mm solid #333;margin-top:1.5mm}.cd span{width:5.6mm;height:6.4mm;line-height:6.4mm;border-right:.3mm solid #333;font-size:11.5pt;text-align:center}.cd span:last-child{border-right:0}'
    + '.bt{display:flex;margin:2.5mm 6mm 0;gap:6mm}.bt .a{flex:1 1 0}.bt .b{flex:0 0 118mm}.bt .ln{font-size:13.5pt;margin:.8mm 0;white-space:nowrap}.bt b.k{display:inline-block;min-width:42mm}.red{color:#d00000;font-weight:700}'
    + '.op{font-size:13.5pt;font-weight:700;margin-top:3mm}.op .red{display:block;margin:2mm 0 0 10mm}'
    + '.sg{display:flex;border:.4mm solid #111;height:30mm;margin-top:3mm;background:rgba(255,255,255,.7)}.sg div{flex:1 1 0;padding:2.5mm 4mm;font-size:12pt;position:relative}.sg div+div{border-left:.4mm solid #111}.sg img{position:absolute;right:4mm;bottom:1.5mm;max-height:23mm;max-width:46mm}'
    + '.sg .gn{display:block;font-weight:700;font-size:11.5pt;margin-top:2mm}.ft{position:absolute;left:8mm;bottom:3mm;font-size:8pt;color:#555}';
  function html(o) {
    o = o || {};
    var code = String(o.code || '').slice(0, 10), cells = code.split('').map(function (c) { return '<span>' + esc(c) + '</span>'; }).join('');
    var logo = img(o.logo), photo = img(o.photo), visa = img(o.visa), qr = String(o.qr || '');
    if (/^data:image\/(png|jpe?g|gif|webp);base64,/i.test(qr)) qr = '<img src="' + qr + '" alt="">'; else if (!/^\s*<svg[\s>]/i.test(qr)) qr = '';
    var org = esc(o.org || 'Excellencia Building');
    var left = (o.lignes && o.lignes.length) ? o.lignes.map(function (l) { return row(l[0], l[1]); }).join('') : (row('Étudiant', o.nom) + row('Matricule', o.matricule) + row('Faculté', o.faculte) + row('Département', o.filiere) + row('Promotion', o.promotion)
      + (o.sexe ? row('Sexe', o.sexe) : '') + row('Payé le', o.datePaiement) + row('Banque', o.mode) + row('No. Transaction', o.reference));
    return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Reçu ' + esc(o.no) + '</title><style>' + CSS + '</style></head><body><div class="rc">'
      + '<div class="top"><div class="tl">' + (logo ? '<img class="lg" src="' + logo + '" alt="">' : '') + '</div><div class="org">' + org + '</div><div class="tr">' + (photo ? '<img class="ph" src="' + photo + '" alt="">' : '<span class="ph0"></span>') + '</div></div>'
      + '<div class="gc">' + esc(o.guichet || 'GUICHET D’APUREMENT DES FRAIS') + '</div><div class="ti">' + esc(o.titre || 'REÇU DE PAIEMENT DES FRAIS') + '</div>'
      + '<div class="bx"><div class="l"><table>' + left + '</table></div><div class="r"><div class="no">Reçu N° ' + esc(o.no) + '</div><div class="dt">Date : ' + esc(o.dateEmission) + '</div>'
      + (qr ? '<div class="qr">' + qr + '</div>' : '') + (cells ? '<div class="cd">' + cells + '</div>' : '') + '</div></div>'
      + '<div class="bt"><div class="a">' + (o.libAnnee === '' ? '' : '<div class="ln"><b class="k">' + esc(o.libAnnee || 'Année Académique') + '</b> <span class="red">: ' + esc(o.annee || '—') + '</span></div>') + '<div class="op">Opérateur<span class="red">' + esc(o.operateur || '') + '</span></div></div>'
      + '<div class="b">' + ((o.bas && o.bas.length) ? o.bas.map(function (l) { return '<div class="ln"><b>' + esc(l[0]) + '</b> <span class="red">: ' + esc(l[1]) + '</span></div>'; }).join('') : '<div class="ln"><b>Motif</b> <span class="red">&nbsp;&nbsp;: ' + esc(o.motif || '—') + '</span></div><div class="ln"><b>Montant</b> <span class="red">: ' + esc(o.montant) + '</span></div>') + ''
      + '<div class="sg"><div>' + esc(o.libEtudiant || 'Etudiant') + '</div><div>Guichetier' + (o.guichetier ? '<span class="gn">' + esc(o.guichetier) + '</span>' : '') + (visa ? '<img src="' + visa + '" alt="">' : '') + '</div></div></div></div>'
      + '</div></body></html>';
  }
  function dataUrl(src) {
    return new Promise(function (ok) {
      try { var im = new Image(); im.onload = function () { try { var c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); ok(c.toDataURL('image/png')); } catch (e) { ok(''); } }; im.onerror = function () { ok(''); }; im.src = src; } catch (e) { ok(''); }
    });
  }
  /* cachet + signature du Directeur publiés (Site vitrine › Publier) : lus tels quels, jamais inventés ; vide si rien n'est publié */
  function visaPublic() {
    var RK = 'EXB_VISA_REMOTE', cached = ''; try { cached = w.localStorage.getItem(RK) || ''; } catch (e) {}
    var c = w.EXB_SUPABASE || {};
    if (!c.url || typeof w.fetch !== 'function') return Promise.resolve(img(cached));
    return w.fetch(String(c.url).replace(/\/+$/, '') + '/storage/v1/object/public/vitrine/visa.png?t=' + Date.now()).then(function (r) { if (!r.ok) throw 0; return r.blob(); })
      .then(function (b) { return new Promise(function (ok, ko) { var fr = new FileReader(); fr.onload = function () { ok(String(fr.result)); }; fr.onerror = ko; fr.readAsDataURL(b); }); })
      .then(function (u) { if (!img(u)) throw 0; try { w.localStorage.setItem(RK, u); } catch (e) {} return u; }).catch(function () { return img(cached); });
  }
  /* V194 — reçu d'inscription / de formation (espace apprenant et logiciel) au même modèle.
   * r = { no, date, formation, participant, matricule, debut, lieu, distinction, inscription:{montant,statut}, formation_frais:{montant,statut}, guichetier, code, qr, logo, visa, photo }
   * Les lignes s'adaptent aux informations de la formation : une ligne n'apparaît que si elle est renseignée. */
  function jour(d) { var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(d || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] : String(d || ''); }
  function codeUrl(u) { try { var raw = decodeURIComponent((String(u || '').split('c=')[1] || '').split('&')[0]); return (raw.split('~')[5] || '').toUpperCase(); } catch (e) { return ''; } }
  function depuisApprenant(r) {
    r = r || {}; var fi = r.inscription || {}, ff = r.formation_frais || {}, L = [], B = [];
    function add(a, k, v) { if (v != null && String(v).trim() !== '') a.push([k, String(v)]); }
    add(L, 'Participant', r.participant); add(L, 'Matricule', r.matricule); add(L, 'Formation', r.formation); add(L, 'Début', jour(r.debut)); add(L, 'Lieu', r.lieu); add(L, 'Distinction', r.distinction); add(L, 'Payé le', jour(r.date));
    if (fi.montant) B.push(['Frais d’inscription', String(fi.montant) + (fi.statut ? ' · ' + fi.statut : '')]);
    if (ff.montant) B.push(['Frais de formation', String(ff.montant) + (ff.statut ? ' · ' + ff.statut : '')]);
    return { no: r.no, dateEmission: jour(r.date), lignes: L, bas: B, libAnnee: '', libEtudiant: 'Participant', operateur: r.guichetier || 'Administration Excellencia Building', guichetier: r.guichetier || '',
      code: r.code || codeUrl(r.url), qr: r.qr, logo: r.logo, visa: r.visa, photo: r.photo };
  }
  w.EXBRecuTFL = { html: html, visaPublic: visaPublic, dataUrl: dataUrl, depuisApprenant: depuisApprenant };
})(window);
