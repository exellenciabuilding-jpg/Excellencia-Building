/* V121c — diagnostic de lenteur : repère les tâches automatiques (minuteries) qui bloquent l'écran plus de 300 ms.
 * Garde les 30 dernières dans « exb_diag_lent » (sur l'appareil seulement, jamais synchronisé). Aucun contenu saisi n'est lu.
 * Rapport : Ctrl + Alt + L (ou EXBDiag.rapport() dans la console). À charger EN PREMIER (avant les autres scripts). */
(function(w){'use strict';
if(w.EXBDiag)return;
var KEY='exb_diag_lent',SEUIL=300,MAX=30,VER='V120';
try{if(w.localStorage.getItem(KEY+'_v')!==VER){w.localStorage.removeItem(KEY);w.localStorage.setItem(KEY+'_v',VER)}}catch(e){}
var ALERT0=w.alert,cache=0,cacheDe=0;
try{w.addEventListener('visibilitychange',function(){if(w.document.hidden)cache=Date.now();else cacheDe=Date.now()})}catch(e){}
/* Boîtes de dialogue natives (alert/confirm/prompt) : durée d'attente notée avec le début du message, pour distinguer « fenêtre restée ouverte » d'un vrai calcul. */
['alert','confirm','prompt'].forEach(function(n){try{var o=w[n];if(!o||o.__diag)return;var f=function(m){var t=Date.now(),r=o.apply(w,arguments),d=Date.now()-t;if(d>=1000&&!w.__diagRapport)noter('(boîte de dialogue '+n+' restée ouverte : « '+String(m==null?'':m).replace(/\s+/g,' ').slice(0,70)+' »)',d);return r};f.__diag=1;w[n]=f}catch(e){}});
function lire(){try{return JSON.parse(w.localStorage.getItem(KEY)||'[]')||[]}catch(e){return []}}
function noter(nom,ms){try{var L=lire();L.push({t:new Date().toISOString(),ms:Math.round(ms),job:nom});w.localStorage.setItem(KEY,JSON.stringify(L.slice(-MAX)))}catch(e){}}
function nom(f){try{return String(f).replace(/\s+/g,' ').slice(0,90)}catch(e){return '?'}}
/* V137 : pendant qu'on tape dans un champ (recherche, nom, saisie), les tâches automatiques répétées (≥ 1 s) sont reportées
   au prochain passage : la frappe n'est plus jamais ralentie par une tâche de fond. */
var derniere=0;
try{['keydown','input','compositionupdate'].forEach(function(ev){w.document.addEventListener(ev,function(){derniere=Date.now()},{capture:true,passive:true})})}catch(e){}
function enSaisie(){try{if(Date.now()-derniere>1500)return false;var a=w.document.activeElement,t=a&&a.tagName;return t==='INPUT'||t==='TEXTAREA'||(a&&a.isContentEditable)||false}catch(e){return false}}
function emballer(f,periodique){
  if(typeof f!=='function'||f.__exbDiag)return f;
  var g=function(){if(periodique&&enSaisie())return;var t0=Date.now();try{return f.apply(this,arguments)}finally{var d=Date.now()-t0;if(d>=SEUIL)noter(nom(f),d)}};
  g.__exbDiag=1;return g}
var si=w.setInterval,st=w.setTimeout;
w.setInterval=function(f,d){var a=Array.prototype.slice.call(arguments);a[0]=emballer(f,(d|0)>=1000);return si.apply(w,a)};
w.setTimeout=function(f,d){var a=Array.prototype.slice.call(arguments);if((d|0)>=1000)a[0]=emballer(f);return st.apply(w,a)};
/* V137b : observateurs de DOM (MutationObserver) — leurs rappels sont chronométrés et, s'ils se déclenchent en rafale
   (boucle d'un script qui modifie la page que l'autre surveille), regroupés : au plus 4 exécutions par seconde et par observateur. */
try{var MO=w.MutationObserver;if(MO&&!MO.__exbDiag){
  var MO2=function(cb){var last=0,pend=null,rec=[],self=null,tm=null;
    function run(){tm=null;var r=rec;rec=[];last=Date.now();var t0=last;try{cb.call(self,r,self)}catch(e){try{w.setTimeout(function(){throw e},0)}catch(e2){}}var d=Date.now()-t0;if(d>=SEUIL)noter('(observateur DOM) '+nom(cb),d)}
    var hist=[];
    var o=new MO(function(r){self=o;rec=rec.concat(r);var n=Date.now(),dt=n-last;hist.push(n);while(hist.length&&n-hist[0]>1000)hist.shift();
      /* en fonctionnement normal : exécution immédiate ; seulement en rafale (≥ 12 déclenchements en 1 s) : regroupement toutes les 250 ms */
      if(hist.length<12){if(tm){w.clearTimeout(tm);tm=null}run()}else if(!tm){tm=st(run,Math.max(0,250-dt))}});
    var tr=o.takeRecords.bind(o);o.takeRecords=function(){var x=rec.concat(tr());rec=[];return x};
    return o};
  MO2.prototype=MO.prototype;MO2.__exbDiag=1;w.MutationObserver=MO2}}catch(e){}
/* V137b : images d'écran longues (Long Animation Frames, Chrome/Edge récents) : indiquent le script et la fonction responsables */
try{if(w.PerformanceObserver&&(w.PerformanceObserver.supportedEntryTypes||[]).indexOf('long-animation-frame')>=0)
  new w.PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.duration<1000||w.__diagRapport)return;var sc=(e.scripts||[]).slice().sort(function(a,b){return b.duration-a.duration})[0];
    noter('(image longue) '+(sc?(sc.invokerType+' '+(sc.invoker||'')+' '+String(sc.sourceURL||'').split('/').pop()+':'+(sc.sourceFunctionName||'?')+':'+(sc.sourceCharPosition||'')):'sans script (style/mise en page '+Math.round(e.styleAndLayoutStart?e.startTime+e.duration-e.styleAndLayoutStart:0)+' ms)')+' ['+(w.location.hash||w.location.pathname.split('/').pop()||'/')+']',e.duration)})}).observe({type:'long-animation-frame',buffered:true})}catch(e){}
try{var raf=w.requestAnimationFrame;w.requestAnimationFrame=function(f){return raf.call(w,emballer(f))}}catch(e){}
try{if(w.PerformanceObserver&&(w.PerformanceObserver.supportedEntryTypes||[]).indexOf('longtask')>=0)
  new w.PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.duration<1000||w.__diagRapport)return;var fin=Date.now(),deb=fin-e.duration,veille=w.document.hidden||(cache&&cache>deb-1000&&cache<fin+1000)||(cacheDe&&cacheDe>deb&&cacheDe<fin+1000);noter(veille?'(onglet masqué ou ordinateur en veille ~'+Math.round(e.duration/1000)+' s — pas un calcul)':e.duration>=5000?'(arrêt de '+Math.round(e.duration/1000)+' s sans boîte de dialogue ni veille détectée : à signaler)':'(blocage écran, source inconnue)',e.duration)})}).observe({entryTypes:['longtask']})}catch(e){}
function rapport(){var L=lire();if(!L.length)return 'Aucun blocage de plus de '+SEUIL+' ms enregistré.';
  var par={};L.forEach(function(x){var p=par[x.job]||(par[x.job]={n:0,max:0,der:''});p.n++;p.max=Math.max(p.max,x.ms);p.der=x.t});
  return Object.keys(par).sort(function(a,b){return par[b].max-par[a].max}).map(function(k){return par[k].max+' ms max · '+par[k].n+' fois · '+k}).join('\n')}
w.EXBDiag={rapport:rapport,effacer:function(){try{w.localStorage.removeItem(KEY)}catch(e){}},version:VER};
w.addEventListener('keydown',function(e){if(e.ctrlKey&&e.altKey&&(e.key==='l'||e.key==='L')){e.preventDefault();w.__diagRapport=1;try{ALERT0.call(w,'Tâches qui ont bloqué l\u2019écran :\n\n'+rapport())}finally{setTimeout(function(){w.__diagRapport=0},400)}}});
})(window);
