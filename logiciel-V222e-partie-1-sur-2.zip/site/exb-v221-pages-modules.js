/* Excellencia Building V221i — ÉCRANS DES MODULES EN PAGE (comme « Pilotage projets »).
 * Avant : Environnement, Maintenance, Électricité, Plomberie, Topographie, VRD, Géotechnique, Études P2, Dalles, Juridique, Contrôle réglementaire,
 * Règles IDS, Programme & surfaces, IA architecte, Analyse de site, Coordination, Matériaux et Dossier BE s'ouvraient dans une fenêtre flottante sur fond sombre.
 * Maintenant : chaque module s'affiche dans la zone de contenu, à la place de l'écran en cours, avec la barre latérale visible — exactement comme Pilotage projets.
 * Le contenu, les calculs et les boutons des modules ne changent pas : seule la présentation change (bouton ✕ = retour à l'écran précédent).
 * Si ce fichier est absent, les modules reprennent leur fenêtre flottante d'origine. */
(function (w) {
  'use strict';
  if (w.EXBPAGE) return;
  var d = w.document;
  var IDS = ['exbBeDal', 'exbBeP2', 'exbElec', 'exbEnv', 'exbGeoPlus', 'exbMaint', 'exbReg', 'exbIds', 'exbJur', 'exbPlomb', 'exbTopo', 'exbProg', 'exbIaArch', 'exbVrd', 'exbSite', 'exbCoord', 'exbMat', 'exbBeD'];
  var last = 'dashboard', wrapped = false, current = null;
  function $(i) { return d.getElementById(i); }

  /* V221i : habillage « Chantiers & finances » — titre fort, description, onglets horizontaux à soulignement doré, fil d'Ariane, bouton retour */
  var CSS = '.exb-page-module{font-family:inherit}'
    + '.exb-page-module>div[id$="Box"]{background:#fff!important;border-radius:16px!important;padding:22px 24px!important;box-shadow:0 1px 6px rgba(15,23,42,.10)!important;border:1px solid #e5e9f2}'
    + '.exb-page-module h3{font-size:24px!important;line-height:1.25;color:#173565!important;font-weight:800;margin:6px 0 8px!important}'
    + '.exb-page-module h3+p{font-size:14.5px!important;color:#475569!important;margin:0 0 14px!important}'
    + '.exb-page-module [data-a=close]{display:none!important}'
    + '.exb-page-module div:has(>[data-a=tab]){gap:2px!important;border-bottom:1px solid #d8dfec;margin:0 0 14px!important;overflow-x:auto;flex-wrap:nowrap!important}'
    + '.exb-page-module [data-a=tab]{background:transparent!important;color:#475569!important;border-radius:0!important;border-bottom:3px solid transparent!important;padding:10px 14px!important;font-weight:700;white-space:nowrap}'
    + '.exb-page-module [data-a=tab][style*="0f766e"],.exb-page-module [data-a=tab][style*="15, 118, 110"]{color:#173565!important;border-bottom-color:#c49a38!important}'
    + '.exbpg-top{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:0 0 10px;font:13px Arial,sans-serif;color:#64748b}'
    + '.exbpg-top button{background:#173565;color:#fff;border:0;border-radius:999px;padding:7px 14px;font-weight:700;cursor:pointer}'
    + '.exbpg-top b{color:#173565}';
  function addCss() { if ($('exbPageCss')) return; var st = d.createElement('style'); st.id = 'exbPageCss'; st.textContent = CSS; (d.head || d.documentElement).appendChild(st); }
  function addTop(o) {
    if (o.querySelector('.exbpg-top')) return;
    var top = d.createElement('div'); top.className = 'exbpg-top';
    top.innerHTML = '<button type="button" data-exbpg-back>← Projets &amp; Chantiers</button><span>Accueil › Projets &amp; Chantiers › <b data-exbpg-name></b></span>';
    o.insertBefore(top, o.firstChild);
    top.querySelector('[data-exbpg-back]').addEventListener('click', function () { var c = o.querySelector('[data-a=close]'); if (c) c.click(); else o.remove(); });
    function name() { var h = o.querySelector('h3'), n = top.querySelector('[data-exbpg-name]'); if (h && n) n.textContent = h.textContent.replace(/^[^\wÀ-ÿ]+/, '').trim(); }
    name(); try { new MutationObserver(name).observe(o, { childList: true, subtree: true }); } catch (e) { }
  }
  function hostRef() { return $('pilotprojet') || $('dashboard') || $('projets') || $('direction'); }
  function wrapShow() {
    if (wrapped || typeof w.show !== 'function') return; wrapped = true;
    var os = w.show;
    w.show = function (x) { if (x !== '__exbpage') { last = x || last; closeAll(true); } return os.apply(this, arguments); };
  }
  function closeAll(silent) { IDS.forEach(function (id) { var o = $(id); if (o && o.getAttribute('data-exbpage')) { o.setAttribute('data-exbpage', ''); Element.prototype.remove.call(o); } }); if (!silent) current = null; }
  /* transforme la fenêtre flottante `o` en page intégrée */
  function toPage(o) {
    try {
      var ref = hostRef(); if (!ref || !ref.parentNode) return false;
      wrapShow();
      IDS.forEach(function (id) { var p = $(id); if (p && p !== o && p.getAttribute('data-exbpage')) { p.setAttribute('data-exbpage', ''); Element.prototype.remove.call(p); } });
      addCss(); o.setAttribute('data-exbpage', '1'); o.classList.add('exb-page-module'); addTop(o);
      try { d.body.style.overflow = ''; d.documentElement.style.overflow = ''; } catch (e) { }
      o.style.cssText = 'display:block;position:static;background:transparent;padding:0;margin:0;width:100%;overflow:visible';
      o.onclick = null;
      var box = o.firstElementChild; if (box) { box.style.maxWidth = 'none'; box.style.width = '100%'; box.style.boxSizing = 'border-box'; box.style.boxShadow = '0 1px 4px rgba(15,23,42,.12)'; }
      /* masquer l'écran en cours (liste officielle de show()), puis placer la page dans la zone de contenu */
      try { w.show('__exbpage'); } catch (e) { }
      ref.parentNode.insertBefore(o, ref.nextSibling);
      /* fermeture : retour à l'écran précédent */
      o.remove = function () { if (o.getAttribute('data-exbpage')) { o.setAttribute('data-exbpage', ''); Element.prototype.remove.call(o); try { w.show(last || 'dashboard'); } catch (e) { } } else Element.prototype.remove.call(o); };
      current = o;
      try { o.scrollIntoView({ block: 'start' }); w.scrollTo(0, 0); } catch (e) { }
      return true;
    } catch (e) { return false; }
  }
  function isModuleOverlay(n) { return n && n.nodeType === 1 && n.tagName === 'DIV' && IDS.indexOf(n.id) >= 0 && /position:\s*fixed/.test(n.getAttribute('style') || '') && !n.getAttribute('data-exbpage'); }
  if (typeof MutationObserver !== 'undefined' && d.body) {
    new MutationObserver(function (list) {
      list.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes, function (n) { if (isModuleOverlay(n)) { var o = n; setTimeout(function () { if (o.parentNode === d.body && isModuleOverlay(o)) toPage(o); }, 0); } }); });
    }).observe(d.body, { childList: true });
  } else d.addEventListener('DOMContentLoaded', function () { if (typeof MutationObserver !== 'undefined') new MutationObserver(function (list) { list.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes, function (n) { if (isModuleOverlay(n)) { var o = n; setTimeout(function () { toPage(o); }, 0); } }); }); }).observe(d.body, { childList: true }); });
  w.EXBPAGE = { ids: IDS, toPage: toPage, closeAll: closeAll, version: 'V221i' };
})(typeof window !== 'undefined' ? window : globalThis);
