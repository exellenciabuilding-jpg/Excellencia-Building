/* Excellencia Building — Plan Editor : export PDF.
 * Le plan d'origine est conservé EN VECTORIEL (page insérée telle quelle dans la nouvelle feuille : texte, traits et calques restent nets
 * à n'importe quel zoom). Le cadre, le cartouche, les QR Codes et le filigrane sont écrits en vectoriel aussi.
 * Si le PDF d'origine ne peut pas être inséré (fichier atypique), on retombe sur une image haute résolution du plan.
 * Dépend de pdf-lib (../pdflib/pdf-lib.min.js, hors ligne) et de sheet.js. */
(function (w) {
  'use strict';
  var PT = 72 / 25.4;

  function hex2rgb(c) {
    c = String(c || '#000000').trim();
    var m = /^#([0-9a-f]{3})$/i.exec(c);
    if (m) c = '#' + m[1].split('').map(function (x) { return x + x; }).join('');
    m = /^#([0-9a-f]{6})$/i.exec(c);
    if (!m) return [0, 0, 0];
    var n = parseInt(m[1], 16);
    return [(n >> 16) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function f3(n) { return (Math.round(n * 1000) / 1000).toString(); }

  /* Faux contexte canvas 2D qui écrit des opérateurs PDF. Repère de dessin : unités de la feuille, y vers le bas. */
  function PdfCtx(doc, page, fonts, W, H, wmm, hmm) {
    var PL = w.PDFLib;
    this.doc = doc; this.page = page; this.fonts = fonts; this.PL = PL;
    this.ops = []; this.stack = []; this.path = []; this.fnames = {}; this.gnames = {}; this.inames = {}; this.imgs = new Map();
    this.st = { fill: '#000000', stroke: '#000000', lw: 1, size: 12, bold: false, italic: false, alpha: 1 };
    this.fillStyle = '#000000'; this.strokeStyle = '#000000'; this.lineWidth = 1; this.globalAlpha = 1;
    this.textAlign = 'left'; this.textBaseline = 'alphabetic'; this._font = '12px sans-serif'; this.imageSmoothingQuality = 'high';
    var s = (wmm * PT) / W;
    this.ops.push('q ' + f3(s) + ' 0 0 ' + f3(-s) + ' 0 ' + f3(hmm * PT) + ' cm');
  }
  var P = PdfCtx.prototype;
  Object.defineProperty(P, 'font', {
    get: function () { return this._font; },
    set: function (v) {
      this._font = v; var m = /^\s*(italic|oblique)?\s*(\d+|bold|normal)?\s*([\d.]+)px/i.exec(String(v));
      if (!m) return;
      this.st.italic = !!m[1]; var wt = m[2]; this.st.bold = wt === 'bold' || (+wt || 400) >= 600; this.st.size = parseFloat(m[3]) || 12;
    }
  });
  P.setTransform = function () { /* la base est posée une fois pour toutes dans le constructeur */ };
  P.save = function () { this.stack.push({ fs: this.fillStyle, ss: this.strokeStyle, lw: this.lineWidth, ga: this.globalAlpha, ta: this.textAlign, tb: this.textBaseline, f: this._font, st: Object.assign({}, this.st) }); this.ops.push('q'); };
  P.restore = function () {
    var t = this.stack.pop(); if (!t) return; this.ops.push('Q');
    this.fillStyle = t.fs; this.strokeStyle = t.ss; this.lineWidth = t.lw; this.globalAlpha = t.ga; this.textAlign = t.ta; this.textBaseline = t.tb; this._font = t.f; this.st = t.st;
    this._gsApplied = null;
  };
  P.translate = function (x, y) { this.ops.push('1 0 0 1 ' + f3(x) + ' ' + f3(y) + ' cm'); };
  P.scale = function (x, y) { this.ops.push(f3(x) + ' 0 0 ' + f3(y) + ' 0 0 cm'); };
  P.rotate = function (a) { var c = Math.cos(a), s = Math.sin(a); this.ops.push([f3(c), f3(s), f3(-s), f3(c), 0, 0].join(' ') + ' cm'); };
  P.beginPath = function () { this.path = []; };
  P.moveTo = function (x, y) { this.path.push(f3(x) + ' ' + f3(y) + ' m'); };
  P.lineTo = function (x, y) { this.path.push(f3(x) + ' ' + f3(y) + ' l'); };
  P.closePath = function () { this.path.push('h'); };
  P.rect = function (x, y, w2, h) { this.path.push([f3(x), f3(y), f3(w2), f3(h)].join(' ') + ' re'); };
  P.arc = function (cx, cy, r, a0, a1, ccw) {
    var d = a1 - a0; if (ccw) { while (d > 0) d -= 2 * Math.PI; } else { while (d < 0) d += 2 * Math.PI; }
    if (Math.abs(d) > 2 * Math.PI) d = ccw ? -2 * Math.PI : 2 * Math.PI;
    var n = Math.max(1, Math.ceil(Math.abs(d) / (Math.PI / 2))), step = d / n, k = 4 / 3 * Math.tan(step / 4), a = a0, self = this;
    this.path.push(f3(cx + r * Math.cos(a)) + ' ' + f3(cy + r * Math.sin(a)) + ' ' + (this.path.length ? 'l' : 'm'));
    for (var i = 0; i < n; i++) {
      var b = a + step, x1 = cx + r * (Math.cos(a) - k * Math.sin(a)), y1 = cy + r * (Math.sin(a) + k * Math.cos(a)),
        x2 = cx + r * (Math.cos(b) + k * Math.sin(b)), y2 = cy + r * (Math.sin(b) - k * Math.cos(b)), x3 = cx + r * Math.cos(b), y3 = cy + r * Math.sin(b);
      self.path.push([f3(x1), f3(y1), f3(x2), f3(y2), f3(x3), f3(y3)].join(' ') + ' c'); a = b;
    }
  };
  P._color = function (fill) { var c = hex2rgb(fill ? this.fillStyle : this.strokeStyle); return f3(c[0]) + ' ' + f3(c[1]) + ' ' + f3(c[2]) + (fill ? ' rg' : ' RG'); };
  P._gs = function () {
    var a = Math.round(this.globalAlpha * 1000) / 1000;
    if (this._gsApplied === a) return; this._gsApplied = a;
    var key = String(a), nm = this.gnames[key];
    if (!nm) { var d = this.doc.context.obj({ Type: 'ExtGState', ca: a, CA: a }); nm = this.gnames[key] = this.page.node.newExtGState('GS' + key.replace('.', '_'), d); }
    this.ops.push(nm.toString() + ' gs');
  };
  P.fill = function () { if (!this.path.length) return; this._gs(); this.ops.push(this._color(true) + ' ' + this.path.join(' ') + ' f'); };
  P.stroke = function () { if (!this.path.length) return; this._gs(); this.ops.push(this._color(false) + ' ' + f3(this.lineWidth) + ' w ' + this.path.join(' ') + ' S'); };
  P.clip = function () { if (!this.path.length) return; this.ops.push(this.path.join(' ') + ' W n'); this.path = []; };
  P.fillRect = function (x, y, w2, h) { this._gs(); this.ops.push(this._color(true) + ' ' + [f3(x), f3(y), f3(w2), f3(h)].join(' ') + ' re f'); };
  P.strokeRect = function (x, y, w2, h) { this._gs(); this.ops.push(this._color(false) + ' ' + f3(this.lineWidth) + ' w ' + [f3(x), f3(y), f3(w2), f3(h)].join(' ') + ' re S'); };

  P._pdfFont = function () { return this.fonts[(this.st.bold ? 'b' : '') + (this.st.italic ? 'i' : '') || 'r']; };
  P._enc = function (font, t) {
    var out = '';
    for (var i = 0; i < t.length; i++) {
      var ch = t[i], ok = true;
      try { font.encodeText(ch); } catch (e) { ok = false; }
      out += ok ? ch : (ch === '→' ? '>' : '?');
    }
    return out;
  };
  P.measureText = function (t) { var f = this._pdfFont(); return { width: f.widthOfTextAtSize(this._enc(f, String(t)), this.st.size) }; };
  P.fillText = function (t, x, y) {
    t = String(t == null ? '' : t); if (!t) return;
    var f = this._pdfFont(), sz = this.st.size, txt = this._enc(f, t), wd = f.widthOfTextAtSize(txt, sz);
    if (this.textAlign === 'center') x -= wd / 2; else if (this.textAlign === 'right' || this.textAlign === 'end') x -= wd;
    if (this.textBaseline === 'middle') y += sz * 0.33; else if (this.textBaseline === 'top' || this.textBaseline === 'hanging') y += sz * 0.8;
    var key = (this.st.bold ? 'b' : '') + (this.st.italic ? 'i' : '') || 'r', nm = this.fnames[key];
    if (!nm) nm = this.fnames[key] = this.page.node.newFontDictionary('F' + key, f.ref);
    this._gs();
    var hx = f.encodeText(txt).toString();
    this.ops.push(this._color(true) + ' BT ' + nm.toString() + ' ' + f3(sz) + ' Tf 1 0 0 -1 ' + f3(x) + ' ' + f3(y) + ' Tm ' + hx + ' Tj ET');
  };
  /* Image : soit la page d'origine insérée (objet {__form:{ref,w,h,rot}}), soit un logo préparé par prepareImage(). */
  P.drawImage = function (im, x, y, w2, h) {
    this._gs();
    if (im && im.__form) {
      var F = im.__form, fw = F.w, fh = F.h, rot = F.rot, dw = rot % 180 ? fh : fw, dh = rot % 180 ? fw : fh, sx = w2 / dw, sy = h / dh, m;
      if (rot === 90) m = [0, sy, sx, 0, x, y]; else if (rot === 180) m = [-sx, 0, 0, sy, x + w2, y]; else if (rot === 270) m = [0, -sy, -sx, 0, x + w2, y + h]; else m = [sx, 0, 0, -sy, x, y + h];
      var nm = this.inames['P' + F.idx]; if (!nm) nm = this.inames['P' + F.idx] = this.page.node.newXObject('Plan' + F.idx, F.ref);
      /* un formulaire hérite de l'état graphique courant : on le remet à zéro (noir, trait 1, opacité 1) pour ne pas teinter le plan */
      var ga = this.globalAlpha; this.globalAlpha = 1; this._gsApplied = null; this._gs();
      this.ops.push('q 0 g 0 G 1 w 0 J 0 j [] 0 d ' + m.map(f3).join(' ') + ' cm ' + nm.toString() + ' Do Q');
      this.globalAlpha = ga; this._gsApplied = null; return;
    }
    var rec = this.imgs.get(im); if (!rec) return;
    var n2 = this.inames['I' + rec.idx]; if (!n2) n2 = this.inames['I' + rec.idx] = this.page.node.newXObject('Im' + rec.idx, rec.ref);
    this.ops.push('q ' + [f3(w2), 0, 0, f3(-h), f3(x), f3(y + h)].join(' ') + ' cm ' + n2.toString() + ' Do Q');
  };
  P.finish = function () {
    while (this.stack.length) this.restore();
    this.ops.push('Q');
    var stream = this.doc.context.flateStream(this.ops.join('\n'));
    this.page.node.addContentStream(this.doc.context.register(stream));
  };

  /* Prépare (une seule fois par document) une image HTML pour qu'elle puisse être dessinée.
   * Logo : PNG (transparence conservée, 900 px max). Photo / vue 3D : JPEG sur fond blanc (1800 px max). */
  async function prepareImage(doc, img, cache, photo) {
    if (!img || !img.width) return null;
    if (cache.has(img)) return cache.get(img);
    var mw = photo ? 1800 : 900, r = Math.min(1, mw / Math.max(img.width, img.height)), c = document.createElement('canvas'), g;
    c.width = Math.max(1, Math.round(img.width * r)); c.height = Math.max(1, Math.round(img.height * r));
    g = c.getContext('2d'); if (photo) { g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); }
    g.drawImage(img, 0, 0, c.width, c.height);
    var b64 = c.toDataURL(photo ? 'image/jpeg' : 'image/png', 0.9).split(',')[1], bin = atob(b64), u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    var emb = photo ? await doc.embedJpg(u) : await doc.embedPng(u), rec = { ref: emb.ref, idx: cache.size + 1 };
    cache.set(img, rec); return rec;
  }

  /* build(o) -> Uint8Array
   * o.src            : octets du PDF d'origine (ou null : feuille sans plan)
   * o.sheets         : [{ wmm, hmm, W, H, opts }]  (opts = options de EXBSHEET.drawSheet, hors ctx/ppu/plan)
   * o.plan(i)        : { zoom, dx, dy, w, h } pour la feuille i (w,h = taille d'affichage de la page d'origine, en points)
   * o.raster(i)      : repli, async -> { bytes: Uint8Array JPEG, w, h }
   * o.links          : [url1, url2] liens posés sur les QR Codes
   * o.meta           : { title, author, subject, keywords } */
  async function build(o) {
    var PL = w.PDFLib; if (!PL) throw new Error('Le module PDF (pdf-lib) n’est pas chargé.');
    var doc = await PL.PDFDocument.create(), SF = PL.StandardFonts;
    var fonts = { r: await doc.embedFont(SF.Helvetica), b: await doc.embedFont(SF.HelveticaBold), i: await doc.embedFont(SF.HelveticaOblique), bi: await doc.embedFont(SF.HelveticaBoldOblique) };
    var embedded = null, srcPages = null, vectorOK = false, notes = [];
    if (o.src && o.sheets.length) {
      try {
        var src = await PL.PDFDocument.load(o.src, { updateMetadata: false });
        srcPages = src.getPages();
        var boxes = srcPages.map(function (p) { var cb = p.getCropBox(); return { left: cb.x, bottom: cb.y, right: cb.x + cb.width, top: cb.y + cb.height }; });
        embedded = await doc.embedPages(srcPages, boxes);
        vectorOK = true;
      } catch (e) { notes.push('Plan inséré en image (le PDF d’origine n’a pas pu être repris en vectoriel : ' + (e && e.message || e) + ').'); }
    }
    var imgCache = new Map(), n = o.sheets.length;
    for (var i = 0; i < n; i++) {
      var S = o.sheets[i], page = doc.addPage([S.wmm * PT, S.hmm * PT]), ctx = new PdfCtx(doc, page, fonts, S.W, S.H, S.wmm, S.hmm);
      if (S.opts.logo) { var rec = await prepareImage(doc, S.opts.logo, imgCache); if (rec) ctx.imgs.set(S.opts.logo, rec); }
      if (S.opts.photo && S.opts.photo.img) { var recP = await prepareImage(doc, S.opts.photo.img, imgCache, true); if (recP) ctx.imgs.set(S.opts.photo.img, recP); }
      var po = o.plan ? o.plan(i) : null, plan = null;
      if (po && o.src) {
        if (vectorOK && embedded[i]) {
          var ang = ((srcPages[i].getRotation().angle % 360) + 360) % 360, e = embedded[i];
          plan = { img: { width: po.w, height: po.h, __form: { ref: e.ref, w: e.width, h: e.height, rot: ang, idx: i } }, zoom: po.zoom, dx: po.dx, dy: po.dy };
        } else if (o.raster) {
          var rr = await o.raster(i), jpg = await doc.embedJpg(rr.bytes), rec2 = { ref: jpg.ref, idx: 1000 + i }, key = { width: rr.w, height: rr.h };
          ctx.imgs.set(key, rec2); plan = { img: key, zoom: po.zoom, dx: po.dx, dy: po.dy };
        }
      }
      var opts = Object.assign({}, S.opts, { W: S.W, H: S.H, ppu: 1, plan: plan });
      var L = w.EXBSHEET.drawSheet(ctx, opts);
      ctx.finish();
      (L.qrRects || []).forEach(function (q, k) {
        var url = o.links && o.links[k]; if (!url) return;
        var s = (S.wmm * PT) / S.W, x0 = q.x * s, y0 = (S.hmm * PT) - (q.y + q.size) * s, sz = q.size * s;
        var an = doc.context.obj({ Type: 'Annot', Subtype: 'Link', Rect: [x0, y0, x0 + sz, y0 + sz], Border: [0, 0, 0], A: { Type: 'Action', S: 'URI', URI: PL.PDFString.of(url) } });
        page.node.addAnnot(doc.context.register(an));
      });
    }
    var M = o.meta || {};
    doc.setTitle(M.title || 'Plan'); doc.setAuthor(M.author || 'Excellencia Building'); doc.setSubject(M.subject || '');
    doc.setKeywords(M.keywords || []); doc.setProducer('Excellencia Plan Editor (pdf-lib)'); doc.setCreator('Excellencia Building');
    doc.setCreationDate(new Date()); doc.setModificationDate(new Date());
    var bytes = await doc.save({ useObjectStreams: true });
    return { bytes: bytes, vector: vectorOK, notes: notes };
  }

  w.EXBPDFOUT = { build: build, PdfCtx: PdfCtx };
})(window);
