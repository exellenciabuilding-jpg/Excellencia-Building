/* Excellencia Building — Plan Editor : dessin de la feuille (cadre, en-tête, cartouche, 2 QR Codes, plan).
 * Le dessin n'utilise que des instructions « canvas 2D » simples : le même code sert à l'aperçu (canvas) et à l'export PDF
 * vectoriel (pdfout.js fournit un faux contexte canvas qui écrit des opérateurs PDF). Aucune dépendance externe, 100 % hors ligne. */
(function (w) {
  'use strict';
  var INK = '#14202F', PAPER = '#FFFFFF';
  /* Formats (petit côté, grand côté, en mm). La détection automatique ne compare qu'aux formats ISO A. */
  var FORMATS = {
    A0: [841, 1189], A1: [594, 841], A2: [420, 594], A3: [297, 420], A4: [210, 297], A5: [148, 210],
    'A0+': [914, 1292], 'A1+': [610, 914],
    B0: [1000, 1414], B1: [707, 1000], B2: [500, 707], B3: [353, 500], B4: [250, 353],
    'ANSI A': [216, 279], 'ANSI B': [279, 432], 'ANSI C': [432, 559], 'ANSI D': [559, 864], 'ANSI E': [864, 1118],
    'ARCH C': [457, 610], 'ARCH E1': [762, 1067], 'ARCH E': [914, 1219]
  };
  var ISO_A = ['A0', 'A1', 'A2', 'A3', 'A4'];
  var FORMAT_LABELS = { 'A1+': 'A1+ / ARCH D', 'ANSI A': 'ANSI A (Letter)', 'ANSI B': 'ANSI B (Tabloïd)', 'ARCH C': 'ARCH C (18×24 po)', 'ARCH E1': 'ARCH E1 (30×42 po)', 'ARCH E': 'ARCH E (36×48 po)' };
  var FORMAT_GROUPS = [
    { label: 'ISO A', keys: ['A0', 'A1', 'A2', 'A3', 'A4', 'A5'] },
    { label: 'Allongés (traceurs)', keys: ['A0+', 'A1+'] },
    { label: 'ISO B', keys: ['B0', 'B1', 'B2', 'B3', 'B4'] },
    { label: 'ANSI (USA)', keys: ['ANSI A', 'ANSI B', 'ANSI C', 'ANSI D', 'ANSI E'] },
    { label: 'ARCH (USA)', keys: ['ARCH C', 'ARCH E1', 'ARCH E'] }
  ];
  var FONT_D = 'Helvetica, Arial, "Liberation Sans", sans-serif';
  var FONT_B = FONT_D;

  /* Styles de cartouche. pos : right | left (colonne pleine hauteur) | bottom (bandeau ou bloc en bas).
   * size : largeur de la colonne ou hauteur du bandeau ; bw : largeur du bloc en bas (0 = pleine largeur) ; head/hh : en-tête ; foot/fh : pied de page ;
   * deco : none | swoosh | both (vague + immeubles) ; logoIn / titleIn : où vont le logo et le titre (head | info | zone) ; cols : colonnes de la grille (bandeau).
   * Les dispositions de ISO 7200, Revit/ArchiCAD et AutoCAD/ANSI sont inspirées des usages décrits dans les normes et la pratique ; ce ne sont pas des copies de gabarits officiels. */
  var STYLES = {
    std: { brand: 'exb', name: 'Excellencia Standard', pos: 'right', size: 150, head: true, hh: 84, foot: true, fh: 58, deco: 'both', logoIn: 'head', titleIn: 'head', cols: 1, swH: 34 },
    cmp: { brand: 'exb', name: 'Excellencia Compact', pos: 'right', size: 124, head: true, hh: 62, foot: true, fh: 40, deco: 'swoosh', logoIn: 'head', titleIn: 'head', cols: 1, swH: 22 },
    min: { brand: 'exb', name: 'Excellencia Sobre', pos: 'right', size: 150, head: true, hh: 62, foot: false, fh: 0, deco: 'none', logoIn: 'head', titleIn: 'head', cols: 1, swH: 22 },
    iso: { brand: 'iso', name: 'Bloc en bas à droite', pos: 'bottom', size: 112, bw: 540, head: false, hh: 0, foot: true, fh: 0, deco: 'none', logoIn: 'info', titleIn: 'info', cols: 2, mL: 20, swH: 22 },
    isob: { brand: 'iso', name: 'Bandeau en bas', pos: 'bottom', size: 100, bw: 0, head: false, hh: 0, foot: false, fh: 0, deco: 'none', logoIn: 'info', titleIn: 'info', cols: 4, mL: 20, swH: 22 },
    revr: { brand: 'arc', name: 'Bandeau vertical à droite', pos: 'right', size: 176, head: false, hh: 0, foot: false, fh: 0, deco: 'none', logoIn: 'info', titleIn: 'info', cols: 1, revTable: true, bigSheet: true, qrRow: true, hideRows: ['ind', 'date'], swH: 22 },
    revl: { brand: 'arc', name: 'Bandeau vertical à gauche', pos: 'left', size: 176, head: false, hh: 0, foot: false, fh: 0, deco: 'none', logoIn: 'info', titleIn: 'info', cols: 1, revTable: true, bigSheet: true, qrRow: true, hideRows: ['ind', 'date'], swH: 22 },
    cad: { brand: 'cad', name: 'Bandeau en bas (titre à part)', pos: 'bottom', size: 100, bw: 0, head: false, hh: 0, foot: false, fh: 0, deco: 'none', logoIn: 'info', titleIn: 'zone', cols: 3, swH: 22 },
    free: { brand: 'free', name: 'Cartouche libre', pos: 'right', size: 150, bw: 0, head: true, hh: 70, foot: false, fh: 50, deco: 'none', logoIn: 'head', titleIn: 'head', cols: 2, swH: 26 }
  };
  var BRANDS = [
    { id: 'exb', name: 'Excellencia Building', models: ['std', 'cmp', 'min'] },
    { id: 'iso', name: 'ISO 7200 (norme internationale)', models: ['iso', 'isob'] },
    { id: 'arc', name: 'Architecte — style Revit / ArchiCAD', models: ['revr', 'revl'] },
    { id: 'cad', name: 'AutoCAD / ANSI', models: ['cad'] },
    { id: 'free', name: 'Cartouche libre', models: ['free'] }
  ];
  function brandOf(key) { return (STYLES[key] || STYLES.std).brand; }

  /* Style effectif : modèle + réglages de l'utilisateur (tune) + options du cartouche libre (free). */
  function resolve(key, tune, free, hasPhoto) {
    var b = STYLES[key] || STYLES.std, s = {}, k;
    for (k in b) s[k] = b[k];
    if (key === 'free' && free) for (k in free) if (free[k] !== undefined && free[k] !== null) s[k] = free[k];
    if (tune) {
      ['size', 'bw', 'hh', 'fh'].forEach(function (n) { if (tune[n] !== undefined && tune[n] !== null) s[n] = +tune[n]; });
      if (tune.fh !== undefined && tune.fh !== null && s.pos !== 'bottom') s.foot = +tune.fh > 0;
    }
    if (s.head) s.titleIn = 'head'; else { if (s.titleIn === 'head') s.titleIn = 'info'; if (s.logoIn === 'head') s.logoIn = 'info'; }
    if (hasPhoto && s.pos !== 'bottom' && !s.foot) { s.foot = true; s.fh = s.fh > 20 ? s.fh : 46; }
    if (hasPhoto && s.pos === 'bottom' && s.bw > 0) s.foot = true;
    s.key = key; return s;
  }

  /* Dimensions de la feuille en unités de dessin : le petit côté vaut toujours 594. ratio = grand côté / petit côté (A1 par défaut). */
  function sheetUnits(landscape, ratio) {
    var r = ratio || (841 / 594), L = Math.round(594 * r * 100) / 100;
    return landscape ? { W: L, H: 594 } : { W: 594, H: L };
  }

  function nearestFormat(wmm, hmm) {
    var a = Math.min(wmm, hmm), b = Math.max(wmm, hmm), best = null, d = 1e9;
    ISO_A.forEach(function (k) {
      var f = FORMATS[k], e = Math.abs(f[0] - a) / f[0] + Math.abs(f[1] - b) / f[1];
      if (e < d) { d = e; best = k; }
    });
    return { key: best, exact: d < 0.04 };
  }

  /* Découpage de la feuille : cadre, cartouche (info), en-tête, pied de page, zone du plan. */
  function layout(W, H, st, hasPhoto) {
    var m = 12, mL = st.mL || m, x0 = mL, y0 = m, x1 = W - m, y1 = H - m, size = st.size, hh = st.head ? st.hh : 0, fh = st.foot ? st.fh : 0;
    var L = { m: m, x0: x0, y0: y0, x1: x1, y1: y1, st: st, head: null, foot: null }, rx0 = x0, rx1 = x1;
    if (st.pos === 'bottom') {
      var full = x1 - x0, bw = st.bw > 0 ? Math.min(st.bw, full) : full;
      if (full - bw < 90) bw = full;
      L.info = { x: x1 - bw, y: y1 - size, w: bw, h: size };
      if (hh) L.head = { x: x0, y: y0, w: full, h: hh };
      if (bw < full - 1 && st.foot) L.foot = { x: x0, y: y1 - size, w: full - bw, h: size };
      L.plan = { x: x0, y: y0 + hh, w: full, h: (y1 - size) - (y0 + hh) };
    } else {
      if (st.pos === 'left') { L.info = { x: x0, y: y0, w: size, h: y1 - y0 }; rx0 = x0 + size; } else { L.info = { x: x1 - size, y: y0, w: size, h: y1 - y0 }; rx1 = x1 - size; }
      if (hh) L.head = { x: rx0, y: y0, w: rx1 - rx0, h: hh };
      if (fh) L.foot = { x: rx0, y: y1 - fh, w: rx1 - rx0, h: fh };
      L.plan = { x: rx0, y: y0 + hh, w: rx1 - rx0, h: (y1 - fh) - (y0 + hh) };
    }
    L.photoInfo = !!hasPhoto && !L.foot;
    /* compatibilité avec l'ancien code (V140) */
    L.cw = L.info.w; L.colX = L.info.x; L.hh = hh; L.fh = fh;
    return L;
  }

  function fit(ctx, text, maxW, size, min, weight, family, style) {
    var s = size;
    for (; s > min; s -= 0.5) {
      ctx.font = (style || '') + ' ' + weight + ' ' + s + 'px ' + family;
      if (ctx.measureText(text).width <= maxW) break;
    }
    ctx.font = (style || '') + ' ' + weight + ' ' + s + 'px ' + family;
    return s;
  }

  function line(ctx, x1, y1, x2, y2, wd, c) {
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2);
    ctx.lineWidth = wd; ctx.strokeStyle = c || INK; ctx.stroke();
  }

  /* Coupe un nom d'entreprise en deux lignes au plus (« EXCELLENCIA » / « BUILDING »). */
  function nameLines(name) {
    var t = String(name || '').trim().toUpperCase().split(/\s+/).filter(Boolean);
    if (t.length <= 1) return [t[0] || ''];
    var best = 1, bd = 1e9, i;
    for (i = 1; i < t.length; i++) { var a = t.slice(0, i).join(' ').length, b = t.slice(i).join(' ').length, d = Math.abs(a - b); if (d < bd) { bd = d; best = i; } }
    return [t.slice(0, best).join(' '), t.slice(best).join(' ')];
  }

  /* QR Code : la matrice (tableau de lignes de booléens) vient de EXBQR.matrix (hors ligne) ; 2 modules de marge blanche. */
  function drawQR(ctx, mat, x, y, size) {
    ctx.fillStyle = PAPER; ctx.fillRect(x, y, size, size);
    var quiet = 2, n = mat.length, cell = size / (n + quiet * 2);
    ctx.fillStyle = '#000000';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) {
      if (mat[r][c]) ctx.fillRect(x + (c + quiet) * cell - 0.12, y + (r + quiet) * cell - 0.12, cell + 0.24, cell + 0.24);
    }
  }

  function drawLogoVector(ctx, x, y, w2, h, col, name, tag) {
    var k = Math.min(1, h / 74), cx = x + w2 / 2, ih = h * 0.40, iy = y + 2;
    ctx.fillStyle = '#D49A00';
    ctx.fillRect(cx - 34 * k, iy + ih * 0.30, 24 * k, ih * 0.70);
    ctx.beginPath(); ctx.moveTo(cx - 6 * k, iy + ih); ctx.lineTo(cx - 6 * k, iy + ih * 0.05); ctx.lineTo(cx + 10 * k, iy); ctx.lineTo(cx + 34 * k, iy + ih * 0.22);
    ctx.lineTo(cx + 34 * k, iy + ih); ctx.closePath(); ctx.fill();
    for (var i = 1; i <= 4; i++) { var yy = iy + ih * (0.1 + i * 0.2); line(ctx, cx - 1 * k, yy, cx + 28 * k, yy, 1.2, PAPER); }
    for (var j = 1; j <= 3; j++) { var y2 = iy + ih * (0.38 + j * 0.2); line(ctx, cx - 30 * k, y2, cx - 14 * k, y2, 1.2, PAPER); }
    ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = col;
    var ty = iy + ih + 14 * k, L = nameLines(name), gap = 17 * k;
    L.forEach(function (t, n) { fit(ctx, t, w2, 18 * k, 7, 700, FONT_D); ctx.fillText(t, cx, ty + n * gap); });
    if (tag) { ctx.fillStyle = INK; fit(ctx, tag, w2, 8 * k, 5, 500, FONT_B, 'italic'); ctx.fillText(tag, cx, ty + (L.length - 1) * gap + 10 * k); }
  }

  function drawLogo(ctx, x, y, w2, h, col, img, name, tag) {
    if (img && img.width) {
      var s = Math.min(w2 / img.width, h / img.height), dw = img.width * s, dh = img.height * s;
      ctx.drawImage(img, x + (w2 - dw) / 2, y + (h - dh) / 2, dw, dh);
    } else drawLogoVector(ctx, x, y, w2, h, col, name, tag);
  }
  /* Logo dans un rectangle, avec réglage de taille et de position (o.logoAdj = { scale, dx, dy }) ; tout ce qui dépasse est coupé. */
  function drawLogoAdj(ctx, r, o) {
    var a = o.logoAdj || { scale: 1, dx: 0, dy: 0 }, cx = r.x + r.w / 2, cy = r.y + r.h / 2;
    ctx.save(); ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
    ctx.translate(cx + (a.dx || 0), cy + (a.dy || 0)); ctx.scale(a.scale || 1, a.scale || 1); ctx.translate(-cx, -cy);
    drawLogo(ctx, r.x, r.y, r.w, r.h, o.color, o.logo, (o.org && o.org.name) || '', (o.org && o.org.tag) || '');
    ctx.restore();
  }

  function drawSkyline(ctx, x, y, col, k) {
    var hs = [26, 40, 32, 48, 36, 28, 20], x0 = 0;
    k = k || 1;
    ctx.save(); ctx.translate(x, y); ctx.scale(k, k);
    ctx.strokeStyle = col; ctx.lineWidth = 1.3; ctx.fillStyle = PAPER;
    hs.forEach(function (h) {
      var w2 = 10; ctx.fillRect(x0, -h, w2, h); ctx.strokeRect(x0, -h, w2, h);
      for (var q = 6; q < h - 2; q += 6) line(ctx, x0 + 2.5, -q, x0 + 7.5, -q, 0.8, col);
      x0 += w2 + 2;
    });
    ctx.restore();
  }

  /* Vague de pied de page. k : échelle horizontale (1 = 225 unités de large), h : hauteur. */
  function drawSwoosh(ctx, xr, y1, col, accent, k, h) {
    k = k || 1; h = h || 34;
    ctx.fillStyle = accent; ctx.beginPath();
    ctx.moveTo(xr - 225 * k, y1); ctx.lineTo(xr - 168 * k, y1 - h - 4); ctx.lineTo(xr, y1 - h - 4); ctx.lineTo(xr, y1 - h + 1); ctx.lineTo(xr - 160 * k, y1 - h + 1); ctx.lineTo(xr - 214 * k, y1); ctx.closePath(); ctx.fill();
    ctx.fillStyle = col; ctx.beginPath();
    ctx.moveTo(xr - 210 * k, y1); ctx.lineTo(xr - 156 * k, y1 - h + 4); ctx.lineTo(xr, y1 - h + 4); ctx.lineTo(xr, y1); ctx.closePath(); ctx.fill();
  }

  /* Plan d'exemple vectoriel (aperçu avant l'import d'un PDF) */
  function drawDemo(ctx, r) {
    var VW = 100, VH = 70, s = Math.min(r.w * 0.86 / VW, r.h * 0.84 / VH);
    var ox = r.x + (r.w - VW * s) / 2, oy = r.y + (r.h - VH * s) / 2 + 2 * s;
    ctx.save(); ctx.translate(ox, oy); ctx.scale(s, s);
    var Wl = 1.1;
    function rect(x, y, w2, h, lw, fill) { if (fill) { ctx.fillStyle = fill; ctx.fillRect(x, y, w2, h); } if (lw) { ctx.lineWidth = lw; ctx.strokeStyle = INK; ctx.strokeRect(x, y, w2, h); } }
    rect(70, 36, 30, 34, 0, '#EEF3E8');
    rect(0, 0, 100, 70, 1.6);
    line(ctx, 38, 0, 38, 36, Wl); line(ctx, 70, 0, 70, 70, Wl); line(ctx, 0, 36, 70, 36, Wl);
    line(ctx, 34, 36, 34, 70, Wl); line(ctx, 58, 36, 58, 70, Wl); line(ctx, 70, 36, 100, 36, 0.5, '#555555');
    for (var i = 0; i < 9; i++) line(ctx, 35, 38 + i * 3.6, 57, 38 + i * 3.6, 0.4);
    ctx.fillStyle = '#DDE3EA'; ctx.fillRect(10, 5, 16, 6); ctx.fillRect(43, 12, 20, 8); ctx.fillRect(4, 50, 12, 8);
    ctx.strokeStyle = INK; ctx.lineWidth = 0.4; ctx.strokeRect(10, 5, 16, 6); ctx.strokeRect(43, 12, 20, 8); ctx.strokeRect(4, 50, 12, 8);
    ctx.fillStyle = INK; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    function lab(t, a, x, y) { ctx.font = '600 2.9px ' + FONT_B; ctx.fillText(t, x, y); ctx.font = '400 2.4px ' + FONT_B; ctx.fillText(a, x, y + 3.3); }
    lab('Salon', '28.00 m²', 19, 22); lab('Salle à manger', '20.00 m²', 54, 28); lab('Cuisine', '16.00 m²', 85, 20);
    lab('Chambre 1', '18.00 m²', 17, 62); lab('WC', '6.00 m²', 64, 56); lab('Terrasse', '12.00 m²', 85, 53);
    ctx.restore();
  }

  function drawWatermark(ctx, r, col, text) {
    ctx.save(); ctx.beginPath(); ctx.rect(r.x, r.y, r.w, r.h); ctx.clip();
    ctx.globalAlpha = 0.07; ctx.fillStyle = col; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = '700 26px ' + FONT_D;
    var tw = ctx.measureText(text).width, sx = tw + 110, sy = 130;
    ctx.translate(r.x + r.w / 2, r.y + r.h / 2); ctx.rotate(-Math.PI / 7);
    var L = Math.hypot(r.w, r.h);
    for (var y = -L / 2, k = 0; y < L / 2; y += sy, k++) for (var x = -L / 2 - (k % 2 ? sx / 2 : 0); x < L / 2; x += sx) ctx.fillText(text, x, y);
    ctx.restore();
  }

  function wrap2(s) {
    var words = String(s || '').split(' '), half = Math.ceil(words.length / 2);
    if (String(s || '').length > 18 && words.length > 1) return [words.slice(0, half).join(' '), words.slice(half).join(' ')];
    return [String(s || ''), ''];
  }

  /* Bloc « QR Code + légende ». Retourne l'ordonnée du bas du bloc. */
  function qrBlock(ctx, mat, label, cx, cw, y, qs, rects) {
    var pad = (cw - qs) / 2;
    drawQR(ctx, mat, cx + pad, y + 9, qs);
    if (rects) rects.push({ x: cx + pad, y: y + 9, size: qs });
    ctx.fillStyle = INK; ctx.textAlign = 'center';
    var l = wrap2(label), qy = y + 9 + qs + 12;
    fit(ctx, l[0], cw - 8, 9.5, 5.5, 500, FONT_B); ctx.fillText(l[0], cx + cw / 2, qy);
    if (l[1]) { fit(ctx, l[1], cw - 8, 9.5, 5.5, 500, FONT_B); ctx.fillText(l[1], cx + cw / 2, qy + 11); }
    return qy + (l[1] ? 17 : 8);
  }

  function pad2(n) { return ('0' + n).slice(-2); }
  function defaultRows(o) {
    var f = o.f;
    return [{ l: 'Référence :', v: f.ref, big: true }, { l: 'Maître d’ouvrage :', v: f.moa, big: true }, { l: 'Maître d’œuvre :', v: f.moe, big: true }, { l: 'Le concepteur :', v: f.con, big: true },
      { l: 'Échelle :', v: f.ech }, { l: 'Date :', v: f.date }, { l: 'Indice :', v: f.ind }, { l: 'Feuille :', v: pad2(o.page) + ' / ' + pad2(o.pages) }];
  }

  /* Cellule « libellé + valeur ». stack : libellé au-dessus (sinon sur la même ligne). */
  function cell(ctx, x, y, w2, h, r, stack) {
    var tx = x + 8, maxW = w2 - 14; ctx.textAlign = 'left'; ctx.fillStyle = INK;
    if (r.huge) {
      var hs = Math.min(9.5, h * 0.2); fit(ctx, r.l || '', maxW, hs, 5, 400, FONT_B); ctx.fillText(r.l || '', tx, y + hs + 5);
      fit(ctx, r.v || '', maxW, Math.min(40, h * 0.52), 8, 700, FONT_B); ctx.fillText(r.v || '', tx, y + h - 7); return;
    }
    if (stack) {
      var ls = Math.min(9.5, h * 0.30), vs = Math.min(14.5, h * 0.46);
      fit(ctx, r.l || '', maxW, ls, 5, 400, FONT_B); ctx.fillText(r.l || '', tx, y + h * 0.36);
      fit(ctx, r.v || '', maxW, vs, 6.5, 700, FONT_B); ctx.fillText(r.v || '', tx, y + h * 0.76);
    } else {
      ctx.font = '400 9.5px ' + FONT_B; var lw2 = ctx.measureText((r.l || '') + ' ').width;
      ctx.fillText(r.l || '', tx, y + h * 0.62);
      fit(ctx, r.v || '', maxW - lw2, Math.min(11, h * 0.65), 6.5, 700, FONT_B); ctx.fillText(r.v || '', tx + lw2, y + h * 0.62);
    }
  }

  /* Titre du projet + sous-titre dans un rectangle. */
  function titleBox(ctx, r, f, size, center) {
    var tt = (f.lblTitre ? f.lblTitre + ' ' : '') + String(f.titre || '').toUpperCase(), tx = center ? r.x + r.w / 2 : r.x + 8, mw = r.w - (center ? 24 : 16);
    ctx.textAlign = center ? 'center' : 'left'; ctx.fillStyle = INK;
    fit(ctx, tt, mw, size, 7, 700, FONT_D); ctx.fillText(tt, tx, r.y + r.h * 0.46);
    fit(ctx, f.sous || '', mw, size * 0.63, 5.5, 500, FONT_B, 'italic'); ctx.fillText(f.sous || '', tx, r.y + r.h * 0.46 + size * 0.9);
  }

  /* Vue 3D (ou toute image) dans un rectangle ; ph = { img, scale, dx, dy } ; clipR : zone de découpe. Retourne la largeur dessinée. */
  function drawPhoto(ctx, r, ph, cap, clipR) {
    var im = ph && ph.img; if (!im || !im.width) return 0;
    var sc = ph.scale || 1, capH = cap ? 9 : 0, s = Math.min(r.w / im.width, (r.h - capH) / im.height) * sc, dw = im.width * s, dh = im.height * s;
    var x = r.x + (ph.dx || 0), y = r.y + ((r.h - capH) - dh) / 2 + (ph.dy || 0), c = clipR || r;
    ctx.save(); ctx.beginPath(); ctx.rect(c.x, c.y, c.w, c.h); ctx.clip();
    ctx.drawImage(im, x, y, dw, dh);
    ctx.strokeStyle = INK; ctx.lineWidth = 0.8; ctx.strokeRect(x, y, dw, dh);
    if (cap) { ctx.fillStyle = INK; ctx.textAlign = 'left'; fit(ctx, cap, Math.max(dw, 40), 7, 5, 500, FONT_B, 'italic'); ctx.fillText(cap, x, y + dh + 8); }
    ctx.restore(); return dw;
  }

  /* Tableau des indices (style architecte) : en-tête + ligne courante + ligne libre. */
  function revTable(ctx, x, y, w2, h, f) {
    var cw = [0.2, 0.34, 0.46], rh = h / 3, vals = [['Ind.', 'Date', 'Objet'], [f.ind || '', f.date || '', f.obj || ''], ['', '', '']], k, i;
    var xs = [x, x + w2 * cw[0], x + w2 * (cw[0] + cw[1])];
    for (i = 0; i < 3; i++) {
      for (k = 0; k < 3; k++) {
        var cwid = w2 * cw[k]; ctx.fillStyle = INK; ctx.textAlign = 'left';
        fit(ctx, vals[i][k], cwid - 8, i === 0 ? 8 : 9.5, 5, i === 0 ? 400 : 700, FONT_B); ctx.fillText(vals[i][k], xs[k] + 5, y + i * rh + rh * 0.68);
      }
      if (i < 2) line(ctx, x, y + (i + 1) * rh, x + w2, y + (i + 1) * rh, 0.6);
    }
    line(ctx, xs[1], y, xs[1], y + h, 0.6); line(ctx, xs[2], y, xs[2], y + h, 0.6);
  }

  /* Répartit des cellules dans une grille de ncols colonnes. */
  function pack(cells, ncols) {
    var lines = [], cur = [], used = 0;
    cells.forEach(function (c) {
      var sp = Math.min(c.span || 1, ncols);
      if (used + sp > ncols) { lines.push(cur); cur = []; used = 0; }
      cur.push({ c: c, sp: sp, col: used }); used += sp;
      if (used >= ncols) { lines.push(cur); cur = []; used = 0; }
    });
    if (cur.length) lines.push(cur);
    lines.forEach(function (ln) { var s = ln.reduce(function (a, it) { return a + it.sp; }, 0); ln[ln.length - 1].sp += ncols - s; });
    return lines;
  }
  function drawGrid(ctx, R, cells, ncols, f) {
    var lines = pack(cells, ncols), lw = function (ln) { return ln.reduce(function (a, it) { return Math.max(a, it.c.hw || 1); }, 0); };
    var tot = lines.reduce(function (a, ln) { return a + lw(ln); }, 0) || 1, y = R.y, cwid = R.w / ncols;
    lines.forEach(function (ln, li) {
      var h = R.h * lw(ln) / tot;
      ln.forEach(function (it) {
        var x = R.x + it.col * cwid, w2 = it.sp * cwid;
        if (it.c.title) titleBox(ctx, { x: x, y: y, w: w2, h: h }, f, Math.min(22, h * 0.42), false); else cell(ctx, x, y, w2, h, it.c.r, true);
        if (it.col > 0) line(ctx, x, y, x, y + h, 0.6);
      });
      y += h; if (li < lines.length - 1) line(ctx, R.x, y, R.x + R.w, y, 0.8);
    });
  }

  /* Colonne verticale (pos right / left) : logo, titre, vue 3D, QR Codes, tableau des indices puis lignes d'information. */
  function infoV(ctx, L, o, rows) {
    var R = L.info, st = L.st, f = o.f, cw = R.w, cx = R.x, top = R.y, bottom = R.y + R.h, rects = [], y = top;
    var ex = st.pos === 'left' ? cx + cw : cx; line(ctx, ex, top, ex, bottom, 1.6);
    var lh = st.logoIn === 'info' ? 84 : 0, th = st.titleIn !== 'head' ? 66 : 0, rvh = st.revTable ? 56 : 0, ph = L.photoInfo ? 92 : 0;
    var units = rows.reduce(function (a, r) { return a + (r.huge ? 2.6 : r.big ? 2 : 1); }, 0);
    var side = !!st.qrRow && !!o.qr2, nq = o.qr2 ? 2 : 1, avail = R.h - (lh + th + rvh + ph) - units * 17, qs;
    if (side) qs = Math.max(40, Math.min(cw / 2 - 12, avail - 35)); else qs = Math.max(56, Math.min(cw - 22, avail / nq - 35));
    if (lh) { drawLogoAdj(ctx, { x: cx + 8, y: y + 5, w: cw - 16, h: lh - 10 }, o); y += lh; line(ctx, cx, y, cx + cw, y, 1.2); }
    if (th) { titleBox(ctx, { x: cx, y: y, w: cw, h: th }, f, Math.min(18, th * 0.3), false); y += th; line(ctx, cx, y, cx + cw, y, 1.2); }
    if (ph) { drawPhoto(ctx, { x: cx + 8, y: y + 4, w: cw - 16, h: ph - 8 }, o.photo, f.photoCap, { x: cx, y: y, w: cw, h: ph }); y += ph; line(ctx, cx, y, cx + cw, y, 1.2); }
    if (side) {
      var half = cw / 2, y0 = y, b1 = qrBlock(ctx, o.qr, f.qrLbl || '', cx, half, y, qs, rects), b2 = qrBlock(ctx, o.qr2, f.qr2Lbl || '', cx + half, half, y, qs, rects);
      y = Math.max(b1, b2); line(ctx, cx + half, y0, cx + half, y, 0.9);
    } else {
      y = qrBlock(ctx, o.qr, f.qrLbl || '', cx, cw, y, qs, rects);
      if (o.qr2) { line(ctx, cx, y, cx + cw, y, 0.9); y = qrBlock(ctx, o.qr2, f.qr2Lbl || '', cx, cw, y, qs, rects); }
    }
    L.qrRects = rects;
    line(ctx, cx, y, cx + cw, y, 1.4);
    if (rvh) { revTable(ctx, cx, y, cw, rvh, f); y += rvh; line(ctx, cx, y, cx + cw, y, 1.4); }
    if (!rows.length) return;
    var uh = Math.max(0, (bottom - y) / units);
    rows.forEach(function (r, i) {
      var h = uh * (r.huge ? 2.6 : r.big ? 2 : 1); cell(ctx, cx, y, cw, h, r, r.big || r.huge); y += h;
      if (i < rows.length - 1) line(ctx, cx, y, cx + cw, y, 0.9);
    });
  }

  /* Bandeau ou bloc horizontal (pos bottom) : logo | vue 3D | titre | grille | QR Codes. */
  function infoH(ctx, L, o, rows) {
    var R = L.info, st = L.st, f = o.f, x = R.x, y = R.y, w2 = R.w, h = R.h, nq = o.qr2 ? 2 : 1, rects = [];
    line(ctx, x, y, x + w2, y, 1.6); if (x > L.x0 + 1) line(ctx, x, y, x, y + h, 1.6);
    var qs = Math.max(36, h - 38), qzw = Math.max(qs + 10, 96);
    var lw = st.logoIn === 'info' ? Math.min(110, Math.max(80, h * 1.0)) : 0, phw = L.photoInfo ? Math.min(Math.max(80, h * 1.2), 140) : 0;
    var tw = st.titleIn === 'zone' ? Math.min(240, Math.max(150, w2 * 0.26)) : 0, titleInGrid = st.titleIn !== 'head' && !tw;
    var gw = w2 - lw - phw - tw - nq * qzw;
    if (tw && gw < 190) { tw = 0; titleInGrid = true; gw = w2 - lw - phw - nq * qzw; }
    var xs = x;
    if (lw) { drawLogoAdj(ctx, { x: xs + 6, y: y + 5, w: lw - 12, h: h - 10 }, o); xs += lw; line(ctx, xs, y, xs, y + h, 0.9); }
    if (phw) { drawPhoto(ctx, { x: xs + 6, y: y + 5, w: phw - 12, h: h - 10 }, o.photo, f.photoCap, { x: xs, y: y, w: phw, h: h }); xs += phw; line(ctx, xs, y, xs, y + h, 0.9); }
    if (tw) { titleBox(ctx, { x: xs, y: y, w: tw, h: h }, f, Math.min(20, h * 0.28), false); xs += tw; line(ctx, xs, y, xs, y + h, 0.9); }
    var ncols = Math.max(1, Math.min(st.cols || 2, Math.floor(gw / 96))), cells = [];
    if (titleInGrid) cells.push({ title: true, span: ncols, hw: 1.5 });
    rows.forEach(function (r) { cells.push({ r: r, span: 1, hw: r.huge ? 1.3 : 1 }); });
    drawGrid(ctx, { x: xs, y: y, w: gw, h: h }, cells, ncols, f);
    xs += gw; line(ctx, xs, y, xs, y + h, 0.9);
    qrBlock(ctx, o.qr, f.qrLbl || '', xs, qzw, y, qs, rects); xs += qzw;
    if (o.qr2) { line(ctx, xs, y, xs, y + h, 0.9); qrBlock(ctx, o.qr2, f.qr2Lbl || '', xs, qzw, y, qs, rects); }
    L.qrRects = rects;
  }

  /* En-tête : logo (selon le style) + titre du projet + sous-titre. */
  function drawHead(ctx, L, o) {
    var hd = L.head, st = L.st, f = o.f, lw = st.logoIn === 'head' ? (st.key === 'cmp' ? 130 : 168) : 0, col = o.color;
    if (lw) { drawLogoAdj(ctx, { x: hd.x + 8, y: hd.y + 5, w: lw - 16, h: hd.h - 10 }, o); line(ctx, hd.x + lw, hd.y, hd.x + lw, hd.y + hd.h, 1.2); }
    var size = Math.max(12, Math.min(28, hd.h * 0.34));
    titleBox(ctx, { x: hd.x + lw, y: hd.y, w: hd.w - lw, h: hd.h }, f, size, true);
    line(ctx, hd.x, hd.y + hd.h, hd.x + hd.w, hd.y + hd.h, 1.2);
  }

  /* Pied de page : vue 3D ou immeubles, slogan, vague. */
  function drawFoot(ctx, L, o) {
    var ft = L.foot, st = L.st, f = o.f, col = o.color, acc = o.accent || '#D49A00', hasPh = !!(o.photo && o.photo.img && o.photo.img.width), sw = 0, reserve = 0;
    if (st.deco === 'swoosh' || st.deco === 'both') { sw = Math.min(225, ft.w * 0.42); drawSwoosh(ctx, ft.x + ft.w, ft.y + ft.h, col, acc, sw / 225, st.swH || 34); }
    if (hasPh) reserve = drawPhoto(ctx, { x: ft.x + 6, y: ft.y + 4, w: ft.w * 0.42, h: ft.h - 8 }, o.photo, f.photoCap, ft) + 16;
    else if (st.deco === 'both') { drawSkyline(ctx, ft.x + 16, ft.y + ft.h - 5, col, Math.min(1, (ft.h - 8) / 50)); reserve = 100; }
    var sl = f.slogan || '';
    if (sl) {
      var left = ft.x + reserve, right = ft.x + ft.w - sw - 8, mw = Math.max(60, Math.min(260, right - left - 10));
      ctx.fillStyle = col; ctx.textAlign = 'center'; fit(ctx, sl, mw, Math.min(20, Math.max(11, ft.h * 0.34)), 8, 500, FONT_B, 'italic');
      ctx.fillText(sl, (left + right) / 2, ft.y + ft.h / 2 + 6);
    }
    line(ctx, ft.x, ft.y, ft.x + ft.w, ft.y, 1.2);
  }

  /* o : { W,H,ppu, f(champs), rows[{l,v,big,huge}], qr, qr2|null, color, accent, st (style résolu) | model, wm, wmText, logo, logoAdj, photo:{img,scale,dx,dy}, org:{name,tag},
   *       plan:{img,zoom,dx,dy}|null, page, pages }
   * img : tout objet ayant width/height qu'accepte ctx.drawImage (canvas pour l'aperçu, objet PDF pour l'export). */
  function drawSheet(ctx, o) {
    var W = o.W, H = o.H, st = o.st || resolve(o.model), hasPh = !!(o.photo && o.photo.img && o.photo.img.width), L = layout(W, H, st, hasPh), col = o.color;
    ctx.setTransform(o.ppu, 0, 0, o.ppu, 0, 0);
    ctx.fillStyle = PAPER; ctx.fillRect(0, 0, W, H);
    ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';

    /* Plan */
    ctx.save(); ctx.beginPath(); ctx.rect(L.plan.x + 2, L.plan.y + 2, L.plan.w - 4, L.plan.h - 4); ctx.clip();
    if (o.plan && o.plan.img) {
      var im = o.plan.img, iw = im.width, ih = im.height, pad0 = 14;
      var bs = Math.min((L.plan.w - pad0 * 2) / iw, (L.plan.h - pad0 * 2) / ih) * o.plan.zoom;
      var dw = iw * bs, dh = ih * bs;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(im, L.plan.x + (L.plan.w - dw) / 2 + o.plan.dx, L.plan.y + (L.plan.h - dh) / 2 + o.plan.dy, dw, dh);
    } else if (!o.plan) drawDemo(ctx, L.plan);
    ctx.restore();
    if (o.wm) drawWatermark(ctx, L.plan, col, o.wmText || 'EXCELLENCIA BUILDING');

    if (L.foot) drawFoot(ctx, L, o);
    if (L.head) drawHead(ctx, L, o);
    var rows = o.rows || defaultRows(o);
    if (st.pos === 'bottom') infoH(ctx, L, o, rows); else infoV(ctx, L, o, rows);

    /* Cadre */
    ctx.strokeStyle = INK; ctx.lineWidth = 2.6; ctx.strokeRect(L.x0, L.y0, L.x1 - L.x0, L.y1 - L.y0);
    ctx.lineWidth = 0.8; ctx.strokeStyle = col; ctx.strokeRect(L.x0 - 5, L.y0 - 5, L.x1 - L.x0 + 10, L.y1 - L.y0 + 10);
    return L;
  }

  w.EXBSHEET = { FORMATS: FORMATS, FORMAT_GROUPS: FORMAT_GROUPS, FORMAT_LABELS: FORMAT_LABELS, ISO_A: ISO_A, STYLES: STYLES, BRANDS: BRANDS, brandOf: brandOf, resolve: resolve,
    FONT_B: FONT_B, FONT_D: FONT_D, sheetUnits: sheetUnits, nearestFormat: nearestFormat, layout: layout, drawSheet: drawSheet, defaultRows: defaultRows };
})(window);
