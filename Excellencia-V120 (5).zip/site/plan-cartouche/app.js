/* Excellencia Building — Plan Editor : interface, lecture du PDF, QR Codes, export, envoi en ligne, registre.
 * Tourne dans un cadre de la page principale (même origine) : reprend l'identité de l'entreprise (EXBId / EXB_BRAND), les projets
 * (exb_projects), le registre de vérification (EXBVerif) et la connexion serveur (exbSb). Fonctionne aussi seul (sans ces éléments). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var E = window.EXBSHEET, MAX_BYTES = 50 * 1024 * 1024, RKEY = 'exb_plan_cartouche_registre', SKEY = 'exb_plan_cartouche_seq';
  var H = null; try { if (window.parent && window.parent !== window && window.parent.document) H = window.parent; } catch (e) { H = null; }
  var S = { file: null, bytes: null, pdf: null, pages: [], cur: 0, cache: {}, adj: [], processed: false, exported: false, logo: null, orgLogo: null, color: '#0B2A5B', accent: '#D49A00', fontsReady: true, id: null, busy: false,
    rows: null, tune: { size: null, bw: null, hh: null, fh: null }, free: { pos: 'right', head: true, foot: false, cols: 2, logoIn: 'head', deco: 'none' }, logoAdj: { scale: 1, dx: 0, dy: 0 }, photo: null, phAdj: { scale: 1, dx: 0, dy: 0 } };
  var pdfjs = null;

  /* ---------- utilitaires ---------- */
  var toastTimer;
  function toast(msg, ms) { var t = $('toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastTimer); if (ms !== 0) toastTimer = setTimeout(function () { t.hidden = true; }, ms || 3400); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function sget(k) { try { return (H && H.exbStorage && H.exbStorage.getItem(k)) || localStorage.getItem(k); } catch (e) { return null; } }
  function sset(k, v) { try { if (H && H.exbStorage) H.exbStorage.setItem(k, v); else localStorage.setItem(k, v); } catch (e) { try { localStorage.setItem(k, v); } catch (e2) {} } }
  function jget(k, d) { try { var v = JSON.parse(sget(k)); return v == null ? d : v; } catch (e) { return d; } }
  function fmtSize(b) { return b > 1048576 ? (b / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(b / 1024)) + ' Ko'; }
  function frDate(v) { var p = (v || '').split('-'); return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : v; }
  function today() { var d = new Date(), z = function (n) { return ('0' + n).slice(-2); }; return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); }
  function slug(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, ''); }
  function raf(fn) { var q = false; return function () { if (q) return; q = true; requestAnimationFrame(function () { q = false; fn(); }); }; }
  function rnd(n) { var a = new Uint8Array(n), s = ''; (window.crypto || H.crypto).getRandomValues(a); for (var i = 0; i < n; i++) s += (a[i] % 36).toString(36); return s; }
  async function sha256hex(buf) { var d = await crypto.subtle.digest('SHA-256', buf); return Array.prototype.map.call(new Uint8Array(d), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }

  /* ---------- identité de l'entreprise ---------- */
  function identity() {
    var I = {}, B = {}; try { I = (H && H.EXBId && H.EXBId.get()) || {}; } catch (e) {} try { B = (H && H.EXB_BRAND) || {}; } catch (e) {}
    var nm0 = I.name || B.name || '', isEB = !nm0 || /excellencia\s+building/i.test(nm0), hasLogo = !!(I.logo || B.logo);
    return { eb: isEB && !hasLogo, name: nm0 || 'Excellencia Building', tag: I.tagline || (isEB ? 'L’excellence au cœur de vos constructions' : ''), logo: I.logo || B.logo || (isEB ? new URL('../assets/carte/logo-officiel.jpg', location.href).href : ''), dg: I.dg || '', primary: B.primary || '#0B2A5B', accent: B.accent || '#D49A00', city: I.city || '' };
  }
  function loadImg(src) {
    return new Promise(function (ok) {
      if (!src) return ok(null); var im = new Image(); im.onload = function () { ok(im); }; im.onerror = function () { ok(null); };
      try { if (!/^(data:|blob:|https?:)/i.test(src) && H) src = new URL(src, H.location.href).href; } catch (e) {}
      im.src = src;
    });
  }
  function colors() {
    var I = identity(); return [{ name: 'Bleu entreprise', hex: I.primary }, { name: 'Or', hex: I.accent }, { name: 'Ardoise', hex: '#5B6B80' }, { name: 'Vert forêt', hex: '#1F6B4A' }, { name: 'Noir', hex: '#1B1B1F' }];
  }

  /* ---------- champs ---------- */
  function fields() {
    return { titre: $('iTitre').value, sous: $('iSous').value, ref: $('iRef').value.trim() || ('EXB-' + new Date().getFullYear() + '-###'), ech: $('iEch').value, moa: $('iMoa').value, moe: $('iMoe').value, con: $('iCon').value,
      date: frDate($('iDate').value), ind: $('iInd').value, qrLbl: $('qrLbl').value, qr2Lbl: $('qr2Lbl').value, slogan: $('slogan').value,
      lblTitre: $('lblTitre').value.trim(), obj: $('iObj').value, photoCap: $('phCap').value.trim() };
  }
  function mode() { return document.querySelector('input[name="mode"]:checked').value; }
  function nextRef() { var y = new Date().getFullYear(), n = (+sget(SKEY + '.' + y) || 0) + 1; return 'EXB-' + y + '-' + ('00' + n).slice(-3); }
  function bumpRef(ref) { var m = /^EXB-(\d{4})-(\d+)$/.exec(ref || ''); if (m) { var k = SKEY + '.' + m[1]; if (+m[2] > (+sget(k) || 0)) sset(k, String(+m[2])); } }
  function nextInd(ref) {
    var used = jget(RKEY, []).filter(function (r) { return r.no === ref; }).map(function (r) { return r.ind; });
    if (!used.length) return 'A'; var c = 'A'; while (used.indexOf(c) >= 0 && c < 'Z') c = String.fromCharCode(c.charCodeAt(0) + 1); return c;
  }
  /* aperçu : QR provisoires (le vrai code est enregistré à l'export) */
  function qrPreview() {
    var f = fields();
    return { v: window.EXBQR.matrix('https://verification.exemple/plan?ref=' + encodeURIComponent(f.ref || '') + '&ind=' + encodeURIComponent(f.ind || '')),
      d: window.EXBQR.matrix('https://telechargement.exemple/plan?t=' + encodeURIComponent((f.ref || '') + '-' + (f.ind || ''))) };
  }
  var qrPrevCache = { k: '', q: null };
  function qrP() { var f = fields(), k = f.ref + '|' + f.ind; if (qrPrevCache.k !== k) qrPrevCache = { k: k, q: qrPreview() }; return qrPrevCache.q; }

  /* ---------- géométrie ---------- */
  function detected() { var p = S.pages[0]; return p ? E.nearestFormat(p.wmm, p.hmm) : null; }
  function fmtDims(key) {
    if (key === 'custom') { var a = Math.max(50, Math.min(3000, +$('cW').value || 420)), b = Math.max(50, Math.min(3000, +$('cH').value || 297)); return [Math.min(a, b), Math.max(a, b)]; }
    return E.FORMATS[key] || E.FORMATS.A1;
  }
  function geom(i) {
    var p = S.pages[i], key = $('fmt').value;
    if (key === 'detect') { var d = detected(); key = d ? d.key : 'A1'; }
    var o = $('ori').value, land = o === 'land' ? true : o === 'port' ? false : (p ? p.w >= p.h : true);
    var f = fmtDims(key), u = E.sheetUnits(land, f[1] / f[0]);
    return { key: key === 'custom' ? 'Perso' : key, land: land, W: u.W, H: u.H, wmm: land ? f[1] : f[0], hmm: land ? f[0] : f[1] };
  }
  function styleNow() { return E.resolve($('model').value, S.tune, S.free, !!S.photo); }
  function pad2(n) { return ('0' + n).slice(-2); }
  /* lignes du cartouche (libellés, ordre, lignes ajoutées) */
  function buildRows(i, st, f) {
    var out = [];
    S.rows.forEach(function (r) {
      if (!r.on || (st.hideRows && st.hideRows.indexOf(r.k) >= 0)) return;
      var v = r.custom ? r.v : r.k === 'fe' ? pad2(i + 1) + ' / ' + pad2(Math.max(1, S.pages.length)) : f[r.k];
      out.push({ l: r.l, v: v || '', big: !!r.big, huge: !!(st.bigSheet && r.k === 'fe') });
    });
    return out;
  }
  function baseOpts(i, qrs) {
    var I = identity(), a = S.adj[i] || { zoom: 1, dx: 0, dy: 0 }, auto = mode() === 'auto', st = styleNow(), f = fields();
    return { f: f, st: st, rows: buildRows(i, st, f), qr: qrs.v, qr2: $('qr2on').checked ? qrs.d : null, color: S.color, accent: S.accent, model: $('model').value, wm: $('wm').checked, wmText: String($('wmTxt').value || I.name).toUpperCase(),
      logo: S.logo || S.orgLogo, logoAdj: S.logoAdj, photo: S.photo ? { img: S.photo, scale: S.phAdj.scale, dx: S.phAdj.dx, dy: S.phAdj.dy } : null,
      org: { name: I.name, tag: I.tag }, page: i + 1, pages: Math.max(1, S.pages.length),
      _adj: { zoom: auto ? 1 : a.zoom, dx: auto ? 0 : a.dx, dy: auto ? 0 : a.dy } };
  }

  /* ---------- lecture du PDF ---------- */
  async function lib() {
    if (pdfjs) return pdfjs;
    var m = await import('../pdfjs/pdf.min.mjs'); m.GlobalWorkerOptions.workerSrc = '../pdfjs/pdf.worker.min.mjs'; pdfjs = m; return m;
  }
  async function renderPage(i, maxSide) {
    var page = await S.pdf.getPage(i + 1), v1 = page.getViewport({ scale: 1 }), vp = page.getViewport({ scale: maxSide / Math.max(v1.width, v1.height) });
    var c = document.createElement('canvas'); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
    var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: g, viewport: vp }).promise; return c;
  }
  async function ensurePreview(i) {
    if (!S.pdf || S.cache[i]) return;
    try { S.cache[i] = await renderPage(i, 2400); } catch (e) { $('fMsg').className = 'msg'; $('fMsg').textContent = 'Impossible d’afficher cette page du PDF.'; }
    draw();
  }
  async function openFile(file) {
    var msg = $('fMsg'); msg.className = 'msg'; msg.textContent = ''; if (!file) return;
    if (!/\.pdf$/i.test(file.name) && file.type !== 'application/pdf') { msg.textContent = 'Ce fichier n’est pas un PDF.'; return; }
    if (file.size > MAX_BYTES) { msg.textContent = 'Fichier trop volumineux : la taille maximale est de 50 Mo.'; return; }
    msg.className = 'msg info'; msg.textContent = 'Lecture du plan…';
    try {
      var L = await lib(), buf = await file.arrayBuffer(), bytes = new Uint8Array(buf);
      var pdf = await L.getDocument({ data: bytes.slice(0) }).promise, pages = [];
      for (var i = 1; i <= pdf.numPages; i++) { var p = await pdf.getPage(i), v = p.getViewport({ scale: 1 }); pages.push({ w: v.width, h: v.height, wmm: v.width * 25.4 / 72, hmm: v.height * 25.4 / 72 }); }
      S.file = file; S.bytes = bytes; S.pdf = pdf; S.pages = pages; S.cur = 0; S.cache = {}; S.adj = pages.map(function () { return { zoom: 1, dx: 0, dy: 0 }; });
      S.processed = false; S.exported = false;
      $('fName').textContent = file.name; $('fSize').textContent = fmtSize(file.size); $('fileRow').hidden = false; msg.textContent = ''; $('goMsg').textContent = '';
      if (!$('iTitre').value) $('iTitre').value = file.name.replace(/\.pdf$/i, '').replace(/[_-]+/g, ' ');
      syncUI(); ensurePreview(0);
    } catch (e) { msg.className = 'msg'; msg.textContent = 'Impossible de lire ce PDF. Vérifiez qu’il n’est pas protégé par un mot de passe.'; }
  }
  function clearFile() {
    if (S.pdf) { try { S.pdf.destroy(); } catch (e) {} }
    S.file = null; S.bytes = null; S.pdf = null; S.pages = []; S.cur = 0; S.cache = {}; S.adj = []; S.processed = false; S.exported = false;
    $('fileRow').hidden = true; $('fileIn').value = ''; $('fMsg').textContent = ''; $('goMsg').textContent = ''; syncUI();
  }

  /* ---------- aperçu ---------- */
  var drawNow = function () {
    var st = $('stage'), cv = $('cv'), g = geom(S.cur), aw = Math.max(200, st.clientWidth - 36), ah = Math.max(200, st.clientHeight - 36);
    var base = Math.min(aw / g.W, ah / g.H), z = parseFloat($('zoom').value) || 1, cssW = g.W * base * z, cssH = g.H * base * z, dpr = Math.min(window.devicePixelRatio || 1, 2);
    var pw = Math.min(cssW * dpr, 3200), ppu = pw / g.W;
    cv.width = Math.round(g.W * ppu); cv.height = Math.round(g.H * ppu); cv.style.width = cssW + 'px'; cv.style.height = cssH + 'px'; cv.dataset.upu = String(g.W / cssW);
    var o = baseOpts(S.cur, qrP()), a = o._adj; o.W = g.W; o.H = g.H; o.ppu = cv.width / g.W;
    o.plan = S.pdf ? { img: S.cache[S.cur] || null, zoom: a.zoom, dx: a.dx, dy: a.dy } : null;
    E.drawSheet(cv.getContext('2d'), o);
    cv.classList.toggle('pan', !!S.pdf && mode() !== 'auto'); updateChips();
  };
  var draw = raf(function () { drawNow(); });

  /* ---------- état de l'interface ---------- */
  function setChip(id, ok, a, b) { var c = $(id); c.classList.toggle('ok', ok); $(id + 'a').textContent = a; $(id + 'b').textContent = b; }
  function updateChips() {
    var n = S.pages.length, d = detected(), g = geom(S.cur), qr2 = $('qr2on').checked;
    var fm = d ? (d.exact ? '' : '≈ ') + d.key + ' (' + E.FORMATS[d.key][0] + ' × ' + E.FORMATS[d.key][1] + ' mm)' : '';
    if (!S.pdf) { setChip('c1', false, 'Plan non analysé', 'Importez un PDF'); setChip('c2', false, 'Format de la feuille', g.key + ' (' + g.wmm + ' × ' + g.hmm + ' mm)'); setChip('c3', false, 'QR Codes', qr2 ? 'Vérification + téléchargement' : 'Vérification'); setChip('c4', false, 'Exportation', 'Importez un plan'); return; }
    if (!S.processed) { setChip('c1', false, 'Plan chargé', n + ' page' + (n > 1 ? 's' : '') + ' • lancez le traitement'); setChip('c2', false, 'Format détecté', fm); setChip('c3', false, 'QR Codes', 'En attente'); setChip('c4', false, 'Exportation', 'Lancez le traitement'); return; }
    setChip('c1', true, 'Plan analysé', 'avec succès • ' + n + ' page' + (n > 1 ? 's' : '')); setChip('c2', true, 'Format détecté', fm);
    setChip('c3', true, qr2 ? 'QR Codes générés' : 'QR Code généré', qr2 ? 'vérification + téléchargement' : 'pour le projet'); setChip('c4', true, 'Prêt pour l’exportation', 'Feuille ' + g.key + ' • ' + (g.land ? 'paysage' : 'portrait'));
  }
  function updateSteps() {
    var cur = !S.pdf ? 1 : S.exported ? 5 : S.processed ? 3 : 2;
    document.querySelectorAll('#steps li').forEach(function (li) { var n = +li.dataset.s; li.className = n < cur ? 'done' : n === cur ? 'on' : ''; li.querySelector('.n').textContent = n < cur ? '✓' : String(n); });
  }
  function syncUI() {
    var has = !!S.pdf, multi = S.pages.length > 1, m = mode();
    $('banner').hidden = has; $('pgNav').hidden = !multi; $('pgTxt').textContent = (S.cur + 1) + ' / ' + S.pages.length; $('pPrev').disabled = S.cur === 0; $('pNext').disabled = S.cur >= S.pages.length - 1;
    $('adj').hidden = !has || m === 'auto'; $('customBox').hidden = $('fmt').value !== 'custom'; $('wmBox').hidden = !$('wm').checked;
    $('modeHelp').textContent = m === 'auto' ? 'Le plan est placé et dimensionné automatiquement dans la feuille.' : m === 'manual' ? 'Vous placez et dimensionnez le plan vous-même dans la feuille.' : 'Le plan est ajusté automatiquement. Vous pouvez ensuite le déplacer et l’agrandir.';
    var a = S.adj[S.cur] || { zoom: 1 }; $('pz').value = Math.round(a.zoom * 100); $('pzv').textContent = Math.round(a.zoom * 100) + ' %';
    $('qr2Lbl').parentNode.hidden = !$('qr2on').checked; $('logoRst').hidden = !S.logo; updateSteps(); draw();
  }
  function process() {
    if (!S.pdf) { $('goMsg').className = 'msg'; $('goMsg').textContent = 'Importez d’abord un fichier PDF.'; $('fileIn').focus(); return false; }
    $('goMsg').textContent = ''; S.processed = true; syncUI();
    if (window.matchMedia && matchMedia('(max-width:920px)').matches) $('pv').scrollIntoView({ behavior: 'smooth', block: 'start' });
    return true;
  }

  /* ---------- enregistrement du fichier (Android / Windows / navigateur) ---------- */
  async function saveFile(name, blob) {
    try {
      if (H && H.EXBNativeDownload && H.EXBNativeDownload.save) { await H.EXBNativeDownload.save(blob, name); return true; }
      if (H && typeof H.saveFile === 'function') { return !!(await H.saveFile(name, blob)); }
    } catch (e) {}
    var u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = name; a.style.display = 'none'; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(u); a.remove(); }, 4000); return true;
  }

  /* ---------- portail clients V129 (un seul chemin) : plan_public_publier + espace « exb-plans-publics » + Plans & fichiers CAO ---------- */
  var PBK = 'exb-plans-publics', MAPK = 'exb_pub_map';
  function org() { try { return (H && H.EXBDB && H.EXBDB.org && H.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function canPublish() { return !!(H && H.exbSb && H.exbSb.isIn && H.exbSb.isIn() && org() && navigator.onLine && H.EXBPLN && H.EXBPLN.addFrom && H.EXBS); }
  function rpc(n, b) { return H.exbSb.api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  function tok32() { var a = new Uint8Array(16); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function portalLink(ref, code) { var V = H && H.EXBVerif, base = V && V.vbase ? V.vbase() : location.origin + '/'; return base + 'plan?ref=' + encodeURIComponent(ref) + '&k=' + encodeURIComponent(code); }
  function sizeTxt(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function jpegOf(cv) { var u = cv.toDataURL('image/jpeg', 0.72); if (u.length > 450000) { var t = document.createElement('canvas'); t.width = Math.round(cv.width * 0.65); t.height = Math.round(cv.height * 0.65); t.getContext('2d').drawImage(cv, 0, 0, t.width, t.height); u = t.toDataURL('image/jpeg', 0.6); } return u.length > 480000 ? null : u; }
  /* aperçu de la feuille finie (avec les vrais QR) pour la page du portail */
  async function sheetThumb(qrs, ref) {
    try {
      var g = geom(0), c = document.createElement('canvas'), ppu = 1000 / g.W; c.width = Math.round(g.W * ppu); c.height = Math.round(g.H * ppu);
      var o = baseOpts(0, qrs), a = o._adj; o.W = g.W; o.H = g.H; o.ppu = ppu; o.page = 1; o.f = Object.assign({}, o.f, { ref: ref }); o.rows = buildRows(0, o.st, o.f);
      if (!S.cache[0]) S.cache[0] = await renderPage(0, 2400);
      o.plan = { img: S.cache[0], zoom: a.zoom, dx: a.dx, dy: a.dy }; E.drawSheet(c.getContext('2d'), o); return jpegOf(c);
    } catch (e) { return null; }
  }
  function pubCall(o, token, f0, planId, ref, size, apercu) {
    return rpc('plan_public_publier', { p_org: o, p_plan_id: planId || '', p_ref_plan: f0.ref || '', p_titre: f0.titre, p_type: 'Plan — ' + f0.titre, p_moe: f0.moe, p_mo: f0.moa, p_concepteur: f0.con, p_echelle: f0.ech, p_indice: 'Indice ' + f0.ind,
      p_apercu: apercu || null, p_docs: [{ nom: 'Plan — ' + (f0.ref || f0.titre) + ' (indice ' + f0.ind + ')', fichier: o + '/' + token + '/plan.pdf', format: 'PDF', taille: size ? sizeTxt(size) : '', kind: 'plan' }], p_token: token, p_ref: ref || null });
  }
  /* attend que « Plans & fichiers CAO » ait enregistré le fichier envoyé par addFrom */
  async function waitPlanRecord(name, pid) {
    for (var i = 0; i < 40; i++) {
      var rec = (H.EXBS.get('exb_plan_files') || []).filter(function (x) { return x.name === name && String(x.project) === String(pid); }).pop();
      if (rec) return rec; await new Promise(function (r) { setTimeout(r, 250); });
    }
    return null;
  }

  /* ---------- export ---------- */
  async function exportPdf() {
    var f0 = fields(), wantDl = $('qr2on').checked, V = H && H.EXBVerif, G = geom(0), pid = $('iProj').value, o = org();
    if (wantDl && !canPublish()) {
      if (!window.confirm('Pas de connexion au serveur (☁️) : le QR de téléchargement ne peut pas être créé.\n\nExporter quand même, sans QR de téléchargement ?')) return;
      wantDl = false;
    }
    if (wantDl && !pid) { toast('Choisissez le projet (liste « Projet enregistré dans le logiciel ») : le plan est publié aux clients et rangé dans Plans & fichiers CAO.', 7000); var dd = $('iProj').closest('details'); if (dd) dd.open = true; $('iProj').focus(); return; }
    var busy = $('exp'); busy.disabled = true; S.busy = true; var reserved = null, done = false;
    try {
      toast('Préparation du PDF…', 0);
      var srcHash = await sha256hex(S.bytes), token = tok32(), nonce = rnd(6), ref = $('iRef').value.trim(), portal = null;
      /* 1. référence + code d'accès attribués par le serveur (même numéro partout : cartouche, portail, vérification, Plans & fichiers) */
      if (wantDl) {
        var prev = jget(RKEY, []).filter(function (r) { return r.portal && r.no === ref; })[0];
        var r1 = await pubCall(o, token, Object.assign({}, f0, { ref: ref || f0.titre }), '', prev ? prev.portal.ref : null, 0, null);
        if (!r1 || !r1.ok) throw new Error((r1 && r1.erreur) || 'Publication refusée par le serveur.');
        reserved = { ref: r1.ref, code: r1.code, existing: !!prev, old: r1.ancien_token || '' }; portal = { ref: r1.ref, code: r1.code }; ref = r1.ref; $('iRef').value = ref; f0.ref = ref;
      } else if (!ref) { ref = nextRef(); $('iRef').value = ref; f0.ref = ref; }
      var vurl = '', hash = '', rec = null;
      if (V && V.docRec) {
        var title = 'Plan architectural : ' + f0.titre, sub = (f0.sous ? f0.sous + ' ' : '') + '(indice ' + f0.ind + ')';
        var dr = V.docRec({ no: ref, date: $('iDate').value, title: title, sub: sub, digest: [srcHash, f0.ind, f0.titre, f0.sous, f0.moa, nonce].join('|'), nom: f0.moa,
          detail: 'Indice ' + f0.ind + ' · ' + S.pages.length + ' feuille(s) · ' + G.key + ' · Maître d’œuvre : ' + f0.moe });
        rec = dr.rec; hash = dr.code.hash; vurl = dr.code.url;
      } else { vurl = 'EXCELLENCIA BUILDING | ' + f0.titre + ' | ' + ref + ' | Indice ' + f0.ind + ' | ' + f0.date; hash = srcHash.slice(0, 10); }
      var durl = portal ? portalLink(portal.ref, portal.code) : '';
      var qrs = { v: window.EXBQR.matrix(vurl), d: durl ? window.EXBQR.matrix(durl) : null };
      var sheets = [];
      for (var i = 0; i < S.pages.length; i++) { var g = geom(i), op = baseOpts(i, qrs); op.f = Object.assign({}, op.f, { ref: ref }); op.rows = buildRows(i, op.st, op.f); sheets.push({ wmm: g.wmm, hmm: g.hmm, W: g.W, H: g.H, opts: op }); }
      var res = await window.EXBPDFOUT.build({
        src: S.bytes, sheets: sheets,
        plan: function (i) { var a = baseOpts(i, qrs)._adj, p = S.pages[i]; return { zoom: a.zoom, dx: a.dx, dy: a.dy, w: p.w, h: p.h }; },
        raster: async function (i) {
          var c = await renderPage(i, 5200), bl = await new Promise(function (ok) { c.toBlob(ok, 'image/jpeg', 0.92); }), ab = new Uint8Array(await bl.arrayBuffer()), r = { bytes: ab, w: c.width, h: c.height }; c.width = 0; return r;
        },
        links: [vurl, durl].filter(function (x) { return /^https?:/.test(x); }),
        meta: { title: f0.titre + ' – ' + f0.sous, author: identity().name, subject: 'Réf. ' + ref + ' – indice ' + f0.ind, keywords: ['plan', ref, 'indice ' + f0.ind, 'vérification ' + String(hash).toUpperCase()] }
      });
      var blob = new Blob([res.bytes], { type: 'application/pdf' }), name = slug(ref) + '.pdf';
      /* 2. envoi du PDF final dans l'espace public + rangement dans Plans & fichiers CAO (même chemin que « Envoyer vers Plans ») + finalisation */
      var planRec = null;
      if (portal) {
        toast('Envoi du plan au portail clients…', 0);
        await H.exbSb.api('/storage/v1/object/' + PBK + '/' + o + '/' + token + '/plan.pdf', { method: 'POST', headers: { 'Content-Type': 'application/pdf', 'x-upsert': 'true' }, body: blob });
        await H.EXBPLN.addFrom(new File([blob], name, { type: 'application/pdf' }), pid);
        planRec = await waitPlanRecord(name, pid);
        var ap = await sheetThumb(qrs, ref), r3 = await pubCall(o, token, f0, planRec ? planRec.id : '', portal.ref, blob.size, ap);
        if (!r3 || !r3.ok) throw new Error((r3 && r3.erreur) || 'Finalisation refusée par le serveur.');
        if (reserved && reserved.old && reserved.old !== token && reserved.old !== r3.ancien_token) { try { await H.exbSb.api('/storage/v1/object/' + PBK, { method: 'DELETE', body: JSON.stringify({ prefixes: [o + '/' + reserved.old + '/plan.pdf', o + '/' + reserved.old + '/fiche.pdf'] }) }); } catch (e) {} } /* V140+V129 : ancienne version retirée du portail */
        if (r3.ancien_token && r3.ancien_token !== token) { try { await H.exbSb.api('/storage/v1/object/' + PBK, { method: 'DELETE', body: JSON.stringify({ prefixes: [o + '/' + r3.ancien_token + '/plan.pdf', o + '/' + r3.ancien_token + '/fiche.pdf'] }) }); } catch (e) {} }
        if (planRec) { var m = jget(MAPK, {}); m[planRec.id] = { ref: portal.ref, code: portal.code }; try { localStorage.setItem(MAPK, JSON.stringify(m)); } catch (e) {} }
        done = true;
      }
      if (rec && V.publish) V.publish(rec);
      var entry = { id: token, no: ref, ind: f0.ind, titre: f0.titre, sous: f0.sous, nom: f0.moa, date: $('iDate').value, pages: S.pages.length, fmt: G.key, hash: hash, vurl: vurl, durl: durl, status: 'valide', portal: portal, planId: planRec ? planRec.id : '', size: blob.size, vector: res.vector };
      var reg = jget(RKEY, []); reg.unshift(entry); sset(RKEY, JSON.stringify(reg.slice(0, 500))); bumpRef(ref);
      var saved = await saveFile(name, blob);
      S.exported = true; syncUI(); renderHist(); $('iRef').value = wantDl ? '' : nextRef(); $('iInd').value = 'A'; draw();
      toast((portal ? 'Plan publié aux clients (' + portal.ref + ') et rangé dans Plans & fichiers CAO. ' : '') + (saved ? 'PDF exporté' + (res.vector ? ' (plan vectoriel conservé).' : ' (plan inséré en image).') : 'Export terminé.'), 6000);
      if (res.notes && res.notes.length) toast(res.notes[0], 8000);
    } catch (e) {
      if (reserved && !done && !reserved.existing) { try { await rpc('plan_public_retirer', { p_org: o, p_ref: reserved.ref }); } catch (x) {} }
      var msg = (e && e.message) || String(e);
      if (/function .*plan_public|schema cache|PGRST202/i.test(msg)) msg = 'Fonction serveur absente : exécutez supabase/migration-v129-plans-publics.sql (Supabase › SQL Editor).';
      toast('Impossible de générer le PDF : ' + msg, 9000);
    } finally { busy.disabled = false; S.busy = false; }
  }
  async function exportPng() {
    var c = document.createElement('canvas'), g = geom(S.cur), pxmm = Math.min(150 / 25.4, Math.sqrt(16e6 / (g.wmm * g.hmm))), ppu = pxmm * g.wmm / g.W;
    c.width = Math.round(g.W * ppu); c.height = Math.round(g.H * ppu);
    var o = baseOpts(S.cur, qrP()), a = o._adj; o.W = g.W; o.H = g.H; o.ppu = c.width / g.W;
    o.plan = S.pdf ? { img: await renderPage(S.cur, 4200), zoom: a.zoom, dx: a.dx, dy: a.dy } : null;
    E.drawSheet(c.getContext('2d'), o);
    var blob = await new Promise(function (ok) { c.toBlob(ok, 'image/png'); }); c.width = 0;
    await saveFile(slug(fields().ref || 'plan') + '_apercu_F' + (S.cur + 1) + '.png', blob); toast('Image exportée (QR d’aperçu non valables : utilisez l’export PDF).', 6000);
  }
  function exportAs(kind) {
    if (!S.pdf) { toast('Importez d’abord un fichier PDF.'); return; } if (!S.processed && !process()) return;
    if (kind === 'png') exportPng().catch(function (e) { toast('Image impossible : ' + (e && e.message || e)); }); else exportPdf();
  }

  /* ---------- registre des plans émis ---------- */
  function renderHist() {
    var reg = jget(RKEY, []), box = $('histBody');
    if (!reg.length) { box.innerHTML = '<p class="small" style="padding:14px;margin:0">Aucun plan émis pour le moment. Chaque export est enregistré ici ; le PDF est aussi rangé dans 🗂 Plans & fichiers CAO.</p>'; return; }
    box.innerHTML = '<table><thead><tr><th>Réf.</th><th>Ind.</th><th>Projet</th><th>Date</th><th>Statut</th><th>Portail clients</th><th>Actions</th></tr></thead><tbody>' + reg.map(function (r, i) {
      var st = r.status === 'annulé' ? '<span class="tag ko">Annulé</span>' : '<span class="tag ok">Valide</span>';
      var cd = r.portal ? String(r.portal.code) : '', on = !r.portal ? '<span class="tag">Non publié</span>' : r.status === 'annulé' ? '<span class="tag ko">Retiré</span>' : '<span class="tag ok">Publié</span><div class="small">Code : ' + esc(cd.length === 10 ? cd.slice(0, 5) + '-' + cd.slice(5) : cd) + '</div>';
      return '<tr><td><b>' + esc(r.no) + '</b></td><td>' + esc(r.ind) + '</td><td>' + esc(r.titre) + '<div class="small">' + esc(r.nom) + ' · ' + r.pages + ' f. · ' + esc(r.fmt) + '</div></td><td>' + esc(frDate(r.date)) + '</td><td>' + st + '</td><td>' + on + '</td><td>'
        + (r.portal && r.status !== 'annulé' ? '<button data-a="cd" data-i="' + i + '">🔗 Lien téléch.</button>' : '')
        + '<button data-a="cv" data-i="' + i + '">🔗 Lien vérif.</button>'
        + (r.status !== 'annulé' ? '<button data-a="ko" data-i="' + i + '">✖ Annuler</button>' : '') + '</td></tr>';
    }).join('') + '</tbody></table><p class="small" style="padding:8px 14px;margin:0">Pour retélécharger ou republier un plan : 🗂 Plans & fichiers CAO → 🌐.</p>';
  }
  async function copy(t) { try { await navigator.clipboard.writeText(t); toast('Lien copié.'); } catch (e) { window.prompt('Copiez ce lien :', t); } }
  async function histAct(e) {
    var b = e.target.closest('button[data-a]'); if (!b) return; var reg = jget(RKEY, []), r = reg[+b.dataset.i]; if (!r) return;
    if (b.dataset.a === 'cv') copy(r.vurl); else if (b.dataset.a === 'cd') copy(portalLink(r.portal.ref, r.portal.code));
    else if (b.dataset.a === 'ko') {
      if (!window.confirm('Annuler le plan ' + r.no + ' indice ' + r.ind + ' ? Le QR de vérification affichera « ANNULÉ »' + (r.portal ? ' et le plan sera retiré du portail clients (le QR de téléchargement cessera de fonctionner).' : '.'))) return;
      try { var V = H && H.EXBVerif; if (V && V.publish) await V.publish({ no: r.no, kind: 'document', hash: r.hash, date: r.date, total: 0, cur: '', status: 'annulé', nom: r.nom, matricule: '', libelle: 'Plan architectural : ' + r.titre + ' (indice ' + r.ind + ')', detail: 'Annulé' }); } catch (er) {}
      if (r.portal && canPublish()) { try { await rpc('plan_public_retirer', { p_org: org(), p_ref: r.portal.ref }); } catch (er) { toast('Retrait du portail impossible : ' + (er && er.message || er) + ' — retirez-le dans Plans & fichiers CAO › 🌐.', 8000); } }
      r.status = 'annulé'; sset(RKEY, JSON.stringify(reg)); renderHist();
    }
  }


  /* ---------- V141 : formats, marques de cartouche, réglages, logo et vue 3D ajustables, lignes libres ---------- */
  var CFGK = 'exb_plan_cartouche_cfg2', CFG_IDS = ['lblTitre', 'iObj', 'wmTxt', 'wm', 'phCap'];
  var ROWS0 = [{ k: 'ref', l: 'Référence :', big: true }, { k: 'moa', l: 'Maître d’ouvrage :', big: true }, { k: 'moe', l: 'Maître d’œuvre :', big: true }, { k: 'con', l: 'Le concepteur :', big: true },
    { k: 'ech', l: 'Échelle :', big: false }, { k: 'date', l: 'Date :', big: false }, { k: 'ind', l: 'Indice :', big: false }, { k: 'fe', l: 'Feuille :', big: false }];
  function cloneRows() { return ROWS0.map(function (r) { return { k: r.k, l: r.l, big: r.big, on: true }; }); }
  var BRAND_HELP = {
    exb: 'Cartouche aux couleurs de l’entreprise (colonne à droite, en-tête et pied de page).',
    iso: 'Disposition inspirée de la norme ISO 7200 : bloc d’identification en bas à droite de la feuille.',
    arc: 'Bandeau vertical d’architecte (logo, QR Codes, tableau des indices, informations, grand numéro de feuille), dans l’esprit des gabarits Revit / ArchiCAD.',
    cad: 'Bandeau horizontal en bas dans l’esprit des gabarits AutoCAD / ANSI : titre du plan à part, cases d’information en grille.',
    free: 'Vous choisissez la position, la grille, l’en-tête, le pied de page et les lignes.'
  };

  function fillFormats() {
    var h = '<option value="detect">Format du plan détecté</option>';
    E.FORMAT_GROUPS.forEach(function (g) {
      h += '<optgroup label="' + esc(g.label) + '">' + g.keys.map(function (k) { var f = E.FORMATS[k]; return '<option value="' + esc(k) + '"' + (k === 'A1' ? ' selected' : '') + '>' + esc(E.FORMAT_LABELS[k] || k) + ' (' + f[0] + ' × ' + f[1] + ' mm)</option>'; }).join('') + '</optgroup>';
    });
    $('fmt').innerHTML = h + '<option value="custom">Format personnalisé…</option>';
  }
  function fillModels(brandId, key) {
    var b = E.BRANDS.filter(function (x) { return x.id === brandId; })[0] || E.BRANDS[0], m = $('model');
    m.innerHTML = b.models.map(function (k) { return '<option value="' + k + '">' + esc(E.STYLES[k].name) + '</option>'; }).join('');
    m.value = key && b.models.indexOf(key) >= 0 ? key : b.models[0];
    $('brandHelp').textContent = (BRAND_HELP[b.id] || '') + (b.id === 'exb' || b.id === 'free' ? '' : ' Disposition inspirée, pas une copie du gabarit officiel.');
  }
  function fillBrands(key) {
    $('brand').innerHTML = E.BRANDS.map(function (b) { return '<option value="' + b.id + '">' + esc(b.name) + '</option>'; }).join('');
    var br = E.brandOf(key); $('brand').value = br; fillModels(br, key);
  }
  function saveCfg() {
    sset(CFGK, JSON.stringify({ model: $('model').value, tune: S.tune, free: S.free, rows: S.rows, logoAdj: S.logoAdj, phAdj: S.phAdj, lblTitre: $('lblTitre').value, wmTxt: $('wmTxt').value, wm: $('wm').checked, obj: $('iObj').value }));
  }
  function loadCfg() {
    var c = jget(CFGK, null) || {}, ok = function (k) { return E.STYLES[k]; };
    S.rows = Array.isArray(c.rows) && c.rows.length ? c.rows.filter(function (r) { return r && r.k && typeof r.l === 'string'; }) : cloneRows();
    ROWS0.forEach(function (r0) { if (!S.rows.some(function (r) { return r.k === r0.k; })) S.rows.push({ k: r0.k, l: r0.l, big: r0.big, on: true }); });
    if (c.tune) S.tune = Object.assign({ size: null, bw: null, hh: null, fh: null }, c.tune);
    if (c.free) S.free = Object.assign(S.free, c.free);
    if (c.logoAdj) S.logoAdj = Object.assign(S.logoAdj, c.logoAdj);
    if (c.phAdj) S.phAdj = Object.assign(S.phAdj, c.phAdj);
    if (typeof c.lblTitre === 'string') $('lblTitre').value = c.lblTitre;
    if (typeof c.wmTxt === 'string' && c.wmTxt) $('wmTxt').value = c.wmTxt;
    if (typeof c.wm === 'boolean') $('wm').checked = c.wm;
    if (typeof c.obj === 'string' && c.obj) $('iObj').value = c.obj;
    var legacy = sget('exb_plan_cartouche_model');
    return ok(c.model) ? c.model : ok(legacy) ? legacy : 'std';
  }
  function setRange(id, lo, hi, v) { var e = $(id); e.min = lo; e.max = hi; e.value = Math.round(v); $(id + 'V').textContent = Math.round(v); }
  function syncTune() {
    var st = styleNow(), isB = st.pos === 'bottom';
    $('freeBox').hidden = $('model').value !== 'free';
    $('tSizeL').textContent = isB ? 'Hauteur du cartouche' : 'Largeur du cartouche';
    setRange('tSize', isB ? 60 : 90, isB ? 220 : 300, st.size);
    $('wBw').hidden = !isB; if (isB) setRange('tBw', 300, 800, st.bw > 0 ? st.bw : 800);
    $('wHh').hidden = !st.head; if (st.head) setRange('tHh', 40, 140, st.hh);
    $('wFh').hidden = isB; if (!isB) setRange('tFh', 0, 120, st.foot ? st.fh : 0);
    $('fPos').value = S.free.pos; $('fCols').value = String(S.free.cols); $('fHead').checked = !!S.free.head; $('fFoot').checked = !!S.free.foot; $('fLogo').value = S.free.logoIn; $('fDeco').value = S.free.deco;
  }
  function pctTxt(id, v) { $(id).textContent = v; }
  function syncAdjust() {
    $('lgS').value = Math.round(S.logoAdj.scale * 100); $('lgX').value = S.logoAdj.dx; $('lgY').value = S.logoAdj.dy;
    pctTxt('lgSV', Math.round(S.logoAdj.scale * 100) + ' %'); pctTxt('lgXV', S.logoAdj.dx); pctTxt('lgYV', S.logoAdj.dy);
    $('phS').value = Math.round(S.phAdj.scale * 100); $('phX').value = S.phAdj.dx; $('phY').value = S.phAdj.dy;
    pctTxt('phSV', Math.round(S.phAdj.scale * 100) + ' %'); pctTxt('phXV', S.phAdj.dx); pctTxt('phYV', S.phAdj.dy);
    $('phAdj').hidden = !S.photo;
  }
  function renderRows() {
    var box = $('rowsBox'); box.innerHTML = '';
    S.rows.forEach(function (r, i) {
      var d = document.createElement('div'); d.className = 'rw' + (r.on ? '' : ' off'); d.dataset.i = i;
      d.innerHTML = '<input type="checkbox" data-f="on" aria-label="Afficher cette ligne"' + (r.on ? ' checked' : '') + '>'
        + '<input type="text" data-f="l" aria-label="Libellé" value="' + esc(r.l) + '">'
        + '<span class="acts"><button type="button" data-a="up" aria-label="Monter">↑</button><button type="button" data-a="dn" aria-label="Descendre">↓</button>' + (r.custom ? '<button type="button" data-a="del" aria-label="Supprimer">✕</button>' : '') + '</span>'
        + (r.custom ? '<input type="text" class="v" data-f="v" aria-label="Valeur" placeholder="Valeur de la ligne" value="' + esc(r.v || '') + '">' : '')
        + '<label class="big v"><input type="checkbox" data-f="big"' + (r.big ? ' checked' : '') + '> Cellule large (libellé au-dessus)</label>';
      box.appendChild(d);
    });
  }
  function initV141() {
    var model = loadCfg(); fillBrands(model); renderRows(); syncTune(); syncAdjust(); $('wmBox').hidden = !$('wm').checked;
  }
  function onModelChange() { S.tune = { size: null, bw: null, hh: null, fh: null }; syncTune(); saveCfg(); draw(); }
  function readImage(file, cb) {
    if (!file) return; var im = new Image(), u = URL.createObjectURL(file);
    im.onload = function () { cb(im); }; im.onerror = function () { toast('Impossible de lire cette image.'); }; im.src = u;
  }
  function bindV141() {
    $('brand').addEventListener('change', function () { fillModels($('brand').value); onModelChange(); });
    $('model').addEventListener('change', onModelChange);
    /* réglages du cartouche */
    [['tSize', 'size'], ['tBw', 'bw'], ['tHh', 'hh'], ['tFh', 'fh']].forEach(function (p) {
      $(p[0]).addEventListener('input', function () { S.tune[p[1]] = +$(p[0]).value; $(p[0] + 'V').textContent = $(p[0]).value; saveCfg(); draw(); });
    });
    $('tReset').addEventListener('click', function () { onModelChange(); });
    /* cartouche libre */
    function freeChange() {
      var oldPos = S.free.pos;
      S.free = { pos: $('fPos').value, cols: +$('fCols').value, head: $('fHead').checked, foot: $('fFoot').checked, logoIn: $('fLogo').value, deco: $('fDeco').value };
      if (oldPos !== S.free.pos) S.tune = { size: null, bw: null, hh: null, fh: null };
      syncTune(); saveCfg(); draw();
    }
    ['fPos', 'fCols', 'fHead', 'fFoot', 'fLogo', 'fDeco'].forEach(function (id) { $(id).addEventListener('change', freeChange); });
    /* logo */
    function logoChange() { S.logoAdj = { scale: $('lgS').value / 100, dx: +$('lgX').value, dy: +$('lgY').value }; syncAdjust(); saveCfg(); draw(); }
    ['lgS', 'lgX', 'lgY'].forEach(function (id) { $(id).addEventListener('input', logoChange); });
    $('lgRst').addEventListener('click', function () { S.logoAdj = { scale: 1, dx: 0, dy: 0 }; syncAdjust(); saveCfg(); draw(); });
    /* vue 3D */
    $('phIn').addEventListener('change', function () { readImage($('phIn').files[0], function (im) { S.photo = im; syncAdjust(); syncTune(); draw(); toast('Vue 3D placée dans le pied de page : ajustez sa taille et sa position.'); }); });
    function photoChange() { S.phAdj = { scale: $('phS').value / 100, dx: +$('phX').value, dy: +$('phY').value }; syncAdjust(); saveCfg(); draw(); }
    ['phS', 'phX', 'phY'].forEach(function (id) { $(id).addEventListener('input', photoChange); });
    $('phRst').addEventListener('click', function () { S.photo = null; $('phIn').value = ''; S.phAdj = { scale: 1, dx: 0, dy: 0 }; syncAdjust(); syncTune(); saveCfg(); draw(); });
    /* lignes */
    var rb = $('rowsBox');
    rb.addEventListener('input', function (e) {
      var t = e.target, row = t.closest('.rw'), f = t.dataset.f; if (!row || !f) return; var r = S.rows[+row.dataset.i]; if (!r) return;
      if (t.type === 'checkbox') { r[f] = t.checked; if (f === 'on') row.classList.toggle('off', !t.checked); } else r[f] = t.value;
      saveCfg(); draw();
    });
    rb.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-a]'), row = b && b.closest('.rw'); if (!b || !row) return; var i = +row.dataset.i, a = b.dataset.a;
      if (a === 'up' && i > 0) { var t1 = S.rows[i]; S.rows[i] = S.rows[i - 1]; S.rows[i - 1] = t1; }
      else if (a === 'dn' && i < S.rows.length - 1) { var t2 = S.rows[i]; S.rows[i] = S.rows[i + 1]; S.rows[i + 1] = t2; }
      else if (a === 'del') S.rows.splice(i, 1);
      renderRows(); saveCfg(); draw();
    });
    $('rowAdd').addEventListener('click', function () {
      S.rows.push({ k: 'x' + Date.now().toString(36), l: 'Nouvelle ligne :', v: '', big: false, on: true, custom: true }); renderRows(); saveCfg(); draw();
      var ins = rb.querySelectorAll('.rw'); var last = ins[ins.length - 1]; if (last) { var li = last.querySelector('input[data-f="l"]'); if (li) { li.focus(); li.select(); } }
    });
    $('rowReset').addEventListener('click', function () { if (S.rows.some(function (r) { return r.custom; }) && !window.confirm('Les lignes ajoutées seront supprimées. Continuer ?')) return; S.rows = cloneRows(); renderRows(); saveCfg(); draw(); });
  }

  /* ---------- initialisation ---------- */
  function buildSwatches() {
    var box = $('sws'); box.innerHTML = ''; var cs = colors(), saved = sget('exb_plan_cartouche_color');
    if (saved) S.color = saved; else S.color = cs[0].hex; S.accent = identity().accent;
    cs.forEach(function (c) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'sw'; b.style.background = c.hex; b.setAttribute('role', 'radio'); b.title = c.name; b.setAttribute('aria-label', c.name); b.setAttribute('aria-checked', String(c.hex === S.color));
      b.addEventListener('click', function () { S.color = c.hex; sset('exb_plan_cartouche_color', c.hex); box.querySelectorAll('.sw').forEach(function (x) { x.setAttribute('aria-checked', String(x === b)); }); draw(); });
      box.appendChild(b);
    });
  }
  function projects() { return jget('exb_projects', []); }
  function fillProjects() {
    var s = $('iProj'); s.innerHTML = '<option value="">— Saisie libre —</option>' + projects().map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.name) + (p.client ? ' — ' + esc(p.client) : '') + '</option>'; }).join('');
  }
  function refreshRefs(afterExport) {
    if (afterExport) { var r = nextRef(); $('iRef').value = r; $('iInd').value = 'A'; } else { $('iInd').value = nextInd($('iRef').value.trim()); }
    draw();
  }
  function prefill() {
    var I = identity();
    $('iMoe').value = sget('exb_plan_cartouche_moe') || I.name; $('iCon').value = sget('exb_plan_cartouche_con') || 'Service Technique'; $('slogan').value = sget('exb_plan_cartouche_slogan') || 'Bâtir avec Excellence…';
    $('iDate').value = today(); $('iRef').value = ''; $('iInd').value = 'A';
    $('userName').textContent = I.dg || I.name; $('avatar').textContent = String(I.dg || I.name).split(/\s+/).map(function (x) { return x[0]; }).join('').slice(0, 2).toUpperCase();
    $('wmTxt').value = I.name;
    var lo = $('orgLogo'); loadImg(I.logo).then(function (im) { S.orgLogo = im; var bm = $('brandMark'); if (I.eb) { if (bm) bm.hidden = false; } else { if (bm) bm.hidden = true; if (im) { lo.src = im.src; lo.hidden = false; } } draw(); });
    $('qr2help').textContent = canPublish() ? 'Le plan est publié sur le portail clients (page « Saisir la référence »), avec la référence et le code d\u2019accès attribués par le serveur. Il est aussi rangé dans Plans & fichiers CAO.' : 'Connectez-vous au serveur (☁️) pour créer ce QR : la référence et le code d\u2019accès sont attribués par le serveur.';
  }
  function bind() {
    ['iTitre', 'iSous', 'iRef', 'iEch', 'iMoa', 'iMoe', 'iCon', 'iDate', 'iInd', 'iObj', 'qrLbl', 'qr2Lbl', 'slogan', 'lblTitre', 'wm', 'wmTxt', 'phCap', 'fmt', 'ori', 'qr2on', 'cW', 'cH'].forEach(function (id) {
      $(id).addEventListener('input', function () { if (id === 'iMoe') sset('exb_plan_cartouche_moe', $(id).value); if (id === 'iCon') sset('exb_plan_cartouche_con', $(id).value); if (id === 'slogan') sset('exb_plan_cartouche_slogan', $(id).value); if (id === 'qr2on' || id === 'fmt' || id === 'wm') syncUI(); if (CFG_IDS.indexOf(id) >= 0) saveCfg(); updateSteps(); draw(); });
      $(id).addEventListener('change', function () { if (id === 'iRef') $('iInd').value = nextInd($('iRef').value); draw(); });
    });
    $('iProj').addEventListener('change', function () { var p = projects().filter(function (x) { return String(x.id) === $('iProj').value; })[0]; if (p) { $('iTitre').value = p.name || ''; if (p.client) $('iMoa').value = p.client; } draw(); });
    document.querySelectorAll('input[name="mode"]').forEach(function (r) { r.addEventListener('change', syncUI); });
    var drop = $('drop'); $('fileIn').addEventListener('change', function () { openFile($('fileIn').files[0]); });
    ['dragenter', 'dragover'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); }); });
    drop.addEventListener('drop', function (e) { var f = e.dataTransfer && e.dataTransfer.files[0]; if (f) openFile(f); });
    window.addEventListener('dragover', function (e) { e.preventDefault(); }); window.addEventListener('drop', function (e) { e.preventDefault(); });
    $('fileX').addEventListener('click', clearFile); $('go').addEventListener('click', process);
    $('pz').addEventListener('input', function () { var a = S.adj[S.cur]; if (!a) return; a.zoom = $('pz').value / 100; $('pzv').textContent = $('pz').value + ' %'; draw(); });
    $('recenter').addEventListener('click', function () { if (S.adj[S.cur]) { S.adj[S.cur] = { zoom: 1, dx: 0, dy: 0 }; syncUI(); } });
    $('pPrev').addEventListener('click', function () { if (S.cur > 0) { S.cur--; syncUI(); ensurePreview(S.cur); } });
    $('pNext').addEventListener('click', function () { if (S.cur < S.pages.length - 1) { S.cur++; syncUI(); ensurePreview(S.cur); } });
    $('zoom').addEventListener('change', draw);
    function step(d) { var s = $('zoom'), i = Math.max(0, Math.min(s.options.length - 1, s.selectedIndex + d)); s.selectedIndex = i; draw(); }
    $('zIn').addEventListener('click', function () { step(1); }); $('zOut').addEventListener('click', function () { step(-1); });
    $('fs').addEventListener('click', function () { try { if (document.fullscreenElement) document.exitFullscreen(); else $('pv').requestFullscreen().catch(function () { toast('Le plein écran n’est pas disponible dans cette vue.'); }); } catch (e) { toast('Le plein écran n’est pas disponible dans cette vue.'); } });
    document.addEventListener('fullscreenchange', draw);
    $('exp').addEventListener('click', function () { exportAs('pdf'); });
    $('expMore').addEventListener('click', function (e) { e.stopPropagation(); var o = $('menu').hidden; $('menu').hidden = !o; $('expMore').setAttribute('aria-expanded', String(o)); });
    $('menu').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) { $('menu').hidden = true; exportAs(b.dataset.x); } });
    document.addEventListener('click', function () { $('menu').hidden = true; });
    $('logoIn').addEventListener('change', function () { var f = $('logoIn').files[0]; if (!f) return; var im = new Image(); im.onload = function () { S.logo = im; syncUI(); }; im.onerror = function () { toast('Impossible de lire ce logo.'); }; im.src = URL.createObjectURL(f); });
    $('logoRst').addEventListener('click', function () { S.logo = null; $('logoIn').value = ''; syncUI(); });
    $('histBody').addEventListener('click', histAct);
    var cv = $('cv'), drag = null; cv.style.touchAction = 'none';
    cv.addEventListener('pointerdown', function (e) { if (!S.pdf || mode() === 'auto') return; var a = S.adj[S.cur]; if (!a) return; drag = { x: e.clientX, y: e.clientY, dx: a.dx, dy: a.dy }; cv.setPointerCapture(e.pointerId); e.preventDefault(); });
    cv.addEventListener('pointermove', function (e) { if (!drag) return; var u = parseFloat(cv.dataset.upu) || 1, a = S.adj[S.cur]; a.dx = drag.dx + (e.clientX - drag.x) * u; a.dy = drag.dy + (e.clientY - drag.y) * u; draw(); });
    ['pointerup', 'pointercancel'].forEach(function (ev) { cv.addEventListener(ev, function () { drag = null; }); });
    var last = { w: 0, h: 0 }; new ResizeObserver(function () { var s = $('stage'); if (Math.abs(s.clientWidth - last.w) > 1 || Math.abs(s.clientHeight - last.h) > 1) { last = { w: s.clientWidth, h: s.clientHeight }; draw(); } }).observe($('stage'));
  }

  fillFormats(); prefill(); buildSwatches(); fillProjects(); initV141(); bind(); bindV141(); (function () { var pd = $('pDl'); if (pd) pd.addEventListener('click', function () { $('exp').click(); }); var w = $('wm'), n = w && w.nextSibling, I0 = identity(); if (n && n.nodeType === 3 && I0.name) n.textContent = 'Ajouter le filigrane ' + I0.name; })(); renderHist(); syncUI();
  window.EXBPLANCART = { refresh: function () { fillProjects(); buildSwatches(); renderHist(); draw(); }, state: S, exportPdf: exportPdf, openFile: openFile, version: 'V141' };
})();
