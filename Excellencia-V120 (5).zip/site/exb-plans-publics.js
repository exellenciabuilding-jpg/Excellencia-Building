/* Excellencia Building V129 — Publier un plan aux clients (portail public « plan.html » / adresse /plan).
 * Dans 🗂 Plans & fichiers CAO : bouton 🌐 sur chaque plan PDF ou image.
 * - envoie le plan (et une fiche PDF facultative) dans l'espace public « exb-plans-publics », dossier au nom ALÉATOIRE ;
 * - enregistre la publication (fonction serveur plan_public_publier) : le serveur attribue la référence EXB-AAAA-NNN
 *   et un code d'accès ; le QR contient la référence + le code (jamais le PDF ni un chemin de stockage) ;
 * - republier le même plan garde la même référence et le même code : le QR déjà imprimé reste valable ;
 * - « 🌐 Plans publiés aux clients » : liste, QR / lien, retrait (les fichiers publics sont alors supprimés).
 * Prérequis : supabase/migration-v129-plans-publics.sql exécuté ; connexion au serveur (☁️) ; droit « plans_fichiers ». */
(function (w, d) {
  'use strict';
  var C = w.EXB81;
  if (!C) return;
  var BK = 'exb-plans-publics', MAPK = 'exb_pub_map', DEFK = 'exb_pub_defaults';

  function ls(k, def) { try { return JSON.parse(localStorage.getItem(k)) || def; } catch (e) { return def; } }
  function ss(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* stockage plein */ } }
  function org() { try { return (w.EXBDB && w.EXBDB.org && w.EXBDB.org()) || ''; } catch (e) { return ''; } }
  function online() { return !!(org() && w.exbSb && w.exbSb.isIn && w.exbSb.isIn() && navigator.onLine); }
  function api(p, o) { return w.exbSb.api(p, o); }
  function rpc(n, b) { return api('/rest/v1/rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) }); }
  function esc(s) { return C.esc(s); }
  function canW() { return C.can('plans_fichiers', 'ecrire'); }
  function files() { return (w.EXBS && w.EXBS.get('exb_plan_files')) || []; }
  function rec(id) { return files().find(function (x) { return x.id === id; }); }
  function size(n) { n = Number(n) || 0; return n > 1048576 ? (n / 1048576).toFixed(1) + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function rnd32() { var a = new Uint8Array(16); (w.crypto || w.msCrypto).getRandomValues(a); return Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
  function baseUrl() { try { if (w.EXBVerif && w.EXBVerif.vbase) return w.EXBVerif.vbase(); } catch (e) { /* repli */ } return location.origin + '/'; }
  function linkOf(ref, code) { return baseUrl() + 'plan?ref=' + encodeURIComponent(ref) + '&k=' + encodeURIComponent(code); }
  function fmtCode(c) { c = String(c || ''); return c.length === 10 ? c.slice(0, 5) + '-' + c.slice(5) : c; }
  function st(m, bad) { var e = d.getElementById('pbSt'); if (e) { e.textContent = m || ''; e.style.color = bad ? '#b42318' : '#15803d'; } }

  /* ---------- lecture du fichier du plan (cet appareil, sinon espace partagé de l'équipe) ---------- */
  function idbGet(id) {
    return new Promise(function (ok, ko) {
      var q = indexedDB.open('exb81', 1);
      q.onupgradeneeded = function () { q.result.createObjectStore('blobs'); };
      q.onsuccess = function () { try { var g = q.result.transaction('blobs').objectStore('blobs').get(id); g.onsuccess = function () { ok(g.result || null); }; g.onerror = function () { ko(g.error); }; } catch (e) { ko(e); } };
      q.onerror = function () { ko(q.error); };
    });
  }
  function getBlob(r) {
    return idbGet(r.id).then(function (b) {
      if (b) return b;
      if (!r.path || !online()) throw new Error('Fichier introuvable sur cet appareil : ouvrez-le d’abord depuis la liste (connecté) pour le télécharger.');
      return api('/storage/v1/object/sign/exb-plans/' + r.path, { method: 'POST', body: JSON.stringify({ expiresIn: 300 }) })
        .then(function (x) { return fetch(w.exbSb.cfg().url + '/storage/v1' + x.signedURL); })
        .then(function (x) { if (!x.ok) throw new Error('Téléchargement impossible (' + x.status + ')'); return x.blob(); });
    });
  }

  /* ---------- aperçu (1re page du PDF ou image réduite) ---------- */
  function jpeg(cv) {
    var u = cv.toDataURL('image/jpeg', 0.72);
    if (u.length > 450000) { var s = d.createElement('canvas'); s.width = Math.round(cv.width * 0.65); s.height = Math.round(cv.height * 0.65); s.getContext('2d').drawImage(cv, 0, 0, s.width, s.height); u = s.toDataURL('image/jpeg', 0.6); }
    return u.length > 480000 ? '' : u;
  }
  function thumb(blob, ext) {
    if (/^(png|jpe?g|webp)$/i.test(ext)) {
      return new Promise(function (ok) {
        var u = URL.createObjectURL(blob), im = new Image();
        im.onload = function () {
          var s = Math.min(1, 900 / im.width), cv = d.createElement('canvas'); cv.width = Math.round(im.width * s); cv.height = Math.round(im.height * s);
          var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); x.drawImage(im, 0, 0, cv.width, cv.height);
          URL.revokeObjectURL(u); ok(jpeg(cv));
        };
        im.onerror = function () { ok(''); };
        im.src = u;
      });
    }
    return import('./pdfjs/pdf.min.mjs').then(function (m) {
      m.GlobalWorkerOptions.workerSrc = './pdfjs/pdf.worker.min.mjs';
      return blob.arrayBuffer().then(function (buf) { return m.getDocument({ data: buf }).promise; });
    }).then(function (doc) { return doc.getPage(1); }).then(function (pg) {
      var v1 = pg.getViewport({ scale: 1 }), vp = pg.getViewport({ scale: Math.min(2, 900 / v1.width) }), cv = d.createElement('canvas');
      cv.width = Math.ceil(vp.width); cv.height = Math.ceil(vp.height);
      var x = cv.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height);
      return pg.render({ canvasContext: x, viewport: vp }).promise.then(function () { return jpeg(cv); });
    }).catch(function () { return ''; });
  }

  /* ---------- espace public ---------- */
  function up(o, token, name, blob) {
    return api('/storage/v1/object/' + BK + '/' + o + '/' + token + '/' + name, { method: 'POST', headers: { 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'true' }, body: blob });
  }
  function purge(o, token) {
    if (!/^[a-f0-9]{32}$/.test(String(token || ''))) return Promise.resolve();
    var pre = o + '/' + token + '/';
    return api('/storage/v1/object/list/' + BK, { method: 'POST', body: JSON.stringify({ prefix: pre, limit: 20 }) })
      .then(function (L) { var n = (L || []).map(function (x) { return pre + x.name; }); if (!n.length) return null; return api('/storage/v1/object/' + BK, { method: 'DELETE', body: JSON.stringify({ prefixes: n }) }); })
      .catch(function () { /* suppression non bloquante */ });
  }

  /* ---------- fenêtre de publication ---------- */
  function openPub(id) {
    var r = rec(id); if (!r) return;
    if (!canW()) return C.say('Accès non autorisé.', 'error');
    if (!online()) return C.say('Connectez-vous au serveur (☁️) pour publier aux clients.', 'warn');
    var prev = ls(MAPK, {})[id], df = ls(DEFK, {});
    var h = '<p style="color:#64748b;font-size:13px;margin:8px 0">Le client scanne le QR du plan, voit ces informations et télécharge le plan. ' +
      (prev ? '<b style="color:#15803d">Déjà publié (' + esc(prev.ref) + ') : la publication est mise à jour, le QR déjà imprimé reste valable.</b>' : 'Une référence et un code d’accès sont créés par le serveur.') + '</p>' +
      '<div style="display:flex;flex-wrap:wrap;gap:8px">' +
      C.field('pbTitre', 'Titre du projet', df.titre_p && df.titre_p[r.project] || C.pn(r.project), '', 96) +
      C.field('pbType', 'Type de document', 'Plan — ' + (r.ref || ''), '', 96) +
      C.field('pbMoe', 'Maître d’œuvre', df.moe || 'Excellencia Building', '', 45) +
      C.field('pbMo', 'Maître d’ouvrage (client)', df.mo_p && df.mo_p[r.project] || '', '', 45) +
      C.field('pbConc', 'Concepteur', df.conc || 'Service Technique', '', 45) +
      C.field('pbEch', 'Échelle', df.ech || '', '', 20) +
      C.field('pbInd', 'Indice / Feuille', 'Indice ' + (r.ver || 'A'), '', 30) + '</div>' +
      '<p style="font-size:13px;margin:10px 0 4px"><b>Fiche ou certificat (PDF, facultatif)</b><br><input type="file" id="pbFiche" accept=".pdf,application/pdf"></p>' +
      (prev ? '<p style="font-size:12px;color:#b45309;margin:4px 0">Si vous ne joignez pas de fiche, la fiche précédente est retirée.</p>' : '') +
      '<p style="margin:12px 0 4px"><button id="pbGo" onclick="EXBPUB.go(\'' + esc(id) + '\')" style="padding:10px 18px;background:#082653;color:#fff;border:0;border-radius:8px;font-weight:700">🌐 Publier</button> <button onclick="document.getElementById(\'exbPub\').remove()" style="padding:10px 14px">Annuler</button></p><div id="pbSt" style="font-size:13px;min-height:18px"></div>';
    C.overlay('exbPub', '🌐 Publier aux clients — ' + esc(r.ref), h, 640);
  }

  function go(id) {
    var r = rec(id); if (!r) return;
    var g = C.val, titre = g('pbTitre'), fiche = d.getElementById('pbFiche'); fiche = fiche && fiche.files && fiche.files[0];
    if (titre.length < 2) return C.say('Indiquez le titre du projet.', 'warn');
    if (fiche && !/\.pdf$/i.test(fiche.name)) return C.say('La fiche doit être un fichier PDF.', 'warn');
    if (!online()) return C.say('Connectez-vous au serveur (☁️).', 'warn');
    var btn = d.getElementById('pbGo'); if (btn) btn.disabled = true;
    var o = org(), token = rnd32(), prev = ls(MAPK, {})[id], ext = String(r.ext || 'pdf').toLowerCase().replace('jpeg', 'jpg'), blobRef;
    st('Lecture du plan…');
    getBlob(r).then(function (blob) {
      blobRef = blob; st('Création de l’aperçu…');
      return thumb(blob, ext);
    }).then(function (ap) {
      var docs = [{ nom: 'Plan — ' + (r.ref || '') + ' (indice ' + (r.ver || 'A') + ')', fichier: o + '/' + token + '/plan.' + ext, format: ext.toUpperCase(), taille: size(blobRef.size), kind: 'plan' }];
      st('Envoi du plan (' + size(blobRef.size) + ')…');
      return up(o, token, 'plan.' + ext, blobRef).then(function () {
        if (!fiche) return null;
        st('Envoi de la fiche…');
        docs.push({ nom: fiche.name.replace(/\.pdf$/i, '').slice(0, 100), fichier: o + '/' + token + '/fiche.pdf', format: 'PDF', taille: size(fiche.size), kind: 'fiche' });
        return up(o, token, 'fiche.pdf', fiche);
      }).then(function () {
        st('Publication…');
        return rpc('plan_public_publier', { p_org: o, p_plan_id: id, p_ref_plan: r.ref || '', p_titre: titre, p_type: g('pbType'), p_moe: g('pbMoe'), p_mo: g('pbMo'), p_concepteur: g('pbConc'), p_echelle: g('pbEch'), p_indice: g('pbInd'), p_apercu: ap || null, p_docs: docs, p_token: token, p_ref: prev ? prev.ref : null });
      });
    }).then(function (res) {
      if (!res || !res.ok) { purge(o, token); throw new Error((res && res.erreur) || 'Publication refusée par le serveur.'); }
      var m = ls(MAPK, {}); m[id] = { ref: res.ref, code: res.code }; ss(MAPK, m);
      var df = ls(DEFK, {}); df.moe = g('pbMoe'); df.conc = g('pbConc'); df.ech = g('pbEch'); df.titre_p = df.titre_p || {}; df.titre_p[r.project] = titre; df.mo_p = df.mo_p || {}; df.mo_p[r.project] = g('pbMo'); ss(DEFK, df);
      if (res.ancien_token) purge(o, res.ancien_token);
      showLink(res.ref, res.code, titre);
    }).catch(function (e) {
      var msg = (e && e.message) || String(e);
      if (/not found|bucket/i.test(msg)) msg += ' — le script supabase/migration-v129-plans-publics.sql est-il exécuté ?';
      if (/function .*plan_public|schema cache|PGRST202/i.test(msg)) msg = 'Fonction serveur absente : exécutez supabase/migration-v129-plans-publics.sql (Supabase › SQL Editor).';
      st(msg, true); if (btn) btn.disabled = false;
    });
  }

  /* ---------- résultat : lien + QR ---------- */
  function showLink(ref, code, titre) {
    var url = linkOf(ref, code), png = '';
    try { png = (w.EXBVerif && w.EXBVerif.qrPng) ? w.EXBVerif.qrPng(url) : ''; } catch (e) { /* QR indisponible */ }
    var h = '<p style="background:#effaf3;border:1px solid #b5e1c5;color:#176b3d;padding:10px;border-radius:10px;margin:8px 0"><b>✓ Plan publié</b> — les clients peuvent le consulter et le télécharger.</p>' +
      '<div style="display:flex;flex-wrap:wrap;gap:16px;align-items:center">' + (png ? '<img id="pbQr" src="' + png + '" alt="QR Code du plan" style="width:210px;height:210px;image-rendering:pixelated;border:1px solid #dce4ef;border-radius:8px">' : '') +
      '<div style="flex:1;min-width:220px;font-size:14px"><div><span style="color:#64748b">Référence</span><br><b style="font-size:20px;color:#082653">' + esc(ref) + '</b></div>' +
      '<div style="margin-top:8px"><span style="color:#64748b">Code d’accès</span><br><b style="font-size:20px;letter-spacing:1px">' + esc(fmtCode(code)) + '</b></div>' +
      '<div style="font-size:12px;color:#64748b;margin-top:8px">Imprimez le QR sur le plan, avec la référence et le code (pour la saisie manuelle).</div></div></div>' +
      '<p style="margin:12px 0 4px"><input id="pbLink" readonly value="' + esc(url) + '" style="width:100%;padding:8px;box-sizing:border-box;font-size:12px"></p>' +
      '<p style="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0"><button onclick="EXBPUB.copy()">📋 Copier le lien</button>' +
      (png ? '<a href="' + png + '" download="QR-' + esc(ref) + '.png" style="padding:6px 10px;border:1px solid #999;border-radius:4px;background:#efefef;color:#000;text-decoration:none;font-size:13px">⬇ QR (PNG)</a><button onclick="EXBPUB.print(\'' + esc(ref) + '\',\'' + esc(code) + '\',\'' + esc(String(titre || '').replace(/'/g, '’')) + '\')">🖨 Imprimer le QR</button>' : '') +
      '<a href="https://wa.me/?text=' + encodeURIComponent('Documents de votre projet — Excellencia Building : ' + url) + '" target="_blank" rel="noopener" style="padding:6px 10px;border:1px solid #999;border-radius:4px;background:#efefef;color:#000;text-decoration:none;font-size:13px">💬 Envoyer par WhatsApp</a>' +
      '<button onclick="EXBPUB.list()">🌐 Plans publiés</button></p>';
    C.overlay('exbPub', '🌐 ' + esc(titre || ref), h, 640);
  }

  function printQr(ref, code, titre) {
    var png = ''; try { png = w.EXBVerif.qrPng(linkOf(ref, code)); } catch (e) { return; }
    var win = w.open('', '_blank'); if (!win) return C.say('Autorisez les fenêtres pour imprimer.', 'warn');
    win.document.write('<!doctype html><meta charset="utf-8"><title>QR ' + esc(ref) + '</title><body style="font:16px Arial;text-align:center;padding:30px;color:#082653"><div style="border-top:6px solid #d8a326;padding-top:14px"><b style="font-size:22px">EXCELLENCIA BUILDING</b><br><i style="font-size:12px;color:#66758c">L’excellence au cœur de vos constructions</i></div><h2>' + esc(titre) + '</h2><img src="' + png + '" style="width:320px;height:320px;image-rendering:pixelated"><p style="font-size:20px"><b>Référence : ' + esc(ref) + '</b><br>Code d’accès : <b>' + esc(fmtCode(code)) + '</b></p><p style="font-size:13px;color:#555">Scannez ce QR Code pour consulter et télécharger vos documents.</p><script>setTimeout(function(){print()},400)<\/script></body>');
    win.document.close();
  }

  /* ---------- liste des plans publiés ---------- */
  function list() {
    if (!online()) return C.say('Connectez-vous au serveur (☁️).', 'warn');
    rpc('plan_public_lister', { p_org: org() }).then(function (L) {
      L = Array.isArray(L) ? L : [];
      var h = L.length ? '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:13px"><tr style="text-align:left;background:#f1f5fb"><th style="padding:6px">Référence</th><th>Projet / plan</th><th>Mis à jour</th><th>État</th><th></th></tr>' +
        L.map(function (x) {
          return '<tr style="border-bottom:1px solid #e2e8f0;' + (x.actif ? '' : 'opacity:.55') + '"><td style="padding:6px"><b>' + esc(x.ref) + '</b></td><td>' + esc(x.titre) + '<br><small>' + esc(x.ref_plan || '') + ' · ' + esc(x.nb_docs) + ' doc.</small></td><td>' + C.frDate(String(x.maj_le || '').slice(0, 10)) + '</td><td>' + (x.actif ? '✅ En ligne' : '⛔ Retiré') + '</td><td>' +
            (x.actif ? '<button onclick="EXBPUB.show(\'' + esc(x.ref) + '\',\'' + esc(x.code) + '\',\'' + esc(String(x.titre || '').replace(/'/g, '’')) + '\')">QR / lien</button> <button onclick="EXBPUB.retire(\'' + esc(x.ref) + '\')">Retirer</button>' : '') + '</td></tr>';
        }).join('') + '</table></div>' : '<p style="color:#64748b">Aucun plan publié pour le moment. Dans 🗂 Plans & fichiers CAO, touchez 🌐 à côté d’un plan PDF ou image.</p>';
      C.overlay('exbPub', '🌐 Plans publiés aux clients', h, 760);
    }).catch(function (e) { C.say((e && e.message) || 'Liste indisponible.', 'error'); });
  }
  function retire(ref) {
    if (!w.confirm('Retirer ' + ref + ' ? Les clients ne pourront plus consulter ni télécharger ce plan (le QR imprimé cessera de fonctionner).')) return;
    var o = org();
    rpc('plan_public_retirer', { p_org: o, p_ref: ref }).then(function (r) {
      if (!r || !r.ok) throw new Error((r && r.erreur) || 'Retrait refusé.');
      var m = ls(MAPK, {}); Object.keys(m).forEach(function (k) { if (m[k].ref === ref) delete m[k]; }); ss(MAPK, m);
      return purge(o, r.token);
    }).then(function () { C.say('Plan retiré.', 'success'); list(); }).catch(function (e) { C.say((e && e.message) || 'Retrait impossible.', 'error'); });
  }

  /* ---------- boutons dans la liste des plans ---------- */
  var tmr = 0;
  function inject() {
    var ov = d.getElementById('exbPln'); if (!ov || !canW()) return;
    var p = ov.querySelector('p');
    if (p && !ov.querySelector('.exbPubTop')) { var b = d.createElement('button'); b.className = 'exbPubTop'; b.textContent = '🌐 Plans publiés aux clients'; b.style.cssText = 'margin-left:8px;padding:8px 12px'; b.onclick = list; p.appendChild(b); }
    ov.querySelectorAll('tr').forEach(function (tr) {
      var cb = tr.querySelector('input[type=checkbox]'); if (!cb) return;
      var m = /EXBPLN\.pick\('([^']+)'/.exec(cb.getAttribute('onchange') || ''); if (!m) return;
      var r = rec(m[1]); if (!r || !/^(pdf|png|jpe?g|webp)$/i.test(r.ext || '')) return;
      var td = tr.lastElementChild; if (!td || td.querySelector('.exbPubBtn')) return;
      var bt = d.createElement('button'); bt.className = 'exbPubBtn'; bt.textContent = '🌐'; bt.title = 'Publier aux clients (portail public)'; bt.onclick = function () { openPub(r.id); };
      td.appendChild(d.createTextNode(' ')); td.appendChild(bt);
    });
  }
  function start() { new MutationObserver(function () { clearTimeout(tmr); tmr = setTimeout(inject, 60); }).observe(d.body, { childList: true, subtree: true }); }
  if (d.body) start(); else d.addEventListener('DOMContentLoaded', start);

  w.EXBPUB = {
    open: openPub, go: go, list: list, show: showLink, retire: retire, print: printQr,
    copy: function () { var e = d.getElementById('pbLink'); if (!e) return; e.select(); try { navigator.clipboard.writeText(e.value); } catch (x) { d.execCommand('copy'); } C.say('Lien copié.', 'success'); }
  };
})(window, document);
