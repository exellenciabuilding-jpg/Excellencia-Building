/* Excellencia Building V99zy — « 🔗 Portails & signatures » (Clients & CRM).
 * 1) Portails client / sous-traitant : l'entreprise PUBLIE un instantané choisi (avancement, jalons, photos, journal, factures, lots, documents)
 *    sous un lien secret + un code ; le visiteur ouvre portail.html (sans compte). Republier = mettre à jour ; Révoquer = couper l'accès.
 * 2) E-signature des contrats : modèles, empreinte SHA-256, signature de l'entreprise dans l'application, signature du client / sous-traitant dans le portail,
 *    attestation imprimable. Une fois joint à un portail, le texte est verrouillé (nouvelle version pour modifier).
 * 3) Retours : signatures, messages, déclarations d'avancement des sous-traitants (acceptées / refusées), visites.
 * 4) Relances : messages WhatsApp / SMS / e-mail PRÉPARÉS automatiquement (factures impayées, situations non facturées, signatures en attente, retards, publications) ;
 *    l'envoi se fait d'un appui (aucune passerelle d'envoi automatique n'est incluse).
 * Nécessite supabase/migration-v99zy-portails.sql, la connexion au compte en ligne ET l'appartenance à une organisation (⚙️ Administration › Équipe) pour publier / lire les retours.
 * Données synchronisées entre les appareils de l'organisation (collections portails, esign, relances). Les codes d'accès, eux, ne quittent jamais l'appareil (exb_portail_codes). */
(function (w, d) {
'use strict';
var $ = function (i) { return d.getElementById(i); };
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function G(k) { try { var v = w.EXBS.get(k); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
function Pu(k, v) { try { return w.EXBS.set(k, v); } catch (e) { return false; } }
function uid(p) { return p + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6); }
function today() { return new Date().toISOString().slice(0, 10); }
function days(t) { var x = new Date(t); return isNaN(x) ? 0 : Math.floor((Date.now() - x.getTime()) / 864e5); }
function fr(t, l) { if (!t) return '–'; var x = new Date(t); return isNaN(x) ? '–' : x.toLocaleDateString('fr-FR', l ? { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' } : { day: '2-digit', month: 'short', year: 'numeric' }); }
function money(n, c) { return (Number(n) || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + (c === 'FC' ? 'FC' : '$'); }
function say(m, t) { try { if (w.notify) w.notify(m, t || 'success'); else alert(m); } catch (e) {} }
function org() { try { return JSON.parse(localStorage.getItem('EXB_DB_META') || '{}').org || ''; } catch (e) { return ''; } }
function codes() { try { return JSON.parse(localStorage.getItem('exb_portail_codes') || '{}') || {}; } catch (e) { return {}; } }
function setCode(id, c) { var m = codes(); m[id] = c; try { localStorage.setItem('exb_portail_codes', JSON.stringify(m)); } catch (e) {} }
function needOrg() { if (!org()) throw new Error('Créez ou rejoignez votre organisation (⚙️ Administration › Équipe) : les portails sont rattachés à l’organisation.'); }
function isIn() { return !!(w.exbSb && w.exbSb.isIn && w.exbSb.isIn()); }
function rpc(fn, b) { return w.exbSb.api('/rest/v1/rpc/' + fn, { method: 'POST', body: JSON.stringify(b || {}) }); }
async function sha(t) { var b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)); return Array.prototype.map.call(new Uint8Array(b), function (x) { return x.toString(16).padStart(2, '0'); }).join(''); }
function ident() { try { return w.EXBId ? w.EXBId.get() : {}; } catch (e) { return {}; } }
function phoneNorm(p) { var raw = String(p || ''), dg = raw.replace(/\D/g, ''), cc = '243'; try { cc = localStorage.getItem('exb_cc') || '243'; } catch (e) {} if (!dg) return ''; if (/^\s*\+/.test(raw)) return dg; if (dg.indexOf('00') === 0) return dg.slice(2); if (dg[0] === '0') return cc + dg.slice(1); if (dg.length <= 9) return cc + dg; return dg; }
function opt(list, sel) { return list.map(function (x) { return '<option value="' + esc(x[0]) + '"' + (String(x[0]) === String(sel) ? ' selected' : '') + '>' + esc(x[1]) + '</option>'; }).join(''); }
function linkOf(tok) { var b = (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,'')); return b + 'portail.html?t=' + tok; }

/* ---------- réglages des relances ---------- */
var CFG0 = { on: { facture: true, situation: true, signature: true, retard: true, publication: true }, factureJ: 15, situationJ: 7, signatureJ: 3,
  tpl: {
    facture: 'Bonjour {nom}, sauf erreur de notre part, la facture {no} du projet « {projet} » ({montant}) reste à régler depuis {jours} jours. Merci de nous indiquer la date de paiement. — {entreprise}',
    situation: 'Bonjour {nom}, la situation de travaux {no} du projet « {projet} » ({montant}) a été émise le {date}. Merci de la valider afin que nous puissions émettre la facture. — {entreprise}',
    signature: 'Bonjour {nom}, le document « {no} » attend votre signature depuis {jours} jours : {lien} (le code d’accès vous a été transmis séparément). — {entreprise}',
    retard: 'Alerte interne : le projet « {projet} » a dépassé sa date de fin prévue ({date}) avec un avancement de {montant}.',
    publication: 'Bonjour {nom}, l’avancement de votre projet « {projet} » est à jour sur votre espace de suivi : {lien} — {entreprise}'
  } };
function cfg() { var c = {}; try { c = JSON.parse(localStorage.getItem('exb_portail_cfg') || '{}') || {}; } catch (e) {} return { on: Object.assign({}, CFG0.on, c.on), factureJ: c.factureJ || CFG0.factureJ, situationJ: c.situationJ || CFG0.situationJ, signatureJ: c.signatureJ || CFG0.signatureJ, tpl: Object.assign({}, CFG0.tpl, c.tpl) }; }
function saveCfg(c) { try { localStorage.setItem('exb_portail_cfg', JSON.stringify(c)); } catch (e) {} }
function fill(t, v) { return String(t).replace(/\{(\w+)\}/g, function (m, k) { return v[k] != null ? v[k] : m; }); }

/* ---------- modèles de contrats (indicatifs : à faire relire par un juriste) ---------- */
var TYPES = [['contrat', 'Contrat de travaux (client)', 'client'], ['soustraitance', 'Contrat de sous-traitance', 'soustraitant'], ['avenant', 'Avenant', 'client'], ['os', 'Ordre de service', 'soustraitant'], ['pv', 'PV de réception', 'client'], ['devis', 'Devis accepté', 'client'], ['autre', 'Autre document', 'client']];
function model(type, v) {
  var E = v.entreprise || '…', C = v.client || '…', P = v.projet || '…', L = v.lieu || '…';
  var common = '\n\nPRIX ET PAIEMENT\nLe prix, les acomptes et les modalités de paiement sont ceux du devis / DQE validé : ………\n\nDÉLAI\nLes travaux débutent le ……… et s’achèvent le ………, sous réserve des cas de force majeure.\n\nPÉNALITÉS DE RETARD\nEn cas de retard imputable à l’entrepreneur, une pénalité de ……… % du montant par jour de retard est appliquée, plafonnée à ……… %.\n\nRETENUE DE GARANTIE\nUne retenue de ……… % est opérée sur chaque paiement et restituée à la réception définitive, après levée des réserves.\n\nRÉCEPTION\nLa réception a lieu par procès-verbal signé des deux parties ; les réserves sont levées dans un délai de ……… jours.\n\nRÉSILIATION\nChaque partie peut résilier après mise en demeure restée sans effet pendant ……… jours.\n\nLITIGES\nLes parties recherchent une solution amiable ; à défaut, le tribunal compétent est celui de ………\n\nFait en deux exemplaires. Signatures précédées de la mention « lu et approuvé » portée par la signature électronique.';
  if (type === 'soustraitance') return 'CONTRAT DE SOUS-TRAITANCE\n\nEntre ' + E + ' (« l’entrepreneur principal ») et ' + C + ' (« le sous-traitant »).\n\nOBJET\nLe sous-traitant exécute les lots suivants du projet « ' + P + ' » (' + L + ') : ………\n\nOBLIGATIONS DU SOUS-TRAITANT\nRespect des plans, des règles de l’art, de la sécurité du chantier (port des EPI) et des instructions du conducteur de travaux. Assurance responsabilité civile valable pendant toute la durée du marché.' + common;
  if (type === 'os') return 'ORDRE DE SERVICE N° ………\n\nDe : ' + E + '\nÀ : ' + C + '\nProjet : ' + P + ' (' + L + ')\n\nVous êtes invité à ………\n\nDate de prise d’effet : ………\nDélai d’exécution : ………\n\nLa signature de ce document vaut accusé de réception et acceptation de l’ordre.';
  if (type === 'pv') return 'PROCÈS-VERBAL DE RÉCEPTION\n\nProjet : ' + P + ' (' + L + ')\nMaître d’ouvrage : ' + C + '\nEntreprise : ' + E + '\n\nAprès visite des ouvrages le ………, le maître d’ouvrage déclare :\n☐ réceptionner les travaux sans réserve\n☐ réceptionner les travaux avec les réserves suivantes : ………\n\nLes réserves seront levées avant le ………\nLa garantie de parfait achèvement court à compter de ce jour.';
  if (type === 'avenant') return 'AVENANT N° ………\n\nAu contrat entre ' + E + ' et ' + C + ' relatif au projet « ' + P + ' ».\n\nObjet de la modification : ………\nIncidence sur le prix : ………\nIncidence sur le délai : ………\n\nLes autres clauses du contrat restent inchangées.';
  if (type === 'devis') return 'ACCEPTATION DE DEVIS\n\nLe client ' + C + ' accepte le devis n° ……… de ' + E + ' relatif au projet « ' + P + ' », pour un montant de ……… , aux conditions de paiement suivantes : ………';
  if (type === 'autre') return '';
  return 'CONTRAT DE TRAVAUX\n\nEntre ' + E + ' (« l’entrepreneur ») et ' + C + ' (« le client »).\n\nOBJET\nL’entrepreneur réalise pour le client les travaux du projet « ' + P + ' » situé à ' + L + ', décrits dans le devis / DQE : ………\n\nOBLIGATIONS\nL’entrepreneur exécute les travaux selon les règles de l’art et les plans validés. Le client donne l’accès au chantier et règle les sommes dues aux échéances prévues.' + common;
}

/* ---------- état ---------- */
var st = { tab: 'p', ed: null, edDoc: null, ret: null, retAt: 0, busy: false, msg: '' };
function blankEd() { var pr = G('exb_projects')[0] || {}; return { id: '', token: '', kind: 'client', pid: pr.id || '', titre: '', dest: '', tel: '', email: '', code: String(100000 + Math.floor(Math.random() * 900000)), expDays: 90,
  opts: { avanc: true, jalons: '', photos: 12, journal: 5, fin: true, docs: [], lots: '' } }; }
function projOf(id) { return G('exb_projects').find(function (x) { return x.id === id; }) || {}; }
function clientOf(name) { var n = String(name || '').trim().toLowerCase(); if (!n) return {}; return G('exb_clients').find(function (c) { return String(c.full_name || '').toLowerCase() === n || String(c.company || '').toLowerCase() === n; }) || {}; }

/* ---------- instantané publié ---------- */
function shrink(u, mw, q) { return new Promise(function (res) { if (!/^data:image\//.test(u || '')) return res(''); var im = new Image(); im.onload = function () { try { var r = Math.min(1, mw / Math.max(im.width, im.height)), c = d.createElement('canvas'); c.width = Math.max(1, Math.round(im.width * r)); c.height = Math.max(1, Math.round(im.height * r)); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); var o = c.toDataURL('image/jpeg', q); res(o.length < 110000 ? o : ''); } catch (e) { res(''); } }; im.onerror = function () { res(''); }; im.src = u; }); }
function lines(t) { return String(t || '').split(/\r?\n/).map(function (l) { return l.split('|').map(function (x) { return x.trim(); }); }).filter(function (a) { return a[0]; }); }
async function snapshot(r) {
  var o = r.opts, I = ident(), pr = projOf(r.pid), C = { v: 1, entreprise: { nom: I.name || '', tel: I.phone || '', email: I.email || '', adresse: I.address || '' } };
  if (o.avanc) C.projet = { nom: pr.name || r.titre, lieu: pr.location || '', debut: pr.start || '', fin: pr.end || '', statut: pr.status || '', avancement: Number(pr.progress) || 0 };
  C.jalons = lines(o.jalons).map(function (a) { return { nom: a[0], pct: Math.max(0, Math.min(100, Number(a[1]) || 0)) }; });
  if (r.kind === 'soustraitant') C.lots = lines(o.lots).map(function (a) { return { nom: a[0], montant: a[1] !== undefined && a[1] !== '' ? Number(a[1]) : null, cur: /fc|cdf/i.test(a[2] || '') ? 'FC' : 'USD' }; });
  var J = G('exb_site_journal').filter(function (j) { return j.project_id === r.pid; }).sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); });
  if (o.journal > 0 && r.kind === 'client') C.journal = J.slice(0, o.journal).map(function (j) { return { d: j.date, meteo: j.weather || '', effectif: j.crew || '', travaux: j.work || '' }; });
  if (o.photos > 0 && r.kind === 'client') { C.photos = []; for (var i = 0; i < J.length && C.photos.length < o.photos; i++) { var ph = J[i].photos || []; for (var k = 0; k < ph.length && C.photos.length < o.photos; k++) { var u = await shrink(ph[k], 520, .62); if (u) C.photos.push({ d: J[i].date, t: String(J[i].work || '').slice(0, 60), u: u }); } } }
  if (o.fin && r.kind === 'client') {
    var F = G('exb_finance').filter(function (x) { return x.project === r.pid && x.type !== 'taux'; }), pay = F.filter(function (x) { return x.type === 'paiement'; }), res = {};
    C.finances = F.filter(function (x) { return x.type !== 'devis' || x.status === 'accepté' || x.status === 'envoyé'; }).sort(function (a, b) { return String(a.date).localeCompare(String(b.date)); }).map(function (x) {
      var paid = x.type === 'facture' ? pay.filter(function (p) { return p.parent === x.id; }).reduce(function (s, p) { return s + (Number(p.ttc) || 0); }, 0) : 0, stt = x.status || '';
      if (x.type === 'facture') stt = paid >= (Number(x.ttc) || 0) - .005 ? 'Payée' : paid > 0 ? 'Partiellement payée' : 'À payer'; if (x.type === 'paiement') stt = 'Reçu';
      return { type: x.type, no: x.no, date: x.date, cur: x.cur, ttc: Number(x.ttc) || 0, statut: stt }; });
    F.forEach(function (x) { var c = x.cur === 'FC' ? 'FC' : 'USD'; res[c] = res[c] || { facture: 0, paye: 0, reste: 0 }; if (x.type === 'facture') res[c].facture += Number(x.ttc) || 0; if (x.type === 'paiement') res[c].paye += Number(x.ttc) || 0; });
    Object.keys(res).forEach(function (c) { res[c].reste = Math.max(0, res[c].facture - res[c].paye); }); C.resume = res;
  }
  var DOC = G('exb_esign'); C.documents = [];
  (o.docs || []).forEach(function (id) { var x = DOC.find(function (y) { return y.id === id; }); if (x) C.documents.push({ id: x.id, titre: x.titre + (x.v > 1 ? ' (version ' + x.v + ')' : ''), type: (TYPES.find(function (t) { return t[0] === x.type; }) || [0, 'Document'])[1], texte: x.texte, hash: x.hash, roles: x.roles, date: x.date }); });
  return C;
}

/* ---------- portails ---------- */
function portals() { return G('exb_portails'); }
async function publish(r) {
  if (!isIn()) throw new Error('Connectez-vous au compte en ligne pour publier.'); needOrg();
  var C = await snapshot(r);
  var exp = r.expDays > 0 ? new Date(Date.now() + r.expDays * 864e5).toISOString().slice(0, 10) : null;
  var sendCode = !r.token || (r.code && r.code !== r.codeOnServer);
  var res = await rpc('portail_publier', { p_org: org(), p_token: r.token || null, p_kind: r.kind, p_titre: r.titre, p_dest: r.dest, p_code: sendCode ? r.code : '', p_contenu: C, p_expire: exp });
  var DOC = G('exb_esign'); (r.opts.docs || []).forEach(function (id) { var x = DOC.find(function (y) { return y.id === id; }); if (x && !x.locked) { x.locked = true; x.published = new Date().toISOString(); } }); Pu('exb_esign', DOC);
  r.token = res.token; if (sendCode) setCode(r.id, { code: r.code, srv: r.code }); delete r.code; delete r.codeOnServer; r.pub = new Date().toISOString(); r.exp = exp; r.actif = true; r.size = JSON.stringify(C).length;
  return r;
}
function savePortal(r) { var L = portals(), i = L.findIndex(function (x) { return x.id === r.id; }); if (i >= 0) L[i] = r; else L.unshift(r); Pu('exb_portails', L); }

/* ---------- documents à signer ---------- */
function docs() { return G('exb_esign'); }
function docStatus(x) { var need = ['entreprise'].concat(x.roles || []), got = need.filter(function (r) { return x.sig && x.sig[r]; }); if (got.length === need.length) return ['Signé par toutes les parties', 'ok']; if (!got.length) return [x.locked ? 'En attente de signatures' : 'Brouillon', x.locked ? 'wa' : 'mu']; return ['Signé par ' + got.map(function (r) { return r === 'entreprise' ? 'l’entreprise' : r === 'client' ? 'le client' : 'le sous-traitant'; }).join(' et '), 'wa']; }
function padHtml() { return '<canvas id="ptPad" width="600" height="220" style="width:100%;height:150px;border:1px dashed #94a3b8;border-radius:10px;background:#fff;touch-action:none;display:block"></canvas><div style="margin:6px 0"><button class="pt-s" data-act="padClr" type="button">Effacer</button></div>'; }
function padInit() { var cv = $('ptPad'); if (!cv) return null; var cx = cv.getContext('2d'), dr = false, lx = 0, ly = 0, o = { any: false, cv: cv }; cx.lineWidth = 3; cx.lineCap = 'round'; cx.strokeStyle = '#0b1b4a';
  function pt(e) { var r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; }
  cv.onpointerdown = function (e) { dr = true; var p = pt(e); lx = p[0]; ly = p[1]; try { cv.setPointerCapture(e.pointerId); } catch (x) {} e.preventDefault(); };
  cv.onpointermove = function (e) { if (!dr) return; var p = pt(e); cx.beginPath(); cx.moveTo(lx, ly); cx.lineTo(p[0], p[1]); cx.stroke(); lx = p[0]; ly = p[1]; o.any = true; e.preventDefault(); };
  cv.onpointerup = cv.onpointercancel = function () { dr = false; };
  o.clear = function () { cx.clearRect(0, 0, cv.width, cv.height); o.any = false; };
  o.png = function () { var c = d.createElement('canvas'); c.width = 400; c.height = 147; var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, 400, 147); x.drawImage(cv, 0, 0, 400, 147); return c.toDataURL('image/png'); }; return o; }
function modal(html, onOpen) { var o = $('ptModal'); if (o) o.remove(); o = d.createElement('div'); o.id = 'ptModal'; o.className = 'no-print'; o.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);display:flex;align-items:flex-start;justify-content:center;overflow:auto;padding:16px'; o.innerHTML = '<div class="pt-card" style="max-width:560px;width:100%;margin:auto">' + html + '</div>'; o.addEventListener('click', function (e) { if (e.target === o) o.remove(); }); d.body.appendChild(o); if (onOpen) onOpen(o); return o; }
var PAD = null;
function signModal(id) {
  var x = docs().find(function (y) { return y.id === id; }); if (!x) return; var vis = null;
  modal('<h3>✍️ Signature de l’entreprise</h3><p class="pt-mu">' + esc(x.titre) + ' · empreinte ' + esc((x.hash || '').slice(0, 12)) + '…</p><label>Nom du signataire</label><input id="ptSn" maxlength="120" placeholder="Nom et prénom" value="' + esc(ident().dg || '') + '"><label>Fonction</label><input id="ptSf" maxlength="80" placeholder="Directeur général…" value="' + esc(ident().dg ? ident().dgRole : '') + '">' + padHtml() + '<div id="ptVisi"></div><p class="pt-err" id="ptSe"></p><div class="pt-row"><button class="pt-s" data-act="close" type="button">Annuler</button><button data-act="signGo" data-id="' + esc(id) + '" type="button">Signer</button></div>',
    function () { PAD = padInit(); try { if (w.EXBSign && w.EXBSign.active && w.EXBSign.active() && w.EXBId && w.EXBId.visa) { $('ptVisi').innerHTML = '<button class="pt-s" data-act="useVisa" type="button">Utiliser ma signature et mon cachet enregistrés</button>'; } } catch (e) {} });
}
async function printDoc(id) {
  var x = docs().find(function (y) { return y.id === id; }); if (!x) return; var I = ident(), R = { entreprise: 'Entreprise', client: 'Client', soustraitant: 'Sous-traitant' };
  var s = ['entreprise'].concat(x.roles || []).map(function (r) { var g = x.sig && x.sig[r]; return '<div style="border:1px solid #999;border-radius:8px;padding:8px;margin:6px 0;break-inside:avoid"><b>' + R[r] + '</b> — ' + (g ? esc(g.nom) + (g.fonction ? ', ' + esc(g.fonction) : '') + '<br>Signé le ' + fr(g.at, 1) + (g.image ? '<br><img src="' + esc(g.image) + '" style="height:70px">' : '') : '<i>non signé</i>') + '</div>'; }).join('');
  var win = w.open('', '_blank'); if (!win) return;
  win.document.write('<!doctype html><meta charset="utf-8"><title>' + esc(x.titre) + '</title><body style="font:14px/1.5 system-ui;max-width:720px;margin:24px auto;color:#000"><h2>' + esc(x.titre) + (x.v > 1 ? ' — version ' + x.v : '') + '</h2><div style="color:#555">' + esc(I.name || '') + ' · ' + fr(x.date) + '</div><pre style="white-space:pre-wrap;font:inherit;margin:14px 0">' + esc(x.texte) + '</pre><h3>Signatures électroniques</h3>' + s + '<p style="font-size:12px;color:#444">Empreinte SHA-256 du document (titre + texte) : <code style="word-break:break-all">' + esc(x.hash) + '</code><br>Signature électronique simple : nom, tracé, acceptation, date et heure, empreinte du contenu. Toute modification du texte change l’empreinte.</p><script>onload=function(){print()}<\/script></body>'); win.document.close();
}

/* ---------- relances ---------- */
function queue() { return G('exb_msg_queue'); }
function pushQ(items) { var Q = queue(), n = 0; items.forEach(function (it) { if (Q.some(function (q) { return q.key === it.key; })) return; Q.unshift(Object.assign({ id: uid('MSG'), created: new Date().toISOString(), status: 'a_envoyer' }, it)); n++; }); if (n) Pu('exb_msg_queue', Q); return n; }
function analyze() {
  var c = cfg(), I = ident(), out = [], F = G('exb_finance'), P = G('exb_projects'), pay = F.filter(function (x) { return x.type === 'paiement'; });
  function who(pid) { var p = P.find(function (x) { return x.id === pid; }) || {}, cl = clientOf(p.client); return { p: p, nom: cl.full_name || p.client || 'Madame, Monsieur', tel: cl.phone || '', email: cl.email || '' }; }
  if (c.on.facture) F.filter(function (x) { return x.type === 'facture'; }).forEach(function (f) { var paid = pay.filter(function (p) { return p.parent === f.id; }).reduce(function (s, p) { return s + (Number(p.ttc) || 0); }, 0), reste = (Number(f.ttc) || 0) - paid, j = days(f.date); if (reste > .005 && j >= c.factureJ) { var q = who(f.project); out.push({ key: 'F:' + f.id + ':' + Math.floor(j / 15), rule: 'facture', objet: 'Facture ' + (f.no || '') + ' à régler', nom: q.nom, tel: q.tel, email: q.email, texte: fill(c.tpl.facture, { nom: q.nom, projet: q.p.name || '', no: f.no || '', montant: money(reste, f.cur), jours: j, date: fr(f.date), entreprise: I.name || '' }) }); } });
  if (c.on.situation) F.filter(function (x) { return x.type === 'situation'; }).forEach(function (s) { var j = days(s.date); if (j >= c.situationJ && !F.some(function (f) { return f.type === 'facture' && f.parent === s.id; })) { var q = who(s.project); out.push({ key: 'S:' + s.id, rule: 'situation', objet: 'Situation ' + (s.no || '') + ' à valider', nom: q.nom, tel: q.tel, email: q.email, texte: fill(c.tpl.situation, { nom: q.nom, projet: q.p.name || '', no: s.no || '', montant: money(s.ttc, s.cur), jours: j, date: fr(s.date), entreprise: I.name || '' }) }); } });
  if (c.on.signature) { var PL = portals(); docs().forEach(function (x) { if (!x.locked) return; var need = (x.roles || []).filter(function (r) { return !(x.sig && x.sig[r]); }), j = days(x.published || x.date); if (!need.length || j < c.signatureJ) return; var pt = PL.find(function (p) { return p.actif && (p.opts.docs || []).indexOf(x.id) >= 0; }); if (!pt) return; out.push({ key: 'G:' + x.id + ':' + Math.floor(j / c.signatureJ), rule: 'signature', objet: 'Signature en attente : ' + x.titre, nom: pt.dest || 'Madame, Monsieur', tel: pt.tel, email: pt.email, texte: fill(c.tpl.signature, { nom: pt.dest || '', no: x.titre, jours: j, lien: pt.token ? linkOf(pt.token) : '', entreprise: I.name || '' }) }); }); }
  if (c.on.retard) P.forEach(function (p) { if (p.end && p.end < today() && (Number(p.progress) || 0) < 100 && !/termin|clos|livr/i.test(p.status || '')) out.push({ key: 'R:' + p.id + ':' + today().slice(0, 7), rule: 'retard', interne: true, objet: 'Retard : ' + p.name, nom: 'Interne', tel: '', email: '', texte: fill(c.tpl.retard, { projet: p.name, date: fr(p.end), montant: (Number(p.progress) || 0) + ' %' }) }); });
  return pushQ(out);
}
function openChan(q, how) { var txt = q.texte, num = phoneNorm(q.tel); if (how === 'wa') w.open('https://wa.me/' + num + '?text=' + encodeURIComponent(txt), '_blank', 'noopener'); else if (how === 'sms') w.location.href = 'sms:' + (q.tel || '') + '?body=' + encodeURIComponent(txt); else if (how === 'mail') w.location.href = 'mailto:' + (q.email || '') + '?subject=' + encodeURIComponent(q.objet || '') + '&body=' + encodeURIComponent(txt); else if (how === 'copy') { try { navigator.clipboard.writeText(txt); say('Message copié.'); } catch (e) { prompt('Copiez le message :', txt); } return; }
  var Q = queue(), i = Q.findIndex(function (x) { return x.id === q.id; }); if (i >= 0) { Q[i].status = 'envoye'; Q[i].canal = how; Q[i].sent = new Date().toISOString(); Pu('exb_msg_queue', Q); } setTimeout(render, 400); }

/* ---------- retours du serveur ---------- */
/* V117 : réponse à un client depuis la Messagerie (même appel que « Répondre » du module Portails) */
w.EXBPortailRepondre = async function (token, texte) {
  if (!isIn()) throw new Error('Connectez-vous au compte en ligne pour répondre au client.');
  var t = String(texte || '').trim(); if (!t) throw new Error('Écrivez la réponse.');
  await rpc('portail_repondre', { p_token: token, p_texte: t }); await pullRet(true);
};
async function pullRet(silent) {
  if (!isIn()) { if (!silent) say('Connectez-vous au compte en ligne pour lire les retours.', 'warn'); return; }
  try { needOrg(); var r = await rpc('portail_retours', { p_org: org() }); st.ret = r; st.retAt = Date.now(); try { if (w.EXBMessagerie) { var _tt = {}; portals().forEach(function (x) { _tt[x.token] = x.titre || x.title || x.nom || x.name || ''; }); w.EXBMessagerie.ingestClients(r.messages || [], _tt); w.EXBMessagerie.ingestDeclarations(r.declarations || []); } } catch (e) { /* messagerie facultative */ } var D = docs(), PL = portals(), n = 0;
    (r.signatures || []).forEach(function (s) { var pl = PL.find(function (p) { return p.token === s.token; }); var x = D.find(function (y) { return y.id === s.doc_id; }); if (!x) return; x.sig = x.sig || {}; if (!x.sig[s.role]) { x.sig[s.role] = { nom: s.nom, image: s.image, at: s.signe_le, hash: s.doc_hash, agent: s.agent, mismatch: s.doc_hash !== x.hash }; n++; } });
    if (n) { Pu('exb_esign', D); say(n + ' nouvelle(s) signature(s) reçue(s).'); }
    (r.liens || []).forEach(function (l) { var p = PL.find(function (x) { return x.token === l.token; }); if (p) { p.visites = l.visites; p.lastVisit = l.derniere_visite; if (!l.actif) p.actif = false; } }); Pu('exb_portails', PL);
    var seen = 0; try { seen = Number(localStorage.getItem('exb_pt_seen') || 0); } catch (e) {} st.newMsg = (r.messages || []).filter(function (m) { return m.de === 'visiteur' && new Date(m.cree_le).getTime() > seen; }).length; st.newDecl = (r.declarations || []).filter(function (x) { return x.statut === 'a_verifier'; }).length; try { if (w.EXBALERT) { w.EXBALERT.signal('pt_msg', st.newMsg); w.EXBALERT.signal('pt_decl', st.newDecl); } } catch (e) { }
    render(); } catch (e) { if (!silent) say('Lecture impossible : ' + (e.message || e) + ' (le script SQL V99zn a-t-il été exécuté ?)', 'error'); }
}

/* ---------- rendu ---------- */
var CSS = '#portails .pt-card,.pt-card{background:var(--card,#fff);color:inherit;border:1px solid var(--line,#dbe3ef);border-radius:14px;padding:14px;margin:0 0 12px}#portails input,#portails select,#portails textarea,#ptModal input,#ptModal select,#ptModal textarea{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:10px;margin:3px 0 8px;font:inherit;box-sizing:border-box}#portails label,#ptModal label{font-size:13px;color:#64748b}#portails textarea,#ptModal textarea{min-height:70px}.pt-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.pt-tabs{display:flex;gap:6px;overflow-x:auto;margin-bottom:12px}.pt-tabs button{flex:0 0 auto}.pt-mu{color:#64748b;font-size:13px}.pt-err{color:#b91c1c;min-height:18px;font-size:13px}.pt-ok{color:#15803d}.pt-wa{color:#b45309}.pt-tag{display:inline-block;padding:2px 9px;border-radius:99px;font-size:12px;font-weight:700;background:#eef3fb;border:1px solid #dbe3ef}.pt-s{background:#eef3fb!important;color:#14213d!important;border:1px solid #cbd5e1!important}#portails details{margin:6px 0}#portails .pt-chk{display:flex;gap:8px;align-items:center;margin:4px 0}#portails .pt-chk input{width:auto;margin:0}';
function F(id, label, val, extra) { return '<label>' + label + '</label><input data-f="' + id + '" value="' + esc(val) + '" ' + (extra || '') + '>'; }
function viewPortals() {
  var e = st.ed, h = '';
  if (!isIn()) h += '<div class="pt-card pt-wa">⚠️ Pour publier ou lire les retours, connectez-vous au compte en ligne (⚙️ Administration › Compte). Vous pouvez préparer les documents et les relances sans connexion.</div>';
  if (e) { var P = G('exb_projects'), DOCS = docs().filter(function (x) { return (x.roles || []).indexOf(e.kind) >= 0 && (!x.pid || x.pid === e.pid); });
    h += '<div class="pt-card"><h3>' + (e.id ? 'Modifier le portail' : 'Nouveau portail') + '</h3><label>Type</label><select data-f="kind">' + opt([['client', 'Portail client (maître d’ouvrage)'], ['soustraitant', 'Portail sous-traitant']], e.kind) + '</select><label>Projet</label><select data-f="pid">' + (P.length ? opt(P.map(function (p) { return [p.id, p.name]; }), e.pid) : '<option value="">Aucun projet</option>') + '</select>' + F('titre', 'Titre affiché', e.titre, 'placeholder="Suivi de chantier"') + F('dest', e.kind === 'client' ? 'Nom du client' : 'Nom du sous-traitant', e.dest) + '<div class="pt-row"><div style="flex:1 1 140px">' + F('tel', 'Téléphone (WhatsApp / SMS)', e.tel, 'inputmode="tel"') + '</div><div style="flex:1 1 160px">' + F('email', 'E-mail', e.email, 'inputmode="email"') + '</div></div>'
      + '<div class="pt-chk"><input type="checkbox" id="ptAv" data-o="avanc"' + (e.opts.avanc ? ' checked' : '') + '><label for="ptAv" style="margin:0;color:inherit">Afficher l’avancement du projet (' + (Number(projOf(e.pid).progress) || 0) + ' %)</label></div><label>Jalons (une ligne : nom | % réalisé)</label><textarea data-o="jalons" placeholder="Fondations | 100&#10;Élévation | 40">' + esc(e.opts.jalons) + '</textarea>';
    if (e.kind === 'client') h += '<div class="pt-row"><div style="flex:1 1 120px"><label>Photos du journal</label><select data-o="photos">' + opt([[0, 'Aucune'], [4, '4 dernières'], [8, '8 dernières'], [12, '12 dernières'], [20, '20 dernières'], [30, '30 dernières']], e.opts.photos) + '</select></div><div style="flex:1 1 120px"><label>Entrées du journal</label><select data-o="journal">' + opt([[0, 'Aucune'], [3, '3 dernières'], [5, '5 dernières'], [10, '10 dernières']], e.opts.journal) + '</select></div></div><div class="pt-chk"><input type="checkbox" id="ptFin" data-o="fin"' + (e.opts.fin ? ' checked' : '') + '><label for="ptFin" style="margin:0;color:inherit">Afficher factures, situations et paiements</label></div><p class="pt-mu">Rien de interne (incidents, notes, coûts, marges) n’est publié.</p>';
    else h += '<label>Lots du marché (une ligne : lot | montant | USD ou FC)</label><textarea data-o="lots" placeholder="Maçonnerie | 12000 | USD">' + esc(e.opts.lots) + '</textarea>';
    h += '<label>Documents à signer</label>' + (DOCS.length ? DOCS.map(function (x) { return '<div class="pt-chk"><input type="checkbox" data-doc="' + esc(x.id) + '"' + ((e.opts.docs || []).indexOf(x.id) >= 0 ? ' checked' : '') + '><span>' + esc(x.titre) + (x.v > 1 ? ' (v' + x.v + ')' : '') + '</span></div>'; }).join('') : '<div class="pt-mu">Aucun document pour ce type. Créez-en dans l’onglet Signatures.</div>')
      + '<div class="pt-row"><div style="flex:1 1 120px"><label>Validité du lien</label><select data-f="expDays">' + opt([[30, '30 jours'], [90, '90 jours'], [180, '6 mois'], [365, '1 an'], [0, 'Sans limite']], e.expDays) + '</select></div><div style="flex:1 1 120px">' + F('code', e.token && !e.code ? 'Nouveau code (laisser vide pour ne pas le changer)' : 'Code d’accès (6 chiffres)', e.code, 'inputmode="numeric" maxlength="12"') + '</div></div><p class="pt-err" id="ptErr">' + esc(st.msg) + '</p><div class="pt-row"><button data-act="pubGo" type="button"' + (st.busy ? ' disabled' : '') + '>' + (st.busy ? 'Publication…' : '🚀 Publier') + '</button><button class="pt-s" data-act="edCancel" type="button">Annuler</button></div></div>';
  } else h += '<div class="pt-row" style="margin-bottom:10px"><button data-act="newP" type="button">➕ Nouveau portail</button></div>';
  var L = portals();
  h += L.length ? L.map(function (p) { var pr = projOf(p.pid); return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><b>' + (p.kind === 'client' ? '👤 ' : '🧱 ') + esc(p.titre) + '</b><span class="pt-tag ' + (p.actif === false ? 'pt-wa' : 'pt-ok') + '">' + (p.actif === false ? 'Révoqué' : p.exp && p.exp < today() ? 'Expiré' : 'Actif') + '</span></div><div class="pt-mu">' + esc(p.dest || '') + ' · ' + esc(pr.name || '') + '</div><div class="pt-mu">Publié le ' + fr(p.pub, 1) + (p.exp ? ' · valable jusqu’au ' + fr(p.exp) : '') + (p.visites != null ? ' · ' + p.visites + ' visite(s)' : '') + (p.lastVisit ? ', dernière le ' + fr(p.lastVisit, 1) : '') + '</div><div class="pt-row" style="margin-top:8px"><button class="pt-s" data-act="pLink" data-id="' + p.id + '" type="button">📨 Envoyer le lien</button><button class="pt-s" data-act="pCode" data-id="' + p.id + '" type="button">🔑 Envoyer le code</button><button class="pt-s" data-act="pQr" data-id="' + p.id + '" type="button">QR</button>' + (p.kind === 'client' && p.actif !== false ? '<button class="pt-s" data-act="pAcc" data-id="' + p.id + '" type="button">🔐 Compte client</button>' : '') + '' + (p.kind === 'client' && p.actif !== false ? '<button class="pt-s" data-act="pPlan" data-id="' + p.id + '" type="button">📐 Envoyer un plan</button><button class="pt-s" data-act="pPlans" data-id="' + p.id + '" type="button">📋 Plans envoyés</button>' : '') + '<button class="pt-s" data-act="pRe" data-id="' + p.id + '" type="button">↻ Mettre à jour</button><button class="pt-s" data-act="pEd" data-id="' + p.id + '" type="button">✏️</button><button class="pt-s" data-act="pRev" data-id="' + p.id + '" type="button">⛔ Révoquer</button><button class="pt-s" data-act="pDel" data-id="' + p.id + '" type="button">🗑️</button></div></div>'; }).join('') : (e ? '' : '<div class="pt-card pt-mu">Aucun portail publié. Créez-en un pour partager l’avancement, les photos et les documents avec votre client ou votre sous-traitant.</div>');
  return h;
}
function viewDocs() {
  var e = st.edDoc, h = '', P = G('exb_projects');
  if (e) h += '<div class="pt-card"><h3>' + (e.id ? 'Modifier le document' : 'Nouveau document à signer') + '</h3><label>Type</label><select data-d="type">' + opt(TYPES.map(function (t) { return [t[0], t[1]]; }), e.type) + '</select><label>Projet</label><select data-d="pid"><option value="">—</option>' + opt(P.map(function (p) { return [p.id, p.name]; }), e.pid) + '</select><label>Signataire externe</label><select data-d="role">' + opt([['client', 'Client / maître d’ouvrage'], ['soustraitant', 'Sous-traitant']], e.role) + '</select>' + '<label>Titre</label><input data-d="titre" value="' + esc(e.titre) + '" maxlength="160"><div class="pt-row" style="justify-content:space-between"><label>Texte</label><button class="pt-s" data-act="dModel" type="button">📄 Insérer le modèle</button></div><textarea data-d="texte" style="min-height:240px">' + esc(e.texte) + '</textarea><p class="pt-mu">Modèles indicatifs : à faire relire par un juriste avant usage. Une fois joint à un portail, le texte est verrouillé.</p><p class="pt-err" id="ptErr">' + esc(st.msg) + '</p><div class="pt-row"><button data-act="dSave" type="button">💾 Enregistrer</button><button class="pt-s" data-act="dCancel" type="button">Annuler</button></div></div>';
  else h += '<div class="pt-row" style="margin-bottom:10px"><button data-act="newD" type="button">➕ Nouveau document</button></div>';
  var L = docs();
  h += L.length ? L.map(function (x) { var s = docStatus(x), pr = projOf(x.pid), mis = Object.keys(x.sig || {}).some(function (r) { return x.sig[r].mismatch; });
    return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><b>' + esc(x.titre) + (x.v > 1 ? ' <span class="pt-mu">v' + x.v + '</span>' : '') + '</b><span class="pt-tag pt-' + s[1] + '">' + s[0] + '</span></div><div class="pt-mu">' + esc((TYPES.find(function (t) { return t[0] === x.type; }) || [0, ''])[1]) + ' · ' + esc(pr.name || 'sans projet') + ' · ' + fr(x.date) + ' · empreinte ' + esc((x.hash || '').slice(0, 10)) + '…</div>' + (mis ? '<div class="pt-err">⚠ Une signature porte sur une empreinte différente du texte actuel.</div>' : '') + '<div class="pt-row" style="margin-top:8px">' + (!(x.sig && x.sig.entreprise) ? '<button data-act="dSign" data-id="' + x.id + '" type="button">✍️ Signer (entreprise)</button>' : '') + '<button class="pt-s" data-act="dPrint" data-id="' + x.id + '" type="button">🖨️ Imprimer / PDF</button>' + (!x.locked ? '<button class="pt-s" data-act="dEd" data-id="' + x.id + '" type="button">✏️ Modifier</button>' : '<button class="pt-s" data-act="dVer" data-id="' + x.id + '" type="button">Nouvelle version</button>') + (!x.locked && !Object.keys(x.sig || {}).length ? '<button class="pt-s" data-act="dDel" data-id="' + x.id + '" type="button">🗑️</button>' : '') + '</div></div>'; }).join('') : (e ? '' : '<div class="pt-card pt-mu">Aucun document. Créez un contrat, un ordre de service ou un PV : le client ou le sous-traitant le signera depuis son portail.</div>');
  return h;
}
function viewRet() {
  var r = st.ret, h = '<div class="pt-row" style="margin-bottom:10px"><button data-act="pull" type="button">↻ Actualiser depuis le serveur</button><span class="pt-mu">' + (st.retAt ? 'Lu à ' + new Date(st.retAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'Pas encore lu') + '</span></div>';
  if (!r) return h + '<div class="pt-card pt-mu">' + (isIn() ? 'Appuyez sur « Actualiser » pour lire les signatures, messages et déclarations.' : 'Connectez-vous au compte en ligne pour lire les retours.') + '</div>';
  var PL = portals(), tt = function (tok) { var p = PL.find(function (x) { return x.token === tok; }); return p ? p.titre : 'Portail'; };
  var D = (r.declarations || []).slice().reverse(), M = (r.messages || []).slice().reverse();
  h += '<div class="pt-card"><h3>📈 Déclarations des sous-traitants</h3>' + (D.length ? D.map(function (x) { var c = x.statut === 'accepte' ? 'ok' : x.statut === 'refuse' ? 'wa' : 'wa'; return '<div style="padding:7px 0;border-bottom:1px solid #dbe3ef"><b>' + esc(x.destinataire || x.titre) + '</b> — ' + esc(x.lot) + ' : <b>' + Number(x.pct) + ' %</b> <span class="pt-tag pt-' + c + '">' + (x.statut === 'accepte' ? 'Acceptée' : x.statut === 'refuse' ? 'Refusée' : 'À vérifier') + '</span><div class="pt-mu">' + fr(x.cree_le, 1) + (x.note ? ' · ' + esc(x.note) : '') + '</div>' + (x.statut === 'a_verifier' ? '<div class="pt-row" style="margin-top:6px"><button data-act="dec" data-id="' + x.id + '" data-s="accepte" type="button">✔ Accepter</button><button class="pt-s" data-act="dec" data-id="' + x.id + '" data-s="refuse" type="button">✖ Refuser</button></div>' : '') + '</div>'; }).join('') : '<div class="pt-mu">Aucune déclaration.</div>') + '</div>';
  var byTok = {}; M.forEach(function (m) { (byTok[m.token] = byTok[m.token] || []).push(m); });
  h += '<div class="pt-card"><h3>💬 Messages</h3>' + (Object.keys(byTok).length ? Object.keys(byTok).map(function (tok) { var L = byTok[tok].slice().reverse(); return '<div style="padding:7px 0;border-bottom:1px solid #dbe3ef"><b>' + esc(tt(tok)) + '</b>' + L.slice(-4).map(function (m) { return '<div style="margin:4px 0;' + (m.de === 'entreprise' ? 'text-align:right;color:#1d4ed8' : '') + '"><span class="pt-mu">' + (m.de === 'visiteur' ? 'Visiteur' : 'Vous') + ' · ' + fr(m.cree_le, 1) + '</span><br>' + esc(m.texte) + '</div>'; }).join('') + '<div class="pt-row"><input data-rep="' + esc(tok) + '" placeholder="Répondre…" style="flex:1"><button data-act="rep" data-id="' + esc(tok) + '" type="button">Envoyer</button></div></div>'; }).join('') : '<div class="pt-mu">Aucun message.</div>') + '</div>';
  var S = (r.signatures || []); h += '<div class="pt-card"><h3>✍️ Signatures reçues</h3>' + (S.length ? S.slice().reverse().map(function (s) { return '<div style="padding:5px 0;border-bottom:1px solid #dbe3ef"><b>' + esc(s.doc_titre) + '</b><div class="pt-mu">' + esc(s.nom) + ' (' + (s.role === 'client' ? 'client' : 'sous-traitant') + ') · ' + fr(s.signe_le, 1) + '</div></div>'; }).join('') : '<div class="pt-mu">Aucune signature.</div>') + '</div>';
  return h;
}
function viewRel() {
  var c = cfg(), Q = queue(), pend = Q.filter(function (q) { return q.status === 'a_envoyer'; }), h = '<div class="pt-row" style="margin-bottom:10px"><button data-act="analyze" type="button">🔎 Analyser maintenant</button><span class="pt-mu">Les messages sont préparés automatiquement ; vous les envoyez d’un appui.</span></div>';
  h += pend.length ? pend.map(function (q) { return '<div class="pt-card"><div class="pt-row" style="justify-content:space-between"><b>' + esc(q.objet) + '</b><span class="pt-tag">' + ({ facture: 'Facture', situation: 'Situation', signature: 'Signature', retard: 'Retard', publication: 'Publication' }[q.rule] || q.rule) + '</span></div><div class="pt-mu">Pour ' + esc(q.nom) + (q.tel ? ' · ' + esc(q.tel) : '') + (q.email ? ' · ' + esc(q.email) : '') + '</div><div style="margin:6px 0;white-space:pre-wrap">' + esc(q.texte) + '</div><div class="pt-row">' + (q.interne ? '' : '<button data-act="send" data-how="wa" data-id="' + q.id + '" type="button">WhatsApp</button><button class="pt-s" data-act="send" data-how="sms" data-id="' + q.id + '" type="button">SMS</button><button class="pt-s" data-act="send" data-how="mail" data-id="' + q.id + '" type="button">E-mail</button>') + '<button class="pt-s" data-act="send" data-how="copy" data-id="' + q.id + '" type="button">Copier</button><button class="pt-s" data-act="qDone" data-id="' + q.id + '" type="button">' + (q.interne ? 'Vu' : 'Déjà envoyé') + '</button><button class="pt-s" data-act="qIgn" data-id="' + q.id + '" type="button">Ignorer</button></div></div>'; }).join('') : '<div class="pt-card pt-mu">Aucune relance à envoyer.</div>';
  h += '<details class="pt-card"><summary><b>⚙️ Règles et modèles</b></summary>' + [['facture', 'Facture non soldée depuis plus de', 'factureJ', 'jours'], ['situation', 'Situation non facturée depuis plus de', 'situationJ', 'jours'], ['signature', 'Document non signé depuis plus de', 'signatureJ', 'jours'], ['retard', 'Projet en retard (date de fin dépassée)', '', ''], ['publication', 'Annoncer chaque mise à jour de portail au client', '', '']].map(function (r) { return '<div class="pt-chk"><input type="checkbox" data-rule="' + r[0] + '"' + (c.on[r[0]] ? ' checked' : '') + '><span>' + r[1] + (r[2] ? ' <input type="number" min="1" data-rn="' + r[2] + '" value="' + c[r[2]] + '" style="width:70px;display:inline-block;margin:0"> ' + r[3] : '') + '</span></div>'; }).join('') + '<p class="pt-mu">Variables : {nom} {projet} {no} {montant} {jours} {date} {lien} {entreprise}</p>' + ['facture', 'situation', 'signature', 'publication'].map(function (k) { return '<label>Modèle « ' + k + ' »</label><textarea data-tpl="' + k + '">' + esc(c.tpl[k]) + '</textarea>'; }).join('') + '<button data-act="cfgSave" type="button">Enregistrer</button></details>';
  var done = Q.filter(function (q) { return q.status !== 'a_envoyer'; }).slice(0, 8); if (done.length) h += '<div class="pt-card"><h3>Historique</h3>' + done.map(function (q) { return '<div class="pt-mu" style="padding:3px 0">' + (q.status === 'envoye' ? '✔ ' : '— ') + esc(q.objet) + ' · ' + esc(q.nom) + (q.canal ? ' · ' + q.canal : '') + '</div>'; }).join('') + '</div>';
  h += '<p class="pt-mu">L’envoi se fait depuis votre téléphone (WhatsApp, SMS, e-mail). Un envoi entièrement automatique demande une passerelle (WhatsApp Business API, fournisseur SMS) qui n’est pas incluse.</p>';
  return h;
}
function render() {
  var el = $('portails'); if (!el || el.style.display === 'none') return; var pend = queue().filter(function (q) { return q.status === 'a_envoyer'; }).length;
  var T = [['p', '🔗 Portails'], ['s', '✍️ Signatures'], ['r', '📥 Retours' + ((st.newDecl || 0) + (st.newMsg || 0) ? ' (' + ((st.newDecl || 0) + (st.newMsg || 0)) + ')' : '')], ['n', '🔔 Relances' + (pend ? ' (' + pend + ')' : '')]];
  el.innerHTML = '<style>' + CSS + '</style><div class="pt-card"><h2 style="margin:0 0 4px">🔗 Portails & signatures</h2><div class="pt-mu">Partagez l’avancement avec vos clients et sous-traitants, faites signer vos contrats, relancez sans oublier.</div></div><div class="pt-tabs">' + T.map(function (t) { return '<button type="button" data-act="tab" data-id="' + t[0] + '"' + (st.tab === t[0] ? '' : ' class="pt-s"') + '>' + t[1] + '</button>'; }).join('') + '</div>' + (st.tab === 'p' ? viewPortals() : st.tab === 's' ? viewDocs() : st.tab === 'r' ? viewRet() : viewRel());
}

/* ---------- actions ---------- */
function setField(t) { if (t.dataset.f && st.ed) { var k = t.dataset.f; st.ed[k] = (k === 'expDays') ? Number(t.value) : t.value; if (k === 'kind') { st.ed.opts.docs = []; render(); } if (k === 'pid') { var pr = projOf(t.value), cl = clientOf(pr.client); if (!st.ed.titre) st.ed.titre = 'Suivi — ' + (pr.name || ''); if (st.ed.kind === 'client') { st.ed.dest = pr.client || st.ed.dest; st.ed.tel = cl.phone || st.ed.tel; st.ed.email = cl.email || st.ed.email; } render(); } }
  else if (t.dataset.o && st.ed) { var o = t.dataset.o; st.ed.opts[o] = t.type === 'checkbox' ? t.checked : (['photos', 'journal'].indexOf(o) >= 0 ? Number(t.value) : t.value); }
  else if (t.dataset.doc && st.ed) { var A = st.ed.opts.docs = st.ed.opts.docs || [], i = A.indexOf(t.dataset.doc); if (t.checked && i < 0) A.push(t.dataset.doc); if (!t.checked && i >= 0) A.splice(i, 1); }
  else if (t.dataset.d && st.edDoc) { st.edDoc[t.dataset.d] = t.value; if (t.dataset.d === 'type') { var ty = TYPES.find(function (x) { return x[0] === t.value; }); if (ty) st.edDoc.role = ty[2]; render(); } }
}
async function onAct(a, id, el) {
  var P;
  if (a === 'tab') { st.tab = id; st.msg = ''; if (id === 'r') { pullRet(true); try { localStorage.setItem('exb_pt_seen', String(Date.now())); } catch (e) {} st.newMsg = 0; } if (id === 'n') analyze(); return render(); }
  if (a === 'close') { var m = $('ptModal'); if (m) m.remove(); return; }
  if (a === 'padClr') { if (PAD) PAD.clear(); return; }
  if (a === 'newP') { st.ed = blankEd(); st.msg = ''; return render(); }
  if (a === 'edCancel') { st.ed = null; return render(); }
  if (a === 'pEd') { var p0 = portals().find(function (x) { return x.id === id; }); if (p0) { st.ed = JSON.parse(JSON.stringify(p0)); var cm = codes()[p0.id] || {}; st.ed.code = cm.code || ''; st.ed.codeOnServer = cm.srv || ''; st.msg = ''; render(); } return; }
  if (a === 'pubGo' || a === 'pRe') { var r = a === 'pRe' ? JSON.parse(JSON.stringify(portals().find(function (x) { return x.id === id; }))) : st.ed; if (!r) return; if (a === 'pRe') { var cm2 = codes()[r.id] || {}; r.code = cm2.code || ''; r.codeOnServer = cm2.srv || ''; }
    if (!r.pid) { st.msg = 'Choisissez un projet.'; return render(); } if (!/^\d{6,12}$/.test(r.code || '') && !r.token) { st.msg = 'Le code doit contenir 6 à 12 chiffres.'; return render(); }
    if (!r.id) r.id = uid('PT'); r.titre = r.titre || ('Suivi — ' + (projOf(r.pid).name || '')); st.busy = true; st.msg = ''; render();
    try { await publish(r); savePortal(r); st.ed = null; st.busy = false; 
      if (r.kind === 'client' && cfg().on.publication && r.dest) pushQ([{ key: 'P:' + r.id + ':' + r.pub, rule: 'publication', objet: 'Avancement mis à jour : ' + r.titre, nom: r.dest, tel: r.tel, email: r.email, texte: fill(cfg().tpl.publication, { nom: r.dest, projet: projOf(r.pid).name || '', lien: linkOf(r.token), entreprise: ident().name || '' }) }]);
      render(); say('Portail publié. Envoyez le lien, puis le code par un autre canal.'); } catch (e) { st.busy = false; st.msg = 'Publication impossible : ' + (e.message || e) + (/function|portail_publier/i.test(String(e.message)) ? ' — exécutez supabase/migration-v99zn-portails.sql.' : ''); if (a === 'pRe') say(st.msg, 'error'); render(); }
    return; }
  if (a === 'pLink' || a === 'pCode') { var p = portals().find(function (x) { return x.id === id; }); if (!p) return; var kc = (codes()[p.id] || {}).code;
    if (a === 'pCode' && !kc) { if (!confirm('Le code n’est pas conservé sur cet appareil (il n’est jamais synchronisé). Générer un NOUVEAU code ? L’ancien cessera de fonctionner.')) return; var nr = JSON.parse(JSON.stringify(p)); nr.code = String(100000 + Math.floor(Math.random() * 900000)); nr.codeOnServer = ''; try { await publish(nr); savePortal(nr); p = nr; kc = (codes()[p.id] || {}).code; } catch (e) { say('Échec : ' + (e.message || e), 'error'); return; } }
    p = Object.assign({}, p, { code: kc }); var I = ident(), txt = a === 'pLink' ? 'Bonjour ' + (p.dest || '') + ', voici votre espace de suivi « ' + p.titre + ' » : ' + linkOf(p.token) + '\n(Le code d’accès vous est envoyé séparément.) — ' + (I.name || '') : 'Code d’accès à votre espace de suivi « ' + p.titre + ' » : ' + p.code + ' — ' + (I.name || '');
    openChan({ id: 'x', texte: txt, tel: p.tel, email: p.email, objet: p.titre }, 'wa'); return; }
  if (a === 'pQr') { var q = portals().find(function (x) { return x.id === id; }); if (!q) return; var u = linkOf(q.token), svg = ''; try { svg = w.EXBQR.svg(u, { px: 5, quiet: 2 }); } catch (e) { svg = '<p class="pt-mu">Lien trop long pour un QR.</p>'; } modal('<h3>' + esc(q.titre) + '</h3><div style="max-width:260px;margin:10px auto;background:#fff;padding:8px">' + svg + '</div><p class="pt-mu" style="word-break:break-all">' + esc(u) + '</p><div class="pt-row"><button class="pt-s" data-act="copyL" data-id="' + q.id + '" type="button">Copier le lien</button><button data-act="close" type="button">Fermer</button></div>'); return; }
  if (a === 'pPlan') { var pp = portals().find(function (x) { return x.id === id; }); if (!pp) return;
    var fi = d.createElement('input'); fi.type = 'file'; fi.accept = 'application/pdf,image/png,image/jpeg,image/webp';
    fi.onchange = function () { var f = fi.files && fi.files[0]; if (!f) return;
      if (f.size > 6 * 1048576) { say('Fichier trop lourd (6 Mo maximum). Exportez le plan en PDF allégé.', 'error'); return; }
      if (!/^(application\/pdf|image\/(png|jpeg|webp))$/.test(f.type)) { say('Format accepté : PDF, PNG, JPG ou WebP. Exportez le plan (DXF, IFC, DWG) en PDF.', 'error'); return; }
      var titre = prompt('Titre du plan (ex. Plan R+1). Envoyer un plan du MÊME titre = nouvelle version, signalée « modifié » au client :', f.name.replace(/\.[^.]+$/, '')); if (!titre || !titre.trim()) return;
      var note = prompt('Note pour le client (facultatif, ex. « poteaux déplacés ») :', '') || '';
      var fr2 = new FileReader(); fr2.onload = async function () {
        try { needOrg(); var r2 = await rpc('client_plan_publier', { p_org: org(), p_token: pp.token, p_titre: titre.trim(), p_note: note.trim(), p_data: fr2.result });
          var mod = r2 && r2.version > 1, I3 = ident(), b3 = (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,''));
          say(mod ? 'Plan modifié envoyé (version ' + r2.version + '). Le client le verra à sa prochaine connexion.' : 'Plan envoyé. Le client le verra à sa prochaine connexion.');
          openChan({ id: 'x', texte: 'Bonjour ' + (pp.dest || '') + ', ' + (mod ? 'le plan « ' + titre.trim() + ' » a été modifié (version ' + r2.version + ')' : 'un nouveau plan est disponible : « ' + titre.trim() + ' »') + (note.trim() ? ' — ' + note.trim() : '') + '. Consultez-le dans votre espace client : ' + b3 + 'espace-client.html' + (I3.name ? ' — ' + I3.name : ''), tel: pp.tel, email: pp.email, objet: 'Plan ' + (mod ? 'modifié' : 'nouveau') + ' : ' + titre.trim() }, 'wa');
        } catch (e) { var em = String((e && e.message) || e); say(/function|client_plan_publier/i.test(em) ? 'Envoi impossible : exécutez supabase/migration-v99zzzzzzzzzzzzzzzz-espace-client-plans.sql.' : /fichier_trop_lourd/.test(em) ? 'Fichier trop lourd (6 Mo maximum).' : 'Envoi impossible : ' + em, 'error'); } };
      fr2.readAsDataURL(f); };
    fi.click(); return; }
  if (a === 'pPlans') { var pq = portals().find(function (x) { return x.id === id; }); if (!pq) return;
    try { var sv = await rpc('client_plans_suivi', { p_org: org() }); var mine = (sv || []).filter(function (x) { return x.token === pq.token; });
      modal('<h3 style="margin:0 0 8px">📋 Plans envoyés — ' + esc(pq.titre) + '</h3>' + (mine.length ? mine.map(function (x) { return '<div class="pt-row" style="justify-content:space-between;border-bottom:1px solid #e2e8f0;padding:6px 0"><span><b>' + esc(x.titre) + '</b> · version ' + x.version + '<br><small>Envoyé le ' + fr(x.publie_le, 1) + '</small></span><span class="pt-tag ' + (x.vu_le ? 'pt-ok' : 'pt-wa') + '">' + (x.vu_le ? 'Vu le ' + fr(x.vu_le, 1) : 'Pas encore ouvert') + '</span></div>'; }).join('') : '<p>Aucun plan envoyé.</p>') + '<p><button class="pt-s" type="button" onclick="document.getElementById(\'ptModal\').remove()">Fermer</button></p>');
    } catch (e) { say('Lecture impossible : ' + ((e && e.message) || e), 'error'); } return; }
  if (a === 'pAcc') { var ap = portals().find(function (x) { return x.id === id; }); if (!ap || ap.kind !== 'client') return;
    var mat = prompt('Matricule du client (c’est son identifiant de connexion).\nSon mot de passe provisoire sera ce même matricule ; il devra en choisir un nouveau dès sa première connexion.\nSi le compte existe déjà, il est réinitialisé.', (clientOf(ap.dest) || {}).id || '');
    if (!mat || !mat.trim()) return; mat = mat.trim().toUpperCase();
    try { needOrg(); await rpc('client_compte_creer', { p_org: org(), p_matricule: mat, p_nom: ap.dest || '', p_token: ap.token }); }
    catch (e) { var em = String((e && e.message) || e); say(/matricule_invalide/.test(em) ? 'Matricule invalide (4 à 40 caractères : lettres, chiffres, - . _ /).' : /matricule_pris/.test(em) ? 'Ce matricule est déjà utilisé par une autre organisation.' : /portail_introuvable/.test(em) ? 'Portail introuvable : republiez-le d’abord.' : /function|client_compte_creer/i.test(em) ? 'Compte impossible : exécutez supabase/migration-v99zzzzzzzzzzzzzzz-espace-client.sql.' : 'Compte impossible : ' + em, 'error'); return; }
    var b2 = (window.exbBase?window.exbBase():location.origin+location.pathname.replace(/[^\/]*$/,'')), I2 = ident();
    openChan({ id: 'x', texte: 'Bonjour ' + (ap.dest || '') + ', votre espace client est prêt : ' + b2 + 'espace-client.html\nIdentifiant : ' + mat + '\nMot de passe provisoire : ' + mat + ' (à changer dès la première connexion).' + (I2.name ? ' — ' + I2.name : ''), tel: ap.tel, email: ap.email, objet: 'Votre espace client' }, 'wa');
    say('Compte client créé : identifiant et mot de passe provisoire = ' + mat + '.'); return; }
  if (a === 'copyL') { var c = portals().find(function (x) { return x.id === id; }); try { await navigator.clipboard.writeText(linkOf(c.token)); say('Lien copié.'); } catch (e) { prompt('Copiez le lien :', linkOf(c.token)); } return; }
  if (a === 'pRev') { var rv = portals().find(function (x) { return x.id === id; }); if (!rv || !confirm('Révoquer ce portail ? Le lien cessera de fonctionner immédiatement.')) return; try { await rpc('portail_revoquer', { p_token: rv.token }); rv.actif = false; savePortal(rv); render(); say('Portail révoqué.'); } catch (e) { say('Échec : ' + (e.message || e), 'error'); } return; }
  if (a === 'pDel') { var dp = portals().find(function (x) { return x.id === id; }); if (!dp || !confirm('Retirer ce portail de la liste ? (Pensez à le révoquer d’abord : sinon le lien reste actif.)')) return; Pu('exb_portails', portals().filter(function (x) { return x.id !== id; })); return render(); }
  /* documents */
  if (a === 'newD') { var pj = G('exb_projects')[0] || {}; st.edDoc = { id: '', type: 'contrat', role: 'client', pid: pj.id || '', titre: '', texte: '', v: 1 }; st.msg = ''; return render(); }
  if (a === 'dCancel') { st.edDoc = null; return render(); }
  if (a === 'dEd') { var dd = docs().find(function (x) { return x.id === id; }); if (dd && !dd.locked) { st.edDoc = JSON.parse(JSON.stringify(dd)); st.edDoc.role = (dd.roles || ['client'])[0]; render(); } return; }
  if (a === 'dModel') { var e = st.edDoc, pr = projOf(e.pid), cl = clientOf(pr.client); if (e.texte && !confirm('Remplacer le texte actuel par le modèle ?')) return; e.texte = model(e.type, { entreprise: ident().name, client: e.role === 'client' ? (pr.client || cl.full_name) : '', projet: pr.name, lieu: pr.location }); if (!e.titre) e.titre = (TYPES.find(function (t) { return t[0] === e.type; }) || [0, ''])[1] + (pr.name ? ' — ' + pr.name : ''); return render(); }
  if (a === 'dSave') { var x = st.edDoc; if (!x.titre.trim() || x.texte.trim().length < 20) { st.msg = 'Titre et texte (20 caractères minimum) obligatoires.'; return render(); } var hh = await sha(x.titre.trim() + '\n' + x.texte), D = docs(), rec = x.id ? D.find(function (y) { return y.id === x.id; }) : null;
    if (rec && rec.locked) { st.msg = 'Document verrouillé : créez une nouvelle version.'; return render(); }
    var n = Object.assign(rec || { id: uid('DOC'), sig: {}, date: today(), v: x.v || 1, locked: false }, { type: x.type, pid: x.pid, titre: x.titre.trim(), texte: x.texte, roles: [x.role], hash: hh }); if (!rec) D.unshift(n); Pu('exb_esign', D); st.edDoc = null; return render(); }
  if (a === 'dDel') { if (!confirm('Supprimer ce brouillon ?')) return; Pu('exb_esign', docs().filter(function (x) { return x.id !== id; })); return render(); }
  if (a === 'dVer') { var s0 = docs().find(function (x) { return x.id === id; }); if (!s0) return; st.edDoc = { id: '', type: s0.type, role: (s0.roles || ['client'])[0], pid: s0.pid, titre: s0.titre.replace(/ \(version \d+\)$/, ''), texte: s0.texte, v: (s0.v || 1) + 1 }; st.tab = 's'; return render(); }
  if (a === 'dSign') return signModal(id);
  if (a === 'useVisa') { try { var vs = await w.EXBId.visa(); if (vs) { PAD.visa = vs; $('ptVisi').innerHTML = '<span class="pt-ok">✔ Signature et cachet enregistrés utilisés.</span><br><img src="' + vs + '" style="height:60px;background:#fff">'; } } catch (e) {} return; }
  if (a === 'signGo') { var nom = ($('ptSn').value || '').trim(), fo = ($('ptSf').value || '').trim(), er = $('ptSe'); if (nom.length < 3) { er.textContent = 'Saisissez le nom du signataire.'; return; } if (!PAD || (!PAD.any && !PAD.visa)) { er.textContent = 'Tracez la signature (ou utilisez celle enregistrée).'; return; }
    var D2 = docs(), t = D2.find(function (y) { return y.id === id; }); t.sig = t.sig || {}; t.sig.entreprise = { nom: nom, fonction: fo, image: PAD.visa || PAD.png(), at: new Date().toISOString(), hash: t.hash }; Pu('exb_esign', D2); var m2 = $('ptModal'); if (m2) m2.remove(); say('Document signé par l’entreprise.'); return render(); }
  if (a === 'dPrint') return printDoc(id);
  /* retours */
  if (a === 'pull') return pullRet(false);
  if (a === 'dec') { try { await rpc('portail_decider', { p_id: id, p_statut: el.dataset.s, p_reponse: '' }); await pullRet(true); } catch (e) { say('Échec : ' + (e.message || e), 'error'); } return; }
  if (a === 'rep') { var inp = d.querySelector('[data-rep="' + id + '"]'), tx = inp && inp.value.trim(); if (!tx) return; try { await rpc('portail_repondre', { p_token: id, p_texte: tx }); await pullRet(true); } catch (e) { say('Échec : ' + (e.message || e), 'error'); } return; }
  /* relances */
  if (a === 'analyze') { var k = analyze(); say(k ? k + ' relance(s) préparée(s).' : 'Rien de nouveau à relancer.', k ? 'success' : 'info'); return render(); }
  if (a === 'send') { var qq = queue().find(function (x) { return x.id === id; }); if (qq) openChan(qq, el.dataset.how); return; }
  if (a === 'qDone' || a === 'qIgn') { var Q = queue(), qi = Q.findIndex(function (x) { return x.id === id; }); if (qi >= 0) { Q[qi].status = a === 'qDone' ? 'envoye' : 'ignore'; Pu('exb_msg_queue', Q); } return render(); }
  if (a === 'cfgSave') { var c2 = cfg(); d.querySelectorAll('[data-rule]').forEach(function (i) { c2.on[i.dataset.rule] = i.checked; }); d.querySelectorAll('[data-rn]').forEach(function (i) { c2[i.dataset.rn] = Math.max(1, Number(i.value) || 1); }); d.querySelectorAll('[data-tpl]').forEach(function (i) { c2.tpl[i.dataset.tpl] = i.value; }); saveCfg(c2); say('Règles enregistrées.'); return render(); }
}

/* ---------- montage ---------- */
var mounted = false, tries = 0;
function mount() {
  if (mounted) return; var host = $('clients'), b = $('bclients'); if (!host || !b) { if (++tries > 40) mounted = true; return; }
  if (!$('portails')) {
    host.insertAdjacentHTML('afterend', '<section id="portails" class="no-print" style="display:none"></section>'); b.insertAdjacentHTML('afterend', ' <button id="bportails" onclick="show(\'portails\')">🔗 Portails & signatures</button>');
    var el = $('portails'); el.addEventListener('click', function (e) { var t = e.target.closest('[data-act]'); if (t) onAct(t.dataset.act, t.dataset.id, t); });
    el.addEventListener('change', function (e) { setField(e.target); }); el.addEventListener('input', function (e) { var t = e.target; if (t.matches('textarea,input[type=text],input:not([type]),input[type=number]') && (t.dataset.f || t.dataset.o || t.dataset.d) && t.dataset.f !== 'kind') { if (t.dataset.f === 'pid') return; setField(t); } });
    d.addEventListener('click', function (e) { var t = e.target.closest('#ptModal [data-act]'); if (t) onAct(t.dataset.act, t.dataset.id, t); });
    var os = w.show; w.show = function (x) { var r = os.apply(this, arguments); var s = $('portails'); if (s) s.style.display = x === 'portails' ? '' : 'none'; if (x === 'portails') { analyze(); render(); if (isIn() && Date.now() - st.retAt > 120000) pullRet(true); } return r; };
  }
  mounted = true;
}
setInterval(mount, 1500); setTimeout(mount, 800); setInterval(function () { try { analyze(); } catch (e) {} }, 6 * 3600 * 1000);
w.EXB_PORTAILS = { version: 'V99zy', pull: pullRet, analyze: analyze, model: model, snapshot: snapshot, linkOf: linkOf };
})(window, document);
