# Liste des modules par division — V202

Division « Ingénierie et construction » renommée **Ingénierie et architecture**. Plus aucun écran de Direction & pilotage dans les autres divisions.


## 🧭 Direction & pilotage — 22 écrans


**🏢 Entreprise**

- Import inscriptions
- QCM logiciels
- BI Direction
- Workflow
- Direction
- Enterprise 360°
- Communication
- Site vitrine
- Supervision
- Intelligence BTP
- Pilotage direction
- Droits d’action
- Pièces écrites
- Permis & autorisations
- Maintenance / Facility

**📊 Rapports**

- Rapports

**⚙️ Paramètres**

- Logo Excellencia Building
- Logo RDC
- Affiches
- Administration
- Administration avancée
- Paramètres

## 🏗️ Ingénierie et architecture — 57 écrans


**📐 Architecture**

- Bureau d'études
- Plan de maison
- Plan PDF → éditeur
- Mise en page des plans
- Études techniques
- Plans / PDF
- Feuilles de plans
- Plans & Structure
- Architecture & diagnostic
- Pièces d’architecture
- Phases architecture
- Cartouche des plans
- Plans & fichiers CAO
- Priorité 2 — CDE/BIM/EVM

**🧮 Ingénierie & Structure**

- Métré & devis
- Prédimensionnement
- Bâtiment
- Poutre continue
- Poteau
- Dalle / plancher
- Semelle isolée
- Escalier
- Dosage béton
- Mortier
- Volumes
- Coffrage
- Ferraillage
- Moment maximal
- Coûts
- Agglos
- Vent
- Séisme
- Portique 2D (analyse EF)
- Station d'analyse (Robot)
- Combinaisons d'actions
- Pieux
- Semelle filante
- Radier général
- Mur de soutènement
- Maçonnerie porteuse
- Poutre acier
- Poteau acier
- Poutre bois
- Poteau bois
- Devis DQE
- Devis automatique

**🏗️ Projets & Chantiers**

- Projets & chantiers
- Chantiers & finances
- Terrain & achats
- Planning & budget
- Contrôles & sécurité
- Pilotage projets
- Tâches terrain
- Projet 360° — V67
- Documents de chantier
- Chantier hors ligne
- Réception de chantier

## 💼 Gestion & finances — 13 écrans


**🏢 Entreprise**

- Portails & signatures
- Personnel & RH

**👥 Clients & CRM**

- Clients
- CRM : pipeline, relances, réclamations

**💰 Finance**

- Finances
- Décomptes
- Comptabilité
- Budget & pilotage
- Compta : avoirs, échéances, journal
- Finance USD / FC
- Paie & RH

**🛒 Achats & Stocks**

- Stock & matériaux
- Stock : dépôts, inventaires, comparatifs

## 🎓 Formation & académie — 26 écrans


**📚 Formations classiques — Inscriptions, participants, formations, planning, présences, évaluations**

- Inscriptions
- Reçus de paiement
- Participants
- Cartes matricules
- Formations
- Formateurs
- Planning
- Présences
- TP / TD
- Évaluations
- Fiche de cotation
- Portail apprenant

**🎯 Parcours TFL — Travaux de fin de licence : sujets, candidatures, banque, bibliothèque, contributions**

- TFL
- Dossiers & candidatures
- Tableau de bord TFL
- Sujets
- Bibliothèque
- Encadreurs
- Propositions d’encadreurs
- Frais TFL
- Portails étudiant et encadreur
- Liens à envoyer
- Plans
- Signatures

**📜 Certificats — Certificats, statuts (valide, suspendu, révoqué), impression groupée**

- Certificats
- Impression groupée

## 🖥️ Infrastructure numérique — 10 écrans


**🏢 Entreprise**

- Documents
- Archives
- Scanner
- Données & installation
- Continuité
- Journal d’audit

**📊 Rapports**

- Registre & sauvegarde
- Sécurité & sauvegardes

**⚙️ Paramètres**

- Synchronisation
- Centre V51 — Super Admin


Total affiché : 128 tuiles (les tuiles Parcours TFL sont des accès directs aux vues du module TFL).