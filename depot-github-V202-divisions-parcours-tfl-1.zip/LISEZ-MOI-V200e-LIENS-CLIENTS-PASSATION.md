# V200e — Liens à envoyer aux clients + passation vers le module Clients

## Ce que ça change
- **Module Clients › 🔗 Liens à envoyer aux clients** (comme pour les apprenants) : un seul endroit, avec pour chaque lien 📋 Copier et 💬 WhatsApp / Partager :
  - Demande de projet (le client choisit le type) : `demande.html`
  - Demande Construction / Architecture / Métré & Devis / Rénovation : `demande.html?type=…`
  - Espace client (connexion) : `espace-client.html`
  - Fiche d'identité client : `client.html`
- **Passation** : la boîte « Demandes en ligne — BTP & Architecture » s'affiche aussi en bas du module **Clients** (en plus de Projets). Chemin : le client envoie sa demande → elle arrive dans Clients → **⬇ Importer** crée sa fiche client → la fiche est ensuite choisie dans Projets, Chantiers, devis, factures, paiements, etc. ; **✅ Approuver** propose de créer le chantier.
- Le bouton « 📋 Copier le lien du formulaire » de la boîte BTP copie désormais `demande.html` (et non plus l'ancien `btp.html`).
- À l'import, le matricule de l'espace client (CLI-…) est noté dans la fiche client.
- Les liens utilisent l'adresse publique du site (EXB_PUBLIC_URL / Netlify), y compris dans l'application Windows / Android.

## Fichiers
Modifiés : `site/index.html`, `site/exb-liens-profils.js`, `site/sw.js` (cache renouvelé), `site/tools/check.js`, `site/tools/e2e-liens.py`.
Nouveau : `site/tools/e2e-liens-clients.py`.

## À faire de votre côté
Redéployer / déposer le ZIP, fermer complètement l'application une fois (cache). **Aucun nouveau SQL.**

## Vérifié ici
`node tools/check.js` : 670 contrôles, 0 échec ; `e2e-liens-clients` (7 liens, boîte BTP dans Clients et Projets, copie), `e2e-liens`, `e2e-demande`, `e2e-accueil-client` : tout passe.
**Non testé** : réception réelle d'une demande depuis votre Supabase, ni un vrai téléphone.

## Limite connue
Une demande déjà importée reste visible dans l'historique de la boîte BTP ; la fiche client n'est pas créée deux fois (rapprochement par téléphone ou e-mail).
