# V202 — Divisions sans écrans « Direction & pilotage » + Parcours TFL à part

Base : V201. **Aucun SQL, aucune donnée modifiée** : seul l'affichage du menu change.

## 1. Plus d'écran de « Direction & pilotage » dans les autres divisions
Avant, six écrans de la catégorie Entreprise (Direction & pilotage) étaient reclassés ailleurs et apparaissaient dans :
- **Ingénierie et architecture** (sous un groupe « Entreprise ») : Intelligence BTP, Pièces écrites, Permis & autorisations, Maintenance / Facility ;
- **Formation & académie** (dans « Formations classiques ») : Import inscriptions, QCM logiciels.

Ils restent désormais dans **Direction & pilotage** (catégorie Entreprise). Chaque division n'affiche plus que ses propres catégories :
Ingénierie et architecture = Architecture, Ingénierie & Structure, Projets & Chantiers ; Formation & académie = Formation (+ espaces TFL et Certificats).
La fuite existait aussi en parcours « Construction » / « Formation » : corrigée (test ajouté).

## 2. Parcours TFL : son propre côté
- **Menu latéral** : nouvelle entrée « 🎯 Parcours TFL » sous Formation & académie.
- **Page dédiée** « Parcours TFL » : le module TFL complet + 11 accès directs à ses vues (Dossiers & candidatures, Tableau de bord, Sujets, Bibliothèque, Encadreurs, Propositions d'encadreurs, Frais TFL, Portails, Liens à envoyer, Plans, Signatures).
- Le même espace « Parcours TFL » de la page Formation & académie affiche ces accès ; la tuile « TFL » reste aussi dans la catégorie Formation.
- Fil d'Ariane : « ← Parcours TFL » ; boutons Retour / Avant pris en charge.

## Fichiers
Modifiés : `site/exb-v99r-shell.js`, `site/sw.js` (cache v202), `site/tools/check.js` (+3 contrôles), `site/tools/e2e-divisions.py` (le menu compte maintenant l'entrée TFL à part).
Ajouté : `site/tools/e2e-tfl-espace.py`.

## Vérifié
`node site/tools/check.js` : 681 / 681. Navigateur : e2e-tfl-espace (nouveau) 0 échec ; e2e-divisions, e2e-formation-espaces, e2e-parcours OK ; test-parcours.js 27 / 27.

## Non modifié (à confirmer si besoin)
« Personnel & RH » et « Portails & signatures » (catégorie Entreprise) restent dans Gestion & finances ; Documents, Archives, Scanner, etc. restent dans Infrastructure numérique (règle V185c).

## À faire de votre côté
Redéployer le ZIP, fermer complètement l'application une fois (cache v202).
