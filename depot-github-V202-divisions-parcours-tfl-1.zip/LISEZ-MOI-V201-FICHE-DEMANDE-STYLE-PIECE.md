# V201 — La fiche de demande du client prend la mise en page des pièces écrites

Base : V200f. **Aucun SQL.**

## Ce que ça change
La fiche PDF remise au client à la fin de sa demande (formulaire du portail client `demande.html` et formulaire `btp.html`) reprend la mise en page du procès-verbal / des lettres :
- **En-tête** : logo, nom, slogan et coordonnées à droite, double filet or / bleu (plus de bandeau bleu, plus de page de garde).
- **Encadré de référence** (identifiant client ou référence BTP, date, type de demande, lieu), puis **titre centré entre deux filets or**.
- **Tableau des informations** bordé, libellés sur fond bleu clair ; encadré « À retenir » conservé ; photos conservées.
- **Bloc « Directeur Général »** à droite, en bas de la dernière page : cachet + signature, nom du DG et nom de l'entreprise. Si le client a signé (btp.html), sa signature figure à gauche.
- **Pied de page sur chaque page** : QR « Vérifier ce document » + code, coordonnées, référence · date, numéro de page.
- Pages suivantes : en-tête réduit (logo + nom + titre).

## Fichiers
Modifiés : `site/exb-pdf.js` (nouveau style `style:'piece'`, les autres PDF sont inchangés), `site/exb-demande.js` (visa activé, style pièce), `site/exb-btp.js`, `site/demande.html` (charge maintenant identité, visa, QR et vérification), `site/btp.html` (charge l'identité), `site/sw.js` (cache renouvelé), `site/tools/check.js` (+4 contrôles).

## À faire de votre côté
1. Redéployer le ZIP (Netlify / GitHub), fermer complètement l'application une fois (cache).
2. **Cachet et signature** : sur l'appareil du client ils viennent du visa public. Administrateur : Paramètres › Logo Excellencia Building (signature + cachet actifs), puis Site vitrine › « Publier sur le site ». Sans cette publication, le bloc « Directeur Général » sort avec un espace vide, sans cachet ni signature.

## Vérifié ici
`node tools/check.js` : 678 contrôles, 0 échec. Rendu réel dans Chrome headless (fiche courte avec visa de test, fiche longue sur 2 pages, fiche sans visa) : en-tête, encadré, tableau, bloc signature et QR sur chaque page conformes ; `demande.html` et `btp.html` se chargent sans erreur JavaScript.
**Non testé** : votre vrai cachet / signature publiés, l'envoi réel vers votre Supabase, un téléphone, la lecture du QR par le vérificateur.

## Limites connues
- Le site web affiché dans l'en-tête est celui de « Identité de l'entreprise » s'il est connu de l'appareil, sinon l'adresse du site où le client a rempli sa demande.
- Le slogan et les coordonnées viennent de l'identité publiée (`brand.json`) ; sur l'appareil d'un client ils peuvent différer légèrement de ceux de vos pièces écrites tant que l'identité n'est pas republiée.
- Les autres fiches de formulaires (inscription, formateur, personnel, client, TP/TD) gardent leur mise en page actuelle (bandeau bleu + page de garde) ; le style est disponible pour elles par `style:'piece'`.
