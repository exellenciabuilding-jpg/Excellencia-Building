# V200f — Le client arrive directement sur le nouveau portail, sans code de suivi

## Ce que ça change
- Après sa demande, quand le client se connecte (`espace-client.html` → `portail.html`), il arrive sur le **nouveau tableau de bord client** (menu bleu/doré : Accueil, Mon Projet, Plans & Documents, Documents à signer, Factures & Paiements, Suivi de chantier, Messages, Mon Profil, Aide & Assistance). L'ancien écran « Mon dossier » (liste simple) est supprimé.
- **Avant le lancement du projet** : bandeau « Votre demande est en cours d'étude », avancement par étapes (Demande reçue 100 %, Étude par notre équipe, Devis et contrat, Lancement des travaux), activité « Demande envoyée », rubrique **Mon Projet › Mes demandes** (détail de chaque demande, bouton « Nouvelle demande »). Messages = Appeler / WhatsApp / E-mail de l'entreprise.
- **Après la publication du suivi par l'entreprise** : même tableau de bord avec les vraies données (plans, devis, factures, paiements, photos, messages), automatiquement — rien à refaire.
- **Plus de code / numéro de suivi** : le compte (identifiant + mot de passe choisi) suffit. L'identifiant du compte est affiché en haut à droite ; sur l'écran de confirmation et la fiche PDF, « Numéro de suivi » / « numéro client » deviennent « Identifiant client » (« Identifiant de votre espace »). Le numéro BTP-… n'est plus affiché au client.

## Fichiers
Modifiés : `site/portail.html`, `site/exb-demande.js`, `site/demande.html`, `site/sw.js` (cache renouvelé), `site/tools/check.js`, `site/tools/e2e-demande.py`.

## À faire de votre côté
Redéployer / déposer le ZIP, fermer complètement l'application une fois (cache). **Aucun nouveau SQL.**

## Vérifié ici
`node tools/check.js` : 674 contrôles, 0 échec ; `e2e-demande` (connexion → nouveau tableau de bord, aucun code de suivi, Mon projet, Nouvelle demande, messagerie), `e2e-accueil-client`, `e2e-espace-client`, `e2e-liens-clients` : tout passe. Rendu contrôlé sur capture (ordinateur).
**Non testé** : un vrai compte sur votre Supabase, un vrai téléphone.

## Limite connue
La connexion se fait toujours avec l'identifiant client (CLI-…) + mot de passe : connexion par téléphone ou e-mail = nouvelle fonction SQL (non faite ici).
